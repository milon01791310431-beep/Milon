package com.surokar.app;

import ai.onnxruntime.OnnxTensor;
import ai.onnxruntime.OrtEnvironment;
import ai.onnxruntime.OrtSession;
import ai.onnxruntime.TensorInfo;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.Collections;

/** Runs the MDX-Net model with ONNX Runtime (native CPU, multi-threaded). Everything stays on the phone. */
final class OrtInfer implements MdxSeparator.Infer, AutoCloseable {
    private final OrtEnvironment env;
    private final OrtSession session;
    private final String inputName;
    private final long[] shape;
    private final FloatBuffer inBuf;
    final int dimT;

    OrtInfer(String modelPath, int threads) throws Exception {
        env = OrtEnvironment.getEnvironment();
        OrtSession s;
        OrtSession.SessionOptions o = new OrtSession.SessionOptions();
        try {
            o.setIntraOpNumThreads(threads);
            o.setInterOpNumThreads(1);
            o.setMemoryPatternOptimization(false);   // keeps peak memory low on phones
            o.setCPUArenaAllocator(false);
            s = env.createSession(modelPath, o);
        } finally {
            o.close();
        }
        session = s;
        inputName = session.getInputNames().iterator().next();
        long[] sh = ((TensorInfo) session.getInputInfo().get(inputName).getInfo()).getShape();
        dimT = (int) sh[3];
        shape = new long[]{1, 4, MdxSeparator.DIMF, dimT};
        inBuf = ByteBuffer.allocateDirect(4 * MdxSeparator.DIMF * dimT * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
    }

    @Override
    public void run(float[] in, float[] out) throws Exception {
        inBuf.clear();
        inBuf.put(in);
        inBuf.rewind();
        try (OnnxTensor t = OnnxTensor.createTensor(env, inBuf, shape);
             OrtSession.Result r = session.run(Collections.singletonMap(inputName, t))) {
            OnnxTensor o = (OnnxTensor) r.get(0);
            o.getFloatBuffer().get(out);
        }
    }

    @Override
    public void close() throws Exception {
        session.close();
    }
}
