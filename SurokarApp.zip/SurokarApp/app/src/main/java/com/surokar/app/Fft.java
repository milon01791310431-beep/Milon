package com.surokar.app;

/**
 * Complex FFT for any size whose prime factors are 2, 3 and 5 (e.g. 7680 = 2^9 * 3 * 5).
 * Stockham auto-sort, mixed radix. Not thread-safe (uses internal scratch buffers).
 */
final class Fft {
    private final int n;
    private final int[] factors;
    private final float[] cosN, sinN;       // W_N^k = cos - i sin
    private final float[] yr, yi;

    Fft(int n) {
        this.n = n;
        int[] f = new int[32];
        int cnt = 0, rest = n;
        while (rest % 4 == 0) { f[cnt++] = 4; rest /= 4; }
        while (rest % 2 == 0) { f[cnt++] = 2; rest /= 2; }
        while (rest % 3 == 0) { f[cnt++] = 3; rest /= 3; }
        while (rest % 5 == 0) { f[cnt++] = 5; rest /= 5; }
        if (rest != 1) throw new IllegalArgumentException("FFT size must be 2^a*3^b*5^c: " + n);
        factors = java.util.Arrays.copyOf(f, cnt);
        cosN = new float[n]; sinN = new float[n];
        for (int k = 0; k < n; k++) {
            double a = 2.0 * Math.PI * k / n;
            cosN[k] = (float) Math.cos(a); sinN[k] = (float) Math.sin(a);
        }
        yr = new float[n]; yi = new float[n];
    }

    /** In-place transform. inverse=true gives the UNSCALED inverse (caller divides by n). */
    void transform(float[] xr, float[] xi, boolean inverse) {
        if (inverse) for (int i = 0; i < n; i++) xi[i] = -xi[i];
        float[] ar = xr, ai = xi, br = yr, bi = yi;
        int len = n, s = 1;
        for (int r : factors) {
            final int m = len / r, tw = n / len;
            switch (r) {
                case 4: stage4(ar, ai, br, bi, m, s, tw); break;
                case 2: stage2(ar, ai, br, bi, m, s, tw); break;
                case 3: stageGeneric(ar, ai, br, bi, m, s, tw, 3); break;
                default: stageGeneric(ar, ai, br, bi, m, s, tw, 5); break;
            }
            float[] t = ar; ar = br; br = t; t = ai; ai = bi; bi = t;
            len = m; s *= r;
        }
        if (ar != xr) { System.arraycopy(ar, 0, xr, 0, n); System.arraycopy(ai, 0, xi, 0, n); }
        if (inverse) for (int i = 0; i < n; i++) xi[i] = -xi[i];
    }

    private void stage2(float[] ar, float[] ai, float[] br, float[] bi, int m, int s, int tw) {
        for (int p = 0; p < m; p++) {
            final int k = tw * p; final float wr = cosN[k], wi = -sinN[k];
            for (int q = 0; q < s; q++) {
                int i0 = q + s * p, i1 = i0 + s * m, o0 = q + s * 2 * p, o1 = o0 + s;
                float a0r = ar[i0], a0i = ai[i0], a1r = ar[i1], a1i = ai[i1];
                br[o0] = a0r + a1r; bi[o0] = a0i + a1i;
                float dr = a0r - a1r, di = a0i - a1i;
                br[o1] = dr * wr - di * wi; bi[o1] = dr * wi + di * wr;
            }
        }
    }

    private void stage4(float[] ar, float[] ai, float[] br, float[] bi, int m, int s, int tw) {
        for (int p = 0; p < m; p++) {
            final int k1 = tw * p, k2 = (2 * k1) % n, k3 = (3 * k1) % n;
            final float w1r = cosN[k1], w1i = -sinN[k1], w2r = cosN[k2], w2i = -sinN[k2], w3r = cosN[k3], w3i = -sinN[k3];
            for (int q = 0; q < s; q++) {
                int i0 = q + s * p, i1 = i0 + s * m, i2 = i1 + s * m, i3 = i2 + s * m;
                int o0 = q + s * 4 * p, o1 = o0 + s, o2 = o1 + s, o3 = o2 + s;
                float t0r = ar[i0] + ar[i2], t0i = ai[i0] + ai[i2];
                float t1r = ar[i0] - ar[i2], t1i = ai[i0] - ai[i2];
                float t2r = ar[i1] + ar[i3], t2i = ai[i1] + ai[i3];
                float t3r = ar[i1] - ar[i3], t3i = ai[i1] - ai[i3];
                br[o0] = t0r + t2r; bi[o0] = t0i + t2i;
                float y1r = t1r + t3i, y1i = t1i - t3r;      // t1 + (-i) t3
                float y2r = t0r - t2r, y2i = t0i - t2i;
                float y3r = t1r - t3i, y3i = t1i + t3r;      // t1 + i t3
                br[o1] = y1r * w1r - y1i * w1i; bi[o1] = y1r * w1i + y1i * w1r;
                br[o2] = y2r * w2r - y2i * w2i; bi[o2] = y2r * w2i + y2i * w2r;
                br[o3] = y3r * w3r - y3i * w3i; bi[o3] = y3r * w3i + y3i * w3r;
            }
        }
    }

    private void stageGeneric(float[] ar, float[] ai, float[] br, float[] bi, int m, int s, int tw, int r) {
        final float[] cr = new float[r], ci = new float[r];
        for (int k = 0; k < r; k++) { double a = 2.0 * Math.PI * k / r; cr[k] = (float) Math.cos(a); ci[k] = (float) -Math.sin(a); }
        final float[] xr = new float[r], xi = new float[r];
        for (int p = 0; p < m; p++) {
            for (int q = 0; q < s; q++) {
                for (int t = 0; t < r; t++) { int i = q + s * (p + t * m); xr[t] = ar[i]; xi[t] = ai[i]; }
                for (int u = 0; u < r; u++) {
                    float sr = 0f, si = 0f;
                    for (int t = 0; t < r; t++) {
                        int e = (t * u) % r;
                        sr += xr[t] * cr[e] - xi[t] * ci[e];
                        si += xr[t] * ci[e] + xi[t] * cr[e];
                    }
                    int o = q + s * (r * p + u);
                    if (u == 0) { br[o] = sr; bi[o] = si; }
                    else {
                        int k = (tw * p * u) % n; float wr = cosN[k], wi = -sinN[k];
                        br[o] = sr * wr - si * wi; bi[o] = sr * wi + si * wr;
                    }
                }
            }
        }
    }
}
