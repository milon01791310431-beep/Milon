package com.surokar.app;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.RandomAccessFile;

/**
 * Neural vocal separation with an MDX-Net model (UVR-MDX-NET-Voc_FT).
 * Pure Java signal processing (STFT / overlap-add / iSTFT); the network itself runs through {@link Infer}
 * (ONNX Runtime on the phone, nothing leaves the device).
 *
 * Input / output files: 44.1 kHz, 16-bit little-endian, interleaved stereo PCM (same format as Separator).
 */
public final class MdxSeparator {

    /** Runs the network. {@code in} and {@code out} are [4][DIMF][T] floats: L.re, L.im, R.re, R.im. */
    public interface Infer { void run(float[] in, float[] out) throws Exception; }

    public interface Progress {
        void update(float fraction);
        boolean cancelled();
    }

    public static final int NFFT = 7680, HOP = 1024, DIMF = 3072;

    private final Infer infer;
    private final int T, chunk, trim, gen;
    private final Fft fft = new Fft(NFFT);
    private final float[] win = new float[NFFT];
    private final float[] invEnv;           // 1 / sum(win^2) over the useful part of one chunk
    private final float[] in, out;

    public MdxSeparator(Infer infer, int dimT) {
        this.infer = infer;
        this.T = dimT;
        this.chunk = HOP * (T - 1);
        this.trim = NFFT / 2;
        this.gen = chunk - NFFT;           // samples kept per chunk (edges are discarded)
        for (int i = 0; i < NFFT; i++) win[i] = (float) (0.5 - 0.5 * Math.cos(2.0 * Math.PI * i / NFFT));
        int total = HOP * (T - 1) + NFFT;
        double[] e = new double[total];
        for (int t = 0; t < T; t++) for (int i = 0; i < NFFT; i++) e[t * HOP + i] += (double) win[i] * win[i];
        invEnv = new float[chunk];
        for (int i = 0; i < chunk; i++) invEnv[i] = (float) (1.0 / Math.max(e[trim + i], 1e-11));
        in = new float[4 * DIMF * T];
        out = new float[4 * DIMF * T];
    }

    /** Number of network runs needed for n samples. */
    public int segments(int n, double overlap) {
        int step = stepFor(overlap);
        return n <= gen ? 1 : (int) Math.ceil((n - gen) / (double) step) + 1;
    }

    private int stepFor(double overlap) {
        double ov = Math.max(0, Math.min(0.5, overlap));
        return Math.max(1, gen - (int) Math.round(gen * ov));
    }

    /**
     * @param overlap 0 = fastest (UVR default), up to 0.5 = smoother joins between chunks but proportionally slower.
     */
    public void separate(File inPcm, File outPcm, double overlap, Progress prog) throws Exception {
        final int n = (int) (inPcm.length() / 4);
        if (n < 1) throw new IOException("empty input");
        final int step = stepFor(overlap), R = gen - step;
        final int nSeg = segments(n, overlap);

        final float[][] seg = new float[2][chunk];
        final float[][] acc = new float[2][gen];
        final float[] zr = new float[NFFT], zi = new float[NFFT];
        final int olaLen = HOP * (T - 1) + NFFT;
        final float[][] ola = new float[2][olaLen];
        final byte[] rbuf = new byte[chunk * 4];
        final byte[] obuf = new byte[gen * 4];

        try (RandomAccessFile raf = new RandomAccessFile(inPcm, "r");
             OutputStream os = new BufferedOutputStream(new FileOutputStream(outPcm), 1 << 16)) {
            for (int s = 0; s < nSeg; s++) {
                if (prog.cancelled()) throw new IOException("cancelled");
                final long base = (long) s * step;
                final long a = base - trim;                       // first original sample of this chunk

                // ---- read chunk (zero outside the file)
                java.util.Arrays.fill(seg[0], 0f); java.util.Arrays.fill(seg[1], 0f);
                long from = Math.max(a, 0), to = Math.min(a + chunk, n);
                if (to > from) {
                    int cnt = (int) (to - from), off = (int) (from - a);
                    raf.seek(from * 4); raf.readFully(rbuf, 0, cnt * 4);
                    for (int i = 0; i < cnt; i++) {
                        int p = i * 4;
                        seg[0][off + i] = (short) ((rbuf[p] & 0xff) | (rbuf[p + 1] << 8)) * (1f / 32768f);
                        seg[1][off + i] = (short) ((rbuf[p + 2] & 0xff) | (rbuf[p + 3] << 8)) * (1f / 32768f);
                    }
                }

                stft(seg, zr, zi);
                prog.update((s + 0.04f) / nSeg);
                infer.run(in, out);
                if (prog.cancelled()) throw new IOException("cancelled");
                prog.update((s + 0.90f) / nSeg);
                istft(ola, zr, zi);

                // ---- weighted accumulate of the useful part [trim, trim+gen)
                final boolean first = s == 0, last = s == nSeg - 1;
                for (int c = 0; c < 2; c++) {
                    float[] o = ola[c], ac = acc[c];
                    for (int i = 0; i < gen; i++) {
                        float w = 1f;
                        if (R > 0) {
                            if (!first && i < R) w = i / (float) R;
                            else if (!last && i >= gen - R) w = (gen - i) / (float) R;
                        }
                        ac[i] += o[2 * trim + i] * invEnv[trim + i] * w;   // ola index = chunk position + NFFT/2
                    }
                }

                // ---- finalize what later chunks will not touch
                int count = last ? (int) (n - base) : step;
                for (int i = 0; i < count; i++) {
                    int l = Math.round(Math.max(-1f, Math.min(1f, acc[0][i])) * 32767f);
                    int r = Math.round(Math.max(-1f, Math.min(1f, acc[1][i])) * 32767f);
                    int p = i * 4;
                    obuf[p] = (byte) l; obuf[p + 1] = (byte) (l >> 8); obuf[p + 2] = (byte) r; obuf[p + 3] = (byte) (r >> 8);
                }
                os.write(obuf, 0, count * 4);
                if (!last) {
                    for (int c = 0; c < 2; c++) {
                        System.arraycopy(acc[c], step, acc[c], 0, R);
                        java.util.Arrays.fill(acc[c], R, gen, 0f);
                    }
                }
                prog.update((s + 1f) / nSeg);
            }
        }
        prog.update(1f);
    }

    // ------------------------------------------------------------------ STFT / iSTFT
    /** seg[2][chunk] -> in[4][DIMF][T]  (torch.stft: center=True, reflect pad, periodic Hann, hop 1024). */
    private void stft(float[][] seg, float[] zr, float[] zi) {
        final float[] L = seg[0], Rr = seg[1];
        for (int t = 0; t < T; t++) {
            final int start = t * HOP - trim;
            for (int i = 0; i < NFFT; i++) {
                int j = start + i;
                if (j < 0) j = -j; else if (j >= chunk) j = 2 * (chunk - 1) - j;
                float w = win[i];
                zr[i] = L[j] * w; zi[i] = Rr[j] * w;
            }
            fft.transform(zr, zi, false);
            for (int k = 0; k < DIMF; k++) {
                int k2 = (NFFT - k) % NFFT;
                float lr = (zr[k] + zr[k2]) * .5f, li = (zi[k] - zi[k2]) * .5f;
                float rr = (zi[k] + zi[k2]) * .5f, ri = -(zr[k] - zr[k2]) * .5f;
                in[(0 * DIMF + k) * T + t] = lr; in[(1 * DIMF + k) * T + t] = li;
                in[(2 * DIMF + k) * T + t] = rr; in[(3 * DIMF + k) * T + t] = ri;
            }
        }
    }

    /** out[4][DIMF][T] -> ola[2][...] (overlap-added, window-weighted, NOT yet divided by the envelope). */
    private void istft(float[][] ola, float[] zr, float[] zi) {
        java.util.Arrays.fill(ola[0], 0f); java.util.Arrays.fill(ola[1], 0f);
        final float inv = 1f / NFFT;
        for (int t = 0; t < T; t++) {
            java.util.Arrays.fill(zr, 0f); java.util.Arrays.fill(zi, 0f);
            for (int k = 0; k < DIMF; k++) {
                float lr = out[(0 * DIMF + k) * T + t], li = out[(1 * DIMF + k) * T + t];
                float rr = out[(2 * DIMF + k) * T + t], ri = out[(3 * DIMF + k) * T + t];
                if (k == 0) { zr[0] = lr; zi[0] = rr; }           // DC bin is real
                else {
                    zr[k] = lr - ri; zi[k] = li + rr;
                    zr[NFFT - k] = lr + ri; zi[NFFT - k] = rr - li;
                }
            }
            fft.transform(zr, zi, true);
            final int off = t * HOP;
            for (int i = 0; i < NFFT; i++) {
                float w = win[i] * inv;
                ola[0][off + i] += zr[i] * w;
                ola[1][off + i] += zi[i] * w;
            }
        }
    }
}
