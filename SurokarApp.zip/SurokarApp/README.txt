APK বানানোর নিয়ম
1. সব ফাইল (লুকানো .github ফোল্ডারসহ) GitHub রিপোতে আপলোড করো।
2. Actions ট্যাবে "Build Android APK" চলবে। শেষে রানের পাতার নিচে Artifacts থেকে APK নামাও।
3. Release APK (ঐচ্ছিক): Settings > Secrets and variables > Actions এ চারটি secret দাও:
   KEYSTORE_BASE64, KEYSTORE_PASSWORD, KEY_ALIAS, KEY_PASSWORD
   তারপর Actions > Run workflow থেকে release বেছে নাও, অথবা v1.0.0 নামে ট্যাগ করো (GitHub Release-এও APK উঠবে)।
   secret না থাকলে শুধু debug APK বানাবে, কোনো এরর দেবে না।
