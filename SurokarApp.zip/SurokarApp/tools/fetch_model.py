#!/usr/bin/env python3
"""Fetch the vocal-separation model used by the app and prepare it for bundling.

Model : UVR-MDX-NET-Voc_FT (MDX-Net, from the Ultimate Vocal Remover project's public model repo)
Source: https://github.com/TRvlvr/model_repo/releases/tag/all_public_uvr_models
Step 1: download (or --src a local copy) and verify the SHA-256 of the original file.
Step 2: patch the fixed time axis 256 -> 128 frames. The network is fully convolutional in time, so it
        keeps working, but one inference now needs half the memory (~0.65 GB instead of ~1.3 GB) and
        runs faster. (Measured on test mixes: -0.3 dB vs. the 256-frame version, recovered by overlap.)
Output: app/src/main/assets/models/Voc_FT_T128.onnx   (bundled into the APK; the app never goes online)

Run from the project root:  python3 tools/fetch_model.py [--src path/to/UVR-MDX-NET-Voc_FT.onnx]
"""
import hashlib, os, sys, urllib.request

URL = "https://github.com/TRvlvr/model_repo/releases/download/all_public_uvr_models/UVR-MDX-NET-Voc_FT.onnx"
SRC_SHA256 = "534b2070fcc7df514b13ef660dc8cbb328679c2374d04354a5c42bb14ecce111"
OUT = os.path.join("app", "src", "main", "assets", "models", "Voc_FT_T128.onnx")
# protobuf bytes of the [.., 3072, 256] pair of dimensions in the model's input / output shapes
OLD = b"\x0a\x03\x08\x80\x18\x0a\x03\x08\x80\x02"
NEW = b"\x0a\x03\x08\x80\x18\x0a\x03\x08\x80\x01"


def sha(b):
    return hashlib.sha256(b).hexdigest()


def main():
    if os.path.exists(OUT) and os.path.getsize(OUT) > 1_000_000:
        print("model already present:", OUT)
        return
    if "--src" in sys.argv:
        data = open(sys.argv[sys.argv.index("--src") + 1], "rb").read()
    else:
        print("downloading", URL)
        req = urllib.request.Request(URL, headers={"User-Agent": "surokar-build"})
        with urllib.request.urlopen(req, timeout=300) as r:
            data = r.read()
    if sha(data) != SRC_SHA256:
        sys.exit("SHA-256 mismatch for the downloaded model: " + sha(data))
    if data.count(OLD) != 2:
        sys.exit("unexpected model layout (expected 2 shape records, found %d)" % data.count(OLD))
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "wb") as f:
        f.write(data.replace(OLD, NEW))
    print("wrote", OUT, os.path.getsize(OUT), "bytes")


if __name__ == "__main__":
    main()
