package com.surokar.app;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.*;
import android.widget.Toast;
import java.io.OutputStream;

public class MainActivity extends Activity {
    WebView web;
    ValueCallback<Uri[]> cb;
    OutputStream os;
    boolean lastVid;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        web.addJavascriptInterface(new Bridge(), "Android");
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> c, FileChooserParams p) {
                if (cb != null) cb.onReceiveValue(null);
                cb = c;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                boolean img = false;
                if (p != null && p.getAcceptTypes() != null)
                    for (String t : p.getAcceptTypes()) if (t != null && t.startsWith("image")) img = true;
                i.setType(img ? "image/*" : "audio/*");
                startActivityForResult(Intent.createChooser(i, img ? "ছবি বেছে নাও" : "অডিও বেছে নাও"), 1);
                return true;
            }
        });
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("(window.surokarBack&&window.surokarBack())?'1':'0'", value -> {
            if (!"\"1\"".equals(value)) finish();
        });
    }

    @Override
    protected void onActivityResult(int r, int c, Intent d) {
        if (r == 1 && cb != null) {
            cb.onReceiveValue(c == RESULT_OK && d != null && d.getData() != null ? new Uri[]{d.getData()} : null);
            cb = null;
        }
    }

    class Bridge {
        @JavascriptInterface
        public void begin(String name) {
            try {
                boolean vid = name.endsWith(".mp4") || name.endsWith(".webm");
                lastVid = vid;
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                v.put(MediaStore.MediaColumns.MIME_TYPE,
                    name.endsWith(".mp4") ? "video/mp4" : name.endsWith(".webm") ? "video/webm"
                    : name.endsWith(".mp3") ? "audio/mpeg" : "audio/wav");
                v.put(MediaStore.MediaColumns.RELATIVE_PATH,
                    vid ? Environment.DIRECTORY_MOVIES + "/Surokar" : Environment.DIRECTORY_DOWNLOADS);
                Uri u = getContentResolver().insert(
                    vid ? MediaStore.Video.Media.EXTERNAL_CONTENT_URI : MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                os = getContentResolver().openOutputStream(u);
            } catch (Exception e) { e.printStackTrace(); }
        }

        @JavascriptInterface
        public void keepOn(final boolean on) {
            runOnUiThread(() -> web.setKeepScreenOn(on));
        }

        @JavascriptInterface
        public void chunk(String b64) {
            try { os.write(Base64.decode(b64, Base64.DEFAULT)); } catch (Exception e) { e.printStackTrace(); }
        }

        @JavascriptInterface
        public void end() {
            try { os.close(); } catch (Exception e) { e.printStackTrace(); }
            runOnUiThread(() -> Toast.makeText(MainActivity.this, lastVid ? "গ্যালারিতে সেভ হয়েছে (Movies/Surokar)" : "Downloads ফোল্ডারে সেভ হয়েছে", Toast.LENGTH_LONG).show());
        }

        @JavascriptInterface
        public String appVersion() {
            try { return getPackageManager().getPackageInfo(getPackageName(), 0).versionName; }
            catch (Exception e) { return "?"; }
        }
    }
}
