import numpy as np, scipy.io.wavfile as w, scipy.signal as sg
sr,x=w.read('ref.wav'); x=x.astype(np.float32)/32768
print(sr,len(x)/sr)
# band onset envelopes
def band(lo,hi):
    sos=sg.butter(4,[lo,hi],'band',fs=sr,output='sos'); return sg.sosfilt(sos,x)
hop=256
def env(y):
    e=np.abs(y); e=np.convolve(e,np.ones(hop)/hop,'same')[::hop]; 
    d=np.maximum(0,np.diff(e,prepend=e[0])); return e,d
bands={'kick':(40,120),'snare/clap':(1500,4000),'hat':(7000,10500)}
E={}
for k,(a,b) in bands.items(): E[k]=env(band(a,b))
d=E['kick'][1]
# BPM via autocorrelation of kick onset
fs=sr/hop
ac=np.correlate(d-d.mean(),d-d.mean(),'full')[len(d)-1:]
lags=np.arange(len(ac))/fs
for bpm in range(70,180):
    pass
cands=[(ac[int(60/b*fs)],b) for b in np.arange(70,180,0.5)]
cands.sort(reverse=True); print('bpm cands',cands[:6])
hop=128; fs=sr/hop
def env2(y):
    e=np.abs(y); e=np.convolve(e,np.ones(hop)/hop,'same')[::hop]
    return np.maximum(0,np.diff(e,prepend=e[0]))
K=env2(band(40,120)); S=env2(band(1500,4000)); H=env2(band(7000,10500)); L=env2(band(120,300))
def comb(d,bpm,ph):
    T=60/bpm*fs; n=len(d); idx=np.arange(ph*fs,n-1,T).astype(int); return d[idx].mean()
best=(0,0,0)
for bpm in np.arange(74,86,0.02):
    for ph in np.arange(0,60/bpm,0.01):
        s=comb(K,bpm,ph)
        if s>best[0]: best=(s,bpm,ph)
print('best',best)
_,bpm,ph=best
step=60/bpm/4
# fold into 16-step bar patterns, per 8-bar window to find the drop
nb=int((len(x)/sr-ph)/(step*16))
def fold(d,b0,b1):
    pat=np.zeros(16)
    for b in range(b0,b1):
        for s in range(16):
            t=ph+(b*16+s)*step
            i=int(t*fs); pat[s]+=d[max(0,i-2):i+3].max()
    return pat/(b1-b0)
tot=np.array([ (K[int((ph+b*16*step)*fs):int((ph+(b+1)*16*step)*fs)]).sum()+H[int((ph+b*16*step)*fs):int((ph+(b+1)*16*step)*fs)].sum() for b in range(nb)])
print('bars',nb); print(np.round(tot/tot.max(),2))
np.save('meta.npy',np.array([bpm,ph]))
for name,d in [('kick',K),('low',L),('snare',S),('hat',H)]:
    p=fold(d,nb//3,nb*2//3); p/= p.max()+1e-9
    print(name.ljust(6),' '.join('%d'%round(v*9) for v in p))
