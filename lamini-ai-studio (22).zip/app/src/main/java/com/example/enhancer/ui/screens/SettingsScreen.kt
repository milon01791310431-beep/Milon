package com.example.enhancer.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.RadioButtonChecked
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.enhancer.engine.DownloadStatus
import com.example.enhancer.model.EngineStatusInfo
import com.example.enhancer.model.EngineType
import com.example.enhancer.model.EnhancementConfig
import com.example.enhancer.model.EnhancementMode
import com.example.enhancer.model.ExportFormat
import com.example.enhancer.model.ModelSlotInfo
import com.example.enhancer.model.ModelSlotType
import com.example.enhancer.model.UpscaleFactor
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.BorderColor
import com.example.ui.theme.CardBackground
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.MainBackground
import com.example.ui.theme.MainText
import com.example.ui.theme.PrimaryGradient
import com.example.ui.theme.PrimaryPurple
import com.example.ui.theme.SecondaryBackground
import com.example.ui.theme.SecondaryText
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextMuted

@Composable
fun SettingsScreen(
  config: EnhancementConfig,
  exportFormat: ExportFormat,
  engineType: EngineType,
  engineStatusInfo: EngineStatusInfo?,
  modelSlots: Map<ModelSlotType, ModelSlotInfo>,
  importingSlotType: ModelSlotType?,
  importErrorMessage: String?,
  downloadStatusMap: Map<ModelSlotType, DownloadStatus> = emptyMap(),
  isMobileData: Boolean = false,
  historyCount: Int = 0,
  onSetUseAiModel: (Boolean) -> Unit = {},
  onImportModel: (Uri, ModelSlotType) -> Unit,
  onDownloadModel: (ModelSlotType) -> Unit = {},
  onCancelDownloadModel: (ModelSlotType) -> Unit = {},
  onDeleteModel: (ModelSlotType) -> Unit,
  onDismissImportError: () -> Unit = {},
  onSetEnhancementMode: (EnhancementMode) -> Unit = {},
  onSetUpscaleFactor: (UpscaleFactor) -> Unit = {},
  onToggleFaceEnhancement: (Boolean) -> Unit = {},
  onSetFaceStrength: (Float) -> Unit = {},
  onSetExportFormat: (ExportFormat) -> Unit = {},
  onSetHighQualitySlowMode: (Boolean) -> Unit = {},
  onPromptClearHistory: () -> Unit = {},
  modifier: Modifier = Modifier
) {
  var targetImportSlot by remember { mutableStateOf<ModelSlotType?>(null) }
  var selectedLanguage by remember { mutableStateOf("bn") } // "bn" = বাংলা (ডিফল্ট), "en" = English
  var activeDownloadSlot by remember { mutableStateOf<ModelSlotType?>(null) }

  if (activeDownloadSlot != null) {
    val slot = activeDownloadSlot!!
    val status = downloadStatusMap[slot] ?: DownloadStatus.Idle
    ModelDownloadGateScreen(
      downloadStatus = status,
      isMobileData = isMobileData,
      slotType = slot,
      onStartDownload = { onDownloadModel(slot) },
      onCancelDownload = { onCancelDownloadModel(slot) },
      onImportModel = { uri, s -> onImportModel(uri, s) },
      onClose = { activeDownloadSlot = null }
    )
    return
  }

  val modelFilePicker = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.OpenDocument()
  ) { uri: Uri? ->
    val slot = targetImportSlot
    if (uri != null && slot != null) {
      onImportModel(uri, slot)
    }
    targetImportSlot = null
  }

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(MainBackground)
      .verticalScroll(rememberScrollState())
      .padding(horizontal = 20.dp, vertical = 14.dp)
  ) {
    // Header
    Text(
      text = if (selectedLanguage == "bn") "সেটিংস ও AI মডেল" else "Settings & AI Models",
      fontSize = 24.sp,
      fontWeight = FontWeight.ExtraBold,
      color = MainText
    )
    Text(
      text = if (selectedLanguage == "bn")
        "AI মডেল ম্যানেজার ও অ্যাপ তথ্য (100% অফলাইন)"
      else
        "AI Model Manager & App Info (100% Offline)",
      fontSize = 13.sp,
      color = SecondaryText
    )

    Spacer(modifier = Modifier.height(20.dp))

    // Import error banner if any
    if (importErrorMessage != null) {
      Surface(
        shape = RoundedCornerShape(14.dp),
        color = ErrorRed.copy(alpha = 0.15f),
        border = androidx.compose.foundation.BorderStroke(1.dp, ErrorRed),
        modifier = Modifier
          .fillMaxWidth()
          .padding(bottom = 16.dp)
      ) {
        Row(
          modifier = Modifier.padding(14.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
            Icon(Icons.Default.Warning, contentDescription = null, tint = ErrorRed, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(10.dp))
            Text(
              text = importErrorMessage,
              fontSize = 12.sp,
              color = MainText,
              lineHeight = 16.sp
            )
          }
          IconButton(onClick = onDismissImportError, modifier = Modifier.size(24.dp)) {
            Icon(Icons.Default.Close, contentDescription = "Close", tint = SecondaryText, modifier = Modifier.size(16.dp))
          }
        }
      }
    }

    // SECTION: PERFORMANCE & QUALITY
    SettingsSectionTitle(
      title = if (selectedLanguage == "bn") "PROCESSING SPEED (গতি ও কোয়ালিটি)" else "PROCESSING SPEED"
    )

    Card(
      shape = RoundedCornerShape(16.dp),
      colors = CardDefaults.cardColors(containerColor = CardBackground),
      border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor),
      modifier = Modifier.fillMaxWidth()
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
          Text(
            text = "বেশি কোয়ালিটি মোড (ধীর)",
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            color = MainText
          )
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = if (selectedLanguage == "bn")
              "ডিফল্ট অফ (দ্রুত ৫-৮ সেকেন্ড)। অন থাকলে সম্পূর্ণ ছবিতে Real-ESRGAN চলবে (সময় বেশি লাগবে)।"
            else
              "Default OFF (fast 5-8s). When ON, runs whole-image Real-ESRGAN without time budget.",
            fontSize = 12.sp,
            color = SecondaryText,
            lineHeight = 16.sp
          )
        }
        Switch(
          checked = config.highQualitySlowMode,
          onCheckedChange = onSetHighQualitySlowMode
        )
      }
    }

    Spacer(modifier = Modifier.height(20.dp))

    // SECTION 1: AI MODEL CARDS (IMAGE MODEL & FACE MODEL)
    SettingsSectionTitle(
      title = if (selectedLanguage == "bn") "AI MODELS (মডেল ম্যানেজার)" else "AI MODELS (MODEL MANAGER)"
    )

    // Slot 1: Image model card (Real-ESRGAN .onnx)
    val imageSlot = modelSlots[ModelSlotType.IMAGE_MODEL]
    ModelSlotCard(
      slotType = ModelSlotType.IMAGE_MODEL,
      slotInfo = imageSlot,
      icon = Icons.Default.Image,
      isImporting = importingSlotType == ModelSlotType.IMAGE_MODEL,
      downloadStatus = downloadStatusMap[ModelSlotType.IMAGE_MODEL],
      selectedLanguage = selectedLanguage,
      onImportClick = {
        targetImportSlot = ModelSlotType.IMAGE_MODEL
        modelFilePicker.launch(arrayOf("*/*", "application/octet-stream"))
      },
      onDownloadClick = {
        activeDownloadSlot = ModelSlotType.IMAGE_MODEL
        onDownloadModel(ModelSlotType.IMAGE_MODEL)
      },
      onCancelDownloadClick = { onCancelDownloadModel(ModelSlotType.IMAGE_MODEL) },
      onDeleteClick = { onDeleteModel(ModelSlotType.IMAGE_MODEL) }
    )

    Spacer(modifier = Modifier.height(12.dp))

    // Slot 2: Face model card (GFPGAN/CodeFormer .onnx)
    val faceSlot = modelSlots[ModelSlotType.FACE_MODEL]
    ModelSlotCard(
      slotType = ModelSlotType.FACE_MODEL,
      slotInfo = faceSlot,
      icon = Icons.Default.Face,
      isImporting = importingSlotType == ModelSlotType.FACE_MODEL,
      downloadStatus = downloadStatusMap[ModelSlotType.FACE_MODEL],
      selectedLanguage = selectedLanguage,
      onImportClick = {
        targetImportSlot = ModelSlotType.FACE_MODEL
        modelFilePicker.launch(arrayOf("*/*", "application/octet-stream"))
      },
      onDownloadClick = {
        activeDownloadSlot = ModelSlotType.FACE_MODEL
        onDownloadModel(ModelSlotType.FACE_MODEL)
      },
      onCancelDownloadClick = { onCancelDownloadModel(ModelSlotType.FACE_MODEL) },
      onDeleteClick = { onDeleteModel(ModelSlotType.FACE_MODEL) }
    )

    Spacer(modifier = Modifier.height(14.dp))

    // Model Guide info card
    Card(
      shape = RoundedCornerShape(14.dp),
      colors = CardDefaults.cardColors(containerColor = SecondaryBackground),
      border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(modifier = Modifier.padding(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Default.Info, contentDescription = null, tint = AccentCyan, modifier = Modifier.size(18.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = if (selectedLanguage == "bn") "মডেল ফাইল ব্যবহারের নিয়ম" else "Model File Guide",
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = MainText
          )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
          text = if (selectedLanguage == "bn")
            "Real-ESRGAN .onnx এবং GFPGAN .onnx মডেল ফাইল ডাউনলোড বা 'ইমপোর্ট' করে ব্যবহার করুন। মডেলগুলো একবার ইনস্টল হলে পরবর্তীতে ইন্টারনেট ছাড়াই 100% অফলাইনে ছবি ফ্রেশ ও ক্রিস্টাল ক্লিয়ার এনহান্স করবে।"
          else
            "Download or import Real-ESRGAN .onnx and GFPGAN .onnx models. Once installed, enhancement runs 100% offline on-device without any internet connection.",
          fontSize = 12.sp,
          color = SecondaryText,
          lineHeight = 16.sp
        )
      }
    }

    Spacer(modifier = Modifier.height(24.dp))

    // SECTION 2: LANGUAGE (ভাষা)
    SettingsSectionTitle(
      title = if (selectedLanguage == "bn") "LANGUAGE (ভাষা)" else "LANGUAGE"
    )

    Card(
      shape = RoundedCornerShape(16.dp),
      colors = CardDefaults.cardColors(containerColor = CardBackground),
      border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Default.Language, contentDescription = null, tint = AccentCyan, modifier = Modifier.size(18.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = if (selectedLanguage == "bn") "অ্যাপের ভাষা নির্বাচন করুন" else "Select App Language",
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = MainText
          )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Bengali option
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(if (selectedLanguage == "bn") PrimaryPurple.copy(alpha = 0.15f) else Color.Transparent)
            .clickable { selectedLanguage = "bn" }
            .padding(12.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(
            imageVector = if (selectedLanguage == "bn") Icons.Default.RadioButtonChecked else Icons.Default.RadioButtonUnchecked,
            contentDescription = null,
            tint = if (selectedLanguage == "bn") AccentCyan else SecondaryText,
            modifier = Modifier.size(20.dp)
          )
          Spacer(modifier = Modifier.width(12.dp))
          Column {
            Text("বাংলা (ডিফল্ট)", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MainText)
            Text("সম্পূর্ণ ইন্টারফেস বাংলায় প্রদর্শিত হবে", fontSize = 11.sp, color = SecondaryText)
          }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // English option
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(if (selectedLanguage == "en") PrimaryPurple.copy(alpha = 0.15f) else Color.Transparent)
            .clickable { selectedLanguage = "en" }
            .padding(12.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(
            imageVector = if (selectedLanguage == "en") Icons.Default.RadioButtonChecked else Icons.Default.RadioButtonUnchecked,
            contentDescription = null,
            tint = if (selectedLanguage == "en") AccentCyan else SecondaryText,
            modifier = Modifier.size(20.dp)
          )
          Spacer(modifier = Modifier.width(12.dp))
          Column {
            Text("English", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MainText)
            Text("Display user interface in English", fontSize = 11.sp, color = SecondaryText)
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(24.dp))

    // SECTION 3: VERSION & ABOUT (অ্যাপের তথ্য)
    SettingsSectionTitle(
      title = if (selectedLanguage == "bn") "ABOUT & VERSION (অ্যাপ তথ্য)" else "ABOUT & VERSION"
    )

    Card(
      shape = RoundedCornerShape(16.dp),
      colors = CardDefaults.cardColors(containerColor = CardBackground),
      border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(20.dp))
          Spacer(modifier = Modifier.width(10.dp))
          Column {
            Text("Lamini AI Photo Enhancer", fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, color = MainText)
            Text("ভার্সন 1.0.0 (100% Offline AI)", fontSize = 12.sp, color = AccentCyan)
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        Text(
          text = if (selectedLanguage == "bn")
            "• ইঞ্জিন: Local ONNX Runtime (Real-ESRGAN x2/x4 + GFPGAN Face)\n• আউটপুট: মূল রেজোলিউশন সংরক্ষিত (উচ্চ স্পষ্টতা ও ফ্রেশ ডিটেইল)\n• নিরাপত্তা: কোনো ফটো কোনো সার্ভারে পাঠানো হয় না\n• স্টোরেজ: Pictures/Lamini ও অন-ডিভাইস Room ডাটাবেস"
          else
            "• Engine: Local ONNX Runtime (Real-ESRGAN x2/x4 + GFPGAN Face)\n• Output: Original resolution preserved (high clarity & fresh details)\n• Privacy: No photos are ever uploaded to any server\n• Storage: Pictures/Lamini & local Room database",
          fontSize = 12.sp,
          color = SecondaryText,
          lineHeight = 20.sp
        )
      }
    }

    Spacer(modifier = Modifier.height(36.dp))
  }
}

@Composable
private fun ModelSlotCard(
  slotType: ModelSlotType,
  slotInfo: ModelSlotInfo?,
  icon: ImageVector,
  isImporting: Boolean,
  downloadStatus: DownloadStatus?,
  selectedLanguage: String = "bn",
  onImportClick: () -> Unit,
  onDownloadClick: () -> Unit,
  onCancelDownloadClick: () -> Unit,
  onDeleteClick: () -> Unit
) {
  val isInstalled = slotInfo?.isInstalled == true
  val isDownloading = downloadStatus is DownloadStatus.Downloading
  val isValidating = downloadStatus is DownloadStatus.Validating
  val isError = downloadStatus is DownloadStatus.Error

  Card(
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(
      containerColor = if (isInstalled) CardBackground else Color(0xFF161924)
    ),
    border = androidx.compose.foundation.BorderStroke(
      1.dp,
      if (isInstalled) SuccessGreen.copy(alpha = 0.5f) else BorderColor
    ),
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
          Surface(
            shape = CircleShape,
            color = if (isInstalled) SuccessGreen.copy(alpha = 0.2f) else SecondaryBackground,
            modifier = Modifier.size(36.dp)
          ) {
            Box(contentAlignment = Alignment.Center) {
              Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (isInstalled) SuccessGreen else AccentCyan,
                modifier = Modifier.size(20.dp)
              )
            }
          }
          Spacer(modifier = Modifier.width(12.dp))
          Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Text(
                text = slotType.title,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = MainText
              )
              if (slotType == ModelSlotType.IMAGE_MODEL) {
                Spacer(modifier = Modifier.width(6.dp))
                Surface(
                  shape = RoundedCornerShape(4.dp),
                  color = AccentCyan.copy(alpha = 0.15f),
                  border = androidx.compose.foundation.BorderStroke(1.dp, AccentCyan.copy(alpha = 0.4f))
                ) {
                  Text(
                    text = if (selectedLanguage == "bn") "ঐচ্ছিক" else "Optional",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = AccentCyan,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                  )
                }
              }
            }
            Text(
              text = if (isInstalled) {
                if (selectedLanguage == "bn") "ইনস্টল করা আছে • ${slotInfo?.formattedSize}" else "Installed • ${slotInfo?.formattedSize}"
              } else {
                if (slotType == ModelSlotType.IMAGE_MODEL) {
                  if (selectedLanguage == "bn") "ইনস্টল নেই (${slotType.recommendedFileName}) • ঐচ্ছিক" else "Not installed (${slotType.recommendedFileName}) • Optional"
                } else {
                  if (selectedLanguage == "bn") "ইনস্টল নেই (${slotType.recommendedFileName})" else "Not installed (${slotType.recommendedFileName})"
                }
              },
              fontSize = 11.sp,
              color = if (isInstalled) SuccessGreen else Color(0xFFF59E0B)
            )
          }
        }

        // Status badge
        Surface(
          shape = RoundedCornerShape(8.dp),
          color = if (isInstalled) {
            SuccessGreen.copy(alpha = 0.15f)
          } else if (slotType == ModelSlotType.IMAGE_MODEL) {
            AccentCyan.copy(alpha = 0.15f)
          } else {
            Color(0xFFF59E0B).copy(alpha = 0.15f)
          }
        ) {
          Text(
            text = if (isInstalled) {
              "Installed"
            } else if (slotType == ModelSlotType.IMAGE_MODEL) {
              if (selectedLanguage == "bn") "ঐচ্ছিক" else "Optional"
            } else {
              "Not installed"
            },
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = if (isInstalled) {
              SuccessGreen
            } else if (slotType == ModelSlotType.IMAGE_MODEL) {
              AccentCyan
            } else {
              Color(0xFFF59E0B)
            },
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
          )
        }
      }

      // Download progress
      if (isDownloading) {
        val downloadInfo = downloadStatus as DownloadStatus.Downloading
        Spacer(modifier = Modifier.height(14.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "${downloadInfo.percent}% ডাউনলোড হচ্ছে...",
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            color = AccentCyan
          )
          Text(
            text = "${downloadInfo.downloadedMb} / ${downloadInfo.totalMb} MB (${downloadInfo.speedText})",
            fontSize = 11.sp,
            color = SecondaryText
          )
        }
        Spacer(modifier = Modifier.height(8.dp))
        LinearProgressIndicator(
          progress = { downloadInfo.percent / 100f },
          modifier = Modifier
            .fillMaxWidth()
            .height(6.dp)
            .clip(RoundedCornerShape(3.dp)),
          color = AccentCyan,
          trackColor = BorderColor
        )
        Spacer(modifier = Modifier.height(12.dp))
        OutlinedButton(
          onClick = onCancelDownloadClick,
          colors = ButtonDefaults.outlinedButtonColors(contentColor = ErrorRed),
          border = androidx.compose.foundation.BorderStroke(1.dp, ErrorRed.copy(alpha = 0.4f)),
          shape = RoundedCornerShape(10.dp),
          modifier = Modifier.fillMaxWidth().height(38.dp)
        ) {
          Text("বাতিল করুন", fontSize = 12.sp)
        }
      } else if (isValidating) {
        Spacer(modifier = Modifier.height(14.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
          CircularProgressIndicator(modifier = Modifier.size(16.dp), color = AccentCyan, strokeWidth = 2.dp)
          Spacer(modifier = Modifier.width(8.dp))
          Text("মডেল যাচাই হচ্ছে...", fontSize = 12.sp, color = SecondaryText)
        }
      } else if (isError) {
        val errorInfo = downloadStatus as DownloadStatus.Error
        Spacer(modifier = Modifier.height(10.dp))
        Text(
          text = errorInfo.message,
          fontSize = 11.sp,
          color = ErrorRed
        )
        Spacer(modifier = Modifier.height(10.dp))
        Button(
          onClick = onDownloadClick,
          colors = ButtonDefaults.buttonColors(containerColor = ErrorRed),
          shape = RoundedCornerShape(10.dp),
          modifier = Modifier.fillMaxWidth().height(38.dp)
        ) {
          Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(14.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("আবার চেষ্টা করুন", fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
      } else {
        Spacer(modifier = Modifier.height(14.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          // Import (.onnx) Button
          OutlinedButton(
            onClick = onImportClick,
            enabled = !isImporting,
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = MainText),
            border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor),
            modifier = Modifier
              .weight(1f)
              .height(42.dp)
          ) {
            if (isImporting) {
              CircularProgressIndicator(
                modifier = Modifier.size(16.dp),
                strokeWidth = 2.dp,
                color = MainText
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text("যাচাই...", fontSize = 11.sp)
            } else {
              Icon(Icons.Default.UploadFile, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                if (selectedLanguage == "bn") "ইমপোর্ট (.onnx)" else "Import (.onnx)",
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold
              )
            }
          }

          // Download / Re-download Button
          Button(
            onClick = onDownloadClick,
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.buttonColors(
              containerColor = Color.Transparent,
              contentColor = MainText
            ),
            modifier = Modifier
              .weight(1f)
              .height(42.dp)
              .background(PrimaryGradient, RoundedCornerShape(10.dp))
          ) {
            Icon(Icons.Default.FileDownload, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              if (isInstalled) {
                if (selectedLanguage == "bn") "পুনরায় ডাউনলোড" else "Re-download"
              } else {
                if (selectedLanguage == "bn") "ডাউনলোড" else "Download"
              },
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold
            )
          }

          // Delete Button if installed
          if (isInstalled) {
            OutlinedButton(
              onClick = onDeleteClick,
              shape = RoundedCornerShape(10.dp),
              colors = ButtonDefaults.outlinedButtonColors(contentColor = ErrorRed),
              border = androidx.compose.foundation.BorderStroke(1.dp, ErrorRed.copy(alpha = 0.6f)),
              modifier = Modifier.height(42.dp)
            ) {
              Icon(Icons.Default.Delete, contentDescription = "Delete", tint = ErrorRed, modifier = Modifier.size(16.dp))
            }
          }
        }
      }
    }
  }
}

@Composable
private fun SettingsSectionTitle(title: String) {
  Text(
    text = title,
    fontSize = 11.sp,
    fontWeight = FontWeight.Bold,
    color = TextMuted,
    letterSpacing = 1.sp,
    modifier = Modifier.padding(bottom = 8.dp)
  )
}
