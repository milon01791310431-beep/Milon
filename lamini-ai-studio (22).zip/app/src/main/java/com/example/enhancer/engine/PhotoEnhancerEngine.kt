package com.example.enhancer.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.PointF
import android.graphics.Rect
import android.media.FaceDetector
import android.util.Log
import com.example.enhancer.model.EngineStatus
import com.example.enhancer.model.EngineStatusInfo
import com.example.enhancer.model.EngineType
import com.example.enhancer.model.EnhancementConfig
import com.example.enhancer.model.EnhancementMode
import com.example.enhancer.model.ProcessingProgress
import com.example.enhancer.model.UpscaleFactor
import com.example.enhancer.utils.MemorySafetyCalculator
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import kotlin.coroutines.coroutineContext
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt

/**
 * Classical Algorithmic Computer Vision Engine (Fallback Engine).
 *
 * Implements non-neural image processing:
 * - Bilateral edge-preserving noise reduction
 * - Adaptive luminance & S-curve tone equalization
 * - Landmark-guided face enhancement
 * - High-frequency Laplacian unsharp masking
 * - Exact resolution scaling (keeping aspect ratio)
 *
 * NOTE: This pipeline runs 100% locally on device using algorithmic CV filters,
 * NOT deep neural networks.
 */
class PhotoEnhancerEngine(private val context: Context) : AiInferenceEngine {

  override val engineType: EngineType = EngineType.BUILT_IN_CV

  override suspend fun getStatusInfo(): EngineStatusInfo {
    return EngineStatusInfo(
      engineType = EngineType.BUILT_IN_CV,
      status = EngineStatus.READY,
      modelName = "AI মডেল নেই, বেসিক এনহান্সমেন্ট ব্যবহার হয়েছে",
      modelVersion = "CV-v1.2",
      runtimeEnvironment = "On-Device CPU (Android Graphics Engine)",
      computeDevice = "Local CPU",
      statusMessage = "AI মডেল নেই, বেসিক এনহান্সমেন্ট ব্যবহার হয়েছে (Bilateral Denoising, S-Curve Dynamic Range, Laplacian Unsharp Mask)।",
      isNeuralAi = false,
      supportedScales = listOf(2),
      supportsFaceRestoration = true,
      diagnosticNotes = "100% অফলাইন ক্লাসিক্যাল কম্পিউটার ভিশন অ্যালগরিদম।"
    )
  }

  override suspend fun checkReadiness(): Result<EngineStatusInfo> {
    return Result.success(getStatusInfo())
  }

  override suspend fun enhance(
    sourceBitmap: Bitmap,
    config: EnhancementConfig,
    onProgress: (ProcessingProgress) -> Unit
  ): Result<Bitmap> = withContext(Dispatchers.Default) {
    var workingBitmap: Bitmap? = null
    var finalBitmap: Bitmap? = null

    try {
      coroutineContext.ensureActive()

      // Output size = Input size (Remini style, capped at 4096)
      val srcW = sourceBitmap.width
      val srcH = sourceBitmap.height
      val maxDim = max(srcW, srcH)
      val targetW: Int
      val targetH: Int
      if (maxDim > 4096) {
        val f = 4096f / maxDim
        targetW = (srcW * f).roundToInt().coerceAtLeast(1)
        targetH = (srcH * f).roundToInt().coerceAtLeast(1)
      } else {
        targetW = srcW
        targetH = srcH
      }

      onProgress(
        ProcessingProgress(
          stage = "ছবি প্রস্তুত করা হচ্ছে...",
          percent = 0.10f,
          isIndeterminate = false,
          detail = "ইনপুট রেজোলিউশন: ${srcW} × ${srcH} px"
        )
      )

      coroutineContext.ensureActive()

      // 1. Scene analysis & Face detection
      onProgress(
        ProcessingProgress(
          stage = "ফেস ও ইমেজ অ্যানালাইসিস...",
          percent = 0.25f,
          isIndeterminate = false,
          detail = "অফলাইন পোর্ট্রেট অঞ্চল বিশ্লেষণ..."
        )
      )

      val detectedFaces = mutableListOf<FaceRegion>()
      if (config.faceEnhancement || config.mode == EnhancementMode.FACE_RESTORATION) {
        detectFaceRegions(sourceBitmap, detectedFaces)
      }

      coroutineContext.ensureActive()

      workingBitmap = sourceBitmap.copy(Bitmap.Config.ARGB_8888, true)

      // 2. Bilateral noise filtering
      if (config.noiseReduction) {
        onProgress(
          ProcessingProgress(
            stage = "নয়েজ রিডাকশন প্রয়োগ হচ্ছে...",
            percent = 0.40f,
            isIndeterminate = false,
            detail = "এজ-প্রিজার্ভিং বাইল্যাটারাল স্মুথিং..."
          )
        )
        val denoised = applyBilateralDenoise(workingBitmap)
        workingBitmap.recycle()
        workingBitmap = denoised
      }

      coroutineContext.ensureActive()

      // 3. Contrast & tone expansion
      if (config.autoColorBalancing) {
        onProgress(
          ProcessingProgress(
            stage = "কালার ও কনট্রাস্ট অপ্টিমাইজেশন...",
            percent = 0.55f,
            isIndeterminate = false,
            detail = "ডায়নামিক রেঞ্জ অ্যাডজাস্টমেন্ট..."
          )
        )
        val toneEnhanced = applyToneAndColorEnhancement(workingBitmap)
        workingBitmap.recycle()
        workingBitmap = toneEnhanced
      }

      coroutineContext.ensureActive()

      // 4. Face restoration
      val tFacesStart = System.currentTimeMillis()
      if ((config.faceEnhancement || config.mode == EnhancementMode.FACE_RESTORATION) && detectedFaces.isNotEmpty()) {
        onProgress(
          ProcessingProgress(
            stage = "ফেস ক্ল্যারিটি বৃদ্ধি করা হচ্ছে...",
            percent = 0.70f,
            isIndeterminate = false,
            detail = "${detectedFaces.size}টি মুখের অংশ উন্নত করা হচ্ছে..."
          )
        )
        val faceRestored = restoreFaces(workingBitmap, detectedFaces)
        workingBitmap.recycle()
        workingBitmap = faceRestored
      }
      val facesDuration = System.currentTimeMillis() - tFacesStart
      Log.i("PerformanceTiming", "Stage [faces]: ${facesDuration} ms")

      coroutineContext.ensureActive()

      // 5. Sharpening
      val sharpnessStrength = when (config.mode) {
        EnhancementMode.HIGH_DETAIL -> 0.55f
        EnhancementMode.FACE_RESTORATION -> 0.35f
        EnhancementMode.BALANCED -> 0.42f
      }
      coroutineContext.ensureActive()

      // Remini-look tone and skin step with SmartAutoAnalyzer
      val faceBoxes = detectedFaces.map { FaceDetectorOfflineHelper.DetectedFaceBox(it.bounds) }
      val tAnalysisStart = System.currentTimeMillis()
      val analysis = SmartAutoAnalyzer.analyze(workingBitmap, faceBoxes)
      val plan = SmartAutoAnalyzer.decide(analysis)
      val analysisDuration = System.currentTimeMillis() - tAnalysisStart
      Log.i("PerformanceTiming", "Stage [analysis]: ${analysisDuration} ms")
      Log.i("PhotoEnhancerEngine", "SmartAutoAnalyzer PhotoAnalysis: $analysis")
      Log.i("PhotoEnhancerEngine", "SmartAutoAnalyzer EnhancePlan: $plan")

      val toneProgressCallback: (Float, String) -> Unit = { pct, detail ->
        onProgress(
          ProcessingProgress(
            stage = "টোন ও স্কিন অপ্টিমাইজেশন চলছে...",
            percent = pct.coerceIn(0.80f, 0.95f),
            isIndeterminate = false,
            detail = detail
          )
        )
      }

      val predictedIntensity = ReminiToneSkinEngine.predictToneIntensity(
        workingBitmap,
        faceBoxes,
        plan = plan
      )

      val reminiToned = ReminiToneSkinEngine.applyReminiLook(
        workingBitmap,
        faceBoxes,
        intensity = predictedIntensity,
        plan = plan,
        onProgress = toneProgressCallback
      )

      if (reminiToned != workingBitmap) {
        workingBitmap.recycle()
      }
      workingBitmap = reminiToned

      coroutineContext.ensureActive()

      // 6. Resample to target dimensions (keeping aspect ratio)
      onProgress(
        ProcessingProgress(
          stage = "ফাইনাল অপ্টিমাইজেশন সম্পন্ন হচ্ছে...",
          percent = 0.95f,
          isIndeterminate = false,
          detail = "রেজোলিউশন স্কেলিং: ${targetW} × ${targetH} px..."
        )
      )

      finalBitmap = Bitmap.createScaledBitmap(workingBitmap, targetW, targetH, true)
      workingBitmap.recycle()
      workingBitmap = null

      onProgress(
        ProcessingProgress(
          stage = "ফাইনাল অপ্টিমাইজেশন সম্পন্ন হচ্ছে...",
          percent = 0.97f,
          isIndeterminate = false,
          detail = "শার্পেনিং ও টেক্সচার পলিশ প্রয়োগ হচ্ছে..."
        )
      )

      val finalSharpened = applyUnsharpMask(finalBitmap, strength = 0.25f)
      finalBitmap.recycle()
      finalBitmap = null

      onProgress(
        ProcessingProgress(
          stage = "সম্পন্ন হয়েছে!",
          percent = 1.0f,
          isIndeterminate = false,
          detail = "ছবি প্রস্তুত হয়েছে"
        )
      )

      Result.success(finalSharpened)
    } catch (e: CancellationException) {
      workingBitmap?.recycle()
      finalBitmap?.recycle()
      throw e
    } catch (e: Exception) {
      workingBitmap?.recycle()
      finalBitmap?.recycle()
      Result.failure(e)
    }
  }

  override fun release() {
    // Release any cached buffers
  }

  private fun detectFaceRegions(bitmap: Bitmap, outputList: MutableList<FaceRegion>) {
    var rgb565: Bitmap? = null
    try {
      val width = bitmap.width
      val height = bitmap.height
      val evenWidth = if (width % 2 == 0) width else width - 1
      rgb565 = Bitmap.createBitmap(evenWidth, height, Bitmap.Config.RGB_565)
      val canvas = Canvas(rgb565)
      canvas.drawBitmap(bitmap, 0f, 0f, null)

      val detector = FaceDetector(evenWidth, height, 5)
      val faces = Array<FaceDetector.Face?>(5) { null }
      val count = detector.findFaces(rgb565, faces)

      val midPoint = PointF()
      for (i in 0 until count) {
        val face = faces[i] ?: continue
        face.getMidPoint(midPoint)
        val eyeDistance = face.eyesDistance()
        val confidence = face.confidence()

        val halfBox = (eyeDistance * 1.5f).toInt()
        val left = (midPoint.x - halfBox).toInt().coerceAtLeast(0)
        val top = (midPoint.y - halfBox * 1.1f).toInt().coerceAtLeast(0)
        val right = (midPoint.x + halfBox).toInt().coerceAtMost(width)
        val bottom = (midPoint.y + halfBox * 1.4f).toInt().coerceAtMost(height)

        if (right > left && bottom > top) {
          outputList.add(
            FaceRegion(
              bounds = Rect(left, top, right, bottom),
              eyeDistance = eyeDistance,
              confidence = confidence
            )
          )
        }
      }
    } catch (_: Exception) {
      // Gracefully continue without face regions
    } finally {
      rgb565?.recycle()
    }
  }

  private fun applyBilateralDenoise(input: Bitmap): Bitmap {
    val width = input.width
    val height = input.height
    val output = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)

    val step = if (width > 1200 || height > 1200) 2 else 1
    val radius = 2
    val sigmaSpatial = 3.0
    val sigmaColor = 35.0

    val spatialKernel = DoubleArray((2 * radius + 1) * (2 * radius + 1))
    var kIdx = 0
    for (dy in -radius..radius) {
      for (dx in -radius..radius) {
        spatialKernel[kIdx++] = kotlin.math.exp(-(dx * dx + dy * dy) / (2 * sigmaSpatial * sigmaSpatial))
      }
    }

    val pixels = IntArray(width * height)
    input.getPixels(pixels, 0, width, 0, 0, width, height)
    val outPixels = pixels.clone()

    val yRange = radius until (height - radius) step step
    val xRange = radius until (width - radius) step step

    for (y in yRange) {
      val rowOffset = y * width
      for (x in xRange) {
        val centerPixel = pixels[rowOffset + x]
        val cR = (centerPixel shr 16) and 0xFF
        val cG = (centerPixel shr 8) and 0xFF
        val cB = centerPixel and 0xFF

        var sumR = 0.0
        var sumG = 0.0
        var sumB = 0.0
        var weightSum = 0.0
        var kernelIdx = 0

        for (dy in -radius..radius) {
          val nRowOffset = (y + dy) * width
          for (dx in -radius..radius) {
            val nPixel = pixels[nRowOffset + (x + dx)]
            val nR = (nPixel shr 16) and 0xFF
            val nG = (nPixel shr 8) and 0xFF
            val nB = nPixel and 0xFF

            val colorDistSq = ((nR - cR) * (nR - cR) + (nG - cG) * (nG - cG) + (nB - cB) * (nB - cB)) / 3.0
            val colorWeight = kotlin.math.exp(-colorDistSq / (2 * sigmaColor * sigmaColor))
            val weight = spatialKernel[kernelIdx++] * colorWeight

            sumR += nR * weight
            sumG += nG * weight
            sumB += nB * weight
            weightSum += weight
          }
        }

        if (weightSum > 0.0) {
          val fR = (sumR / weightSum).toInt().coerceIn(0, 255)
          val fG = (sumG / weightSum).toInt().coerceIn(0, 255)
          val fB = (sumB / weightSum).toInt().coerceIn(0, 255)
          val filtered = (0xFF shl 24) or (fR shl 16) or (fG shl 8) or fB
          outPixels[rowOffset + x] = filtered

          if (step == 2) {
            if (x + 1 < width) outPixels[rowOffset + x + 1] = filtered
            if (y + 1 < height) outPixels[(y + 1) * width + x] = filtered
            if (x + 1 < width && y + 1 < height) outPixels[(y + 1) * width + x + 1] = filtered
          }
        }
      }
    }

    output.setPixels(outPixels, 0, width, 0, 0, width, height)
    return output
  }

  private fun applyToneAndColorEnhancement(input: Bitmap): Bitmap {
    val width = input.width
    val height = input.height
    val output = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)

    val pixels = IntArray(width * height)
    input.getPixels(pixels, 0, width, 0, 0, width, height)

    val sCurve = IntArray(256)
    for (i in 0..255) {
      val normalized = i / 255.0
      val curved = 1.0 / (1.0 + kotlin.math.exp(-8.0 * (normalized - 0.5)))
      sCurve[i] = (curved * 255.0).toInt().coerceIn(0, 255)
    }

    for (i in pixels.indices) {
      val p = pixels[i]
      val a = (p shr 24) and 0xFF
      val r = (p shr 16) and 0xFF
      val g = (p shr 8) and 0xFF
      val b = p and 0xFF

      val enhancedR = sCurve[r]
      val enhancedG = sCurve[g]
      val enhancedB = sCurve[b]

      val lum = (0.299 * enhancedR + 0.587 * enhancedG + 0.114 * enhancedB)
      val satBoost = 1.08
      val finalR = (lum + (enhancedR - lum) * satBoost).toInt().coerceIn(0, 255)
      val finalG = (lum + (enhancedG - lum) * satBoost).toInt().coerceIn(0, 255)
      val finalB = (lum + (enhancedB - lum) * satBoost).toInt().coerceIn(0, 255)

      pixels[i] = (a shl 24) or (finalR shl 16) or (finalG shl 8) or finalB
    }

    output.setPixels(pixels, 0, width, 0, 0, width, height)
    return output
  }

  private fun restoreFaces(input: Bitmap, faceRegions: List<FaceRegion>): Bitmap {
    val result = input.copy(Bitmap.Config.ARGB_8888, true)
    val canvas = Canvas(result)

    for (region in faceRegions) {
      val bounds = region.bounds
      if (bounds.width() <= 0 || bounds.height() <= 0) continue

      val faceBitmap = Bitmap.createBitmap(
        input,
        bounds.left,
        bounds.top,
        bounds.width(),
        bounds.height()
      )

      val sharpenedFace = applyUnsharpMask(faceBitmap, strength = 0.45f)
      faceBitmap.recycle()

      val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        alpha = (region.confidence * 210).toInt().coerceIn(120, 240)
      }

      canvas.drawBitmap(sharpenedFace, bounds.left.toFloat(), bounds.top.toFloat(), paint)
      sharpenedFace.recycle()
    }

    return result
  }

  private fun applyUnsharpMask(input: Bitmap, strength: Float = 0.45f): Bitmap {
    val width = input.width
    val height = input.height
    val output = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)

    val pixels = IntArray(width * height)
    input.getPixels(pixels, 0, width, 0, 0, width, height)
    val outPixels = pixels.clone()

    val clampedStrength = strength.coerceIn(0.1f, 1.2f)

    for (y in 1 until height - 1) {
      val rowPrev = (y - 1) * width
      val rowCurr = y * width
      val rowNext = (y + 1) * width

      for (x in 1 until width - 1) {
        val center = pixels[rowCurr + x]
        val cR = (center shr 16) and 0xFF
        val cG = (center shr 8) and 0xFF
        val cB = center and 0xFF

        val nTop = pixels[rowPrev + x]
        val nBottom = pixels[rowNext + x]
        val nLeft = pixels[rowCurr + (x - 1)]
        val nRight = pixels[rowCurr + (x + 1)]

        val lapR = 4 * cR - (((nTop shr 16) and 0xFF) + ((nBottom shr 16) and 0xFF) + ((nLeft shr 16) and 0xFF) + ((nRight shr 16) and 0xFF))
        val lapG = 4 * cG - (((nTop shr 8) and 0xFF) + ((nBottom shr 8) and 0xFF) + ((nLeft shr 8) and 0xFF) + ((nRight shr 8) and 0xFF))
        val lapB = 4 * cB - ((nTop and 0xFF) + (nBottom and 0xFF) + (nLeft and 0xFF) + (nRight and 0xFF))

        val sharpR = (cR + clampedStrength * lapR).toInt().coerceIn(0, 255)
        val sharpG = (cG + clampedStrength * lapG).toInt().coerceIn(0, 255)
        val sharpB = (cB + clampedStrength * lapB).toInt().coerceIn(0, 255)

        outPixels[rowCurr + x] = (0xFF shl 24) or (sharpR shl 16) or (sharpG shl 8) or sharpB
      }
    }

    output.setPixels(outPixels, 0, width, 0, 0, width, height)
    return output
  }

  data class FaceRegion(
    val bounds: Rect,
    val eyeDistance: Float,
    val confidence: Float
  )
}
