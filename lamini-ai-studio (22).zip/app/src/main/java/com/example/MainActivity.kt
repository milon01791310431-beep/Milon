package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.enhancer.engine.DownloadStatus
import com.example.enhancer.model.AppTab
import com.example.enhancer.model.ModelSlotType
import com.example.enhancer.model.WorkflowStep
import com.example.enhancer.ui.components.LaminiBottomNavBar
import com.example.enhancer.ui.screens.EnhancePreviewScreen
import com.example.enhancer.ui.screens.HistoryScreen
import com.example.enhancer.ui.screens.HomeScreen
import com.example.enhancer.ui.screens.ModelDownloadGateScreen
import com.example.enhancer.ui.screens.ProcessingScreen
import com.example.enhancer.ui.screens.ResultScreen
import com.example.enhancer.ui.screens.SettingsScreen
import com.example.enhancer.ui.viewmodel.EnhancerViewModel
import com.example.ui.theme.CardBackground
import com.example.ui.theme.LaminiTheme
import com.example.ui.theme.MainBackground
import com.example.ui.theme.MainText
import com.example.ui.theme.SecondaryText
import com.example.ui.theme.SuccessGreen

class MainActivity : ComponentActivity() {

  private val viewModel: EnhancerViewModel by viewModels()

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      LaminiTheme {
        val uiState by viewModel.uiState.collectAsStateWithLifecycle()
        val allHistory by viewModel.allHistoryPhotos.collectAsStateWithLifecycle()
        val recentHistory by viewModel.recentHistoryPhotos.collectAsStateWithLifecycle()
        val historyCount by viewModel.historyCount.collectAsStateWithLifecycle()

        // Handle system back navigation smoothly
        BackHandler(enabled = uiState.currentStep == WorkflowStep.RESULT) {
          viewModel.backToPhoto()
        }

        BackHandler(enabled = uiState.currentStep == WorkflowStep.IDLE && uiState.currentTab != AppTab.HOME) {
          viewModel.selectTab(AppTab.HOME)
        }

        val showBottomBar = uiState.currentStep != WorkflowStep.PROCESSING

        Scaffold(
          containerColor = MainBackground,
          contentWindowInsets = WindowInsets.safeDrawing,
          bottomBar = {
            if (showBottomBar) {
              LaminiBottomNavBar(
                currentTab = uiState.currentTab,
                onTabSelected = { tab ->
                  if (uiState.currentStep == WorkflowStep.RESULT) {
                    viewModel.backToPhoto()
                  }
                  viewModel.selectTab(tab)
                }
              )
            }
          },
          modifier = Modifier.fillMaxSize()
        ) { innerPadding ->
          Box(
            modifier = Modifier
              .fillMaxSize()
              .padding(innerPadding)
          ) {
            when (uiState.currentStep) {
              WorkflowStep.PROCESSING -> {
                ProcessingScreen(
                  originalBitmap = uiState.originalBitmap,
                  progress = uiState.progress,
                  errorMessage = uiState.errorMessage,
                  onCancel = { viewModel.cancelEnhancement() },
                  onTryAgain = { viewModel.startEnhancement() },
                  onBackToPhoto = { viewModel.backToPhoto() }
                )
              }

                WorkflowStep.RESULT -> {
                  val original = uiState.originalBitmap
                  val enhanced = uiState.enhancedBitmap
                  if (original != null && enhanced != null) {
                    ResultScreen(
                      originalBitmap = original,
                      enhancedBitmap = enhanced,
                      originalMetadata = uiState.originalMetadata,
                      enhancedMetadata = uiState.enhancedMetadata,
                      config = uiState.config,
                      sliderPosition = uiState.sliderPosition,
                      comparisonMode = uiState.comparisonMode,
                      exportFormat = uiState.exportFormat,
                      saveNotification = uiState.saveNotification,
                      isSaving = uiState.isSaving,
                      usedEngineName = uiState.usedEngineName,
                      usedEngineIsAi = uiState.usedEngineIsAi,
                      aiUpscaleSkippedNote = uiState.aiUpscaleSkippedNote,
                      onSliderPositionChange = { viewModel.updateSliderPosition(it) },
                      onComparisonModeChange = { viewModel.setComparisonMode(it) },
                      onExportFormatChange = { viewModel.setExportFormat(it) },
                      onDownload = { viewModel.saveEnhancedImage() },
                      onShare = { viewModel.shareEnhancedImage() },
                      onTryAgain = { viewModel.backToPhoto() },
                      onEnhanceAnother = { viewModel.enhanceAnotherPhoto() },
                      onDismissNotification = { viewModel.dismissNotification() },
                      onBitmapModified = { viewModel.updateEnhancedBitmap(it) }
                    )
                  }
                }

                WorkflowStep.IDLE -> {
                  AnimatedContent(
                    targetState = uiState.currentTab,
                    transitionSpec = { fadeIn() togetherWith fadeOut() },
                    label = "tab_transition"
                  ) { tab ->
                    when (tab) {
                      AppTab.HOME -> {
                        HomeScreen(
                          recentPhotos = recentHistory,
                          hasSelectedPhoto = uiState.originalBitmap != null,
                          isFaceModelInstalled = uiState.isFaceModelInstalled,
                          isFaceCardDismissed = uiState.isFaceCardDismissed,
                          faceDownloadStatus = uiState.downloadStatusMap[ModelSlotType.FACE_MODEL] ?: DownloadStatus.Idle,
                          onDownloadFaceModel = { viewModel.startModelDownload(ModelSlotType.FACE_MODEL) },
                          onCancelDownloadFaceModel = { viewModel.cancelModelDownload(ModelSlotType.FACE_MODEL) },
                          onDismissFaceCard = { viewModel.dismissFaceDownloadCard() },
                          onImageSelected = { viewModel.onImageSelected(it) },
                          onSampleSelected = { generator, title ->
                            viewModel.onSampleSelected(generator, title)
                          },
                          onOpenHistoryItem = { entity ->
                            viewModel.openHistoryItem(entity)
                          },
                          onNavigateToHistory = {
                            viewModel.selectTab(AppTab.HISTORY)
                          },
                          onNavigateToSettings = {
                            viewModel.selectTab(AppTab.SETTINGS)
                          },
                          onNavigateToPreview = {
                            viewModel.selectTab(AppTab.ENHANCE)
                          }
                        )
                      }

                      AppTab.ENHANCE -> {
                        EnhancePreviewScreen(
                          bitmap = uiState.originalBitmap,
                          metadata = uiState.originalMetadata,
                          showRemoveDialog = uiState.showRemoveConfirmDialog,
                          engineType = uiState.engineType,
                          engineStatusInfo = uiState.engineStatusInfo,
                          onImageSelected = { viewModel.onImageSelected(it) },
                          onRotatePhoto = { viewModel.rotatePhoto() },
                          onPromptRemove = { viewModel.promptRemovePhoto() },
                          onDismissRemoveDialog = { viewModel.dismissRemovePhotoDialog() },
                          onConfirmRemove = { viewModel.confirmRemovePhoto() },
                          onNavigateToSettings = { viewModel.selectTab(AppTab.SETTINGS) },
                          onStartEnhance = { viewModel.startEnhancement() },
                          onNavigateBack = { viewModel.selectTab(AppTab.HOME) }
                        )
                      }

                      AppTab.HISTORY -> {
                        HistoryScreen(
                          photos = allHistory,
                          showClearDialog = uiState.showClearHistoryDialog,
                          onOpenPhoto = { entity ->
                            viewModel.openHistoryItem(entity)
                          },
                          onDeletePhoto = { entity ->
                            viewModel.deleteHistoryItem(entity)
                          },
                          onPromptClearHistory = { viewModel.promptClearHistory() },
                          onDismissClearDialog = { viewModel.dismissClearHistoryDialog() },
                          onConfirmClearHistory = { viewModel.confirmClearHistory() },
                          onNavigateToEnhance = { viewModel.selectTab(AppTab.ENHANCE) }
                        )
                      }

                      AppTab.SETTINGS -> {
                        SettingsScreen(
                          config = uiState.config,
                          exportFormat = uiState.exportFormat,
                          engineType = uiState.engineType,
                          engineStatusInfo = uiState.engineStatusInfo,
                          modelSlots = uiState.modelSlots,
                          importingSlotType = uiState.importingSlotType,
                          importErrorMessage = uiState.importErrorMessage,
                          downloadStatusMap = uiState.downloadStatusMap,
                          isMobileData = uiState.isMobileData,
                          historyCount = historyCount,
                          onSetUseAiModel = { viewModel.setUseAiModel(it) },
                          onImportModel = { uri, slot -> viewModel.importModel(uri, slot) },
                          onDownloadModel = { slot -> viewModel.startModelDownload(slot) },
                          onCancelDownloadModel = { slot -> viewModel.cancelModelDownload(slot) },
                          onDeleteModel = { slot -> viewModel.deleteModel(slot) },
                          onDismissImportError = { viewModel.dismissNotification() },
                          onSetEnhancementMode = { viewModel.setEnhancementMode(it) },
                          onSetUpscaleFactor = { viewModel.setUpscaleFactor(it) },
                          onToggleFaceEnhancement = { viewModel.toggleFaceEnhancement(it) },
                          onSetFaceStrength = { viewModel.setFaceStrength(it) },
                          onSetExportFormat = { viewModel.setExportFormat(it) },
                          onSetHighQualitySlowMode = { viewModel.setHighQualitySlowMode(it) },
                          onPromptClearHistory = { viewModel.promptClearHistory() }
                        )
                      }
                    }
                  }
                }
              }

              // Floating banner if saveNotification is shown during IDLE step
              AnimatedVisibility(
                visible = uiState.currentStep == WorkflowStep.IDLE && uiState.saveNotification != null,
                enter = slideInVertically(initialOffsetY = { -it }) + fadeIn(),
                exit = slideOutVertically(targetOffsetY = { -it }) + fadeOut(),
                modifier = Modifier
                  .align(Alignment.TopCenter)
                  .padding(16.dp)
              ) {
                Card(
                  shape = RoundedCornerShape(12.dp),
                  colors = CardDefaults.cardColors(containerColor = CardBackground),
                  border = androidx.compose.foundation.BorderStroke(1.dp, SuccessGreen.copy(alpha = 0.6f)),
                  modifier = Modifier.fillMaxWidth()
                ) {
                  Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    Icon(
                      imageVector = Icons.Default.CheckCircle,
                      contentDescription = null,
                      tint = SuccessGreen,
                      modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                      text = uiState.saveNotification ?: "",
                      fontSize = 13.sp,
                      fontWeight = FontWeight.Medium,
                      color = MainText,
                      modifier = Modifier.weight(1f)
                    )
                    IconButton(
                      onClick = { viewModel.dismissNotification() },
                      modifier = Modifier.size(24.dp)
                    ) {
                      Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Dismiss",
                        tint = SecondaryText,
                        modifier = Modifier.size(16.dp)
                      )
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
