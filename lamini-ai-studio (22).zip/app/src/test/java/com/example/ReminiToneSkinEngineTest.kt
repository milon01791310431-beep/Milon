package com.example

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect
import com.example.enhancer.engine.FaceDetectorOfflineHelper
import com.example.enhancer.engine.ReminiToneSkinEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ReminiToneSkinEngineTest {

  private fun computeMeanLstar(bitmap: Bitmap): Float {
    val w = bitmap.width
    val h = bitmap.height
    val pixels = IntArray(w * h)
    bitmap.getPixels(pixels, 0, w, 0, 0, w, h)
    var sum = 0.0
    for (p in pixels) {
      val r = Color.red(p)
      val g = Color.green(p)
      val b = Color.blue(p)
      sum += ReminiToneSkinEngine.rgbToLstar(r, g, b)
    }
    return (sum / (w * h)).toFloat()
  }

  @Test
  fun testFullPipeline_DarkImage_LandsWithin55To59_AndBlacksProtected() {
    // Dark test image: mean L* < 57 (around 47), with shadow/black pixels below L* 20
    val w = 100
    val h = 100
    val darkBitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)

    // Fill with RGB(116, 116, 116) (~48.9 L*) and top 5 rows with RGB(30, 30, 30) (~11.2 L*)
    val pixels = IntArray(w * h) { i ->
      val y = i / w
      if (y < 5) Color.rgb(30, 30, 30) else Color.rgb(116, 116, 116)
    }
    darkBitmap.setPixels(pixels, 0, w, 0, 0, w, h)

    val inMeanL = computeMeanLstar(darkBitmap)
    assertTrue("Input dark image must be below 57 L*, was $inMeanL", inMeanL < 57.0f)

    val enhanced = ReminiToneSkinEngine.applyReminiLook(darkBitmap)
    val outMeanL = computeMeanLstar(enhanced)

    // 1 & 5: Calibrated auto-exposure gamma lands final mean L* within 55..59
    assertTrue("Dark image mean L* ($outMeanL) after full pipeline must land within 55..59", outMeanL in 55.0f..59.0f)

    // 2 & 5: Black pixels below L* 20 stay below L* 22 (no haze, protected blacks)
    val blackSample = enhanced.getPixel(10, 2)
    val blackL = ReminiToneSkinEngine.rgbToLstar(Color.red(blackSample), Color.green(blackSample), Color.blue(blackSample))
    assertTrue("Black pixel below L* 20 must stay below L* 22, was $blackL", blackL <= 22.0f)
  }

  @Test
  fun testFullPipeline_NormalImage_LandsWithin55To59_AndBlacksProtected() {
    // Normal test image: mean L* around 50..52 (slightly below 57)
    val w = 100
    val h = 100
    val normalBitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)

    val pixels = IntArray(w * h) { i ->
      val y = i / w
      if (y < 5) Color.rgb(30, 30, 30) else Color.rgb(124, 124, 124) // ~52.3 L*
    }
    normalBitmap.setPixels(pixels, 0, w, 0, 0, w, h)

    val inMeanL = computeMeanLstar(normalBitmap)
    assertTrue("Input normal image must be below 57 L*, was $inMeanL", inMeanL < 57.0f)

    val enhanced = ReminiToneSkinEngine.applyReminiLook(normalBitmap)
    val outMeanL = computeMeanLstar(enhanced)

    // Mean L* lands within 55..59
    assertTrue("Normal image mean L* ($outMeanL) after full pipeline must land within 55..59", outMeanL in 55.0f..59.0f)

    // Black pixels below L* 20 stay below L* 22
    val blackSample = enhanced.getPixel(10, 2)
    val blackL = ReminiToneSkinEngine.rgbToLstar(Color.red(blackSample), Color.green(blackSample), Color.blue(blackSample))
    assertTrue("Black pixel below L* 20 must stay below L* 22, was $blackL", blackL <= 22.0f)
  }

  @Test
  fun testFullPipeline_BrightImage_Unchanged_AndBlacksProtected() {
    // Bright test image: mean L* >= 57 (around 63..64)
    val w = 100
    val h = 100
    val brightBitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)

    val pixels = IntArray(w * h) { i ->
      val y = i / w
      if (y < 5) Color.rgb(30, 30, 30) else Color.rgb(160, 160, 160) // ~66.2 L*
    }
    brightBitmap.setPixels(pixels, 0, w, 0, 0, w, h)

    val inMeanL = computeMeanLstar(brightBitmap)
    assertTrue("Input bright image must be >= 57 L*, was $inMeanL", inMeanL >= 57.0f)

    val enhanced = ReminiToneSkinEngine.applyReminiLook(brightBitmap)
    val outMeanL = computeMeanLstar(enhanced)

    // "or unchanged if already above 57": mean L* stays within 0.5 of input
    assertEquals("Bright image mean L* must remain unchanged when already above 57", inMeanL, outMeanL, 0.5f)

    // Black pixels below L* 20 stay below L* 22
    val blackSample = enhanced.getPixel(10, 2)
    val blackL = ReminiToneSkinEngine.rgbToLstar(Color.red(blackSample), Color.green(blackSample), Color.blue(blackSample))
    assertTrue("Black pixel below L* 20 must stay below L* 22, was $blackL", blackL <= 22.0f)
  }

  @Test
  fun testProtectBlacks_AnchoredBelow25() {
    // Anchor the curve so L* below about 25 is unchanged (no black lift, no haze)
    for (l in 0..25) {
      val outL = ReminiToneSkinEngine.computeToneMappedLstar(
        lStar = l.toFloat(),
        gamma = 0.5f,
        p5 = 20f,
        p95 = 80f
      )
      assertEquals("L* <= 25 must remain strictly unchanged", l.toFloat(), outL, 0.001f)
    }
  }

  @Test
  fun testContrastHighlightsNeverHardClipSkin() {
    // Test that extreme highlights (L* near 100) are softly compressed and never exceed 100
    for (l in 80..100) {
      val outL = ReminiToneSkinEngine.computeContrastLstar(l.toFloat(), p5 = 20f, p95 = 80f)
      assertTrue("Highlights must never exceed 100 L*", outL <= 100f)
      assertTrue("Highlights must not invert order", outL >= 80f)
    }
  }

  @Test
  fun testSaturationBoostAndWarmthShift() {
    // sRGB skin tone
    val r = 180
    val g = 140
    val b = 120

    val lab = ReminiToneSkinEngine.rgbToLab(r, g, b)
    val origB = lab[2]

    // Warmth shifts b* by +4 * intensity
    val warmthShift = 4.0f * ReminiToneSkinEngine.REMINI_LOOK_INTENSITY
    val expectedShiftedB = origB + warmthShift

    // Clamping to sRGB gamut must not clip
    val clamped = ReminiToneSkinEngine.clampChromaToSrgbGamut(lab[0], lab[1], expectedShiftedB)
    val linRgb = ReminiToneSkinEngine.labToLinearRgb(lab[0], clamped[0], clamped[1])

    for (c in linRgb) {
      assertTrue("Gamut clamping must ensure linear RGB is within [0, 1]", c in -0.01f..1.01f)
    }
  }

  @Test
  fun testFaceRelight_BrighterAndPinkerInsideSkinMask() {
    // Test face relight (+5 L* and a* +2) inside the feathered skin mask
    val w = 100
    val h = 100
    val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    bmp.eraseColor(Color.rgb(180, 140, 120)) // Warm skin tone

    val faceBox = FaceDetectorOfflineHelper.DetectedFaceBox(
      rect = Rect(10, 10, 90, 90),
      eyeBounds = listOf(Rect(25, 35, 45, 50), Rect(55, 35, 75, 50)),
      lipBounds = listOf(Rect(35, 65, 65, 80))
    )

    val enhanced = ReminiToneSkinEngine.applyReminiLook(bmp, listOf(faceBox))
    assertEquals(100, enhanced.width)
    assertEquals(100, enhanced.height)

    // Center forehead skin pixel (x=50, y=28): inside feathered skin mask, away from eyes & lips
    val skinPixel = enhanced.getPixel(50, 28)
    val skinLab = ReminiToneSkinEngine.rgbToLab(Color.red(skinPixel), Color.green(skinPixel), Color.blue(skinPixel))

    // Background pixel outside face (x=5, y=5)
    val bgPixel = enhanced.getPixel(5, 5)
    val bgLab = ReminiToneSkinEngine.rgbToLab(Color.red(bgPixel), Color.green(bgPixel), Color.blue(bgPixel))

    // Face skin should be brighter (+L*) and pinker (+a*) than the background
    assertTrue("Face skin L* (${skinLab[0]}) should be brighter than background L* (${bgLab[0]})", skinLab[0] > bgLab[0])
    assertTrue("Face skin a* (${skinLab[1]}) should be pinker than background a* (${bgLab[1]})", skinLab[1] > bgLab[1])
  }

  @Test
  fun testNoVisibleRectangles_EyeAndSurroundingSkinContinuous() {
    // 5. Unit test: on a synthetic face image, mean L* of the eye region and of the skin ring
    // around it differ by no more than 6, and adjacent pixels along the former rectangle borders
    // never jump by more than 12 L*.
    val w = 120
    val h = 120
    val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    bmp.eraseColor(Color.rgb(180, 140, 120)) // Natural skin tone

    val eyeRect = Rect(30, 40, 50, 55)
    val faceBox = FaceDetectorOfflineHelper.DetectedFaceBox(
      rect = Rect(10, 10, 110, 110),
      eyeBounds = listOf(eyeRect, Rect(70, 40, 90, 55)),
      lipBounds = listOf(Rect(45, 75, 75, 90))
    )

    val enhanced = ReminiToneSkinEngine.applyReminiLook(bmp, listOf(faceBox))

    // Mean L* of the eye region
    var eyeSumL = 0.0
    var eyeCount = 0
    for (y in eyeRect.top until eyeRect.bottom) {
      for (x in eyeRect.left until eyeRect.right) {
        val p = enhanced.getPixel(x, y)
        eyeSumL += ReminiToneSkinEngine.rgbToLstar(Color.red(p), Color.green(p), Color.blue(p))
        eyeCount++
      }
    }
    val eyeMeanL = (eyeSumL / eyeCount).toFloat()

    // Mean L* of the skin ring around it (within 8 pixels margin)
    val ringRect = Rect(eyeRect.left - 8, eyeRect.top - 8, eyeRect.right + 8, eyeRect.bottom + 8)
    var ringSumL = 0.0
    var ringCount = 0
    for (y in ringRect.top until ringRect.bottom) {
      for (x in ringRect.left until ringRect.right) {
        if (!eyeRect.contains(x, y)) {
          val p = enhanced.getPixel(x, y)
          ringSumL += ReminiToneSkinEngine.rgbToLstar(Color.red(p), Color.green(p), Color.blue(p))
          ringCount++
        }
      }
    }
    val ringMeanL = (ringSumL / ringCount).toFloat()

    val diffMean = kotlin.math.abs(eyeMeanL - ringMeanL)
    assertTrue(
      "Mean L* of eye region ($eyeMeanL) and skin ring ($ringMeanL) must differ by no more than 6, was $diffMean",
      diffMean <= 6.0f
    )

    // Check adjacent pixel jumps along former rectangle borders
    var maxBorderJump = 0.0f

    for (x in eyeRect.left until eyeRect.right) {
      val pTopIn = enhanced.getPixel(x, eyeRect.top)
      val pTopOut = enhanced.getPixel(x, eyeRect.top - 1)
      val lTopIn = ReminiToneSkinEngine.rgbToLstar(Color.red(pTopIn), Color.green(pTopIn), Color.blue(pTopIn))
      val lTopOut = ReminiToneSkinEngine.rgbToLstar(Color.red(pTopOut), Color.green(pTopOut), Color.blue(pTopOut))
      val jumpTop = kotlin.math.abs(lTopIn - lTopOut)
      if (jumpTop > maxBorderJump) maxBorderJump = jumpTop

      val pBottomIn = enhanced.getPixel(x, eyeRect.bottom - 1)
      val pBottomOut = enhanced.getPixel(x, eyeRect.bottom)
      val lBottomIn = ReminiToneSkinEngine.rgbToLstar(Color.red(pBottomIn), Color.green(pBottomIn), Color.blue(pBottomIn))
      val lBottomOut = ReminiToneSkinEngine.rgbToLstar(Color.red(pBottomOut), Color.green(pBottomOut), Color.blue(pBottomOut))
      val jumpBottom = kotlin.math.abs(lBottomIn - lBottomOut)
      if (jumpBottom > maxBorderJump) maxBorderJump = jumpBottom
    }

    for (y in eyeRect.top until eyeRect.bottom) {
      val pLeftIn = enhanced.getPixel(eyeRect.left, y)
      val pLeftOut = enhanced.getPixel(eyeRect.left - 1, y)
      val lLeftIn = ReminiToneSkinEngine.rgbToLstar(Color.red(pLeftIn), Color.green(pLeftIn), Color.blue(pLeftIn))
      val lLeftOut = ReminiToneSkinEngine.rgbToLstar(Color.red(pLeftOut), Color.green(pLeftOut), Color.blue(pLeftOut))
      val jumpLeft = kotlin.math.abs(lLeftIn - lLeftOut)
      if (jumpLeft > maxBorderJump) maxBorderJump = jumpLeft

      val pRightIn = enhanced.getPixel(eyeRect.right - 1, y)
      val pRightOut = enhanced.getPixel(eyeRect.right, y)
      val lRightIn = ReminiToneSkinEngine.rgbToLstar(Color.red(pRightIn), Color.green(pRightIn), Color.blue(pRightIn))
      val lRightOut = ReminiToneSkinEngine.rgbToLstar(Color.red(pRightOut), Color.green(pRightOut), Color.blue(pRightOut))
      val jumpRight = kotlin.math.abs(lRightIn - lRightOut)
      if (jumpRight > maxBorderJump) maxBorderJump = jumpRight
    }

    assertTrue(
      "Adjacent pixels along former rectangle borders must never jump by more than 12 L*, max jump was $maxBorderJump",
      maxBorderJump <= 12.0f
    )
  }

  @Test
  fun testComputeDeltaEAndFaceShift_onlyCountsPixelsInsideFaceRect() {
    val orig = Bitmap.createBitmap(100, 100, Bitmap.Config.ARGB_8888)
    val enh = Bitmap.createBitmap(100, 100, Bitmap.Config.ARGB_8888)
    for (y in 0 until 100) {
      for (x in 0 until 100) {
        orig.setPixel(x, y, Color.rgb(120, 120, 120))
        enh.setPixel(x, y, Color.rgb(120, 120, 120))
      }
    }

    // Change a pixel on row y=50 outside the face rect (x=10, y=50)
    enh.setPixel(10, 50, Color.rgb(255, 255, 255))

    val faceBox = FaceDetectorOfflineHelper.DetectedFaceBox(
      rect = Rect(40, 40, 60, 60)
    )

    val (meanDeltaE, faceDeltaE) = ReminiToneSkinEngine.computeDeltaEAndFaceShift(orig, enh, listOf(faceBox))
    assertTrue("Overall meanDeltaE should be non-zero due to the changed pixel", meanDeltaE > 0f)
    assertEquals("faceDeltaE must be 0 because pixels inside face rect are identical", 0f, faceDeltaE, 0.0001f)
  }

  @Test
  fun testBlurOn160pxUpsampledTo1200_staysWithin2LstarOfFullSizeBlur() {
    val fullW = 1200
    val fullH = 1200
    val mask1200 = FloatArray(fullW * fullH)

    val cx = fullW / 2f
    val cy = fullH * 0.52f
    val rx = fullW * 0.44f
    val ry = fullH * 0.48f

    // Synthetic face oval mask with L* values ranging from 40 (background) to 70 (face center)
    for (y in 0 until fullH) {
      val ny = (y - cy) / ry
      val nySq = ny * ny
      val row = y * fullW
      for (x in 0 until fullW) {
        val nx = (x - cx) / rx
        val dist = nx * nx + nySq
        if (dist <= 1.0f) {
          val falloff = if (dist > 0.65f) ((1.0f - dist) / 0.35f).coerceIn(0f, 1f) else 1.0f
          mask1200[row + x] = 40f + 30f * falloff
        } else {
          mask1200[row + x] = 40f
        }
      }
    }

    // Hairline ramp top 15%
    val hairRampH = fullH * 0.15f
    val rampLimit = (fullH * 0.15f).toInt()
    for (y in 0 until rampLimit) {
      val ramp = (y / hairRampH).coerceIn(0f, 1f)
      val factor = ramp * ramp * (3f - 2f * ramp)
      val row = y * fullW
      for (x in 0 until fullW) {
        val delta = mask1200[row + x] - 40f
        mask1200[row + x] = 40f + delta * factor
      }
    }

    // Downscale to 160 px
    val dsW = 160
    val dsH = 160
    val mask160 = FloatArray(dsW * dsH)
    val scaleX = (fullW - 1).toFloat() / (dsW - 1)
    val scaleY = (fullH - 1).toFloat() / (dsH - 1)
    for (y in 0 until dsH) {
      val sy = (y * scaleY).toInt().coerceIn(0, fullH - 1)
      val sRow = sy * fullW
      val dRow = y * dsW
      for (x in 0 until dsW) {
        val sx = (x * scaleX).toInt().coerceIn(0, fullW - 1)
        mask160[dRow + x] = mask1200[sRow + sx]
      }
    }

    // Blur on 160px copy: radius = 160 * 0.12 = 19
    val blur160 = ReminiToneSkinEngine.gaussianBlurFloat(mask160, dsW, dsH, radius = 19)

    // Upsample 160px blurred field to 1200px
    val upsampledBlur = ReminiToneSkinEngine.upsampleBilinear(blur160, dsW, dsH, fullW, fullH)

    // Full-size blur on 1200px copy: radius = 1200 * 0.12 = 144
    val fullBlur = ReminiToneSkinEngine.gaussianBlurFloat(mask1200, fullW, fullH, radius = 144)

    // Compare within face mask region
    var maxLstarDiff = 0f
    var sumDiff = 0.0
    var count = 0

    // Sample across face area to test accuracy
    val step = 4
    for (y in 0 until fullH step step) {
      val row = y * fullW
      for (x in 0 until fullW step step) {
        val origVal = mask1200[row + x]
        if (origVal > 42f) { // Inside face area
          val diff = kotlin.math.abs(fullBlur[row + x] - upsampledBlur[row + x])
          if (diff > maxLstarDiff) maxLstarDiff = diff
          sumDiff += diff
          count++
        }
      }
    }

    val meanDiff = if (count > 0) sumDiff / count else 0.0
    assertTrue("A blur on the 160 px field upsampled to 1200 px stays within 2 L* of full-size blur (was max $maxLstarDiff, mean $meanDiff)", maxLstarDiff <= 2.0f)
  }

  @Test
  fun testProgressValues_areMonotonicNonDecreasing() {
    val w = 200
    val h = 200
    val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    for (y in 0 until h) {
      for (x in 0 until w) {
        bmp.setPixel(x, y, Color.rgb(130, 130, 130))
      }
    }

    val faceBox = FaceDetectorOfflineHelper.DetectedFaceBox(
      rect = Rect(40, 40, 160, 160)
    )

    val progressValues = mutableListOf<Float>()
    val progressDetails = mutableListOf<String>()

    ReminiToneSkinEngine.applyReminiLook(
      inputBitmap = bmp,
      faces = listOf(faceBox),
      onProgress = { pct, detail ->
        progressValues.add(pct)
        progressDetails.add(detail)
      }
    )

    assertTrue("Progress updates must be emitted during processing", progressValues.isNotEmpty())

    for (i in 0 until progressValues.size - 1) {
      val current = progressValues[i]
      val next = progressValues[i + 1]
      assertTrue(
        "Progress must be monotonic non-decreasing: step $i (${current} - ${progressDetails[i]}) > step ${i + 1} (${next} - ${progressDetails[i + 1]})",
        next >= current - 0.0001f
      )
    }

    // Verify progress values land within expected range (0.80 to 0.95)
    assertTrue("Start progress should be >= 0.80, was ${progressValues.first()}", progressValues.first() >= 0.80f)
    assertTrue("End progress should reach 0.95, was ${progressValues.last()}", progressValues.last() >= 0.95f)
  }

  @Test
  fun testPredictToneIntensity_detectsExcessiveShiftAndReducesTo80Percent() {
    val w = 100
    val h = 100
    val orig = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    for (y in 0 until h) {
      for (x in 0 until w) {
        orig.setPixel(x, y, Color.rgb(120, 120, 120))
      }
    }

    // Plan with extreme lift to trigger deltaE > 22
    val extremePlan = com.example.enhancer.engine.SmartAutoAnalyzer.EnhancePlan(
      exposureTarget = 95f,
      maxLift = 40f,
      castCorrectA = 15f,
      castCorrectB = 25f,
      warmth = 15f,
      chromaBoost = 0.50f,
      denoise = 0.3f,
      sharpen = 0.2f,
      runFaceStage = true,
      faceRelightScale = 2.0f,
      skinSmoothing = 0.5f,
      applyColor = true
    )

    val predicted = ReminiToneSkinEngine.predictToneIntensity(
      inputBitmap = orig,
      faces = emptyList(),
      plan = extremePlan
    )

    val expectedReduced = ReminiToneSkinEngine.REMINI_LOOK_INTENSITY * 0.80f
    assertEquals("Extreme shift must be predicted and reduced to 80% strength", expectedReduced, predicted, 0.001f)
  }
}
