package com.example

import android.content.Context
import android.graphics.Bitmap
import androidx.test.core.app.ApplicationProvider
import com.example.enhancer.engine.ModelManager
import com.example.enhancer.engine.OnnxModelEngine
import com.example.enhancer.model.EngineStatus
import com.example.enhancer.model.EnhancementConfig
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Lamini AI Studio", appName)
  }

  @Test
  fun testImageModelIsOptional_EngineStatusIsReadyWithoutModel() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val modelManager = ModelManager(context)
    val engine = OnnxModelEngine(context, modelManager)

    val readiness = engine.checkReadiness()
    assertTrue("Engine must be ready even without image model", readiness.isSuccess)

    val status = engine.getStatusInfo()
    assertEquals(EngineStatus.READY, status.status)
  }

  @Test
  fun testImageModelMissing_SkipsRealEsrganAndUsesFastPathWithoutError() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val modelManager = ModelManager(context)
    val engine = OnnxModelEngine(context, modelManager)

    val testBitmap = Bitmap.createBitmap(120, 120, Bitmap.Config.ARGB_8888)
    val result = engine.enhance(
      sourceBitmap = testBitmap,
      config = EnhancementConfig(faceEnhancement = false)
    ) {}

    assertTrue("Enhancement must succeed even when image model is missing", result.isSuccess)
    val outBitmap = result.getOrNull()
    assertNotNull("Output bitmap must not be null", outBitmap)
    assertFalse("Real-ESRGAN must be skipped when image model is not installed", engine.lastRealEsrganRan)
  }
}

