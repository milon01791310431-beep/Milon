APK বানানোর নিয়ম
1. সব ফাইল (লুকানো .github ফোল্ডারসহ) GitHub রিপোতে আপলোড করো।
2. Actions ট্যাবে "Build Android APK" চলবে। শেষে রানের পাতার নিচে Artifacts থেকে APK নামাও।
   (প্রথমবার বিল্ডে AI মডেল (~৬৭ MB) GitHub থেকে নামিয়ে APK-র ভেতরে ঢোকানো হয়, তাই একটু বেশি সময় লাগে।)
3. Release APK (ঐচ্ছিক): Settings > Secrets and variables > Actions এ চারটি secret দাও:
   KEYSTORE_BASE64, KEYSTORE_PASSWORD, KEY_ALIAS, KEY_PASSWORD
   তারপর Actions > Run workflow থেকে release বেছে নাও, অথবা v1.0.0 নামে ট্যাগ করো (GitHub Release-এও APK উঠবে)।
   secret না থাকলে শুধু debug APK বানাবে, কোনো এরর দেবে না।

ভয়েস সেপারেশন (গান থেকে মিউজিক আলাদা করা)
- মডেল: MDX-Net "UVR-MDX-NET-Voc_FT" (Ultimate Vocal Remover প্রজেক্টের ওপেন মডেল)।
- সবকিছু ফোনের ভেতরেই চলে (ONNX Runtime, নেটিভ)। কোনো সার্ভারে কিছু যায় না, অ্যাপ চালাতে ইন্টারনেট লাগে না।
- মডেল ফাইল রিপোতে থাকে না (বড় বলে); বিল্ডের সময় tools/fetch_model.py সেটা নামায়, SHA-256 মিলিয়ে দেখে এবং
  app/src/main/assets/models/ ফোল্ডারে বসায়। নিজের পিসিতে বিল্ড করলে আগে চালাও:  python3 tools/fetch_model.py
- মান: "স্ট্যান্ডার্ড" ও "সর্বোচ্চ" (চাঙ্কগুলো ৫০% ওভারল্যাপ করে জোড়া লাগায়, সময় প্রায় দ্বিগুণ)।
- মডেল না পেলে বা কোনো ফোনে চালু না হলে অ্যাপ নিজে থেকে হালকা Spleeter ব্যাকআপ মডেলে (spl_*.bin) চলে যায়,
  আর কারণটা স্ক্রিনে লিখে দেয়।
- ফোনে লাগে মোটামুটি ১ GB ফাঁকা RAM; প্রসেসিং চলার সময় স্ক্রিন চালু থাকে।
