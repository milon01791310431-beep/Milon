"""Minimal TensorFlow checkpoint (V2 bundle) reader — no TensorFlow needed."""
import struct, numpy as np

def varint(b, p):
    r = 0; s = 0
    while True:
        c = b[p]; p += 1
        r |= (c & 0x7f) << s; s += 7
        if not c & 0x80: return r, p

def snappy_decompress(b):
    n, p = varint(b, 0); out = bytearray()
    while p < len(b):
        t = b[p]; p += 1; k = t & 3
        if k == 0:
            ln = t >> 2
            if ln >= 60:
                nb = ln - 59; ln = int.from_bytes(b[p:p+nb], 'little'); p += nb
            ln += 1; out += b[p:p+ln]; p += ln
        else:
            if k == 1:
                ln = ((t >> 2) & 7) + 4; off = ((t >> 5) << 8) | b[p]; p += 1
            elif k == 2:
                ln = (t >> 2) + 1; off = int.from_bytes(b[p:p+2], 'little'); p += 2
            else:
                ln = (t >> 2) + 1; off = int.from_bytes(b[p:p+4], 'little'); p += 4
            for _ in range(ln): out.append(out[-off])
    assert len(out) == n
    return bytes(out)

def read_block(f, off, size):
    blk = f[off:off+size]; typ = f[off+size]
    return snappy_decompress(blk) if typ == 1 else bytes(blk)

def block_entries(blk):
    nres = struct.unpack('<I', blk[-4:])[0]
    end = len(blk) - 4 - 4 * nres
    p = 0; key = b''
    while p < end:
        sh, p = varint(blk, p); ns, p = varint(blk, p); vl, p = varint(blk, p)
        key = key[:sh] + blk[p:p+ns]; p += ns
        val = blk[p:p+vl]; p += vl
        yield key, val

def parse_msg(b):
    p = 0; d = {}
    while p < len(b):
        tag, p = varint(b, p); f, w = tag >> 3, tag & 7
        if w == 0: v, p = varint(b, p)
        elif w == 2:
            l, p = varint(b, p); v = b[p:p+l]; p += l
        elif w == 5: v = b[p:p+4]; p += 4
        elif w == 1: v = b[p:p+8]; p += 8
        d.setdefault(f, []).append(v)
    return d

def handle(b, p):
    o, p = varint(b, p); s, p = varint(b, p); return o, s, p

def read_checkpoint(prefix):
    idx = open(prefix + '.index', 'rb').read()
    data = open(prefix + '.data-00000-of-00001', 'rb').read()
    foot = idx[-48:]
    p = 0
    _, _, p = handle(foot, p)            # metaindex
    io, isz, p = handle(foot, p)         # index
    out = {}
    for _, hv in block_entries(read_block(idx, io, isz)):
        o, s, _ = handle(hv, 0)
        for k, v in block_entries(read_block(idx, o, s)):
            if not k: continue
            m = parse_msg(v)
            dt = m.get(1, [0])[0]
            shape = []
            if 2 in m:
                for dim in parse_msg(m[2][0]).get(2, []):
                    shape.append(parse_msg(dim).get(1, [0])[0])
            off = m.get(4, [0])[0]; size = m.get(5, [0])[0]
            if dt != 1: continue
            out[k.decode()] = np.frombuffer(data[off:off+size], '<f4').reshape(shape).copy()
    return out

if __name__ == '__main__':
    import sys
    t = read_checkpoint(sys.argv[1])
    for k in sorted(t): print(k, t[k].shape)
    print(len(t), 'tensors')
