"""Spleeter 2stems TF checkpoint -> compact binary for the Android app.

Layout of each file (little endian):
  magic 'SPL2' | u32 version(1)
  one model (spl_vocals.bin = vocals, spl_accomp.bin = accompaniment):
    for k in 0..5   encoder : W[5,5,cin,cout] f16 | bias[cout] f32 | bn_scale[cout] f32 | bn_shift[cout] f32
    for k in 0..5   decoder : W[5,5,cout,cin] f16 | bias[cout] f32 | bn_scale[cout] f32 | bn_shift[cout] f32
    final: W[4,4,1,2] f16 | bias[2] f32
BN (inference) folded to y = x*scale + shift, scale=gamma/sqrt(var+1e-3), shift=beta-mean*scale
"""
import sys, struct, numpy as np
sys.path.insert(0, __file__.rsplit('/', 1)[0])
from tfckpt import read_checkpoint

EPS = 1e-3

def bn(t, i):
    n = 'batch_normalization' + ('' if i == 0 else '_%d' % i)
    g, b, m, v = (t[n + '/' + s] for s in ('gamma', 'beta', 'moving_mean', 'moving_variance'))
    sc = g / np.sqrt(v + EPS)
    return sc.astype('<f4'), (b - m * sc).astype('<f4')

def model_tensors(t, base):
    """base = 0 for vocals, 1 for accompaniment. Returns dict of arrays (float32)."""
    o = {}
    c0 = 7 * base          # conv2d index offset (7 convs per model)
    d0 = 6 * base          # conv2d_transpose offset
    b0 = 12 * base         # batch_normalization offset
    cn = lambda i: 'conv2d' + ('' if i == 0 else '_%d' % i)
    dn = lambda i: 'conv2d_transpose' + ('' if i == 0 else '_%d' % i)
    for k in range(6):
        o['e%dW' % k] = t[cn(c0 + k) + '/kernel']; o['e%db' % k] = t[cn(c0 + k) + '/bias']
        o['e%ds' % k], o['e%dh' % k] = bn(t, b0 + k)
    for k in range(6):
        o['d%dW' % k] = t[dn(d0 + k) + '/kernel']; o['d%db' % k] = t[dn(d0 + k) + '/bias']
        o['d%ds' % k], o['d%dh' % k] = bn(t, b0 + 6 + k)
    o['fW'] = t[cn(c0 + 6) + '/kernel']; o['fb'] = t[cn(c0 + 6) + '/bias']
    return o

def main(ckpt, outdir):
    """Writes spl_vocals.bin and spl_accomp.bin (each < 25 MB so they fit GitHub's web uploader)."""
    t = read_checkpoint(ckpt)
    for base, name in ((0, 'spl_vocals.bin'), (1, 'spl_accomp.bin')):
        m = model_tensors(t, base)
        with open(outdir.rstrip('/') + '/' + name, 'wb') as f:
            f.write(b'SPL2' + struct.pack('<I', 1))
            for pre in ('e', 'd'):          # 6 encoders first, then 6 decoders
                for k in range(6):
                    f.write(m['%s%dW' % (pre, k)].astype('<f2').tobytes())
                    for s_ in 'bsh': f.write(m['%s%d%s' % (pre, k, s_)].astype('<f4').tobytes())
            f.write(m['fW'].astype('<f2').tobytes()); f.write(m['fb'].astype('<f4').tobytes())
        print('wrote', name)

if __name__ == '__main__':
    main(sys.argv[1], sys.argv[2])
