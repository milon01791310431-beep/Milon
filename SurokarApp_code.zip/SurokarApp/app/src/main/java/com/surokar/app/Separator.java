package com.surokar.app;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.IntConsumer;

/**
 * On-device vocal separator: Spleeter (2 stems) U-Net, re-implemented in plain Java.
 * No network, no native libraries. Input/output: 44.1 kHz, 16-bit, interleaved stereo PCM files.
 */
public class Separator {

    public interface Progress {
        void update(float fraction);
        boolean cancelled();
    }

    static final int N = 4096, HOP = 1024, T = 512, F = 1024;
    static final int CTX = 32;                 // context frames on each side of a chunk
    static final int STEP = T - 2 * CTX;       // frames kept per chunk (448 ≈ 10.4 s)
    static final int[] ECI = {2, 16, 32, 64, 128, 256}, ECO = {16, 32, 64, 128, 256, 512};
    static final int[] DCI = {512, 512, 256, 128, 64, 32}, DCO = {256, 128, 64, 32, 16, 1};
    static final int MAXW = 25 * 256 * 512;

    static final float[] HALF = new float[65536];
    static {
        for (int h = 0; h < 65536; h++) {
            int s = h >>> 15, e = (h >>> 10) & 31, m = h & 1023;
            float v;
            if (e == 0) v = m * (1f / 16777216f);
            else if (e == 31) v = m == 0 ? Float.POSITIVE_INFINITY : Float.NaN;
            else v = Float.intBitsToFloat(((e - 15 + 127) << 23) | (m << 13));
            HALF[h] = s == 0 ? v : -v;
        }
    }

    static final class Layer { short[] w; float[] b, s, h; }
    static final class Model { Layer[] enc = new Layer[6], dec = new Layer[6]; short[] fw; float[] fb; }

    private final Model[] models = new Model[2];
    private final int nThreads;
    private final ExecutorService pool;
    private final ThreadLocal<float[][]> tlAcc = ThreadLocal.withInitial(() -> new float[4][512]);
    private final float[] wf = new float[MAXW];

    // network workspace (reused for every chunk and both models)
    private final float[][] c = new float[6][];
    private final float[] rb = new float[256 * 512 * 16];
    private final float[][] m = new float[5][];
    private final float[] u5 = new float[T * F];

    // FFT
    private final float[] cosT = new float[N / 2], sinT = new float[N / 2], win = new float[N];
    private final int[] rev = new int[N];

    // ---------------------------------------------------------------- loading
    public Separator(InputStream vocals, InputStream accomp) throws IOException {
        int cores = Runtime.getRuntime().availableProcessors();
        nThreads = Math.max(1, Math.min(cores, 6));
        pool = nThreads > 1 ? Executors.newFixedThreadPool(nThreads, r -> {
            Thread t = new Thread(r, "sep-worker"); t.setDaemon(true); return t;
        }) : null;

        InputStream[] ins = {vocals, accomp};
        for (int k = 0; k < 2; k++) {
            InputStream in = ins[k];
            byte[] hdr = new byte[8];
            readFully(in, hdr, 8);
            if (hdr[0] != 'S' || hdr[1] != 'P' || hdr[2] != 'L' || hdr[3] != '2') throw new IOException("bad model file");
            Model md = new Model();
            for (int i = 0; i < 6; i++) md.enc[i] = readLayer(in, ECI[i], ECO[i], false);
            for (int i = 0; i < 6; i++) md.dec[i] = readLayer(in, DCI[i], DCO[i], true);
            md.fw = readShorts(in, 32);
            md.fb = readFloats(in, 2);
            models[k] = md;
        }
        c[0] = new float[256 * 512 * 16]; c[1] = new float[128 * 256 * 32]; c[2] = new float[64 * 128 * 64];
        c[3] = new float[32 * 64 * 128]; c[4] = new float[16 * 32 * 256]; c[5] = new float[8 * 16 * 512];
        m[0] = new float[16 * 32 * 512]; m[1] = new float[32 * 64 * 256]; m[2] = new float[64 * 128 * 128];
        m[3] = new float[128 * 256 * 64]; m[4] = new float[256 * 512 * 32];

        for (int i = 0; i < N / 2; i++) {
            cosT[i] = (float) Math.cos(2 * Math.PI * i / N);
            sinT[i] = (float) -Math.sin(2 * Math.PI * i / N);
        }
        int lg = 12;
        for (int i = 0; i < N; i++) {
            int r = 0;
            for (int b = 0; b < lg; b++) if ((i >> b & 1) != 0) r |= 1 << (lg - 1 - b);
            rev[i] = r;
        }
        for (int i = 0; i < N; i++) win[i] = (float) (0.5 - 0.5 * Math.cos(2 * Math.PI * i / N));
    }

    public void close() { if (pool != null) pool.shutdownNow(); }

    private static Layer readLayer(InputStream in, int ci, int co, boolean dec) throws IOException {
        Layer l = new Layer();
        short[] w = readShorts(in, 25 * ci * co);
        if (dec) {   // file: [kh][kw][co][ci]  ->  [kh][kw][ci][co]
            short[] t = new short[w.length];
            for (int kk = 0; kk < 25; kk++)
                for (int o = 0; o < co; o++)
                    for (int cc = 0; cc < ci; cc++) t[(kk * ci + cc) * co + o] = w[(kk * co + o) * ci + cc];
            w = t;
        }
        l.w = w;
        l.b = readFloats(in, co); l.s = readFloats(in, co); l.h = readFloats(in, co);
        return l;
    }

    private static void readFully(InputStream in, byte[] b, int len) throws IOException {
        int o = 0;
        while (o < len) { int r = in.read(b, o, len - o); if (r < 0) throw new IOException("model file too short"); o += r; }
    }

    private static short[] readShorts(InputStream in, int n) throws IOException {
        short[] out = new short[n];
        byte[] buf = new byte[1 << 16];
        int done = 0;
        while (done < n) {
            int cnt = Math.min(n - done, buf.length / 2);
            readFully(in, buf, cnt * 2);
            ByteBuffer.wrap(buf, 0, cnt * 2).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(out, done, cnt);
            done += cnt;
        }
        return out;
    }

    private static float[] readFloats(InputStream in, int n) throws IOException {
        float[] out = new float[n];
        byte[] buf = new byte[n * 4];
        readFully(in, buf, n * 4);
        ByteBuffer.wrap(buf).order(ByteOrder.LITTLE_ENDIAN).asFloatBuffer().get(out);
        return out;
    }

    // ---------------------------------------------------------------- parallel helper
    private void par(int n, IntConsumer body) {
        if (pool == null || n < 2) { for (int i = 0; i < n; i++) body.accept(i); return; }
        final AtomicInteger next = new AtomicInteger();
        Future<?>[] fs = new Future<?>[nThreads];
        for (int t = 0; t < nThreads; t++)
            fs[t] = pool.submit(() -> { int i; while ((i = next.getAndIncrement()) < n) body.accept(i); });
        try { for (Future<?> f : fs) f.get(); }
        catch (Exception e) { throw new RuntimeException(e); }
    }

    private void toFloat(short[] w, int len) { for (int i = 0; i < len; i++) wf[i] = HALF[w[i] & 0xffff]; }

    // ---------------------------------------------------------------- layers
    /** Accumulate one (kh,kw) tap for 4 output pixels at once, so every weight row is read once for 4 pixels. */
    private static void macTile(float[] in, int i0, int i1, int i2, int i3, int ci, float[] w, int wb, int co,
                                float[] A0, float[] A1, float[] A2, float[] A3) {
        int cc = 0;
        for (; cc + 3 < ci; cc += 4) {
            int w0 = wb + cc * co, w1 = w0 + co, w2 = w1 + co, w3 = w2 + co;
            float a00 = i0 >= 0 ? in[i0 + cc] : 0f, a01 = i0 >= 0 ? in[i0 + cc + 1] : 0f, a02 = i0 >= 0 ? in[i0 + cc + 2] : 0f, a03 = i0 >= 0 ? in[i0 + cc + 3] : 0f;
            float a10 = i1 >= 0 ? in[i1 + cc] : 0f, a11 = i1 >= 0 ? in[i1 + cc + 1] : 0f, a12 = i1 >= 0 ? in[i1 + cc + 2] : 0f, a13 = i1 >= 0 ? in[i1 + cc + 3] : 0f;
            float a20 = i2 >= 0 ? in[i2 + cc] : 0f, a21 = i2 >= 0 ? in[i2 + cc + 1] : 0f, a22 = i2 >= 0 ? in[i2 + cc + 2] : 0f, a23 = i2 >= 0 ? in[i2 + cc + 3] : 0f;
            float a30 = i3 >= 0 ? in[i3 + cc] : 0f, a31 = i3 >= 0 ? in[i3 + cc + 1] : 0f, a32 = i3 >= 0 ? in[i3 + cc + 2] : 0f, a33 = i3 >= 0 ? in[i3 + cc + 3] : 0f;
            for (int o = 0; o < co; o++) {
                float x0 = w[w0 + o], x1 = w[w1 + o], x2 = w[w2 + o], x3 = w[w3 + o];
                A0[o] += a00 * x0 + a01 * x1 + a02 * x2 + a03 * x3;
                A1[o] += a10 * x0 + a11 * x1 + a12 * x2 + a13 * x3;
                A2[o] += a20 * x0 + a21 * x1 + a22 * x2 + a23 * x3;
                A3[o] += a30 * x0 + a31 * x1 + a32 * x2 + a33 * x3;
            }
        }
        for (; cc < ci; cc++) {
            int wo = wb + cc * co;
            float a0 = i0 >= 0 ? in[i0 + cc] : 0f, a1 = i1 >= 0 ? in[i1 + cc] : 0f, a2 = i2 >= 0 ? in[i2 + cc] : 0f, a3 = i3 >= 0 ? in[i3 + cc] : 0f;
            for (int o = 0; o < co; o++) {
                float x = w[wo + o];
                A0[o] += a0 * x; A1[o] += a1 * x; A2[o] += a2 * x; A3[o] += a3 * x;
            }
        }
    }

    /** 5x5 conv, stride 2, TF 'SAME' (pad top/left 1). in [H,W,ci] -> out [H/2,W/2,co]. Wo must be a multiple of 4. */
    private void conv(float[] in, int H, int W, int ci, int co, float[] bias, float[] out) {
        final int Ho = H / 2, Wo = W / 2;
        final float[] w = wf;
        par(Ho, oh -> {
            float[][] ac = tlAcc.get();
            float[] A0 = ac[0], A1 = ac[1], A2 = ac[2], A3 = ac[3];
            for (int ow0 = 0; ow0 < Wo; ow0 += 4) {
                System.arraycopy(bias, 0, A0, 0, co); System.arraycopy(bias, 0, A1, 0, co);
                System.arraycopy(bias, 0, A2, 0, co); System.arraycopy(bias, 0, A3, 0, co);
                for (int kh = 0; kh < 5; kh++) {
                    int ih = 2 * oh + kh - 1; if (ih < 0 || ih >= H) continue;
                    for (int kw = 0; kw < 5; kw++) {
                        int j0 = 2 * ow0 + kw - 1, j1 = j0 + 2, j2 = j0 + 4, j3 = j0 + 6;
                        int i0 = (j0 >= 0 && j0 < W) ? (ih * W + j0) * ci : -1;
                        int i1 = (j1 >= 0 && j1 < W) ? (ih * W + j1) * ci : -1;
                        int i2 = (j2 >= 0 && j2 < W) ? (ih * W + j2) * ci : -1;
                        int i3 = (j3 >= 0 && j3 < W) ? (ih * W + j3) * ci : -1;
                        if (i0 < 0 && i1 < 0 && i2 < 0 && i3 < 0) continue;
                        macTile(in, i0, i1, i2, i3, ci, w, (kh * 5 + kw) * ci * co, co, A0, A1, A2, A3);
                    }
                }
                int ob = (oh * Wo + ow0) * co;
                System.arraycopy(A0, 0, out, ob, co); System.arraycopy(A1, 0, out, ob + co, co);
                System.arraycopy(A2, 0, out, ob + 2 * co, co); System.arraycopy(A3, 0, out, ob + 3 * co, co);
            }
        });
    }

    /**
     * 5x5 transposed conv, stride 2, TF 'SAME'. in [H,W,ci] -> out [2H,2W,co], written with pixel stride ost
     * at channel offset ooff. W must be a multiple of 4. Output pixels are grouped by column parity so that
     * 4 consecutive ones share the same kernel taps.
     */
    private void deconv(float[] in, int H, int W, int ci, int co, float[] bias, float[] out, int ost, int ooff) {
        final int Ho = 2 * H, Wo = 2 * W;
        final float[] w = wf;
        if (co == 1) {
            par(Ho, oh -> {
                for (int ow = 0; ow < Wo; ow++) {
                    float s = bias[0];
                    for (int kh = 0; kh < 5; kh++) {
                        int t = oh + 1 - kh; if (t < 0 || (t & 1) != 0) continue; int ih = t >> 1; if (ih >= H) continue;
                        for (int kw = 0; kw < 5; kw++) {
                            int u = ow + 1 - kw; if (u < 0 || (u & 1) != 0) continue; int iw = u >> 1; if (iw >= W) continue;
                            int ib = (ih * W + iw) * ci, wb = (kh * 5 + kw) * ci;
                            for (int cc = 0; cc < ci; cc++) s += in[ib + cc] * w[wb + cc];
                        }
                    }
                    out[(oh * Wo + ow) * ost + ooff] = s;
                }
            });
            return;
        }
        par(Ho, oh -> {
            float[][] ac = tlAcc.get();
            float[] A0 = ac[0], A1 = ac[1], A2 = ac[2], A3 = ac[3];
            for (int p = 0; p < 2; p++) {
                for (int q0 = 0; q0 < W; q0 += 4) {
                    System.arraycopy(bias, 0, A0, 0, co); System.arraycopy(bias, 0, A1, 0, co);
                    System.arraycopy(bias, 0, A2, 0, co); System.arraycopy(bias, 0, A3, 0, co);
                    for (int kh = 0; kh < 5; kh++) {
                        int t = oh + 1 - kh; if (t < 0 || (t & 1) != 0) continue; int ih = t >> 1; if (ih >= H) continue;
                        for (int kw = (p == 0 ? 1 : 0); kw < 5; kw += 2) {
                            int sh = (p + 1 - kw) / 2;
                            int j0 = q0 + sh, j1 = j0 + 1, j2 = j0 + 2, j3 = j0 + 3;
                            int i0 = (j0 >= 0 && j0 < W) ? (ih * W + j0) * ci : -1;
                            int i1 = (j1 >= 0 && j1 < W) ? (ih * W + j1) * ci : -1;
                            int i2 = (j2 >= 0 && j2 < W) ? (ih * W + j2) * ci : -1;
                            int i3 = (j3 >= 0 && j3 < W) ? (ih * W + j3) * ci : -1;
                            if (i0 < 0 && i1 < 0 && i2 < 0 && i3 < 0) continue;
                            macTile(in, i0, i1, i2, i3, ci, w, (kh * 5 + kw) * ci * co, co, A0, A1, A2, A3);
                        }
                    }
                    for (int j = 0; j < 4; j++) {
                        float[] A = j == 0 ? A0 : j == 1 ? A1 : j == 2 ? A2 : A3;
                        int ow = 2 * (q0 + j) + p;
                        System.arraycopy(A, 0, out, (oh * Wo + ow) * ost + ooff, co);
                    }
                }
            }
        });
    }

    /** x0 [T,F,2] magnitude -> mask [T,F,2] in (0,1) */
    float[] net(Model md, float[] x0, float[] mask) {
        int H = T, W = F;
        float[] cur = x0;
        for (int k = 0; k < 6; k++) {
            Layer l = md.enc[k];
            toFloat(l.w, 25 * ECI[k] * ECO[k]);
            conv(cur, H, W, ECI[k], ECO[k], l.b, c[k]);
            H /= 2; W /= 2;
            if (k < 5) {                         // BN + LeakyReLU(0.2) -> input of next layer
                int co = ECO[k], px = H * W; float[] s = l.s, h = l.h, src = c[k];
                for (int p = 0; p < px; p++) {
                    int b = p * co;
                    for (int o = 0; o < co; o++) { float v = src[b + o] * s[o] + h[o]; rb[b + o] = v > 0 ? v : 0.2f * v; }
                }
                cur = rb;
            }
        }
        // decoder; skip connections use the raw (pre-BN) conv outputs
        cur = c[5];
        for (int k = 0; k < 5; k++) {
            Layer l = md.dec[k];
            int co = DCO[k], ci = DCI[k];
            float[] mk = m[k];
            int skipCh = co, ost = 2 * co, Ho = 2 * H, Wo = 2 * W, px = Ho * Wo;
            toFloat(l.w, 25 * ci * co);
            float[] skip = c[4 - k];
            for (int p = 0; p < px; p++) System.arraycopy(skip, p * skipCh, mk, p * ost, skipCh);
            deconv(cur, H, W, ci, co, l.b, mk, ost, skipCh);
            float[] s = l.s, h = l.h;
            for (int p = 0; p < px; p++) {
                int b = p * ost + skipCh;
                for (int o = 0; o < co; o++) { float v = mk[b + o]; if (v < 0) v = 0; mk[b + o] = v * s[o] + h[o]; }
            }
            cur = mk; H = Ho; W = Wo;
        }
        Layer l = md.dec[5];
        toFloat(l.w, 25 * DCI[5] * DCO[5]);
        deconv(cur, H, W, DCI[5], 1, l.b, u5, 1, 0);
        H *= 2; W *= 2;
        float sc = l.s[0], sh = l.h[0];
        for (int p = 0; p < H * W; p++) { float v = u5[p]; if (v < 0) v = 0; u5[p] = v * sc + sh; }
        // final 4x4 conv, dilation 2, 'same' -> 2 channels, sigmoid
        final short[] fw = md.fw; final float[] fb = md.fb; final int HH = H, WW = W;
        final float[] fwf = new float[32];
        for (int i = 0; i < 32; i++) fwf[i] = HALF[fw[i] & 0xffff];
        par(HH, oh -> {
            for (int ow = 0; ow < WW; ow++) {
                float z0 = fb[0], z1 = fb[1];
                for (int kh = 0; kh < 4; kh++) {
                    int ih = oh + 2 * kh - 3; if (ih < 0 || ih >= HH) continue;
                    for (int kw = 0; kw < 4; kw++) {
                        int iw = ow + 2 * kw - 3; if (iw < 0 || iw >= WW) continue;
                        float a = u5[ih * WW + iw]; int wo = (kh * 4 + kw) * 2;
                        z0 += a * fwf[wo]; z1 += a * fwf[wo + 1];
                    }
                }
                int o = (oh * WW + ow) * 2;
                mask[o] = (float) (1.0 / (1.0 + Math.exp(-z0)));
                mask[o + 1] = (float) (1.0 / (1.0 + Math.exp(-z1)));
            }
        });
        return mask;
    }

    /** test hook */
    float[] debugMask(int model, float[] x0) { return net(models[model], x0, new float[T * F * 2]); }

    // ---------------------------------------------------------------- FFT
    private void fft(float[] re, float[] im, boolean inverse) {
        for (int i = 0; i < N; i++) {
            int j = rev[i];
            if (j > i) { float t = re[i]; re[i] = re[j]; re[j] = t; t = im[i]; im[i] = im[j]; im[j] = t; }
        }
        for (int len = 2; len <= N; len <<= 1) {
            int h = len >> 1, st = N / len;
            for (int i = 0; i < N; i += len) {
                for (int j = 0, k = 0; j < h; j++, k += st) {
                    float wr = cosT[k], wi = inverse ? -sinT[k] : sinT[k];
                    int a = i + j, b = a + h;
                    float xr = re[b] * wr - im[b] * wi, xi = re[b] * wi + im[b] * wr;
                    re[b] = re[a] - xr; im[b] = im[a] - xi; re[a] += xr; im[a] += xi;
                }
            }
        }
    }

    // ---------------------------------------------------------------- main pipeline
    /**
     * @param inPcm  16-bit little-endian interleaved stereo, 44100 Hz
     * @param outPcm same format (vocals only)
     */
    public void separate(File inPcm, File outPcm, Progress prog) throws IOException {
        final int n = (int) (inPcm.length() / 4);
        if (n < 1) throw new IOException("empty input");
        final int FR = (n + HOP - 1) / HOP;
        final int nChunks = (FR + STEP - 1) / STEP;

        final float[] x0 = new float[T * F * 2];
        final float[] mv = new float[T * F * 2], ma = new float[T * F * 2];
        final float[][] sRe = new float[2][T * F], sIm = new float[2][T * F];
        final int regionLen = (T - 1) * HOP + N;
        final float[][] reg = new float[2][regionLen];
        final byte[] rbuf = new byte[regionLen * 4];
        final int accLen = STEP * HOP + (N - HOP);
        final float[][] acc = new float[2][accLen];
        final float[] den = new float[accLen];
        final float[] zr = new float[N], zi = new float[N];
        final byte[] obuf = new byte[STEP * HOP * 4];

        try (RandomAccessFile raf = new RandomAccessFile(inPcm, "r");
             OutputStream os = new BufferedOutputStream(new FileOutputStream(outPcm), 1 << 16)) {

            for (int ci = 0, s = 0; s < FR; s += STEP, ci++) {
                if (prog.cancelled()) throw new IOException("cancelled");
                final int c0 = s - CTX;

                // ---- read PCM region [c0*HOP, c0*HOP + regionLen)
                long a = (long) c0 * HOP;
                java.util.Arrays.fill(reg[0], 0f); java.util.Arrays.fill(reg[1], 0f);
                long from = Math.max(a, 0), to = Math.min(a + regionLen, n);
                if (to > from) {
                    int cnt = (int) (to - from);
                    raf.seek(from * 4);
                    raf.readFully(rbuf, 0, cnt * 4);
                    int off = (int) (from - a);
                    for (int i = 0; i < cnt; i++) {
                        int p = i * 4;
                        reg[0][off + i] = (short) ((rbuf[p] & 0xff) | (rbuf[p + 1] << 8)) * (1f / 32768f);
                        reg[1][off + i] = (short) ((rbuf[p + 2] & 0xff) | (rbuf[p + 3] << 8)) * (1f / 32768f);
                    }
                }

                // ---- STFT (L in real part, R in imaginary part of one complex FFT)
                for (int t = 0; t < T; t++) {
                    int f = c0 + t;
                    if (f < 0 || f >= FR) {
                        for (int k = 0; k < F; k++) {
                            int o = t * F + k;
                            sRe[0][o] = sIm[0][o] = sRe[1][o] = sIm[1][o] = 0f;
                            x0[o * 2] = 0f; x0[o * 2 + 1] = 0f;
                        }
                        continue;
                    }
                    int base = t * HOP;
                    for (int i = 0; i < N; i++) { zr[i] = reg[0][base + i] * win[i]; zi[i] = reg[1][base + i] * win[i]; }
                    fft(zr, zi, false);
                    for (int k = 0; k < F; k++) {
                        int k2 = (N - k) & (N - 1), o = t * F + k;
                        float lr = (zr[k] + zr[k2]) * .5f, li = (zi[k] - zi[k2]) * .5f;
                        float rr = (zi[k] + zi[k2]) * .5f, ri = -(zr[k] - zr[k2]) * .5f;
                        sRe[0][o] = lr; sIm[0][o] = li; sRe[1][o] = rr; sIm[1][o] = ri;
                        x0[o * 2] = (float) Math.sqrt(lr * lr + li * li);
                        x0[o * 2 + 1] = (float) Math.sqrt(rr * rr + ri * ri);
                    }
                }

                prog.update((ci + 0.05f) / nChunks);
                net(models[0], x0, mv);
                prog.update((ci + 0.50f) / nChunks);
                if (prog.cancelled()) throw new IOException("cancelled");
                net(models[1], x0, ma);
                prog.update((ci + 0.92f) / nChunks);

                // ---- ratio mask (separation exponent 2) + synthesis
                final int keep = Math.min(STEP, FR - s);
                for (int t = CTX; t < CTX + keep; t++) {
                    java.util.Arrays.fill(zr, 0f); java.util.Arrays.fill(zi, 0f);
                    for (int k = 0; k < F; k++) {
                        int o = t * F + k, q = o * 2;
                        float pv0 = mv[q] * x0[q], pa0 = ma[q] * x0[q];
                        float pv1 = mv[q + 1] * x0[q + 1], pa1 = ma[q + 1] * x0[q + 1];
                        float r0 = (pv0 * pv0 + 5e-11f) / (pv0 * pv0 + pa0 * pa0 + 1e-10f);
                        float r1 = (pv1 * pv1 + 5e-11f) / (pv1 * pv1 + pa1 * pa1 + 1e-10f);
                        float lr = sRe[0][o] * r0, li = sIm[0][o] * r0, rr = sRe[1][o] * r1, ri = sIm[1][o] * r1;
                        if (k == 0) { zr[0] = lr; zi[0] = rr; }
                        else {
                            zr[k] = lr - ri; zi[k] = li + rr;
                            zr[N - k] = lr + ri; zi[N - k] = rr - li;
                        }
                    }
                    fft(zr, zi, true);
                    int off = (t - CTX) * HOP;
                    float inv = 1f / N;
                    for (int i = 0; i < N; i++) {
                        float w = win[i];
                        acc[0][off + i] += zr[i] * inv * w;
                        acc[1][off + i] += zi[i] * inv * w;
                        den[off + i] += w * w;
                    }
                }

                // ---- finalize samples that no later frame will touch
                final boolean last = s + STEP >= FR;
                int outCount = last ? (int) (n - (long) s * HOP) : STEP * HOP;
                outCount = Math.min(outCount, STEP * HOP + (N - HOP));
                for (int i = 0; i < outCount; i++) {
                    float d = Math.max(den[i], 0.25f);
                    int l = Math.round(Math.max(-1f, Math.min(1f, acc[0][i] / d)) * 32767f);
                    int r = Math.round(Math.max(-1f, Math.min(1f, acc[1][i] / d)) * 32767f);
                    int p = i * 4;
                    obuf[p] = (byte) l; obuf[p + 1] = (byte) (l >> 8); obuf[p + 2] = (byte) r; obuf[p + 3] = (byte) (r >> 8);
                }
                os.write(obuf, 0, outCount * 4);
                if (!last) {
                    int tail = N - HOP, st = STEP * HOP;
                    for (int ch = 0; ch < 2; ch++) {
                        System.arraycopy(acc[ch], st, acc[ch], 0, tail);
                        java.util.Arrays.fill(acc[ch], tail, accLen, 0f);
                    }
                    System.arraycopy(den, st, den, 0, tail);
                    java.util.Arrays.fill(den, tail, accLen, 0f);
                }
                prog.update((ci + 1f) / nChunks);
            }
        }
        prog.update(1f);
    }
}
