package com.surokar.app;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.WindowManager;
import android.webkit.*;
import android.widget.Toast;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.RandomAccessFile;

public class MainActivity extends Activity {
    WebView web;
    ValueCallback<Uri[]> cb;
    OutputStream os;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        web.addJavascriptInterface(new Bridge(), "Android");
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> c, FileChooserParams p) {
                if (cb != null) cb.onReceiveValue(null);
                cb = c;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("audio/*");
                startActivityForResult(Intent.createChooser(i, "অডিও বেছে নাও"), 1);
                return true;
            }
        });
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onDestroy() {
        sepCancel = true;
        super.onDestroy();
    }

    // ---- AI vocal separation state (Spleeter U-Net, runs fully on this phone) ----
    private File sepIn, sepOut;
    private OutputStream sepOs;
    private volatile int sepState = 0;      // 0 idle, 1 running, 2 done, 3 error
    private volatile float sepProg = 0f;
    private volatile String sepMsg = "";
    private volatile boolean sepCancel = false;
    private volatile double sepOverlap = 0.5;   // 0 = fast, 0.5 = best quality (MDX-Net chunk overlap)
    private static final int SEP_CHUNK = 786432;   // bytes per read-back chunk (multiple of 4)

    private void keepScreenOn(final boolean on) {
        runOnUiThread(() -> {
            if (on) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        });
    }

    // ---- engines: MDX-Net (ONNX Runtime) is primary; the pure-Java Spleeter is the safety net ----
    private void copyAssetOnce(String asset, File dest) throws IOException {
        File ok = new File(dest.getPath() + ".ok");
        if (dest.exists() && ok.exists()) return;
        File tmp = new File(dest.getPath() + ".tmp");
        try (InputStream in = getAssets().open(asset);
             OutputStream o = new BufferedOutputStream(new FileOutputStream(tmp), 1 << 16)) {
            byte[] buf = new byte[1 << 16];
            int r;
            while ((r = in.read(buf)) > 0) o.write(buf, 0, r);
        }
        if (dest.exists() && !dest.delete()) throw new IOException("old model file locked");
        if (!tmp.renameTo(dest)) throw new IOException("model copy failed");
        if (!ok.exists() && !ok.createNewFile()) throw new IOException("model marker failed");
    }

    private void runMdx(File in, File out) throws Throwable {
        File model = new File(getFilesDir(), "Voc_FT_T128.onnx");
        copyAssetOnce("models/Voc_FT_T128.onnx", model);
        int cores = Runtime.getRuntime().availableProcessors();
        OrtInfer net = new OrtInfer(model.getAbsolutePath(), Math.max(2, Math.min(4, cores)));
        try {
            MdxSeparator sep = new MdxSeparator(net, net.dimT);
            sep.separate(in, out, sepOverlap, new MdxSeparator.Progress() {
                public void update(float f) { sepProg = f; }
                public boolean cancelled() { return sepCancel; }
            });
        } finally {
            net.close();
        }
    }

    private void runSpleeter(File in, File out) throws Throwable {
        Separator sp = new Separator(
            new BufferedInputStream(getAssets().open("spl_vocals.bin"), 1 << 16),
            new BufferedInputStream(getAssets().open("spl_accomp.bin"), 1 << 16));
        try {
            sp.separate(in, out, new Separator.Progress() {
                public void update(float f) { sepProg = f; }
                public boolean cancelled() { return sepCancel; }
            });
        } finally {
            sp.close();
        }
    }

    private static String why(Throwable t) {
        String m = t instanceof OutOfMemoryError ? "OutOfMemory" : String.valueOf(t.getMessage());
        if (m.length() > 80) m = m.substring(0, 80);
        return t.getClass().getSimpleName() + ": " + m.replace('|', '/');
    }

    @Override
    protected void onActivityResult(int r, int c, Intent d) {
        if (r == 1 && cb != null) {
            cb.onReceiveValue(c == RESULT_OK && d != null && d.getData() != null ? new Uri[]{d.getData()} : null);
            cb = null;
        }
    }

    class Bridge {
        @JavascriptInterface
        public void begin(String name) {
            try {
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                v.put(MediaStore.MediaColumns.MIME_TYPE, "audio/wav");
                v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                os = getContentResolver().openOutputStream(u);
            } catch (Exception e) { e.printStackTrace(); }
        }

        @JavascriptInterface
        public void chunk(String b64) {
            try { os.write(Base64.decode(b64, Base64.DEFAULT)); } catch (Exception e) { e.printStackTrace(); }
        }

        @JavascriptInterface
        public void end() {
            try { os.close(); } catch (Exception e) { e.printStackTrace(); }
            runOnUiThread(() -> Toast.makeText(MainActivity.this, "Downloads ফোল্ডারে সেভ হয়েছে", Toast.LENGTH_LONG).show());
        }

        // ---------- AI separation bridge ----------
        @JavascriptInterface
        public void sepBegin() {
            try {
                if (sepOs != null) { try { sepOs.close(); } catch (IOException ignored) {} }
                sepIn = new File(getCacheDir(), "sep_in.pcm");
                sepOut = new File(getCacheDir(), "sep_out.pcm");
                sepOs = new BufferedOutputStream(new FileOutputStream(sepIn), 1 << 16);
                sepState = 0; sepProg = 0f; sepMsg = ""; sepCancel = false;
            } catch (Exception e) { sepState = 3; sepMsg = "ফাইল তৈরি করা যায়নি: " + e.getMessage(); }
        }

        @JavascriptInterface
        public void sepChunk(String b64) {
            try { sepOs.write(Base64.decode(b64, Base64.DEFAULT)); }
            catch (Exception e) { sepState = 3; sepMsg = "অডিও লেখা যায়নি: " + e.getMessage(); }
        }

        @JavascriptInterface
        public void sepStart() {
            if (sepState == 3) return;
            try { sepOs.close(); } catch (Exception e) { sepState = 3; sepMsg = "অডিও লেখা যায়নি"; return; }
            sepOs = null;
            sepState = 1; sepProg = 0f; sepMsg = ""; sepCancel = false;
            keepScreenOn(true);
            final File in = sepIn, out = sepOut;
            new Thread(() -> {
                try {
                    boolean done = false;
                    sepMsg = "MDX";
                    try {
                        runMdx(in, out);
                        done = true;
                    } catch (Throwable t) {
                        if (sepCancel) throw t;
                        sepMsg = "SPL:" + why(t);          // fall back to the lighter model
                        sepProg = 0f;
                    }
                    if (!done) runSpleeter(in, out);
                    sepState = 2;
                } catch (Throwable t) {
                    sepMsg = sepCancel ? "cancelled"
                        : (t instanceof OutOfMemoryError ? "ফোনের মেমরি কম পড়েছে — ছোট ফাইল দিয়ে চেষ্টা করো"
                        : String.valueOf(t.getMessage()));
                    sepState = 3;
                } finally {
                    in.delete();
                    keepScreenOn(false);
                }
            }, "sep-main").start();
        }

        @JavascriptInterface
        public String sepStatus() { return sepState + "|" + sepProg + "|" + sepMsg; }

        @JavascriptInterface
        public void sepCancel() { sepCancel = true; }

        @JavascriptInterface
        public void sepQuality(double overlap) { sepOverlap = Math.max(0.0, Math.min(0.5, overlap)); }

        @JavascriptInterface
        public long sepOutBytes() { return sepOut != null && sepOut.exists() ? sepOut.length() : 0L; }

        @JavascriptInterface
        public String sepRead(int i) {
            try (RandomAccessFile f = new RandomAccessFile(sepOut, "r")) {
                long off = (long) i * SEP_CHUNK;
                if (off >= f.length()) return "";
                int n = (int) Math.min(SEP_CHUNK, f.length() - off);
                byte[] b = new byte[n];
                f.seek(off); f.readFully(b);
                return Base64.encodeToString(b, Base64.NO_WRAP);
            } catch (Exception e) { return ""; }
        }

        @JavascriptInterface
        public void sepClean() {
            if (sepOut != null) sepOut.delete();
            if (sepIn != null) sepIn.delete();
        }
    }
}
