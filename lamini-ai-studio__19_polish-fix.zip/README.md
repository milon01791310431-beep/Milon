# Lamini AI Studio - On-Device AI Photo Enhancer

Lamini is a Remini-style, 100% on-device AI photo enhancement Android application developed with Jetpack Compose, Kotlin Coroutines, and ONNX Runtime.

## Key Features

1. **100% Offline AI Enhancement**:
   - The photo processing pipeline operates completely on-device without calling any cloud API or server.
   - Works fully in airplane mode once the model file is available.
   - Network permissions (`INTERNET`, `ACCESS_NETWORK_STATE`) are used **strictly and exclusively** for the one-time AI model downloader. User photos are never uploaded anywhere.

2. **First-Launch Model Download Gate**:
   - On first launch, if the primary Image Super-Resolution model is not yet installed, a full-screen gate screen appears before the Home screen.
   - Features:
     - Download progress indicator (% and MB / total MB)
     - Real-time download speed (e.g. `1.5 MB/s`)
     - Cellular / mobile data usage warning banner
     - HTTP Range header resume support for interrupted connections
     - Post-download ONNX tensor integrity validation using ONNX Runtime
     - Alternative direct `.onnx` file import option right from the gate

3. **Optional Face Restoration Model**:
   - After the image model is ready, Home screen displays an optional card offering to download the GFPGAN/CodeFormer face model (~340 MB) or tap "পরে" (Later).
   - With the face model installed, the offline ML Kit Face Detection + GFPGAN face restoration pipeline activates automatically.

4. **Enhancement Pipeline**:
   - **Face Stage**: Detects faces with offline ML Kit Face Detection (fallback to `android.media.FaceDetector`), crops with 30% padding, restores with GFPGAN/CodeFormer (512x512 NCHW), and seamlessly blends with soft feathered alpha mask (default strength 0.7).
   - **Whole-Image Stage**: Runs Real-ESRGAN in overlapping tiles (128x128 with 10px overlap) with weighted blending and real tile progress.
   - **Full HD Output**: Longer side is guaranteed to be 1920 px (1080x1920 portrait or 1920x1080 landscape), preserving original aspect ratio without distortion or cropping.
   - **Save to Gallery**: Saves output image as high-quality JPEG (quality 95) or PNG into `Pictures/Lamini`.

5. **AI Model Manager (Settings > AI Models)**:
   - Slot 1: **Image model** (`image_model.onnx` / Real-ESRGAN)
   - Slot 2: **Face model** (`face_model.onnx` / GFPGAN or CodeFormer)
   - Supports:
     - Direct in-app download / re-download
     - Storage size & status display
     - Importing `.onnx` files directly from device storage (`OpenDocument`)
     - Safe deletion

6. **Engine Fallback**:
   - When AI models are not installed or user selects basic enhancement, Lamini uses the built-in classical computer vision engine with clear Bengali labeling: *"AI মডেল নেই, বেসিক এনহান্সমেন্ট ব্যবহার হয়েছে"*.
