package com.example

import com.example.enhancer.engine.PipelineBudget
import com.example.enhancer.engine.ReminiToneSkinEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs
import kotlin.math.pow

class PipelineBudgetAndLutTest {

  @Test
  fun testPipelineBudget_runsStageWhenBudgetFits() {
    var fakeTime = 1000L
    val budget = PipelineBudget(totalBudgetMs = 9000L, clock = { fakeTime })

    // At 0ms elapsed, remaining is 9000ms. A 2000ms stage easily fits.
    assertTrue("Budget of 9000ms should fit 2000ms stage", budget.hasBudgetFor(2000L))
    assertTrue("checkOrSkip should return true when stage fits", budget.checkOrSkip("test_stage", 2000L))
    assertEquals(9000L, budget.remainingMs())
    assertEquals(0f, budget.elapsedFraction(), 0.001f)

    // Advance clock by 4000ms (remaining = 5000ms)
    fakeTime += 4000L
    assertEquals(4000L, budget.elapsedMs())
    assertEquals(5000L, budget.remainingMs())
    assertTrue("Remaining 5000ms fits a 3000ms stage", budget.hasBudgetFor(3000L))
    assertTrue(budget.checkOrSkip("test_stage_2", 3000L))
  }

  @Test
  fun testPipelineBudget_skipsStageWhenBudgetExceeded() {
    var fakeTime = 1000L
    val budget = PipelineBudget(totalBudgetMs = 9000L, clock = { fakeTime })

    // Advance clock by 7500ms -> remaining budget is 1500ms
    fakeTime += 7500L
    assertEquals(7500L, budget.elapsedMs())
    assertEquals(1500L, budget.remainingMs())

    // An estimated 2500ms stage should NOT fit and should be skipped
    assertFalse("Remaining 1500ms should not fit 2500ms stage", budget.hasBudgetFor(2500L))
    assertFalse("checkOrSkip must return false for stage exceeding budget", budget.checkOrSkip("expensive_stage", 2500L))

    // But a small 1000ms stage should still fit
    assertTrue("Remaining 1500ms should fit 1000ms stage", budget.hasBudgetFor(1000L))
    assertTrue(budget.checkOrSkip("small_stage", 1000L))

    // When time passes total budget, remaining is 0
    fakeTime += 5000L
    assertEquals(0L, budget.remainingMs())
    assertEquals(1.0f, budget.elapsedFraction(), 0.001f)
    assertFalse(budget.hasBudgetFor(1L))
    assertFalse(budget.checkOrSkip("any_stage", 100L))
  }

  @Test
  fun testLut_linearToSrgbErrorBelowHalfPercent() {
    fun exactLinearToSrgb(c: Float): Float {
      if (c <= 0f) return 0f
      if (c >= 1f) return 1f
      return if (c <= 0.0031308f) 12.92f * c else 1.055f * c.pow(1f / 2.4f) - 0.055f
    }

    // Test across range [0.005 .. 1.0] in fine increments
    var c = 0.005f
    while (c <= 1.0f) {
      val lutVal = ReminiToneSkinEngine.linearToSrgb(c)
      val exactVal = exactLinearToSrgb(c)
      val absErr = abs(lutVal - exactVal)
      val relErr = absErr / exactVal

      assertTrue(
        "linearToSrgb relative error at c=$c must be below 0.5% (was ${relErr * 100}%)",
        relErr < 0.005f
      )
      c += 0.005f
    }
  }

  @Test
  fun testLut_cbrtFastErrorBelowHalfPercent() {
    // Test cube root fast lookup across range [0.01 .. 2.0]
    var v = 0.01f
    while (v <= 2.0f) {
      val lutVal = ReminiToneSkinEngine.cbrtFast(v)
      val exactVal = v.pow(1f / 3f)
      val absErr = abs(lutVal - exactVal)
      val relErr = absErr / exactVal

      assertTrue(
        "cbrtFast relative error at v=$v must be below 0.5% (was ${relErr * 100}%)",
        relErr < 0.005f
      )
      v += 0.01f
    }
  }

  @Test
  fun testLut_srgbToLinearExact() {
    for (i in 0..255) {
      val lutVal = ReminiToneSkinEngine.SRGB_TO_LIN[i]
      val c = i / 255f
      val exactVal = if (c <= 0.04045f) c / 12.92f else ((c + 0.055f) / 1.055f).pow(2.4f)
      val absErr = abs(lutVal - exactVal)
      assertTrue(
        "SRGB_TO_LIN exact lookup error at i=$i must be below 0.0001 (was $absErr)",
        absErr < 0.0001f
      )
    }
  }
}
