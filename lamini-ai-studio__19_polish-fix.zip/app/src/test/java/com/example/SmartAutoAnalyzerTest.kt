package com.example

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect
import com.example.enhancer.engine.FaceDetectorOfflineHelper
import com.example.enhancer.engine.ReminiToneSkinEngine
import com.example.enhancer.engine.SmartAutoAnalyzer
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import kotlin.random.Random

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class SmartAutoAnalyzerTest {

  @Test
  fun testDarkPhoto_getsLiftWithinCaps() {
    // Synthetic dark image (mean L ~ 20..30)
    val bmp = Bitmap.createBitmap(128, 128, Bitmap.Config.ARGB_8888)
    for (y in 0 until 128) {
      for (x in 0 until 128) {
        bmp.setPixel(x, y, Color.rgb(40, 40, 40))
      }
    }

    val analysis = SmartAutoAnalyzer.analyze(bmp, emptyList())
    assertTrue("Dark image meanL should be low", analysis.meanL < 35f)

    val plan = SmartAutoAnalyzer.decide(analysis)
    assertTrue("Exposure target should be > meanL", plan.exposureTarget > analysis.meanL)
    assertTrue("maxLift should be within caps <= 13", plan.maxLift <= 13f && plan.maxLift > 0f)
    assertTrue("Denoise should be in 0.1..0.6", plan.denoise in 0.1f..0.6f)
    assertTrue("Sharpen should be in 0.1..0.4", plan.sharpen in 0.1f..0.4f)
  }

  @Test
  fun testBrightPhoto_getsNoOvershootLift() {
    // Synthetic bright image (mean L ~ 80+)
    val bmp = Bitmap.createBitmap(128, 128, Bitmap.Config.ARGB_8888)
    for (y in 0 until 128) {
      for (x in 0 until 128) {
        bmp.setPixel(x, y, Color.rgb(220, 220, 220))
      }
    }

    val analysis = SmartAutoAnalyzer.analyze(bmp, emptyList())
    assertTrue("Bright image meanL should be high", analysis.meanL > 75f)

    val plan = SmartAutoAnalyzer.decide(analysis)
    // For bright image, exposure target is 52..57 <= meanL
    assertTrue("Exposure target should be <= meanL", plan.exposureTarget <= analysis.meanL)
    assertTrue("maxLift cap <= 10", plan.maxLift <= 10f)
  }

  @Test
  fun testBlueCastPhoto_getsColorCorrection() {
    // Synthetic image with bluish cast (high blue, lower red/green)
    val bmp = Bitmap.createBitmap(128, 128, Bitmap.Config.ARGB_8888)
    for (y in 0 until 128) {
      for (x in 0 until 128) {
        bmp.setPixel(x, y, Color.rgb(100, 110, 135))
      }
    }

    val analysis = SmartAutoAnalyzer.analyze(bmp, emptyList())
    // Blue cast produces negative b* in LAB
    assertTrue("Blue cast should result in negative castB: ${analysis.castB}", analysis.castB < 0f)

    val plan = SmartAutoAnalyzer.decide(analysis)
    // Cast correction should counteract the blue cast (positive castCorrectB)
    assertTrue("castCorrectB should be positive to correct blue cast: ${plan.castCorrectB}", plan.castCorrectB > 0f)
    assertTrue("castCorrectB should be capped at 6: ${plan.castCorrectB}", plan.castCorrectB <= 6f)
  }

  @Test
  fun testBlackAndWhitePhoto_hasApplyColorFalse() {
    // Synthetic gray image (zero saturation/chroma)
    val bmp = Bitmap.createBitmap(128, 128, Bitmap.Config.ARGB_8888)
    for (y in 0 until 128) {
      for (x in 0 until 128) {
        val gray = 100 + (x % 50)
        bmp.setPixel(x, y, Color.rgb(gray, gray, gray))
      }
    }

    val analysis = SmartAutoAnalyzer.analyze(bmp, emptyList())
    assertTrue("meanChroma should be near 0: ${analysis.meanChroma}", analysis.meanChroma < 3.0f)
    assertTrue("isBlackAndWhite should be true", analysis.isBlackAndWhite)

    val plan = SmartAutoAnalyzer.decide(analysis)
    assertFalse("applyColor should be false for black and white photo", plan.applyColor)
    assertEquals("Warmth should be 0 for black and white", 0f, plan.warmth, 0.001f)
    assertEquals("chromaBoost should be 0 for black and white", 0f, plan.chromaBoost, 0.001f)
    assertEquals("castCorrectA should be 0 for black and white", 0f, plan.castCorrectA, 0.001f)
    assertEquals("castCorrectB should be 0 for black and white", 0f, plan.castCorrectB, 0.001f)
  }

  @Test
  fun testNoisyPhoto_scalesDenoiseUp() {
    val bmp = Bitmap.createBitmap(128, 128, Bitmap.Config.ARGB_8888)
    val rng = Random(42)
    for (y in 0 until 128) {
      for (x in 0 until 128) {
        val noise = rng.nextInt(-35, 35)
        val v = (128 + noise).coerceIn(0, 255)
        bmp.setPixel(x, y, Color.rgb(v, v, v))
      }
    }

    val analysis = SmartAutoAnalyzer.analyze(bmp, emptyList())
    assertTrue("Noise level should be detected > 3: ${analysis.noiseLevel}", analysis.noiseLevel > 3f)

    val plan = SmartAutoAnalyzer.decide(analysis)
    assertTrue("Denoise should scale up >= 0.25: ${plan.denoise}", plan.denoise >= 0.25f)
    assertTrue("Denoise cap at 0.6: ${plan.denoise}", plan.denoise <= 0.6f)
  }

  @Test
  fun testBlurredPhoto_scalesSharpenUp() {
    // Synthetic smooth flat/blurred image
    val bmp = Bitmap.createBitmap(128, 128, Bitmap.Config.ARGB_8888)
    for (y in 0 until 128) {
      for (x in 0 until 128) {
        val v = (100 + (x / 2)).coerceIn(0, 255)
        bmp.setPixel(x, y, Color.rgb(v, v, v))
      }
    }

    val analysis = SmartAutoAnalyzer.analyze(bmp, emptyList())
    val plan = SmartAutoAnalyzer.decide(analysis)
    assertTrue("Sharpen should be in range 0.1..0.4: ${plan.sharpen}", plan.sharpen in 0.1f..0.4f)
    // Low blur variance should yield higher sharpen
    assertTrue("Sharpen should be boosted for smooth/blurry image: ${plan.sharpen}", plan.sharpen >= 0.25f)
  }

  @Test
  fun testPortraitWithBrightFace_getsScaledDownFaceRelight() {
    val bmp = Bitmap.createBitmap(200, 200, Bitmap.Config.ARGB_8888)
    // Fill background with medium color
    for (y in 0 until 200) {
      for (x in 0 until 200) {
        bmp.setPixel(x, y, Color.rgb(120, 120, 120))
      }
    }

    // Paint a bright skin-toned face box (100x100)
    for (y in 50 until 150) {
      for (x in 50 until 150) {
        // Bright skin tone: high L* (~70+)
        bmp.setPixel(x, y, Color.rgb(235, 205, 190))
      }
    }

    val faceBox = FaceDetectorOfflineHelper.DetectedFaceBox(
      rect = Rect(50, 50, 150, 150)
    )

    val analysis = SmartAutoAnalyzer.analyze(bmp, listOf(faceBox))
    assertTrue("Faces should be detected", analysis.faces.isNotEmpty())
    val face = analysis.faces[0]
    assertTrue("Face skin L* should be bright: ${face.skinMeanL}", face.skinMeanL > 55f)

    val plan = SmartAutoAnalyzer.decide(analysis)
    assertEquals(SmartAutoAnalyzer.SceneHint.PORTRAIT, analysis.sceneHint)
    assertEquals(57f, plan.exposureTarget, 0.001f)
    assertTrue("runFaceStage should be true for 100px face", plan.runFaceStage)
    // Since faceL > targetFaceL (55), faceRelightScale should be clamped to 0
    assertEquals("Bright face should get 0 relight scale", 0f, plan.faceRelightScale, 0.001f)
  }

  @Test
  fun testPortraitWithDarkFace_getsPositiveFaceRelight() {
    val bmp = Bitmap.createBitmap(200, 200, Bitmap.Config.ARGB_8888)
    for (y in 0 until 200) {
      for (x in 0 until 200) {
        bmp.setPixel(x, y, Color.rgb(120, 120, 120))
      }
    }

    // Paint an underexposed skin-toned face box (100x100)
    for (y in 50 until 150) {
      for (x in 50 until 150) {
        // Darker skin tone: lower L* (~40)
        bmp.setPixel(x, y, Color.rgb(115, 80, 65))
      }
    }

    val faceBox = FaceDetectorOfflineHelper.DetectedFaceBox(
      rect = Rect(50, 50, 150, 150)
    )

    val analysis = SmartAutoAnalyzer.analyze(bmp, listOf(faceBox))
    assertTrue("Faces should be detected", analysis.faces.isNotEmpty())
    val face = analysis.faces[0]
    assertTrue("Face skin L* should be underexposed: ${face.skinMeanL}", face.skinMeanL < 50f)

    val plan = SmartAutoAnalyzer.decide(analysis)
    assertTrue("Dark face should get positive faceRelightScale: ${plan.faceRelightScale}", plan.faceRelightScale > 0.5f)
    assertTrue("faceRelightScale <= 1.0: ${plan.faceRelightScale}", plan.faceRelightScale <= 1.0f)
    assertTrue("skinSmoothing should be within 0.3..0.6: ${plan.skinSmoothing}", plan.skinSmoothing in 0.3f..0.6f)
    assertTrue("runFaceStage should be true", plan.runFaceStage)
  }

  @Test
  fun testSmallFace_skipsFaceStage() {
    val bmp = Bitmap.createBitmap(500, 500, Bitmap.Config.ARGB_8888)
    for (y in 0 until 500) {
      for (x in 0 until 500) {
        bmp.setPixel(x, y, Color.rgb(120, 120, 120))
      }
    }

    // Tiny face: only 30x30 pixels (smaller than 64px threshold)
    val faceBox = FaceDetectorOfflineHelper.DetectedFaceBox(
      rect = Rect(100, 100, 130, 130)
    )

    val analysis = SmartAutoAnalyzer.analyze(bmp, listOf(faceBox))
    val plan = SmartAutoAnalyzer.decide(analysis)
    assertFalse("runFaceStage should be false for faces smaller than 64px", plan.runFaceStage)
  }

  @Test
  fun testDecideOutputChangesFinalMeanLstarInExpectedDirection_DarkAndBrightImage() {
    // 1. Dark Image Test:
    // Initial mean L* ~ 35. With decide(analysis), exposure target is general/night target (~45..54).
    // Final mean L* should be lifted in the expected upward direction.
    val darkBmp = Bitmap.createBitmap(100, 100, Bitmap.Config.ARGB_8888)
    for (y in 0 until 100) {
      for (x in 0 until 100) {
        darkBmp.setPixel(x, y, Color.rgb(75, 75, 75)) // ~32.4 L*
      }
    }
    val darkAnalysis = SmartAutoAnalyzer.analyze(darkBmp)
    val darkPlan = SmartAutoAnalyzer.decide(darkAnalysis)
    val darkEnhanced = ReminiToneSkinEngine.applyReminiLook(darkBmp, plan = darkPlan)

    // Compute mean L* of enhanced
    var darkSumL = 0.0
    val darkPixels = IntArray(100 * 100)
    darkEnhanced.getPixels(darkPixels, 0, 100, 0, 0, 100, 100)
    for (p in darkPixels) {
      darkSumL += ReminiToneSkinEngine.rgbToLstar(Color.red(p), Color.green(p), Color.blue(p))
    }
    val darkOutMeanL = (darkSumL / (100 * 100)).toFloat()
    assertTrue(
      "Dark image mean L* should be lifted toward exposure target (in: ${darkAnalysis.meanL}, out: $darkOutMeanL)",
      darkOutMeanL > darkAnalysis.meanL
    )
    assertTrue(
      "Dark image lift should not exceed maxLift + 0.5 (lift: ${darkOutMeanL - darkAnalysis.meanL})",
      (darkOutMeanL - darkAnalysis.meanL) <= (darkPlan.maxLift + 1.0f)
    )

    // 2. Bright Image Test:
    // Initial mean L* ~ 75. Exposure target is ~54.
    // Since input mean L* >= exposureTarget, tone mapping should not lift the photo.
    val brightBmp = Bitmap.createBitmap(100, 100, Bitmap.Config.ARGB_8888)
    for (y in 0 until 100) {
      for (x in 0 until 100) {
        brightBmp.setPixel(x, y, Color.rgb(190, 190, 190)) // ~76.6 L*
      }
    }
    val brightAnalysis = SmartAutoAnalyzer.analyze(brightBmp)
    val brightPlan = SmartAutoAnalyzer.decide(brightAnalysis)
    val brightEnhanced = ReminiToneSkinEngine.applyReminiLook(brightBmp, plan = brightPlan)

    var brightSumL = 0.0
    val brightPixels = IntArray(100 * 100)
    brightEnhanced.getPixels(brightPixels, 0, 100, 0, 0, 100, 100)
    for (p in brightPixels) {
      brightSumL += ReminiToneSkinEngine.rgbToLstar(Color.red(p), Color.green(p), Color.blue(p))
    }
    val brightOutMeanL = (brightSumL / (100 * 100)).toFloat()
    assertTrue(
      "Bright image mean L* ($brightOutMeanL) should not be lifted when above target (${brightAnalysis.meanL})",
      brightOutMeanL <= brightAnalysis.meanL + 0.5f
    )
  }

  @Test
  fun testChromaBoostTuning() {
    // 1. meanChroma 29 gets chromaBoost >= 0.14
    val analysisChroma29 = SmartAutoAnalyzer.PhotoAnalysis(
      meanL = 54f,
      p5 = 10f,
      p95 = 90f,
      clippedShadowShare = 0f,
      clippedHighlightShare = 0f,
      castA = 0f,
      castB = 0f,
      meanChroma = 29f,
      isBlackAndWhite = false,
      noiseLevel = 0f,
      blurLevel = 200f,
      width = 100,
      height = 100,
      faces = emptyList(),
      sceneHint = SmartAutoAnalyzer.SceneHint.GENERAL
    )
    val planChroma29 = SmartAutoAnalyzer.decide(analysisChroma29)
    assertTrue(
      "meanChroma 29 gets chromaBoost >= 0.14: was ${planChroma29.chromaBoost}",
      planChroma29.chromaBoost >= 0.14f
    )

    // 2. meanChroma 50 gets 0
    val analysisChroma50 = SmartAutoAnalyzer.PhotoAnalysis(
      meanL = 54f,
      p5 = 10f,
      p95 = 90f,
      clippedShadowShare = 0f,
      clippedHighlightShare = 0f,
      castA = 0f,
      castB = 0f,
      meanChroma = 50f,
      isBlackAndWhite = false,
      noiseLevel = 0f,
      blurLevel = 200f,
      width = 100,
      height = 100,
      faces = emptyList(),
      sceneHint = SmartAutoAnalyzer.SceneHint.GENERAL
    )
    val planChroma50 = SmartAutoAnalyzer.decide(analysisChroma50)
    assertEquals("meanChroma 50 gets 0", 0f, planChroma50.chromaBoost, 0.0001f)

    // 3. A photo with meanL >= 35 and large planned lift gets chromaBoost up to 0.20
    val analysisLargeLift = SmartAutoAnalyzer.PhotoAnalysis(
      meanL = 38f,
      p5 = 10f,
      p95 = 70f,
      clippedShadowShare = 0.01f,
      clippedHighlightShare = 0f,
      castA = 0f,
      castB = 0f,
      meanChroma = 25f,
      isBlackAndWhite = false,
      noiseLevel = 0f,
      blurLevel = 200f,
      width = 100,
      height = 100,
      faces = emptyList(),
      sceneHint = SmartAutoAnalyzer.SceneHint.GENERAL
    )
    val planLargeLift = SmartAutoAnalyzer.decide(analysisLargeLift)
    assertEquals(
      "photo with meanL >= 35 and large planned lift gets chromaBoost up to 0.20",
      0.20f,
      planLargeLift.chromaBoost,
      0.0001f
    )

    // 4. Black and white stays 0
    val analysisBW = SmartAutoAnalyzer.PhotoAnalysis(
      meanL = 50f,
      p5 = 10f,
      p95 = 90f,
      clippedShadowShare = 0f,
      clippedHighlightShare = 0f,
      castA = 0f,
      castB = 0f,
      meanChroma = 0f,
      isBlackAndWhite = true,
      noiseLevel = 0f,
      blurLevel = 200f,
      width = 100,
      height = 100,
      faces = emptyList(),
      sceneHint = SmartAutoAnalyzer.SceneHint.GENERAL
    )
    val planBW = SmartAutoAnalyzer.decide(analysisBW)
    assertEquals("black and white stays 0", 0f, planBW.chromaBoost, 0.0001f)
  }

  @Test
  fun testVeryDarkPhotoTuning() {
    // 1. Dark portrait (meanL about 32) gets maxLift 13 and chromaBoost above 0.20 and at most 0.30
    val darkPortraitAnalysis = SmartAutoAnalyzer.PhotoAnalysis(
      meanL = 32f,
      p5 = 10f,
      p95 = 65f,
      clippedShadowShare = 0.02f,
      clippedHighlightShare = 0f,
      castA = 0f,
      castB = 0f,
      meanChroma = 26f, // < 35f so baseBoost = 0.15f
      isBlackAndWhite = false,
      noiseLevel = 1f,
      blurLevel = 200f,
      width = 100,
      height = 100,
      faces = listOf(
        SmartAutoAnalyzer.FaceInfo(
          sizeRatio = 0.2f,
          skinMeanL = 36f,
          skinMeanA = 14f,
          skinMeanB = 12f
        )
      ),
      sceneHint = SmartAutoAnalyzer.SceneHint.PORTRAIT
    )
    val darkPortraitPlan = SmartAutoAnalyzer.decide(darkPortraitAnalysis)
    assertEquals("Dark portrait gets maxLift 13", 13f, darkPortraitPlan.maxLift, 0.0001f)
    assertTrue(
      "Dark portrait chromaBoost should be above 0.20: was ${darkPortraitPlan.chromaBoost}",
      darkPortraitPlan.chromaBoost > 0.20f
    )
    assertTrue(
      "Dark portrait chromaBoost should be at most 0.30: was ${darkPortraitPlan.chromaBoost}",
      darkPortraitPlan.chromaBoost <= 0.30f
    )

    // 2. A normal photo (meanL about 48) is unchanged
    val normalAnalysis = SmartAutoAnalyzer.PhotoAnalysis(
      meanL = 48f,
      p5 = 15f,
      p95 = 85f,
      clippedShadowShare = 0f,
      clippedHighlightShare = 0f,
      castA = 0f,
      castB = 0f,
      meanChroma = 28f,
      isBlackAndWhite = false,
      noiseLevel = 1f,
      blurLevel = 200f,
      width = 100,
      height = 100,
      faces = emptyList(),
      sceneHint = SmartAutoAnalyzer.SceneHint.GENERAL
    )
    val normalPlan = SmartAutoAnalyzer.decide(normalAnalysis)
    assertEquals("Normal photo gets maxLift 10", 10f, normalPlan.maxLift, 0.0001f)
    assertEquals("Normal photo chromaBoost unchanged", 0.18f, normalPlan.chromaBoost, 0.0001f)
    assertTrue("Normal photo chromaBoost is at most 0.20", normalPlan.chromaBoost <= 0.20f)

    // 3. A night scene keeps the +6 limit (and old chroma cap 0.20)
    val nightAnalysis = SmartAutoAnalyzer.PhotoAnalysis(
      meanL = 25f,
      p5 = 5f,
      p95 = 60f,
      clippedShadowShare = 0.05f,
      clippedHighlightShare = 0f,
      castA = 0f,
      castB = 0f,
      meanChroma = 20f,
      isBlackAndWhite = false,
      noiseLevel = 2f,
      blurLevel = 200f,
      width = 100,
      height = 100,
      faces = emptyList(),
      sceneHint = SmartAutoAnalyzer.SceneHint.NIGHT
    )
    val nightPlan = SmartAutoAnalyzer.decide(nightAnalysis)
    assertTrue("Night scene maxLift keeps the +6 limit: was ${nightPlan.maxLift}", nightPlan.maxLift <= 6f)
    assertTrue(
      "Night scene keeps old chroma cap 0.20: was ${nightPlan.chromaBoost}",
      nightPlan.chromaBoost <= 0.20f
    )
  }

  @Test
  fun testBlurLevelSharpenMapping() {
    fun createAnalysisWithBlur(blur: Float): SmartAutoAnalyzer.PhotoAnalysis =
      SmartAutoAnalyzer.PhotoAnalysis(
        meanL = 50f,
        p5 = 15f,
        p95 = 85f,
        clippedShadowShare = 0f,
        clippedHighlightShare = 0f,
        castA = 0f,
        castB = 0f,
        meanChroma = 25f,
        isBlackAndWhite = false,
        noiseLevel = 1f,
        blurLevel = blur,
        width = 100,
        height = 100,
        faces = emptyList(),
        sceneHint = SmartAutoAnalyzer.SceneHint.GENERAL
      )

    // blurLevel 50 gives sharpen between 0.2 and 0.3
    val plan50 = SmartAutoAnalyzer.decide(createAnalysisWithBlur(50f))
    assertTrue(
      "blurLevel 50 gives sharpen between 0.2 and 0.3: was ${plan50.sharpen}",
      plan50.sharpen > 0.2f && plan50.sharpen < 0.3f
    )

    // blurLevel 150 gives 0.10
    val plan150 = SmartAutoAnalyzer.decide(createAnalysisWithBlur(150f))
    assertEquals("blurLevel 150 gives 0.10", 0.10f, plan150.sharpen, 0.0001f)

    // blurLevel 15 gives 0.35
    val plan15 = SmartAutoAnalyzer.decide(createAnalysisWithBlur(15f))
    assertEquals("blurLevel 15 gives 0.35", 0.35f, plan15.sharpen, 0.0001f)
  }


  @Test
  fun testPolishAmountMapping() {
    // plan.sharpen 0.10 -> 0.06 and the pass is skipped (below 0.08)
    assertEquals(0.06f, SmartAutoAnalyzer.polishAmountFor(0.10f), 0.0001f)
    assertTrue(SmartAutoAnalyzer.shouldSkipPolish(SmartAutoAnalyzer.polishAmountFor(0.10f)))

    // plan.sharpen 0.25 -> 0.15, not skipped
    assertEquals(0.15f, SmartAutoAnalyzer.polishAmountFor(0.25f), 0.0001f)
    assertFalse(SmartAutoAnalyzer.shouldSkipPolish(SmartAutoAnalyzer.polishAmountFor(0.25f)))

    // plan.sharpen 0.35 -> 0.21, not skipped
    assertEquals(0.21f, SmartAutoAnalyzer.polishAmountFor(0.35f), 0.0001f)
    assertFalse(SmartAutoAnalyzer.shouldSkipPolish(SmartAutoAnalyzer.polishAmountFor(0.35f)))

    // No plan available -> fallback 0.12 (not skipped)
    assertEquals(0.12f, SmartAutoAnalyzer.polishAmountFor(null), 0.0001f)
    assertFalse(SmartAutoAnalyzer.shouldSkipPolish(SmartAutoAnalyzer.polishAmountFor(null)))

    // Skip rule boundary: 0.079 skipped, 0.08 runs
    assertTrue(SmartAutoAnalyzer.shouldSkipPolish(0.079f))
    assertFalse(SmartAutoAnalyzer.shouldSkipPolish(0.08f))
  }
}
