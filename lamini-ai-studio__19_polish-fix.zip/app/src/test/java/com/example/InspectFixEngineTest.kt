package com.example

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect
import androidx.compose.ui.geometry.Offset
import com.example.enhancer.engine.EditPatch
import com.example.enhancer.engine.ImageStroke
import com.example.enhancer.engine.InspectFixEngine
import com.example.enhancer.engine.PatchHistoryManager
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class InspectFixEngineTest {

  @Test
  fun testScreenToImageCoordinates_CenterAt1xZoom() {
    val canvasW = 1000f
    val canvasH = 1000f
    val imgW = 500
    val imgH = 500
    val zoom = 1f
    val panX = 0f
    val panY = 0f

    // Center of canvas (500, 500) should map to center of image (250, 250)
    val imgPt = InspectFixEngine.screenToImageCoordinates(
      screenPos = Offset(500f, 500f),
      canvasWidth = canvasW,
      canvasHeight = canvasH,
      imageWidth = imgW,
      imageHeight = imgH,
      zoom = zoom,
      panX = panX,
      panY = panY
    )

    assertNotNull(imgPt)
    assertEquals(250f, imgPt!!.x, 0.01f)
    assertEquals(250f, imgPt.y, 0.01f)
  }

  @Test
  fun testScreenToImageCoordinates_WithZoomAndPan() {
    val canvasW = 1080f
    val canvasH = 1920f
    val imgW = 1080
    val imgH = 1920
    val zoom = 2f
    val panX = 100f
    val panY = -50f

    val testScreenPt = Offset(540f, 960f)
    val imgPt = InspectFixEngine.screenToImageCoordinates(
      screenPos = testScreenPt,
      canvasWidth = canvasW,
      canvasHeight = canvasH,
      imageWidth = imgW,
      imageHeight = imgH,
      zoom = zoom,
      panX = panX,
      panY = panY
    )
    assertNotNull(imgPt)

    // Reversible conversion check
    val screenAgain = InspectFixEngine.imageToScreenCoordinates(
      imagePos = imgPt!!,
      canvasWidth = canvasW,
      canvasHeight = canvasH,
      imageWidth = imgW,
      imageHeight = imgH,
      zoom = zoom,
      panX = panX,
      panY = panY
    )

    assertEquals(testScreenPt.x, screenAgain.x, 0.1f)
    assertEquals(testScreenPt.y, screenAgain.y, 0.1f)
  }

  @Test
  fun testScreenToImageCoordinates_InvalidDimensionsReturnNull() {
    val result = InspectFixEngine.screenToImageCoordinates(
      screenPos = Offset(100f, 100f),
      canvasWidth = 0f,
      canvasHeight = 100f,
      imageWidth = 500,
      imageHeight = 500,
      zoom = 1f,
      panX = 0f,
      panY = 0f
    )
    assertNull(result)
  }

  @Test
  fun testCalculateStrokeBounds_SingleStrokeWithPadding() {
    val strokes = listOf(
      ImageStroke(
        points = listOf(Offset(100f, 100f)),
        radiusPx = 10f
      )
    )
    val bounds = InspectFixEngine.calculateStrokeBounds(
      strokes = strokes,
      imageWidth = 1000,
      imageHeight = 1000,
      paddingPx = 32
    )

    assertNotNull(bounds)
    // Point (100, 100) with radius 10 extends from 90 to 110
    // With 32 padding: left = 90 - 32 = 58, top = 58, right = 110 + 32 = 142
    assertEquals(58, bounds!!.left)
    assertEquals(58, bounds.top)
    assertEquals(143, bounds.right) // +1 for pixel width
    assertEquals(143, bounds.bottom)
  }

  @Test
  fun testCalculateStrokeBounds_MultipleStrokes() {
    val strokes = listOf(
      ImageStroke(points = listOf(Offset(50f, 50f)), radiusPx = 5f),
      ImageStroke(points = listOf(Offset(200f, 300f)), radiusPx = 8f)
    )
    val bounds = InspectFixEngine.calculateStrokeBounds(
      strokes = strokes,
      imageWidth = 1000,
      imageHeight = 1000,
      paddingPx = 16
    )

    assertNotNull(bounds)
    // Min X is 50 - 5 = 45 -> with 16 padding = 29
    // Max X is 200 + 8 = 208 -> with 16 padding = 224
    assertEquals(29, bounds!!.left)
    assertEquals(225, bounds.right)
  }

  @Test
  fun testCalculateStrokeBounds_ClampsToImageBoundaries() {
    val strokes = listOf(
      ImageStroke(points = listOf(Offset(5f, 5f)), radiusPx = 20f)
    )
    val bounds = InspectFixEngine.calculateStrokeBounds(
      strokes = strokes,
      imageWidth = 500,
      imageHeight = 500,
      paddingPx = 32
    )

    assertNotNull(bounds)
    assertEquals(0, bounds!!.left)
    assertEquals(0, bounds.top)
    assertTrue(bounds.right <= 500)
    assertTrue(bounds.bottom <= 500)
  }

  @Test
  fun testCalculateStrokeBounds_EmptyReturnsNull() {
    val bounds = InspectFixEngine.calculateStrokeBounds(
      strokes = emptyList(),
      imageWidth = 500,
      imageHeight = 500
    )
    assertNull(bounds)
  }

  @Test
  fun testIsMarkedAreaTooLarge() {
    val imgW = 1000
    val imgH = 1000
    // Total pixels = 1,000,000
    // 8% = 80,000 pixels

    // Small box: 100x100 = 10,000 pixels (1%) -> should be false
    val smallBox = Rect(0, 0, 100, 100)
    assertFalse(InspectFixEngine.isMarkedAreaTooLarge(smallBox, imgW, imgH, maxRatio = 0.08f))

    // Large box: 400x300 = 120,000 pixels (12%) -> should be true
    val largeBox = Rect(0, 0, 400, 300)
    assertTrue(InspectFixEngine.isMarkedAreaTooLarge(largeBox, imgW, imgH, maxRatio = 0.08f))
  }

  @Test
  fun testPatchHistoryManager_UndoRedo() {
    val bitmap = Bitmap.createBitmap(100, 100, Bitmap.Config.ARGB_8888)
    bitmap.eraseColor(Color.BLUE)

    val history = PatchHistoryManager(maxCapacity = 10)
    assertFalse(history.canUndo)
    assertFalse(history.canRedo)

    val rect = Rect(10, 10, 20, 20)
    val beforePixels = IntArray(100) { Color.BLUE }
    val afterPixels = IntArray(100) { Color.RED }

    // Apply change
    bitmap.setPixels(afterPixels, 0, 10, 10, 10, 10, 10)
    assertEquals(Color.RED, bitmap.getPixel(15, 15))

    val patch = EditPatch(rect, beforePixels, afterPixels)
    history.recordEdit(patch)
    assertTrue(history.canUndo)
    assertFalse(history.canRedo)

    // Undo: should revert to BLUE
    assertTrue(history.undo(bitmap))
    assertEquals(Color.BLUE, bitmap.getPixel(15, 15))
    assertFalse(history.canUndo)
    assertTrue(history.canRedo)

    // Redo: should re-apply RED
    assertTrue(history.redo(bitmap))
    assertEquals(Color.RED, bitmap.getPixel(15, 15))
    assertTrue(history.canUndo)
    assertFalse(history.canRedo)
  }

  @Test
  fun testPatchHistoryManager_MaxCapacityEnforced() {
    val history = PatchHistoryManager(maxCapacity = 3)
    val rect = Rect(0, 0, 1, 1)

    for (i in 1..5) {
      val patch = EditPatch(rect, intArrayOf(i), intArrayOf(i + 10))
      history.recordEdit(patch)
    }

    // Should only be able to undo 3 times
    val bitmap = Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888)
    assertTrue(history.undo(bitmap))
    assertTrue(history.undo(bitmap))
    assertTrue(history.undo(bitmap))
    assertFalse(history.undo(bitmap))
  }

  @Test
  fun testBitmapOpacityDetection_OpaqueVsTransparent() {
    // Normal opaque bitmap
    val opaqueBmp = Bitmap.createBitmap(50, 50, Bitmap.Config.ARGB_8888)
    opaqueBmp.eraseColor(Color.rgb(100, 150, 200))
    // Check all pixels have alpha 255
    val pixels = IntArray(50 * 50)
    opaqueBmp.getPixels(pixels, 0, 50, 0, 0, 50, 50)
    val hasAlphaLess255 = pixels.any { ((it ushr 24) and 0xFF) < 255 }
    assertFalse(hasAlphaLess255)

    // Bitmap with one semi-transparent pixel
    val transBmp = Bitmap.createBitmap(50, 50, Bitmap.Config.ARGB_8888)
    transBmp.eraseColor(Color.rgb(100, 150, 200))
    transBmp.setPixel(10, 10, Color.argb(128, 100, 150, 200))
    transBmp.getPixels(pixels, 0, 50, 0, 0, 50, 50)
    val transHasAlphaLess255 = pixels.any { ((it ushr 24) and 0xFF) < 255 }
    assertTrue(transHasAlphaLess255)
  }
}
