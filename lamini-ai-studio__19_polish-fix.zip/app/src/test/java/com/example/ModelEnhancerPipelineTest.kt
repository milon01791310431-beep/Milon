package com.example

import com.example.enhancer.config.ModelConfig
import com.example.enhancer.engine.DownloadStatus
import com.example.enhancer.model.ModelSlotType
import com.example.enhancer.utils.MemorySafetyCalculator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ModelEnhancerPipelineTest {

  @Test
  fun testTargetOutputDimensionsCalculation_PreservesExactSize() {
    // 1520x2704 photo stays 1520x2704 (Remini style)
    val dimsPhone = MemorySafetyCalculator.calculateTargetOutputDimensions(1520, 2704)
    assertEquals(1520, dimsPhone.width)
    assertEquals(2704, dimsPhone.height)

    // 4:3 landscape
    val dims = MemorySafetyCalculator.calculateTargetOutputDimensions(800, 600)
    assertEquals(800, dims.width)
    assertEquals(600, dims.height)

    // 16:9 landscape
    val dims169 = MemorySafetyCalculator.calculateTargetOutputDimensions(1280, 720)
    assertEquals(1280, dims169.width)
    assertEquals(720, dims169.height)
  }

  @Test
  fun testTargetOutputDimensionsCalculation_Portrait() {
    // 3:4 portrait
    val dims = MemorySafetyCalculator.calculateTargetOutputDimensions(600, 800)
    assertEquals(600, dims.width)
    assertEquals(800, dims.height)

    // 9:16 portrait
    val dims916 = MemorySafetyCalculator.calculateTargetOutputDimensions(720, 1280)
    assertEquals(720, dims916.width)
    assertEquals(1280, dims916.height)
  }

  @Test
  fun testTargetOutputDimensionsCalculation_Square() {
    val dims = MemorySafetyCalculator.calculateTargetOutputDimensions(500, 500)
    assertEquals(500, dims.width)
    assertEquals(500, dims.height)
  }

  @Test
  fun testTargetOutputDimensionsCalculation_LargerThan4096Capped() {
    // 5000x3750 input should downscale so long side is capped at 4096
    val dims = MemorySafetyCalculator.calculateTargetOutputDimensions(5000, 3750)
    assertEquals(4096, dims.width)
    assertEquals(3072, dims.height)
  }

  @Test
  fun testTilingCoordinates() {
    val dimension = 500
    val tileSize = 128
    val overlap = 10
    val coords = MemorySafetyCalculator.calculateTilingCoordinates(dimension, tileSize, overlap)

    assertTrue("Should have multiple tile coordinates", coords.size > 1)
    assertEquals("First tile must start at 0", 0, coords.first())
    val lastCoord = coords.last()
    assertTrue("Last coordinate + tileSize must cover entire dimension", lastCoord + tileSize >= dimension)
  }

  @Test
  fun testModelConfigUrlValidation() {
    // Default placeholder should be recognized as unconfigured
    assertFalse(ModelConfig.isUrlConfigured("PUT_DIRECT_LINK_HERE"))
    assertFalse(ModelConfig.isUrlConfigured(""))
    assertFalse(ModelConfig.isUrlConfigured("   "))
    assertFalse(ModelConfig.isUrlConfigured("invalid_url_string"))

    // Real http/https URLs should be recognized as configured
    assertTrue(ModelConfig.isUrlConfigured("https://huggingface.co/models/realesrgan.onnx"))
    assertTrue(ModelConfig.isUrlConfigured("http://example.com/model.onnx"))
  }

  @Test
  fun testModelConfigSlots() {
    assertEquals(ModelConfig.IMAGE_MODEL_URL, ModelConfig.getModelUrl(ModelSlotType.IMAGE_MODEL))
    assertEquals(ModelConfig.FACE_MODEL_URL, ModelConfig.getModelUrl(ModelSlotType.FACE_MODEL))
    assertEquals(ModelConfig.IMAGE_MODEL_SIZE_BYTES, ModelConfig.getExpectedSizeBytes(ModelSlotType.IMAGE_MODEL))
    assertEquals(ModelConfig.FACE_MODEL_SIZE_BYTES, ModelConfig.getExpectedSizeBytes(ModelSlotType.FACE_MODEL))
  }

  @Test
  fun testDownloadStatusFormatting() {
    val status = DownloadStatus.Downloading(
      slotType = ModelSlotType.IMAGE_MODEL,
      bytesDownloaded = 2_621_440L, // 2.5 MB
      totalBytes = 5_242_880L, // 5.0 MB
      percent = 50,
      speedText = "1.5 MB/s",
      isResuming = false
    )

    assertEquals("2.5", status.downloadedMb)
    assertEquals("5.0", status.totalMb)
    assertEquals(50, status.percent)
  }

  @Test
  fun testMemoryCapThresholdRules() {
    val maxOutputLongSide = 3840

    // Scale x4: maxInputLongSide = 960
    val scale4 = 4
    val maxInputLongSide4 = maxOutputLongSide / scale4
    assertEquals(960, maxInputLongSide4)

    // Small photo (800 px) with x4 model: runs at original size without resize
    val inputLongSideSmall = 800
    val needsResizeSmall = inputLongSideSmall > maxInputLongSide4
    assertFalse("Small image (800 px) <= 960 px should not be resized before upscale", needsResizeSmall)
    val upscaledLongSideSmall = inputLongSideSmall * scale4
    assertTrue("Upscaled size should be within 3840 px", upscaledLongSideSmall <= maxOutputLongSide)

    // Large photo (1200 px) with x4 model: resized to 960 px so upscaled size is at most 3840 px
    val inputLongSideLarge = 1200
    val needsResizeLarge = inputLongSideLarge > maxInputLongSide4
    assertTrue("Large image (1200 px) > 960 px should be resized to 960 px", needsResizeLarge)
    val effectiveInputLongSideLarge = if (needsResizeLarge) maxInputLongSide4 else inputLongSideLarge
    val upscaledLongSideLarge = effectiveInputLongSideLarge * scale4
    assertEquals("Upscaled size after capping should be exactly 3840 px", 3840, upscaledLongSideLarge)

    // Scale x2: maxInputLongSide = 1920
    val scale2 = 2
    val maxInputLongSide2 = maxOutputLongSide / scale2
    assertEquals(1920, maxInputLongSide2)

    // 1200 px photo with x2 model: runs at original size without resize (1200 * 2 = 2400 <= 3840)
    val needsResizeMedium2 = inputLongSideLarge > maxInputLongSide2
    assertFalse("1200 px image <= 1920 px should not be resized with x2 model", needsResizeMedium2)
    val upscaledLongSideMedium2 = inputLongSideLarge * scale2
    assertTrue("Upscaled size should be within 3840 px", upscaledLongSideMedium2 <= maxOutputLongSide)
  }

  @Test
  fun testDefaultFaceStrengthIs0Point8() {
    val config = com.example.enhancer.model.EnhancementConfig()
    assertEquals(0.8f, config.faceStrength, 0.001f)
  }
}
