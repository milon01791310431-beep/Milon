package com.example.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// Official Lamini AI Studio Color Palette
val MainBackground = Color(0xFF0B0D14)
val SecondaryBackground = Color(0xFF121522)
val CardBackground = Color(0xFF181C2B)
val BorderColor = Color(0xFF292E42)

val PrimaryPurple = Color(0xFF8B5CF6)
val SecondaryBlue = Color(0xFF4F8CFF)
val AccentCyan = Color(0xFF4DE2E2)

val MainText = Color(0xFFFFFFFF)
val SecondaryText = Color(0xFFA6AEC5)
val TextMuted = Color(0xFF6B7280)

val SuccessGreen = Color(0xFF38D996)
val ErrorRed = Color(0xFFFF647C)

// Gradients
val PrimaryGradient = Brush.horizontalGradient(
  colors = listOf(PrimaryPurple, SecondaryBlue)
)

val GlowGradient = Brush.radialGradient(
  colors = listOf(PrimaryPurple.copy(alpha = 0.35f), Color.Transparent)
)

val CardGlowBorder = Brush.linearGradient(
  colors = listOf(PrimaryPurple.copy(alpha = 0.5f), SecondaryBlue.copy(alpha = 0.4f), BorderColor)
)
