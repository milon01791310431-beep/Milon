package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
  primary = PrimaryPurple,
  onPrimary = MainText,
  primaryContainer = CardBackground,
  onPrimaryContainer = AccentCyan,
  secondary = SecondaryBlue,
  onSecondary = MainText,
  secondaryContainer = SecondaryBackground,
  onSecondaryContainer = PrimaryPurple,
  tertiary = AccentCyan,
  onTertiary = MainBackground,
  background = MainBackground,
  onBackground = MainText,
  surface = CardBackground,
  onSurface = MainText,
  surfaceVariant = SecondaryBackground,
  onSurfaceVariant = SecondaryText,
  outline = BorderColor,
  error = ErrorRed,
  onError = MainText
)

@Composable
fun LaminiTheme(
  content: @Composable () -> Unit
) {
  MaterialTheme(
    colorScheme = DarkColorScheme,
    typography = Typography,
    content = content
  )
}
