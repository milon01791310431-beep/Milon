package com.example.enhancer.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.enhancer.engine.DownloadStatus
import com.example.enhancer.model.ModelSlotType
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.BorderColor
import com.example.ui.theme.CardBackground
import com.example.ui.theme.CardGlowBorder
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.MainBackground
import com.example.ui.theme.MainText
import com.example.ui.theme.PrimaryGradient
import com.example.ui.theme.PrimaryPurple
import com.example.ui.theme.SecondaryBackground
import com.example.ui.theme.SecondaryBlue
import com.example.ui.theme.SecondaryText
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextMuted

@Composable
fun ModelDownloadGateScreen(
  downloadStatus: DownloadStatus,
  isMobileData: Boolean,
  onStartDownload: () -> Unit,
  onCancelDownload: () -> Unit,
  onImportModel: (Uri, ModelSlotType) -> Unit,
  modifier: Modifier = Modifier
) {
  val filePickerLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.OpenDocument()
  ) { uri: Uri? ->
    if (uri != null) {
      onImportModel(uri, ModelSlotType.IMAGE_MODEL)
    }
  }

  val isDownloading = downloadStatus is DownloadStatus.Downloading
  val isValidating = downloadStatus is DownloadStatus.Validating
  val isError = downloadStatus is DownloadStatus.Error

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(MainBackground)
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .verticalScroll(rememberScrollState())
        .padding(horizontal = 24.dp, vertical = 28.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center
    ) {
      // Glow icon avatar
      Surface(
        shape = CircleShape,
        color = SecondaryBackground,
        border = androidx.compose.foundation.BorderStroke(2.dp, CardGlowBorder),
        modifier = Modifier.size(96.dp)
      ) {
        Box(contentAlignment = Alignment.Center) {
          Icon(
            imageVector = Icons.Default.CloudDownload,
            contentDescription = null,
            tint = PrimaryPurple,
            modifier = Modifier.size(48.dp)
          )
        }
      }

      Spacer(modifier = Modifier.height(24.dp))

      // Main Gate Title
      Text(
        text = "মডেল ডাউনলোড করুন",
        fontSize = 24.sp,
        fontWeight = FontWeight.Bold,
        color = MainText,
        textAlign = TextAlign.Center
      )

      Spacer(modifier = Modifier.height(10.dp))

      // Informative Bengali text
      Text(
        text = "ছবি HD করার আগে AI মডেল ডাউনলোড করুন। এটা শুধু একবারই লাগবে, এরপর ইন্টারনেট ছাড়াই কাজ করবে।",
        fontSize = 14.sp,
        color = SecondaryText,
        textAlign = TextAlign.Center,
        lineHeight = 22.sp,
        modifier = Modifier.padding(horizontal = 12.dp)
      )

      Spacer(modifier = Modifier.height(24.dp))

      // Model info badge card
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CardBackground),
        border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(18.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text(
                text = "Real-ESRGAN AI মডেল",
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                color = MainText
              )
              Text(
                text = "অন-ডিভাইস সুপার-রেজোলিউশন ও শার্পেনিং",
                fontSize = 12.sp,
                color = TextMuted
              )
            }
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = SecondaryBackground,
              border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor)
            ) {
              Text(
                text = "প্রায় ৫ MB",
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                color = AccentCyan,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
              )
            }
          }

          // Mobile data warning
          if (isMobileData) {
            Spacer(modifier = Modifier.height(12.dp))
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = Color(0xFF2E2312),
              border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE6A23C).copy(alpha = 0.5f)),
              modifier = Modifier.fillMaxWidth()
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Icon(
                  imageVector = Icons.Default.WarningAmber,
                  contentDescription = null,
                  tint = Color(0xFFE6A23C),
                  modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                  text = "মোবাইল ডাটা খরচ হবে, Wi-Fi হলে ভালো।",
                  fontSize = 12.sp,
                  color = Color(0xFFFEEBC8)
                )
              }
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(24.dp))

      // Downloading State Card
      AnimatedVisibility(
        visible = isDownloading,
        enter = fadeIn(),
        exit = fadeOut()
      ) {
        val downloadInfo = downloadStatus as? DownloadStatus.Downloading
        if (downloadInfo != null) {
          Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = SecondaryBackground),
            border = androidx.compose.foundation.BorderStroke(1.dp, PrimaryPurple.copy(alpha = 0.5f)),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(18.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text(
                  text = if (downloadInfo.isResuming) "পুনরায় ডাউনলোড হচ্ছে (Resume)..." else "ডাউনলোড হচ্ছে...",
                  fontSize = 14.sp,
                  fontWeight = FontWeight.SemiBold,
                  color = MainText
                )
                Text(
                  text = "${downloadInfo.percent}%",
                  fontSize = 16.sp,
                  fontWeight = FontWeight.Bold,
                  color = PrimaryPurple
                )
              }

              Spacer(modifier = Modifier.height(10.dp))

              LinearProgressIndicator(
                progress = { downloadInfo.percent / 100f },
                modifier = Modifier
                  .fillMaxWidth()
                  .height(8.dp)
                  .clip(RoundedCornerShape(4.dp)),
                color = PrimaryPurple,
                trackColor = BorderColor
              )

              Spacer(modifier = Modifier.height(12.dp))

              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text(
                  text = "${downloadInfo.downloadedMb} MB / ${downloadInfo.totalMb} MB",
                  fontSize = 12.sp,
                  color = SecondaryText
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(
                    imageVector = Icons.Default.Speed,
                    contentDescription = null,
                    tint = AccentCyan,
                    modifier = Modifier.size(14.dp)
                  )
                  Spacer(modifier = Modifier.width(4.dp))
                  Text(
                    text = downloadInfo.speedText,
                    fontSize = 12.sp,
                    color = AccentCyan
                  )
                }
              }

              Spacer(modifier = Modifier.height(16.dp))

              OutlinedButton(
                onClick = onCancelDownload,
                colors = ButtonDefaults.outlinedButtonColors(contentColor = ErrorRed),
                border = androidx.compose.foundation.BorderStroke(1.dp, ErrorRed.copy(alpha = 0.5f)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                  .fillMaxWidth()
                  .testTag("cancel_download_button")
              ) {
                Text("বাতিল করুন", fontSize = 14.sp)
              }
            }
          }
        }
      }

      // Validating State
      AnimatedVisibility(
        visible = isValidating,
        enter = fadeIn(),
        exit = fadeOut()
      ) {
        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = SecondaryBackground),
          border = androidx.compose.foundation.BorderStroke(1.dp, AccentCyan.copy(alpha = 0.5f)),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier.padding(18.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            CircularProgressIndicator(
              modifier = Modifier.size(24.dp),
              color = AccentCyan,
              strokeWidth = 2.dp
            )
            Spacer(modifier = Modifier.width(14.dp))
            Column {
              Text(
                text = "মডেল যাচাই করা হচ্ছে...",
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                color = MainText
              )
              Text(
                text = "ONNX Runtime টেন্সর ইন্টিগ্রিটি চেক চলছে",
                fontSize = 12.sp,
                color = SecondaryText
              )
            }
          }
        }
      }

      // Error State Card
      AnimatedVisibility(
        visible = isError,
        enter = fadeIn(),
        exit = fadeOut()
      ) {
        val errorInfo = downloadStatus as? DownloadStatus.Error
        if (errorInfo != null) {
          Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF261215)),
            border = androidx.compose.foundation.BorderStroke(1.dp, ErrorRed.copy(alpha = 0.5f)),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(16.dp)) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                  imageVector = Icons.Default.ErrorOutline,
                  contentDescription = null,
                  tint = ErrorRed,
                  modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                  text = "ডাউনলোড ব্যর্থ হয়েছে",
                  fontSize = 14.sp,
                  fontWeight = FontWeight.Bold,
                  color = ErrorRed
                )
              }

              Spacer(modifier = Modifier.height(8.dp))

              Text(
                text = errorInfo.message,
                fontSize = 12.sp,
                color = Color(0xFFFFD2D9),
                lineHeight = 18.sp
              )

              if (errorInfo.canRetry) {
                Spacer(modifier = Modifier.height(14.dp))
                Button(
                  onClick = onStartDownload,
                  colors = ButtonDefaults.buttonColors(containerColor = ErrorRed),
                  shape = RoundedCornerShape(10.dp),
                  modifier = Modifier
                    .fillMaxWidth()
                    .testTag("retry_download_button")
                ) {
                  Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                  Spacer(modifier = Modifier.width(6.dp))
                  Text("আবার চেষ্টা করুন", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
              }
            }
          }
        }
      }

      if (!isDownloading && !isValidating) {
        Spacer(modifier = Modifier.height(8.dp))

        // Big Primary "ডাউনলোড করুন" Button
        Button(
          onClick = onStartDownload,
          colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
          shape = RoundedCornerShape(14.dp),
          modifier = Modifier
            .fillMaxWidth()
            .height(54.dp)
            .background(PrimaryGradient, shape = RoundedCornerShape(14.dp))
            .testTag("start_model_download_button")
        ) {
          Icon(
            imageVector = Icons.Default.FileDownload,
            contentDescription = null,
            tint = Color.White
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "ডাউনলোড করুন",
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
          )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Alternative Option: Import .onnx file directly
        OutlinedButton(
          onClick = {
            filePickerLauncher.launch(arrayOf("*/*"))
          },
          shape = RoundedCornerShape(14.dp),
          colors = ButtonDefaults.outlinedButtonColors(contentColor = SecondaryText),
          border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor),
          modifier = Modifier
            .fillMaxWidth()
            .height(50.dp)
            .testTag("import_onnx_alternative_button")
        ) {
          Icon(
            imageVector = Icons.Default.FileUpload,
            contentDescription = null,
            tint = SecondaryText,
            modifier = Modifier.size(18.dp)
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "অথবা .onnx ফাইল ইমপোর্ট করুন",
            fontSize = 13.sp,
            color = SecondaryText
          )
        }
      }
    }
  }
}
