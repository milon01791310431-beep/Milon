package com.example.enhancer.engine

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import ai.onnxruntime.TensorInfo
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.Shader
import android.util.Log
import com.example.enhancer.model.EngineStatus
import com.example.enhancer.model.EngineStatusInfo
import com.example.enhancer.model.EngineType
import com.example.enhancer.model.EnhancementConfig
import com.example.enhancer.model.ProcessingProgress
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.atomic.AtomicInteger
import java.nio.FloatBuffer
import kotlin.coroutines.coroutineContext
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

class OnnxModelEngine(
  private val context: Context,
  private val modelManager: ModelManager
) : AiInferenceEngine {

  override val engineType: EngineType = EngineType.ONNX_LOCAL_AI

  var lastRealEsrganRan: Boolean = false
    private set

  var lastFacesRestoredCount: Int = 0
    private set

  var lastFaceModelMissingNotice: Boolean = false
    private set

  private var ortEnvironment: OrtEnvironment? = null
  private var imageSession: OrtSession? = null
  private var faceSession: OrtSession? = null
  private var loadedImagePath: String? = null
  private var loadedFacePath: String? = null

  // Cache detected scale per model file path (e.g. 2 or 4)
  private val modelScaleCache = mutableMapOf<String, Int>()

  private fun getOrCreateEnv(): OrtEnvironment {
    var env = ortEnvironment
    if (env == null) {
      env = OrtEnvironment.getEnvironment()
      ortEnvironment = env
    }
    return env
  }

  @Synchronized
  private fun getImageSession(modelFile: File): OrtSession {
    if (imageSession != null && loadedImagePath == modelFile.absolutePath) {
      return imageSession!!
    }
    imageSession?.close()
    val env = getOrCreateEnv()
    val opts = OrtSession.SessionOptions().apply {
      try {
        addNnapi()
      } catch (_: Exception) {
        // Fall back to CPU execution provider
      }
    }
    imageSession = env.createSession(modelFile.absolutePath, opts)
    loadedImagePath = modelFile.absolutePath
    return imageSession!!
  }

  @Synchronized
  private fun getFaceSession(modelFile: File): OrtSession {
    if (faceSession != null && loadedFacePath == modelFile.absolutePath) {
      return faceSession!!
    }
    faceSession?.close()
    val env = getOrCreateEnv()
    val opts = OrtSession.SessionOptions().apply {
      try {
        addNnapi()
      } catch (_: Exception) {
        // Fall back to CPU
      }
    }
    faceSession = env.createSession(modelFile.absolutePath, opts)
    loadedFacePath = modelFile.absolutePath
    return faceSession!!
  }

  override suspend fun getStatusInfo(): EngineStatusInfo {
    val imageReady = modelManager.isImageModelReady()
    val faceReady = modelManager.isFaceModelReady()

    return if (imageReady) {
      val imageFile = modelManager.resolveImageModelFile()
      val cachedScale = imageFile?.let { modelScaleCache[it.absolutePath] } ?: 2
      EngineStatusInfo(
        engineType = EngineType.ONNX_LOCAL_AI,
        status = EngineStatus.READY,
        modelName = "Real-ESRGAN (x$cachedScale)" + (if (faceReady) " + GFPGAN Face" else ""),
        modelVersion = "ONNX Mobile",
        runtimeEnvironment = "Local ONNX Runtime (NNAPI / CPU)",
        computeDevice = "On-Device NPU/CPU",
        statusMessage = "অন-ডিভাইস নিউরাল মডেল প্রস্তুত (${cachedScale}x সুপার-রেজোলিউশন)। 100% অফলাইন মোডে কার্যকর।",
        isNeuralAi = true,
        supportedScales = listOf(2, 4),
        supportsFaceRestoration = faceReady,
        diagnosticNotes = "মডেল ফাইল: ${imageFile?.name ?: "image_model.onnx"} (Scale: ${cachedScale}x)"
      )
    } else {
      EngineStatusInfo(
        engineType = EngineType.ONNX_LOCAL_AI,
        status = EngineStatus.NOT_CONFIGURED,
        modelName = "AI মডেল ইনস্টল নেই",
        modelVersion = null,
        runtimeEnvironment = "Local ONNX Runtime",
        computeDevice = "On-Device",
        statusMessage = "AI মডেল নেই, বেসিক এনহান্সমেন্ট ব্যবহার হয়েছে",
        isNeuralAi = false,
        supportedScales = listOf(2, 4),
        supportsFaceRestoration = false,
        diagnosticNotes = "সেটিংস থেকে Real-ESRGAN .onnx মডেল ফাইল ইমপোর্ট বা ডাউনলোড করুন।"
      )
    }
  }

  override suspend fun checkReadiness(): Result<EngineStatusInfo> {
    val info = getStatusInfo()
    return if (info.status == EngineStatus.READY) {
      Result.success(info)
    } else {
      Result.failure(IllegalStateException("AI মডেল কনফিগার করা নেই। সেটিংস থেকে মডেল ইমপোর্ট করুন।"))
    }
  }

  override suspend fun enhance(
    sourceBitmap: Bitmap,
    config: EnhancementConfig,
    onProgress: (ProcessingProgress) -> Unit
  ): Result<Bitmap> = withContext(Dispatchers.Default) {
    val pipelineStartTime = System.currentTimeMillis()
    val budget = PipelineBudget(9000L)

    var workingInput: Bitmap? = null
    var upscaledBitmap: Bitmap? = null
    var workingBitmap: Bitmap? = null

    lastRealEsrganRan = false
    lastFacesRestoredCount = 0
    lastFaceModelMissingNotice = false

    try {
      coroutineContext.ensureActive()

      val imageModelFile = modelManager.resolveImageModelFile()
      if (imageModelFile == null || !imageModelFile.exists()) {
        return@withContext Result.failure(
          IllegalStateException("AI মডেল নেই, বেসিক এনহান্সমেন্ট ব্যবহার হয়েছে")
        )
      }

      val session = getImageSession(imageModelFile)
      val env = getOrCreateEnv()
      val scale = getOrDetectImageScale(session, env, imageModelFile)

      val origW = sourceBitmap.width
      val origH = sourceBitmap.height
      val longSide = max(origW, origH)

      // Initial analysis to detect blurLevel, small image size, and scene characteristics
      val tInitialAnalysisStart = System.currentTimeMillis()
      val initialFaces = if (config.faceEnhancement) {
        FaceDetectorOfflineHelper.detectFaces(sourceBitmap, maxFaces = 5)
      } else {
        emptyList()
      }
      val initialAnalysis = SmartAutoAnalyzer.analyze(sourceBitmap, initialFaces)
      val initialAnalysisDuration = System.currentTimeMillis() - tInitialAnalysisStart
      Log.i("PerformanceTiming", "Stage [analysis]: ${initialAnalysisDuration} ms")

      // WHOLE-IMAGE Real-ESRGAN:
      // Remove it from default path. It runs ONLY if:
      // photo is small or very blurry (long side < 700 px, or blurLevel < 20 from SmartAutoAnalyzer),
      // or if highQualitySlowMode is ON.
      val isSmallPhoto = longSide < 700
      val isVeryBlurry = initialAnalysis.blurLevel < 20f
      val shouldRunRealEsrgan = config.highQualitySlowMode || (isSmallPhoto || isVeryBlurry)

      // Step 1: Input sizing & memory safety
      val maxInputLongSide = 3840 / scale
      val needsResize = longSide > maxInputLongSide
      val factor = if (needsResize) maxInputLongSide.toFloat() / longSide else 1.0f
      val safeW = (origW * factor).roundToInt().coerceAtLeast(1)
      val safeH = (origH * factor).roundToInt().coerceAtLeast(1)

      val maxTiles = 16
      val estimatedTiles = if (shouldRunRealEsrgan) {
        computeTileCoordinates(safeW).size * computeTileCoordinates(safeH).size
      } else {
        0
      }
      val exceedsMaxTiles = !config.highQualitySlowMode && estimatedTiles > maxTiles

      if (!shouldRunRealEsrgan || exceedsMaxTiles) {
        if (!shouldRunRealEsrgan) {
          Log.i(
            "PerformanceTiming",
            "Stage [tiles] skipped: photo is not small (longSide=$longSide) and not very blurry (blur=${initialAnalysis.blurLevel})"
          )
        } else {
          Log.i(
            "PerformanceTiming",
            "Stage [tiles] skipped: totalTiles ($estimatedTiles) exceeds maxTiles ($maxTiles)"
          )
        }
        // Go straight to the tone stage using one single copy of the source (no extra bicubic copy, no extra sharpen pass)
        workingBitmap = sourceBitmap.copy(Bitmap.Config.ARGB_8888, true)
        lastRealEsrganRan = false
      } else {
        workingInput = if (needsResize) {
          Bitmap.createScaledBitmap(sourceBitmap, safeW, safeH, true)
        } else {
          sourceBitmap.copy(Bitmap.Config.ARGB_8888, true)
        }

        onProgress(
          ProcessingProgress(
            stage = "AI ব্যাকগ্রাউন্ড এনহান্সমেন্ট...",
            percent = if (config.highQualitySlowMode) 0.10f else max(0.10f, budget.elapsedFraction()),
            isIndeterminate = false,
            detail = "Real-ESRGAN (${scale}x) প্রসেসিং..."
          )
        )

        val tTilesStart = System.currentTimeMillis()
        upscaledBitmap = runRealEsrganTiled(
          inputBitmap = workingInput,
          modelFile = imageModelFile,
          scale = scale,
          onProgress = onProgress,
          budget = if (config.highQualitySlowMode) null else budget,
          maxTiles = maxTiles
        )
        val tilesDuration = System.currentTimeMillis() - tTilesStart
        Log.i("PerformanceTiming", "Stage [tiles]: ${tilesDuration} ms")

        if (workingInput != sourceBitmap) {
          workingInput?.recycle()
        }
        workingInput = null

        if (upscaledBitmap != null) {
          workingBitmap = upscaledBitmap
          lastRealEsrganRan = true
        } else {
          // If ESRGAN was skipped/stopped (e.g. tile 0 exceeded remaining budget)
          if (isSmallPhoto) {
            // Only keep the bicubic + applyLightPolish fallback when the photo is tiny (long side < 700) and ESRGAN was skipped
            val bicubicBmp = if (needsResize) {
              Bitmap.createScaledBitmap(sourceBitmap, safeW, safeH, true)
            } else {
              sourceBitmap.copy(Bitmap.Config.ARGB_8888, true)
            }
            val sharpened = applyLightPolish(bicubicBmp, SmartAutoAnalyzer.POLISH_FALLBACK_AMOUNT)
            if (bicubicBmp != sharpened) {
              bicubicBmp.recycle()
            }
            workingBitmap = sharpened
          } else {
            // Not tiny: go straight to tone stage using one single copy of the source
            workingBitmap = sourceBitmap.copy(Bitmap.Config.ARGB_8888, true)
          }
          lastRealEsrganRan = false
        }
      }

      coroutineContext.ensureActive()

      // Step 3: Face Model (GFPGAN)
      val tFacesStart = System.currentTimeMillis()
      val faceModelFile = modelManager.resolveFaceModelFile()
      val faceModelReady = faceModelFile != null && faceModelFile.exists()

      val prefs = context.getSharedPreferences("pipeline_benchmarks", Context.MODE_PRIVATE)
      val knownFaceInferenceMs = prefs.getLong("faceInferenceMs", -1L)

      val detectedFaces = if (config.faceEnhancement) {
        if (workingBitmap.width == sourceBitmap.width && workingBitmap.height == sourceBitmap.height) {
          initialFaces
        } else {
          FaceDetectorOfflineHelper.detectFaces(workingBitmap, maxFaces = 5)
        }
      } else {
        emptyList()
      }

      // Keep the tone and relight on the face even when the face model is skipped
      val facesForTone = detectedFaces

      if (faceModelReady && config.faceEnhancement && detectedFaces.isNotEmpty()) {
        val shouldSkipFaceModel = if (config.highQualitySlowMode) {
          false
        } else {
          // Skip the face model if faceInferenceMs is known and larger than remaining budget minus 2500 ms (first run allowed)
          knownFaceInferenceMs > 0L && knownFaceInferenceMs > (budget.remainingMs() - 2500L)
        }

        if (shouldSkipFaceModel) {
          Log.i(
            "PerformanceTiming",
            "Stage [faces] skipped: faceInferenceMs (${knownFaceInferenceMs}ms) > remaining budget - 2500ms (${budget.remainingMs() - 2500L}ms)"
          )
          lastFacesRestoredCount = 0
        } else {
          onProgress(
            ProcessingProgress(
              stage = "AI ফেস রিস্টোরেশন চলছে...",
              percent = if (config.highQualitySlowMode) 0.70f else max(0.40f, budget.elapsedFraction()),
              isIndeterminate = false,
              detail = "পোর্ট্রেট এরিয়া রিস্টোর করা হচ্ছে..."
            )
          )

          // Restore only the largest face (max 2 if the benchmark says it is fast)
          val sortedFaces = detectedFaces.sortedByDescending { it.rect.width() * it.rect.height() }
          val maxFacesToRestore = if (config.highQualitySlowMode) {
            sortedFaces.size
          } else {
            if (knownFaceInferenceMs in 1..1200 && budget.hasBudgetFor(knownFaceInferenceMs * 2 + 2500L)) 2 else 1
          }
          val facesToRestore = sortedFaces.take(maxFacesToRestore)

          val tFaceInferStart = System.currentTimeMillis()
          val restoredBitmap = restoreFacesWithOnnx(
            workingBitmap,
            facesToRestore,
            faceModelFile,
            faceStrength = config.faceStrength
          )
          val faceInferDuration = System.currentTimeMillis() - tFaceInferStart
          val perFaceMs = if (facesToRestore.isNotEmpty()) faceInferDuration / facesToRestore.size else faceInferDuration
          prefs.edit().putLong("faceInferenceMs", perFaceMs).apply()

          if (restoredBitmap != workingBitmap) {
            workingBitmap.recycle()
          }
          workingBitmap = restoredBitmap
          lastFacesRestoredCount = facesToRestore.size
        }
      } else {
        lastFacesRestoredCount = 0
        if (!faceModelReady && config.faceEnhancement) {
          lastFaceModelMissingNotice = true
        }
      }
      val facesDuration = System.currentTimeMillis() - tFacesStart
      Log.i("PerformanceTiming", "Stage [faces]: ${facesDuration} ms")

      coroutineContext.ensureActive()

      // Step 3.5: "Remini-look" tone and skin step
      onProgress(
        ProcessingProgress(
          stage = "টোন ও স্কিন অপ্টিমাইজেশন চলছে...",
          percent = if (config.highQualitySlowMode) 0.85f else max(0.85f, budget.elapsedFraction()),
          isIndeterminate = false,
          detail = "টোন ও স্কিন: 85%"
        )
      )

      val plan = SmartAutoAnalyzer.decide(initialAnalysis)
      Log.i("OnnxModelEngine", "SmartAutoAnalyzer EnhancePlan: $plan")

      val toneProgressCallback: (Float, String) -> Unit = { pct, detail ->
        val effectivePct = if (config.highQualitySlowMode) pct else max(pct, budget.elapsedFraction())
        onProgress(
          ProcessingProgress(
            stage = "টোন ও স্কিন অপ্টিমাইজেশন চলছে...",
            percent = effectivePct.coerceIn(0.85f, 0.98f),
            isIndeterminate = false,
            detail = detail
          )
        )
      }

      var reminiToned = ReminiToneSkinEngine.applyReminiLook(
        workingBitmap,
        facesForTone,
        plan = plan,
        onProgress = toneProgressCallback,
        budget = if (config.highQualitySlowMode) null else budget
      )

      // Compare result and original on 512px copy: if deltaE > 22 or face region shifted too much, rerun once with 80% strength
      val (meanDeltaE, faceDeltaE) = ReminiToneSkinEngine.computeDeltaEAndFaceShift(workingBitmap, reminiToned, facesForTone)
      Log.i("OnnxModelEngine", "Delta E verification: meanDeltaE=$meanDeltaE, faceDeltaE=$faceDeltaE")

      val canRerun = config.highQualitySlowMode || budget.hasBudgetFor(1000L)
      if ((meanDeltaE > 22.0f || faceDeltaE > 24.0f) && canRerun) {
        Log.w("OnnxModelEngine", "Excessive shift detected (meanDeltaE=$meanDeltaE, faceDeltaE=$faceDeltaE). Rerunning tone step with 80% strength.")
        reminiToned.recycle()
        reminiToned = ReminiToneSkinEngine.applyReminiLook(
          workingBitmap,
          facesForTone,
          intensity = ReminiToneSkinEngine.REMINI_LOOK_INTENSITY * 0.80f,
          plan = plan,
          onProgress = toneProgressCallback,
          budget = if (config.highQualitySlowMode) null else budget
        )
      }

      if (reminiToned != workingBitmap) {
        workingBitmap.recycle()
      }
      workingBitmap = reminiToned

      coroutineContext.ensureActive()

      // Step 4: Output size = Input size (Remini style)
      // Resize final image to original photo dimensions, keeping aspect ratio (no stretch, no crop).
      val origLongSide = max(origW, origH)
      val (targetW, targetH) = if (origLongSide > 4096) {
        val f = 4096f / origLongSide
        Pair((origW * f).roundToInt().coerceAtLeast(1), (origH * f).roundToInt().coerceAtLeast(1))
      } else {
        Pair(origW, origH)
      }

      onProgress(
        ProcessingProgress(
          stage = "আউটপুট রেজোলিউশন অ্যাডজাস্ট হচ্ছে...",
          percent = 0.95f,
          isIndeterminate = false,
          detail = "রেজোলিউশন সাইজ: ${targetW} × ${targetH} px..."
        )
      )

      val resizedBmp = resizeToTargetDimensions(workingBitmap, targetW, targetH)
      if (resizedBmp != workingBitmap) {
        workingBitmap.recycle()
      }
      workingBitmap = resizedBmp

      coroutineContext.ensureActive()

      // Step 5: Light final polish: mild sharpen driven by plan.sharpen (amount = sharpen * 0.6).
      // Skipped completely when the amount is below POLISH_SKIP_BELOW.
      val polishAmount = SmartAutoAnalyzer.polishAmountFor(plan.sharpen)
      onProgress(
        ProcessingProgress(
          stage = "ফাইনাল পলিশ প্রয়োগ হচ্ছে...",
          percent = 0.98f,
          isIndeterminate = false,
          detail = if (SmartAutoAnalyzer.shouldSkipPolish(polishAmount)) {
            "ছবি আগে থেকেই ধারালো, শার্পেন বাদ..."
          } else {
            "মাইল্ড শার্পেন (${"%.2f".format(polishAmount)}) ও ক্ল্যারিটি ব্যালেন্স..."
          }
        )
      )

      val tPolishStart = System.currentTimeMillis()
      val polishedBmp = applyLightPolish(workingBitmap, polishAmount)
      Log.i(
        "PerformanceTiming",
        "Stage [polish]: ${System.currentTimeMillis() - tPolishStart} ms (amount=$polishAmount)"
      )
      if (polishedBmp !== workingBitmap) {
        workingBitmap.recycle()
      }
      workingBitmap = null

      val totalPipelineDuration = System.currentTimeMillis() - pipelineStartTime
      Log.i("PerformanceTiming", "Pipeline Total: ${totalPipelineDuration} ms")

      Result.success(polishedBmp)
    } catch (e: Exception) {
      workingInput?.recycle()
      upscaledBitmap?.recycle()
      workingBitmap?.recycle()
      val totalPipelineDuration = System.currentTimeMillis() - pipelineStartTime
      Log.i("PerformanceTiming", "Pipeline Total: ${totalPipelineDuration} ms (failed)")
      Result.failure(e)
    }
  }

  /**
   * Light final polish: mild sharpen ([amount], 0.20 = the old fixed value) and gentle contrast/clarity.
   * Preserves natural skin tone, age, and identity without oversaturation or plastic look.
   *
   * Runs in parallel row bands (no full-size IntArray, no pixels.clone()). If the amount is below
   * [SmartAutoAnalyzer.POLISH_SKIP_BELOW] the pass is skipped and the SAME bitmap is returned,
   * so callers must not recycle the input when the returned instance is the input.
   */
  private suspend fun applyLightPolish(input: Bitmap, amount: Float): Bitmap = coroutineScope {
    if (SmartAutoAnalyzer.shouldSkipPolish(amount)) {
      return@coroutineScope input
    }
    val width = input.width
    val height = input.height
    if (width < 3 || height < 3) {
      return@coroutineScope input
    }

    val output = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    val sharpenFactor = amount
    // 1.04 at amount 0.20 (same gentle contrast as before), proportionally less for smaller amounts
    val contrastFactor = 1f + 0.2f * amount

    val bandHeight = 128
    val totalBands = (height + bandHeight - 1) / bandHeight
    val workerCount = max(1, min(Runtime.getRuntime().availableProcessors() - 1, totalBands))
    val nextBand = AtomicInteger(0)
    val writeLock = Any()

    val workers = (0 until workerCount).map {
      async(Dispatchers.Default) {
        // Each worker reuses its own buffers: band rows plus a 1 row halo above and below
        val inBuf = IntArray(width * (bandHeight + 2))
        val outBuf = IntArray(width * bandHeight)

        while (true) {
          val band = nextBand.getAndIncrement()
          if (band >= totalBands) break
          ensureActive()

          val y0 = band * bandHeight
          val y1 = min(height, y0 + bandHeight) // exclusive
          val readStart = max(0, y0 - 1)
          val readEnd = min(height, y1 + 1) // exclusive
          input.getPixels(inBuf, 0, width, 0, readStart, width, readEnd - readStart)

          for (y in y0 until y1) {
            val inRow = (y - readStart) * width
            val outRow = (y - y0) * width

            // First and last image rows stay unchanged (as before)
            if (y == 0 || y == height - 1) {
              System.arraycopy(inBuf, inRow, outBuf, outRow, width)
              continue
            }

            val prevRow = inRow - width
            val nextRow = inRow + width

            // First and last columns stay unchanged (as before)
            outBuf[outRow] = inBuf[inRow]
            outBuf[outRow + width - 1] = inBuf[inRow + width - 1]

            for (x in 1 until width - 1) {
              val c = inBuf[inRow + x]
              val cR = (c shr 16) and 0xFF
              val cG = (c shr 8) and 0xFF
              val cB = c and 0xFF

              val top = inBuf[prevRow + x]
              val bottom = inBuf[nextRow + x]
              val left = inBuf[inRow + x - 1]
              val right = inBuf[inRow + x + 1]

              // Laplacian sharpening
              val lapR = (4 * cR) - (((top shr 16) and 0xFF) + ((bottom shr 16) and 0xFF) + ((left shr 16) and 0xFF) + ((right shr 16) and 0xFF))
              val lapG = (4 * cG) - (((top shr 8) and 0xFF) + ((bottom shr 8) and 0xFF) + ((left shr 8) and 0xFF) + ((right shr 8) and 0xFF))
              val lapB = (4 * cB) - ((top and 0xFF) + (bottom and 0xFF) + (left and 0xFF) + (right and 0xFF))

              val sR = cR + sharpenFactor * lapR
              val sG = cG + sharpenFactor * lapG
              val sB = cB + sharpenFactor * lapB

              // Gentle contrast/clarity without oversaturation:
              // adjust the luminance midtone curve and apply the offset uniformly across R, G, B
              val lum = 0.299f * sR + 0.587f * sG + 0.114f * sB
              val contrastLum = (lum - 128f) * contrastFactor + 128f
              val diff = (contrastLum - lum).coerceIn(-8f, 8f)

              val finalR = (sR + diff).roundToInt().coerceIn(0, 255)
              val finalG = (sG + diff).roundToInt().coerceIn(0, 255)
              val finalB = (sB + diff).roundToInt().coerceIn(0, 255)

              outBuf[outRow + x] = (0xFF shl 24) or (finalR shl 16) or (finalG shl 8) or finalB
            }
          }

          synchronized(writeLock) {
            output.setPixels(outBuf, 0, width, 0, y0, width, y1 - y0)
          }
        }
      }
    }
    workers.awaitAll()
    output
  }

  private suspend fun restoreFacesWithOnnx(
    source: Bitmap,
    faces: List<FaceDetectorOfflineHelper.DetectedFaceBox>,
    faceModelFile: File,
    faceStrength: Float
  ): Bitmap = withContext(Dispatchers.Default) {
    val session = getFaceSession(faceModelFile)
    val env = getOrCreateEnv()
    val inputName = session.inputNames.iterator().next()

    val resultBitmap = source.copy(Bitmap.Config.ARGB_8888, true)
    val canvas = Canvas(resultBitmap)

    for (faceBox in faces) {
      coroutineContext.ensureActive()
      val rect = faceBox.rect
      val width = rect.width()
      val height = rect.height()
      if (width <= 10 || height <= 10) continue

      // 30% padding, centered square
      val pad = (max(width, height) * 0.30f).toInt()
      val side = max(width, height) + pad * 2
      val cx = rect.centerX()
      val cy = rect.centerY()

      val cropLeft = (cx - side / 2).coerceIn(0, source.width - 1)
      val cropTop = (cy - side / 2).coerceIn(0, source.height - 1)
      val cropRight = (cropLeft + side).coerceIn(cropLeft + 1, source.width)
      val cropBottom = (cropTop + side).coerceIn(cropTop + 1, source.height)
      val cropW = cropRight - cropLeft
      val cropH = cropBottom - cropTop
      if (cropW <= 0 || cropH <= 0) continue

      val faceCrop = Bitmap.createBitmap(source, cropLeft, cropTop, cropW, cropH)
      val resized512 = Bitmap.createScaledBitmap(faceCrop, 512, 512, true)
      faceCrop.recycle()

      // Convert 512x512 to FloatBuffer NCHW [1, 3, 512, 512] normalized [-1, 1]
      val floatBuffer = FloatBuffer.allocate(1 * 3 * 512 * 512)
      val pixels = IntArray(512 * 512)
      resized512.getPixels(pixels, 0, 512, 0, 0, 512, 512)

      // R channel
      for (i in pixels.indices) {
        val r = (pixels[i] shr 16) and 0xFF
        floatBuffer.put((r / 255.0f - 0.5f) / 0.5f)
      }
      // G channel
      for (i in pixels.indices) {
        val g = (pixels[i] shr 8) and 0xFF
        floatBuffer.put((g / 255.0f - 0.5f) / 0.5f)
      }
      // B channel
      for (i in pixels.indices) {
        val b = pixels[i] and 0xFF
        floatBuffer.put((b / 255.0f - 0.5f) / 0.5f)
      }
      floatBuffer.rewind()
      resized512.recycle()

      val tensor = OnnxTensor.createTensor(env, floatBuffer, longArrayOf(1, 3, 512, 512))
      val sessionResult = session.run(mapOf(inputName to tensor))
      tensor.close()

      val outputTensor = sessionResult.get(0) as OnnxTensor
      val outBuffer = outputTensor.floatBuffer
      val outPixels = IntArray(512 * 512)

      val channelStride = 512 * 512
      for (p in 0 until channelStride) {
        val rVal = outBuffer.get(p)
        val gVal = outBuffer.get(p + channelStride)
        val bVal = outBuffer.get(p + channelStride * 2)

        val r = (((rVal * 0.5f) + 0.5f) * 255f).toInt().coerceIn(0, 255)
        val g = (((gVal * 0.5f) + 0.5f) * 255f).toInt().coerceIn(0, 255)
        val b = (((bVal * 0.5f) + 0.5f) * 255f).toInt().coerceIn(0, 255)
        outPixels[p] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
      }
      sessionResult.close()

      val restored512 = Bitmap.createBitmap(outPixels, 512, 512, Bitmap.Config.ARGB_8888)
      val scaledBack = Bitmap.createScaledBitmap(restored512, cropW, cropH, true)
      restored512.recycle()

      // Feathered blend onto resultBitmap using faceStrength (default 0.8)
      blendFaceOntoCanvas(
        canvas = canvas,
        restoredFace = scaledBack,
        x = cropLeft.toFloat(),
        y = cropTop.toFloat(),
        strength = faceStrength.coerceIn(0.1f, 1.0f)
      )
      scaledBack.recycle()
    }

    resultBitmap
  }

  private fun blendFaceOntoCanvas(
    canvas: Canvas,
    restoredFace: Bitmap,
    x: Float,
    y: Float,
    strength: Float
  ) {
    val w = restoredFace.width
    val h = restoredFace.height
    val maskBitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val maskCanvas = Canvas(maskBitmap)

    // Soft feathered circular/oval mask
    val radius = min(w, h) * 0.48f
    val shader = RadialGradient(
      w / 2f, h / 2f, radius,
      intArrayOf(Color.BLACK, Color.BLACK, Color.TRANSPARENT),
      floatArrayOf(0f, 0.75f, 1.0f),
      Shader.TileMode.CLAMP
    )
    val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
      this.shader = shader
    }
    maskCanvas.drawCircle(w / 2f, h / 2f, radius, paint)

    // Apply strength to mask alpha
    val blendPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
      alpha = (strength * 255).toInt().coerceIn(0, 255)
      xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN)
    }

    val maskedFace = restoredFace.copy(Bitmap.Config.ARGB_8888, true)
    val faceCanvas = Canvas(maskedFace)
    faceCanvas.drawBitmap(maskBitmap, 0f, 0f, blendPaint)
    maskBitmap.recycle()

    canvas.drawBitmap(maskedFace, x, y, null)
    maskedFace.recycle()
  }

  /**
   * Auto-detect the scale factor from the session output tensor shape.
   * Checks static shape first, then runs a probe tile tensor if dynamic.
   * Caches result per loaded model. Supports x2 and x4.
   */
  private fun getOrDetectImageScale(
    session: OrtSession,
    env: OrtEnvironment,
    modelFile: File,
    tileSize: Int = 128
  ): Int {
    modelScaleCache[modelFile.absolutePath]?.let { return it }

    // 1. Try static shape inspection if available
    try {
      val outNode = session.outputInfo.values.firstOrNull()?.info as? TensorInfo
      val inNode = session.inputInfo.values.firstOrNull()?.info as? TensorInfo
      val outShape = outNode?.shape
      val inShape = inNode?.shape
      if (outShape != null && inShape != null && outShape.size >= 4 && inShape.size >= 4) {
        val outH = outShape[2]
        val inH = inShape[2]
        if (outH > 0 && inH > 0) {
          val s = (outH / inH).toInt()
          if (s in listOf(2, 4)) {
            modelScaleCache[modelFile.absolutePath] = s
            return s
          }
        }
      }
    } catch (_: Exception) {}

    // 2. Probe with a dummy tile tensor
    try {
      val inputName = session.inputNames.iterator().next()
      val dummyBuffer = FloatBuffer.allocate(1 * 3 * tileSize * tileSize)
      val tensor = OnnxTensor.createTensor(
        env,
        dummyBuffer,
        longArrayOf(1, 3, tileSize.toLong(), tileSize.toLong())
      )
      val result = session.run(mapOf(inputName to tensor))
      tensor.close()
      val outTensor = result.get(0) as OnnxTensor
      val outShape = outTensor.info.shape
      val realOutH = if (outShape.size >= 4) outShape[2].toInt() else tileSize * 2
      result.close()
      val detectedScale = (realOutH / tileSize).let { if (it >= 3) 4 else 2 }
      modelScaleCache[modelFile.absolutePath] = detectedScale
      return detectedScale
    } catch (_: Exception) {
      val fallback = 2
      modelScaleCache[modelFile.absolutePath] = fallback
      return fallback
    }
  }

  private fun computeTileCoordinates(dimension: Int, tileSize: Int = 128, overlap: Int = 10): List<Int> {
    val coords = mutableListOf<Int>()
    val step = (tileSize - overlap).coerceAtLeast(1)
    if (dimension <= tileSize) {
      coords.add(0)
    } else {
      var curr = 0
      while (curr + tileSize < dimension) {
        coords.add(curr)
        curr += step
      }
      val last = dimension - tileSize
      if (coords.isEmpty() || coords.last() != last) {
        coords.add(last)
      }
    }
    return coords
  }

  private suspend fun runRealEsrganTiled(
    inputBitmap: Bitmap,
    modelFile: File,
    scale: Int,
    onProgress: (ProcessingProgress) -> Unit,
    budget: PipelineBudget? = null,
    maxTiles: Int = 16
  ): Bitmap? = withContext(Dispatchers.Default) {
    val session = getImageSession(modelFile)
    val env = getOrCreateEnv()
    val inputName = session.inputNames.iterator().next()

    val tileSize = 128
    val overlap = 10
    val step = (tileSize - overlap).coerceAtLeast(1)

    // Run AI upscale on the input at its resolution
    val inW = inputBitmap.width
    val inH = inputBitmap.height
    val outW = inW * scale
    val outH = inH * scale

    val outputBitmap = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
    val outputCanvas = Canvas(outputBitmap)

    // Coordinate steps covering the full dimensions with native tile size (no stretching)
    val xCoords = computeTileCoordinates(inW, tileSize, overlap)
    val yCoords = computeTileCoordinates(inH, tileSize, overlap)

    val totalTiles = xCoords.size * yCoords.size
    if (budget != null && totalTiles > maxTiles) {
      Log.i(
        "PerformanceTiming",
        "Stage [tiles] skipped: totalTiles ($totalTiles) exceeds maxTiles ($maxTiles)"
      )
      outputBitmap.recycle()
      return@withContext null
    }

    var processedTiles = 0
    var tile0StartTime = 0L

    val tilePixels = IntArray(tileSize * tileSize)

    for ((yi, y) in yCoords.withIndex()) {
      for ((xi, x) in xCoords.withIndex()) {
        coroutineContext.ensureActive()

        if (processedTiles == 0) {
          tile0StartTime = System.currentTimeMillis()
        }

        val actualW = min(tileSize, inW - x)
        val actualH = min(tileSize, inH - y)

        val tileBmp = Bitmap.createBitmap(inputBitmap, x, y, actualW, actualH)
        val uniformTile = if (actualW != tileSize || actualH != tileSize) {
          // If image dimension is smaller than tileSize, pad onto tileSize x tileSize
          val padded = Bitmap.createBitmap(tileSize, tileSize, Bitmap.Config.ARGB_8888)
          val pCanvas = Canvas(padded)
          pCanvas.drawBitmap(tileBmp, 0f, 0f, null)
          tileBmp.recycle()
          padded
        } else {
          tileBmp
        }

        uniformTile.getPixels(tilePixels, 0, tileSize, 0, 0, tileSize, tileSize)
        uniformTile.recycle()

        // NCHW float32 RGB in [0.0f, 1.0f]
        val floatBuffer = FloatBuffer.allocate(1 * 3 * tileSize * tileSize)
        val channelSize = tileSize * tileSize

        // R
        for (i in 0 until channelSize) {
          floatBuffer.put(((tilePixels[i] shr 16) and 0xFF) / 255.0f)
        }
        // G
        for (i in 0 until channelSize) {
          floatBuffer.put(((tilePixels[i] shr 8) and 0xFF) / 255.0f)
        }
        // B
        for (i in 0 until channelSize) {
          floatBuffer.put((tilePixels[i] and 0xFF) / 255.0f)
        }
        floatBuffer.rewind()

        val tensor = OnnxTensor.createTensor(
          env,
          floatBuffer,
          longArrayOf(1, 3, tileSize.toLong(), tileSize.toLong())
        )
        val runResult = session.run(mapOf(inputName to tensor))
        tensor.close()

        val outTensor = runResult.get(0) as OnnxTensor
        val outBuf = outTensor.floatBuffer
        val outShape = outTensor.info.shape // [1, 3, realOutH, realOutW]

        // Read output with its real dimensions from output tensor shape
        val realOutH = if (outShape.size >= 4) outShape[2].toInt() else tileSize * scale
        val realOutW = if (outShape.size >= 4) outShape[3].toInt() else tileSize * scale

        // Update cached scale
        val tensorScale = (realOutH / tileSize).let { if (it >= 3) 4 else 2 }
        modelScaleCache[modelFile.absolutePath] = tensorScale

        val outChannelSize = realOutW * realOutH
        val outTilePixels = IntArray(outChannelSize)

        // Linear feathering to avoid seams:
        val hasLeftOverlap = xi > 0
        val overlapW = if (hasLeftOverlap) {
          ((xCoords[xi - 1] + tileSize - x) * scale).coerceIn(1, realOutW)
        } else 0

        val hasTopOverlap = yi > 0
        val overlapH = if (hasTopOverlap) {
          ((yCoords[yi - 1] + tileSize - y) * scale).coerceIn(1, realOutH)
        } else 0

        for (py in 0 until realOutH) {
          val weightY = if (hasTopOverlap && py < overlapH) {
            py.toFloat() / overlapH.toFloat()
          } else {
            1.0f
          }

          val rowOffset = py * realOutW

          for (px in 0 until realOutW) {
            val weightX = if (hasLeftOverlap && px < overlapW) {
              px.toFloat() / overlapW.toFloat()
            } else {
              1.0f
            }

            val p = rowOffset + px
            val r = (outBuf.get(p) * 255.0f).toInt().coerceIn(0, 255)
            val g = (outBuf.get(p + outChannelSize) * 255.0f).toInt().coerceIn(0, 255)
            val b = (outBuf.get(p + outChannelSize * 2) * 255.0f).toInt().coerceIn(0, 255)

            // Linear feather alpha blending
            val alphaF = weightX * weightY
            val alpha = (alphaF * 255.0f).roundToInt().coerceIn(0, 255)

            outTilePixels[p] = (alpha shl 24) or (r shl 16) or (g shl 8) or b
          }
        }
        runResult.close()

        val outTileBmp = Bitmap.createBitmap(outTilePixels, realOutW, realOutH, Bitmap.Config.ARGB_8888)

        // If actual input was smaller than tileSize, draw only the valid region
        val drawW = actualW * scale
        val drawH = actualH * scale
        val finalCropTile = if (drawW != realOutW || drawH != realOutH) {
          Bitmap.createBitmap(outTileBmp, 0, 0, drawW, drawH).also { outTileBmp.recycle() }
        } else {
          outTileBmp
        }

        outputCanvas.drawBitmap(finalCropTile, (x * scale).toFloat(), (y * scale).toFloat(), null)
        finalCropTile.recycle()

        processedTiles++
        if (processedTiles == 1 && budget != null) {
          val tile0Ms = System.currentTimeMillis() - tile0StartTime
          val estimatedTotalMs = tile0Ms * totalTiles
          if (!budget.hasBudgetFor(estimatedTotalMs)) {
            Log.i(
              "PerformanceTiming",
              "Stage [tiles] stopped: estimated ${estimatedTotalMs} ms (${tile0Ms} ms x $totalTiles tiles) exceeds remaining ${budget.remainingMs()} ms"
            )
            outputBitmap.recycle()
            return@withContext null
          }
        }

        val progressPercent = 0.10f + 0.58f * (processedTiles.toFloat() / totalTiles.toFloat())
        val budgetFrac = budget?.elapsedFraction() ?: 0f
        val effectiveProgress = max(progressPercent, budgetFrac).coerceIn(0.10f, 0.70f)
        onProgress(
          ProcessingProgress(
            stage = "AI ব্যাকগ্রাউন্ড প্রসেসিং...",
            percent = effectiveProgress,
            isIndeterminate = false,
            detail = "টাইল $processedTiles / $totalTiles সম্পন্ন (${(effectiveProgress * 100).roundToInt()}%)"
          )
        )
      }
    }

    outputBitmap
  }

  /**
   * Resizes image to target dimensions (exact width x height of original photo, capped at 4096).
   * If the AI result is much larger than the target, downscales in steps of 2 (halving)
   * and finishes with one high-quality bicubic resize to keep it sharp.
   */
  fun resizeToTargetDimensions(
    bitmap: Bitmap,
    targetWidth: Int,
    targetHeight: Int
  ): Bitmap {
    if (bitmap.width == targetWidth && bitmap.height == targetHeight) {
      return bitmap
    }

    var current = bitmap
    while (current.width > targetWidth * 2 && current.height > targetHeight * 2) {
      val nextW = current.width / 2
      val nextH = current.height / 2
      val halfBmp = Bitmap.createScaledBitmap(current, nextW, nextH, true)
      if (current != bitmap) {
        current.recycle()
      }
      current = halfBmp
    }

    val finalBmp = Bitmap.createScaledBitmap(current, targetWidth, targetHeight, true)
    if (current != bitmap && current != finalBmp) {
      current.recycle()
    }
    return finalBmp
  }

  override fun release() {
    try {
      imageSession?.close()
      imageSession = null
      loadedImagePath = null
      modelScaleCache.clear()
    } catch (_: Exception) {}

    try {
      faceSession?.close()
      faceSession = null
      loadedFacePath = null
    } catch (_: Exception) {}

    try {
      ortEnvironment?.close()
      ortEnvironment = null
    } catch (_: Exception) {}
  }
}
