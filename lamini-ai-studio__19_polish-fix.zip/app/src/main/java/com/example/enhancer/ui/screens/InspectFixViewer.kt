package com.example.enhancer.ui.screens

import android.graphics.Bitmap
import android.graphics.Rect
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculateCentroidSize
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.Brush
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.PointMode
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.PointerInputChange
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.enhancer.engine.ImageStroke
import com.example.enhancer.engine.InspectFixEngine
import com.example.enhancer.engine.PatchHistoryManager
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.CardBackground
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.MainText
import com.example.ui.theme.PrimaryGradient
import com.example.ui.theme.PrimaryPurple
import com.example.ui.theme.SecondaryText
import com.example.ui.theme.SuccessGreen
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Full-Screen "Inspect & Fix" viewer.
 *
 * Features:
 * - 100% offline, zero cloud API calls.
 * - Real pixel-size inspection with smooth viewport-crop drawImage (srcOffset / srcSize).
 * - Pinch to zoom (up to 8x), two-finger pan, double-tap toggle (1x / 3x).
 * - Press & hold "আসল দেখুন" to compare live with the original image.
 * - Brush mode ("ঠিক করুন") with size slider and single-finger painting in image pixel coordinates.
 * - Fix actions: "আসল ফেরান" (Revert to original inside mask) and "দাগ মুছুন" (Inpaint / clean blemish).
 * - Morphological dilation (3px) + Gaussian feathering (8px) for seamless edges.
 * - Undo / Redo patch manager (up to 10 steps of crop pixels).
 * - Big bottom "Gallery-তে সেভ করুন" button with fixed JPG 95 / PNG lossless format.
 */
@Composable
fun InspectFixViewer(
  originalBitmap: Bitmap,
  enhancedBitmap: Bitmap,
  isSaving: Boolean = false,
  saveNotification: String? = null,
  onBitmapModified: (Bitmap) -> Unit,
  onSaveToGallery: () -> Unit,
  onDismissNotification: () -> Unit = {},
  onClose: () -> Unit,
  modifier: Modifier = Modifier
) {
  val coroutineScope = rememberCoroutineScope()

  // ONE mutable working bitmap created once (edited in place)
  val workingBitmap = remember {
    if (enhancedBitmap.isMutable) {
      enhancedBitmap
    } else {
      enhancedBitmap.copy(Bitmap.Config.ARGB_8888, true)
    }
  }

  // Version counter to trigger Canvas redraws when workingBitmap is edited in place
  var bitmapVersion by remember { mutableIntStateOf(0) }

  // Double-tap tracking state (real double-tap within 300ms)
  var lastTapTime by remember { mutableLongStateOf(0L) }
  var lastTapPosition by remember { mutableStateOf(Offset.Zero) }

  // Undo / Redo patch manager
  val patchHistory = remember { PatchHistoryManager(maxCapacity = 10) }
  var historyUpdateTrigger by remember { mutableStateOf(0) }

  // Viewing transformations
  var zoom by remember { mutableFloatStateOf(1f) }
  var panX by remember { mutableFloatStateOf(0f) }
  var panY by remember { mutableFloatStateOf(0f) }

  // Press-and-hold "আসল দেখুন"
  var isHoldingOriginal by remember { mutableStateOf(false) }

  // Brush mode state
  var isBrushMode by remember { mutableStateOf(false) }
  var brushRadiusPx by remember { mutableFloatStateOf(24f) } // in image pixels (diameter 48px)
  val strokes = remember { mutableStateListOf<ImageStroke>() }
  var currentStrokePoints by remember { mutableStateOf<List<Offset>>(emptyList()) }

  // Background action processing state
  var isProcessingFix by remember { mutableStateOf(false) }
  var processingMessage by remember { mutableStateOf("") }
  var userMessage by remember { mutableStateOf<String?>(null) }

  // Handle system back button
  BackHandler {
    onClose()
  }

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(Color.Black)
      .testTag("inspect_fix_viewer")
  ) {
    // Canvas container for real pixel rendering & gesture processing
    BoxWithConstraints(
      modifier = Modifier.fillMaxSize()
    ) {
      val canvasWidth = constraints.maxWidth.toFloat()
      val canvasHeight = constraints.maxHeight.toFloat()
      val imgW = workingBitmap.width
      val imgH = workingBitmap.height

      val currentZoom by rememberUpdatedState(zoom)
      val currentPanX by rememberUpdatedState(panX)
      val currentPanY by rememberUpdatedState(panY)
      val currentBrushRadiusPx by rememberUpdatedState(brushRadiusPx)
      val currentCanvasWidth by rememberUpdatedState(canvasWidth)
      val currentCanvasHeight by rememberUpdatedState(canvasHeight)
      val currentImgW by rememberUpdatedState(imgW)
      val currentImgH by rememberUpdatedState(imgH)

      // Single unified gesture handler: 2-finger zoom/pan, 1-finger brush or pan, real double tap
      Box(
        modifier = Modifier
          .fillMaxSize()
          .pointerInput(Unit, isBrushMode) {
            awaitEachGesture {
              val firstDown = awaitFirstDown(requireUnconsumed = false)
              var isMultiTouch = false
              var hasMovedSignificantly = false
              val startPos = firstDown.position
              val downTime = System.currentTimeMillis()
              val activePoints = mutableListOf<Offset>()

              if (isBrushMode) {
                // Convert down point to image pixel space
                val imgPt = InspectFixEngine.screenToImageCoordinates(
                  firstDown.position,
                  currentCanvasWidth,
                  currentCanvasHeight,
                  currentImgW,
                  currentImgH,
                  currentZoom,
                  currentPanX,
                  currentPanY
                )
                if (imgPt != null) {
                  activePoints.add(imgPt)
                  currentStrokePoints = activePoints.toList()
                }
              }

              while (true) {
                val event = awaitPointerEvent()
                val pointerCount = event.changes.size

                if (pointerCount >= 2) {
                  // Two or more fingers: Zoom and Pan
                  isMultiTouch = true
                  hasMovedSignificantly = true
                  // Discard partial single-finger brush stroke if user switched to multi-touch
                  if (activePoints.isNotEmpty()) {
                    activePoints.clear()
                    currentStrokePoints = emptyList()
                  }

                  val zoomChange = event.calculateZoom()
                  val panChange = event.calculatePan()

                  val newZoom = (zoom * zoomChange).coerceIn(1f, 8f)
                  zoom = newZoom

                  if (newZoom <= 1.05f) {
                    panX = 0f
                    panY = 0f
                  } else {
                    panX += panChange.x
                    panY += panChange.y
                  }

                  event.changes.forEach { it.consume() }
                } else if (pointerCount == 1) {
                  val change = event.changes[0]
                  if (change.pressed) {
                    if ((change.position - startPos).getDistance() > 18f) {
                      hasMovedSignificantly = true
                    }

                    if (isMultiTouch) {
                      // Still recovering from pinch
                      change.consume()
                    } else if (isBrushMode) {
                      // Single finger painting: track stroke in image space
                      val imgPt = InspectFixEngine.screenToImageCoordinates(
                        change.position,
                        currentCanvasWidth,
                        currentCanvasHeight,
                        currentImgW,
                        currentImgH,
                        zoom,
                        panX,
                        panY
                      )
                      if (imgPt != null) {
                        activePoints.add(imgPt)
                        currentStrokePoints = activePoints.toList()
                      }
                      change.consume()
                    } else {
                      // Pan when brush mode is off
                      if (zoom > 1.05f) {
                        panX += change.positionChange().x
                        panY += change.positionChange().y
                      }
                      change.consume()
                    }
                  } else {
                    // Pointer released (Up)
                    if (isBrushMode && activePoints.isNotEmpty() && !isMultiTouch) {
                      strokes.add(ImageStroke(activePoints.toList(), currentBrushRadiusPx))
                      activePoints.clear()
                      currentStrokePoints = emptyList()
                    }

                    // Double-tap detection when not brushing:
                    // A single quick tap must NOT zoom. Real double-tap (two taps within 300 ms) toggles 1x / 3x.
                    val duration = System.currentTimeMillis() - downTime
                    if (!isMultiTouch && !isBrushMode && !hasMovedSignificantly && duration < 300) {
                      val now = System.currentTimeMillis()
                      val elapsed = now - lastTapTime
                      val distFromLast = (change.position - lastTapPosition).getDistance()

                      if (elapsed in 1..300 && distFromLast < 100f) {
                        // Two taps within 300 ms: toggle 1x / 3x around tap point
                        lastTapTime = 0L
                        lastTapPosition = Offset.Zero
                        val tapPos = change.position

                        if (zoom > 1.2f) {
                          zoom = 1f
                          panX = 0f
                          panY = 0f
                        } else {
                          zoom = 3f
                          val cW = currentCanvasWidth
                          val cH = currentCanvasHeight
                          panX = (cW / 2f - tapPos.x) * 2f
                          panY = (cH / 2f - tapPos.y) * 2f
                        }
                      } else {
                        // First tap of potential double-tap; do not zoom
                        lastTapTime = now
                        lastTapPosition = change.position
                      }
                    }
                    break
                  }
                } else {
                  break
                }
              }
            }
          }
      ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
          val _v = bitmapVersion
          val activeBitmap = if (isHoldingOriginal) originalBitmap else workingBitmap
          val bmpW = activeBitmap.width
          val bmpH = activeBitmap.height

          val baseScale = min(canvasWidth / bmpW.toFloat(), canvasHeight / bmpH.toFloat())
          val effectiveScale = baseScale * zoom
          val dispW = bmpW * effectiveScale
          val dispH = bmpH * effectiveScale

          val screenImgLeft = (canvasWidth - dispW) / 2f + panX
          val screenImgTop = (canvasHeight - dispH) / 2f + panY

          // 1. Draw only visible region from full-resolution bitmap (drawImage with srcOffset/srcSize)
          val visLeftScreen = max(0f, screenImgLeft)
          val visTopScreen = max(0f, screenImgTop)
          val visRightScreen = min(canvasWidth, screenImgLeft + dispW)
          val visBottomScreen = min(canvasHeight, screenImgTop + dispH)

          if (visRightScreen > visLeftScreen && visBottomScreen > visTopScreen) {
            val srcX = ((visLeftScreen - screenImgLeft) / effectiveScale).toInt().coerceIn(0, bmpW - 1)
            val srcY = ((visTopScreen - screenImgTop) / effectiveScale).toInt().coerceIn(0, bmpH - 1)
            val srcW = ((visRightScreen - visLeftScreen) / effectiveScale).toInt().coerceIn(1, bmpW - srcX)
            val srcH = ((visBottomScreen - visTopScreen) / effectiveScale).toInt().coerceIn(1, bmpH - srcY)

            val dstOffset = IntOffset(visLeftScreen.roundToInt(), visTopScreen.roundToInt())
            val dstSize = IntSize(
              (visRightScreen - visLeftScreen).roundToInt(),
              (visBottomScreen - visTopScreen).roundToInt()
            )

            drawImage(
              image = activeBitmap.asImageBitmap(),
              srcOffset = IntOffset(srcX, srcY),
              srcSize = IntSize(srcW, srcH),
              dstOffset = dstOffset,
              dstSize = dstSize,
              filterQuality = FilterQuality.Medium
            )
          }

          // 2. Draw lightweight semi-transparent red marker strokes in screen coordinates
          val markerColor = Color(0x99FF3B30) // Semi-transparent red
          val markerGlowColor = Color(0x33FF3B30)

          fun drawStrokeOverlay(stroke: ImageStroke) {
            val pts = stroke.points
            if (pts.isEmpty()) return
            val strokeWidthScreen = stroke.radiusPx * 2f * effectiveScale

            val screenPoints = pts.map { pt ->
              Offset(
                pt.x * effectiveScale + screenImgLeft,
                pt.y * effectiveScale + screenImgTop
              )
            }

            if (screenPoints.size == 1) {
              drawCircle(
                color = markerColor,
                radius = strokeWidthScreen / 2f,
                center = screenPoints[0]
              )
            } else {
              // Connect points
              drawPoints(
                points = screenPoints,
                pointMode = PointMode.Polygon,
                color = markerColor,
                strokeWidth = strokeWidthScreen,
                cap = StrokeCap.Round
              )
            }
          }

          // Existing committed strokes
          for (stroke in strokes) {
            drawStrokeOverlay(stroke)
          }

          // Current active in-progress stroke
          if (currentStrokePoints.isNotEmpty()) {
            drawStrokeOverlay(ImageStroke(currentStrokePoints, brushRadiusPx))
          }
        }
      }
    }

    // TOP BAR: Back arrow, "আসল দেখুন", Undo, Redo, "ঠিক করুন"
    Surface(
      color = Color.Black.copy(alpha = 0.85f),
      modifier = Modifier
        .align(Alignment.TopCenter)
        .fillMaxWidth()
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        // Back Button
        IconButton(
          onClick = onClose,
          modifier = Modifier.testTag("inspect_back_button")
        ) {
          Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
            contentDescription = "Back",
            tint = Color.White
          )
        }

        // "আসল দেখুন" Press & Hold Button
        Surface(
          shape = RoundedCornerShape(20.dp),
          color = if (isHoldingOriginal) AccentCyan.copy(alpha = 0.35f) else Color.White.copy(alpha = 0.12f),
          border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isHoldingOriginal) AccentCyan else Color.White.copy(alpha = 0.25f)
          ),
          modifier = Modifier
            .pointerInput(Unit) {
              detectTapGestures(
                onPress = {
                  isHoldingOriginal = true
                  tryAwaitRelease()
                  isHoldingOriginal = false
                }
              )
            }
            .testTag("hold_original_button")
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(
              imageVector = Icons.Default.Visibility,
              contentDescription = null,
              tint = if (isHoldingOriginal) AccentCyan else Color.White,
              modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = "আসল দেখুন",
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold,
              color = if (isHoldingOriginal) AccentCyan else Color.White
            )
          }
        }

        // Undo & Redo Buttons
        Row(verticalAlignment = Alignment.CenterVertically) {
          IconButton(
            onClick = {
              if (patchHistory.undo(workingBitmap)) {
                historyUpdateTrigger++
                bitmapVersion++
                onBitmapModified(workingBitmap)
              }
            },
            enabled = patchHistory.canUndo && !isProcessingFix,
            modifier = Modifier.testTag("inspect_undo_button")
          ) {
            Icon(
              imageVector = Icons.AutoMirrored.Filled.Undo,
              contentDescription = "Undo",
              tint = if (patchHistory.canUndo) Color.White else Color.Gray.copy(alpha = 0.4f)
            )
          }

          IconButton(
            onClick = {
              if (patchHistory.redo(workingBitmap)) {
                historyUpdateTrigger++
                bitmapVersion++
                onBitmapModified(workingBitmap)
              }
            },
            enabled = patchHistory.canRedo && !isProcessingFix,
            modifier = Modifier.testTag("inspect_redo_button")
          ) {
            Icon(
              imageVector = Icons.AutoMirrored.Filled.Redo,
              contentDescription = "Redo",
              tint = if (patchHistory.canRedo) Color.White else Color.Gray.copy(alpha = 0.4f)
            )
          }
        }

        // "ঠিক করুন" (Brush Mode Toggle)
        Surface(
          shape = RoundedCornerShape(20.dp),
          color = if (isBrushMode) PrimaryPurple else Color.White.copy(alpha = 0.12f),
          border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isBrushMode) AccentCyan else Color.White.copy(alpha = 0.25f)
          ),
          modifier = Modifier
            .clickable { isBrushMode = !isBrushMode }
            .testTag("toggle_brush_button")
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(
              imageVector = Icons.Default.Brush,
              contentDescription = null,
              tint = if (isBrushMode) Color.White else AccentCyan,
              modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = "ঠিক করুন",
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold,
              color = Color.White
            )
          }
        }
      }
    }

    // FLOATING TOAST / USER MESSAGE
    if (userMessage != null) {
      Surface(
        shape = RoundedCornerShape(12.dp),
        color = CardBackground.copy(alpha = 0.95f),
        border = androidx.compose.foundation.BorderStroke(1.dp, ErrorRed),
        modifier = Modifier
          .align(Alignment.TopCenter)
          .padding(top = 70.dp, start = 20.dp, end = 20.dp)
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = userMessage ?: "",
            color = Color.White,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium
          )
          Spacer(modifier = Modifier.width(8.dp))
          Icon(
            imageVector = Icons.Default.Clear,
            contentDescription = "Close",
            tint = Color.Gray,
            modifier = Modifier
              .size(16.dp)
              .clickable { userMessage = null }
          )
        }
      }
    }

    // SPINNER OVERLAY DURING FIX ACTION
    if (isProcessingFix) {
      Surface(
        shape = RoundedCornerShape(16.dp),
        color = CardBackground.copy(alpha = 0.90f),
        modifier = Modifier.align(Alignment.Center)
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 20.dp, vertical = 14.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          CircularProgressIndicator(
            color = AccentCyan,
            strokeWidth = 2.dp,
            modifier = Modifier.size(20.dp)
          )
          Spacer(modifier = Modifier.width(12.dp))
          Text(
            text = processingMessage,
            color = Color.White,
            fontSize = 14.sp,
            fontWeight = FontWeight.SemiBold
          )
        }
      }
    }

    // BOTTOM CONTROLS & SAVE BAR
    Column(
      modifier = Modifier
        .align(Alignment.BottomCenter)
        .fillMaxWidth()
        .background(Color.Black.copy(alpha = 0.88f))
        .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
      // 1. Brush Controls & Fix Action Buttons (Shown when brush mode is active)
      AnimatedVisibility(
        visible = isBrushMode,
        enter = fadeIn() + slideInVertically { it },
        exit = fadeOut() + slideOutVertically { it }
      ) {
        Column(modifier = Modifier.fillMaxWidth()) {
          // Brush size slider & "মুছে ফেলুন"
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
              Text(
                text = "ব্রাশ: ${(brushRadiusPx * 2).roundToInt()} px",
                color = SecondaryText,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium
              )
              Spacer(modifier = Modifier.width(8.dp))
              Slider(
                value = brushRadiusPx,
                onValueChange = { brushRadiusPx = it },
                valueRange = 8f..60f,
                colors = SliderDefaults.colors(
                  thumbColor = AccentCyan,
                  activeTrackColor = AccentCyan,
                  inactiveTrackColor = Color.DarkGray
                ),
                modifier = Modifier.weight(1f)
              )
            }

            if (strokes.isNotEmpty()) {
              Text(
                text = "মুছে ফেলুন",
                color = ErrorRed,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                  .padding(start = 12.dp)
                  .clickable { strokes.clear() }
                  .testTag("clear_strokes_button")
              )
            }
          }

          Spacer(modifier = Modifier.height(8.dp))

          // Two Action Buttons: "আসল ফেরান" and "দাগ মুছুন" (enabled when strokes exist)
          if (strokes.isNotEmpty()) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
              // "আসল ফেরান" (Revert to Original)
              Button(
                onClick = {
                  val bounds = InspectFixEngine.calculateStrokeBounds(
                    strokes.toList(),
                    workingBitmap.width,
                    workingBitmap.height
                  )
                  if (bounds == null) return@Button

                  if (InspectFixEngine.isMarkedAreaTooLarge(bounds, workingBitmap.width, workingBitmap.height)) {
                    userMessage = "অনেক বড় জায়গা, ছোট ছোট করে দাগ দিন"
                    return@Button
                  }

                  userMessage = null
                  isProcessingFix = true
                  processingMessage = "আসল অংশ ব্লেন্ড হচ্ছে..."

                  coroutineScope.launch {
                    val patch = withContext(Dispatchers.Default) {
                      val mask = InspectFixEngine.buildFeatheredMask(strokes.toList(), bounds)
                      InspectFixEngine.applyRevertToOriginal(workingBitmap, originalBitmap, bounds, mask)
                    }
                    patchHistory.recordEdit(patch)
                    historyUpdateTrigger++
                    strokes.clear()
                    isProcessingFix = false
                    bitmapVersion++
                    onBitmapModified(workingBitmap)
                  }
                },
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                  containerColor = CardBackground,
                  contentColor = Color.White
                ),
                border = androidx.compose.foundation.BorderStroke(1.dp, AccentCyan),
                modifier = Modifier
                  .weight(1f)
                  .height(44.dp)
                  .testTag("action_revert_original")
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(Icons.Default.Restore, contentDescription = null, tint = AccentCyan, modifier = Modifier.size(16.dp))
                  Spacer(modifier = Modifier.width(6.dp))
                  Text("আসল ফেরান", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
              }

              // "দাগ মুছুন" (Inpaint / Diffusion Erase)
              Button(
                onClick = {
                  val bounds = InspectFixEngine.calculateStrokeBounds(
                    strokes.toList(),
                    workingBitmap.width,
                    workingBitmap.height
                  )
                  if (bounds == null) return@Button

                  if (InspectFixEngine.isMarkedAreaTooLarge(bounds, workingBitmap.width, workingBitmap.height)) {
                    userMessage = "অনেক বড় জায়গা, ছোট ছোট করে দাগ দিন"
                    return@Button
                  }

                  userMessage = null
                  isProcessingFix = true
                  processingMessage = "দাগ মোছা হচ্ছে..."

                  coroutineScope.launch {
                    val patch = withContext(Dispatchers.Default) {
                      val mask = InspectFixEngine.buildFeatheredMask(strokes.toList(), bounds)
                      InspectFixEngine.applyInpaintBlemish(workingBitmap, bounds, mask)
                    }
                    patchHistory.recordEdit(patch)
                    historyUpdateTrigger++
                    strokes.clear()
                    isProcessingFix = false
                    bitmapVersion++
                    onBitmapModified(workingBitmap)
                  }
                },
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                  containerColor = PrimaryPurple,
                  contentColor = Color.White
                ),
                modifier = Modifier
                  .weight(1f)
                  .height(44.dp)
                  .testTag("action_inpaint_blemish")
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(Icons.Default.AutoFixHigh, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                  Spacer(modifier = Modifier.width(6.dp))
                  Text("দাগ মুছুন", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
              }
            }

            Spacer(modifier = Modifier.height(10.dp))
          }
        }
      }

      // Save notification banner if present
      if (saveNotification != null) {
        val isError = saveNotification.startsWith("ত্রুটি") || saveNotification.startsWith("Error")
        Surface(
          shape = RoundedCornerShape(12.dp),
          color = if (isError) ErrorRed.copy(alpha = 0.2f) else SuccessGreen.copy(alpha = 0.2f),
          border = androidx.compose.foundation.BorderStroke(1.dp, if (isError) ErrorRed else SuccessGreen),
          modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 8.dp)
        ) {
          Row(
            modifier = Modifier.padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text(
              text = saveNotification,
              fontSize = 12.sp,
              color = Color.White,
              modifier = Modifier.weight(1f)
            )
            Icon(
              imageVector = Icons.Default.Clear,
              contentDescription = "Dismiss",
              tint = Color.Gray,
              modifier = Modifier
                .size(16.dp)
                .clickable { onDismissNotification() }
            )
          }
        }
      }

      // The same big "Gallery-তে সেভ করুন" button
      Button(
        onClick = onSaveToGallery,
        enabled = !isSaving && !isProcessingFix,
        shape = RoundedCornerShape(18.dp),
        colors = ButtonDefaults.buttonColors(
          containerColor = Color.Transparent,
          contentColor = MainText
        ),
        modifier = Modifier
          .fillMaxWidth()
          .height(54.dp)
          .shadow(16.dp, RoundedCornerShape(18.dp), spotColor = PrimaryPurple)
          .background(PrimaryGradient, RoundedCornerShape(18.dp))
          .testTag("inspect_save_button")
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.Center
        ) {
          if (isSaving) {
            CircularProgressIndicator(
              modifier = Modifier.size(18.dp),
              strokeWidth = 2.dp,
              color = Color.White
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text("গ্যালারিতে সেভ হচ্ছে...", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color.White)
          } else {
            Icon(Icons.Default.Download, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "Gallery-তে সেভ করুন",
              fontSize = 15.sp,
              fontWeight = FontWeight.Bold,
              color = Color.White
            )
          }
        }
      }
    }
  }
}
