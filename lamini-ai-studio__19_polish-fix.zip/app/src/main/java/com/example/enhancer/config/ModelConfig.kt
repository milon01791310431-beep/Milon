package com.example.enhancer.config

import com.example.enhancer.model.ModelSlotType

/**
 * AI Model download configuration.
 * The network is used strictly for one-time model downloads.
 * Image processing stays 100% offline on-device.
 */
object ModelConfig {

  // Real-ESRGAN .onnx (approx 5 MB) for whole-image super-resolution
  const val IMAGE_MODEL_URL = "PUT_DIRECT_LINK_HERE"
  const val IMAGE_MODEL_SIZE_BYTES = 5_242_880L // ~5 MB estimated
  const val IMAGE_MODEL_SHA256 = "" // Optional SHA-256 hash for verification

  // GFPGAN / CodeFormer .onnx (approx 340 MB) for face restoration
  const val FACE_MODEL_URL = "PUT_DIRECT_LINK_HERE"
  const val FACE_MODEL_SIZE_BYTES = 356_515_840L // ~340 MB estimated
  const val FACE_MODEL_SHA256 = "" // Optional SHA-256 hash for verification

  fun getModelUrl(slotType: ModelSlotType): String {
    return when (slotType) {
      ModelSlotType.IMAGE_MODEL -> IMAGE_MODEL_URL
      ModelSlotType.FACE_MODEL -> FACE_MODEL_URL
    }
  }

  fun getExpectedSizeBytes(slotType: ModelSlotType): Long {
    return when (slotType) {
      ModelSlotType.IMAGE_MODEL -> IMAGE_MODEL_SIZE_BYTES
      ModelSlotType.FACE_MODEL -> FACE_MODEL_SIZE_BYTES
    }
  }

  fun getSha256(slotType: ModelSlotType): String {
    return when (slotType) {
      ModelSlotType.IMAGE_MODEL -> IMAGE_MODEL_SHA256
      ModelSlotType.FACE_MODEL -> FACE_MODEL_SHA256
    }
  }

  fun isUrlConfigured(url: String): Boolean {
    val trimmed = url.trim()
    return trimmed.isNotEmpty() &&
        !trimmed.contains("PUT_DIRECT_LINK_HERE", ignoreCase = true) &&
        (trimmed.startsWith("http://", ignoreCase = true) || trimmed.startsWith("https://", ignoreCase = true))
  }
}
