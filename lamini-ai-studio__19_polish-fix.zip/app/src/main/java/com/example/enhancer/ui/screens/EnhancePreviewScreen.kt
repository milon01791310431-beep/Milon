package com.example.enhancer.ui.screens

import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ChangeCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Hd
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.enhancer.model.EngineStatus
import com.example.enhancer.model.EngineStatusInfo
import com.example.enhancer.model.EngineType
import com.example.enhancer.model.ImageMetadata
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.BorderColor
import com.example.ui.theme.CardBackground
import com.example.ui.theme.CardGlowBorder
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.MainBackground
import com.example.ui.theme.MainText
import com.example.ui.theme.PrimaryGradient
import com.example.ui.theme.PrimaryPurple
import com.example.ui.theme.SecondaryBackground
import com.example.ui.theme.SecondaryBlue
import com.example.ui.theme.SecondaryText
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextMuted
import kotlin.math.roundToInt

@Composable
fun EnhancePreviewScreen(
  bitmap: Bitmap?,
  metadata: ImageMetadata?,
  showRemoveDialog: Boolean,
  engineType: EngineType = EngineType.ONNX_LOCAL_AI,
  engineStatusInfo: EngineStatusInfo? = null,
  onImageSelected: (Uri) -> Unit,
  onRotatePhoto: () -> Unit,
  onPromptRemove: () -> Unit,
  onDismissRemoveDialog: () -> Unit,
  onConfirmRemove: () -> Unit,
  onNavigateToSettings: () -> Unit,
  onStartEnhance: () -> Unit,
  onNavigateBack: () -> Unit,
  modifier: Modifier = Modifier
) {
  var showZoomDialog by remember { mutableStateOf(false) }

  val photoPickerLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.PickVisualMedia()
  ) { uri: Uri? ->
    if (uri != null) {
      onImageSelected(uri)
    }
  }

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(MainBackground)
      .verticalScroll(rememberScrollState())
      .padding(horizontal = 20.dp, vertical = 12.dp)
  ) {
    // Header
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        IconButton(
          onClick = onNavigateBack,
          modifier = Modifier.testTag("enhance_back_button")
        ) {
          Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
            contentDescription = "Back",
            tint = MainText
          )
        }
        Spacer(modifier = Modifier.width(4.dp))
        Text(
          text = "ফটো প্রিভিউ",
          fontSize = 19.sp,
          fontWeight = FontWeight.Bold,
          color = MainText
        )
      }

      Row(verticalAlignment = Alignment.CenterVertically) {
        IconButton(
          onClick = onRotatePhoto,
          modifier = Modifier.testTag("rotate_photo_button")
        ) {
          Icon(
            imageVector = Icons.Default.RotateRight,
            contentDescription = "Rotate",
            tint = SecondaryText
          )
        }

        IconButton(
          onClick = {
            photoPickerLauncher.launch(
              PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
            )
          },
          modifier = Modifier.testTag("replace_photo_button")
        ) {
          Icon(
            imageVector = Icons.Default.ChangeCircle,
            contentDescription = "Change photo",
            tint = SecondaryText
          )
        }

        IconButton(
          onClick = onPromptRemove,
          modifier = Modifier.testTag("delete_photo_button")
        ) {
          Icon(
            imageVector = Icons.Default.Delete,
            contentDescription = "Delete",
            tint = ErrorRed
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(16.dp))

    // Main Photo Preview Card
    if (bitmap != null) {
      Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = CardBackground),
        border = androidx.compose.foundation.BorderStroke(1.5.dp, CardGlowBorder),
        modifier = Modifier
          .fillMaxWidth()
          .shadow(16.dp, RoundedCornerShape(22.dp), spotColor = PrimaryPurple)
      ) {
        Column(modifier = Modifier.padding(12.dp)) {
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .aspectRatio(bitmap.width.toFloat() / bitmap.height.toFloat().coerceAtLeast(1f))
              .clip(RoundedCornerShape(16.dp))
              .background(SecondaryBackground)
              .clickable { showZoomDialog = true }
          ) {
            Image(
              bitmap = bitmap.asImageBitmap(),
              contentDescription = "Selected Photo",
              contentScale = ContentScale.Fit,
              modifier = Modifier.fillMaxSize()
            )

            // Zoom hint button
            Surface(
              shape = CircleShape,
              color = CardBackground.copy(alpha = 0.8f),
              modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(10.dp)
                .size(34.dp)
            ) {
              Box(contentAlignment = Alignment.Center) {
                Icon(
                  imageVector = Icons.Default.ZoomIn,
                  contentDescription = "Zoom",
                  tint = AccentCyan,
                  modifier = Modifier.size(18.dp)
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          // Resolution Specs (Remini style: Output size = Input size)
          val srcW = bitmap.width
          val srcH = bitmap.height
          val maxDim = kotlin.math.max(srcW, srcH)
          val (targetW, targetH) = if (maxDim > 4096) {
            val f = 4096.0 / maxDim
            Pair((srcW * f).roundToInt().coerceAtLeast(1), (srcH * f).roundToInt().coerceAtLeast(1))
          } else {
            Pair(srcW, srcH)
          }

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = AccentCyan, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = "${targetW} × ${targetH} px (অরিজিনাল রেজোলিউশন)",
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = MainText
              )
            }

            Text(
              text = metadata?.formattedSize ?: "",
              fontSize = 11.sp,
              color = TextMuted
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(18.dp))

      // Engine status summary banner
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CardBackground),
        border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor),
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(14.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
            val isAiReady = engineType == EngineType.ONNX_LOCAL_AI && engineStatusInfo?.status == EngineStatus.READY
            Surface(
              shape = CircleShape,
              color = if (isAiReady) SuccessGreen.copy(alpha = 0.2f) else AccentCyan.copy(alpha = 0.2f),
              modifier = Modifier.size(32.dp)
            ) {
              Box(contentAlignment = Alignment.Center) {
                Icon(
                  imageVector = if (isAiReady) Icons.Default.Tune else Icons.Default.Memory,
                  contentDescription = null,
                  tint = if (isAiReady) SuccessGreen else AccentCyan,
                  modifier = Modifier.size(18.dp)
                )
              }
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = if (isAiReady) "অন-ডিভাইস AI ইঞ্জিন (Real-ESRGAN)" else "বেসিক ক্লাসিক্যাল CV ইঞ্জিন",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = MainText
              )
              Text(
                text = if (isAiReady) "100% অফলাইন নিউরাল ইনফ্যারেন্স" else "AI মডেল নেই, ক্লাসিক্যাল মোডে চলবে",
                fontSize = 11.sp,
                color = SecondaryText
              )
            }
          }

          TextButton(onClick = onNavigateToSettings) {
            Icon(Icons.Default.Settings, contentDescription = null, tint = AccentCyan, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("মডেল", fontSize = 12.sp, color = AccentCyan)
          }
        }
      }

      Spacer(modifier = Modifier.height(24.dp))

      // STEP 2: ONE BIG BUTTON "ফ্রেশ করুন"
      Button(
        onClick = onStartEnhance,
        shape = RoundedCornerShape(20.dp),
        colors = ButtonDefaults.buttonColors(
          containerColor = Color.Transparent,
          contentColor = MainText
        ),
        modifier = Modifier
          .fillMaxWidth()
          .height(64.dp)
          .shadow(20.dp, RoundedCornerShape(20.dp), spotColor = PrimaryPurple)
          .background(PrimaryGradient, RoundedCornerShape(20.dp))
          .testTag("fresh_enhance_button")
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.Center
        ) {
          Icon(
            imageVector = Icons.Default.AutoAwesome,
            contentDescription = null,
            tint = AccentCyan,
            modifier = Modifier.size(26.dp)
          )
          Spacer(modifier = Modifier.width(12.dp))
          Text(
            text = "ফ্রেশ করুন",
            fontSize = 20.sp,
            fontWeight = FontWeight.ExtraBold,
            color = MainText,
            letterSpacing = 0.5.sp
          )
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      Text(
        text = "AI দিয়ে ফ্রেশ ও ক্লিয়ার করা হবে। ছবির মূল সাইজ ও অনুপাত অক্ষুণ্ণ থাকবে।",
        fontSize = 12.sp,
        color = SecondaryText,
        modifier = Modifier.fillMaxWidth(),
        textAlign = androidx.compose.ui.text.style.TextAlign.Center
      )

      Spacer(modifier = Modifier.height(30.dp))
    }

    // Remove Confirmation Dialog
    if (showRemoveDialog) {
      AlertDialog(
        onDismissRequest = onDismissRemoveDialog,
        title = { Text("ছবি সরিয়ে ফেলবেন?", color = MainText) },
        text = { Text("বর্তমান ছবিটি সরিয়ে হোম স্ক্রিনে ফিরে যাবেন?", color = SecondaryText) },
        confirmButton = {
          TextButton(onClick = onConfirmRemove) {
            Text("হ্যাঁ, সরান", color = ErrorRed)
          }
        },
        dismissButton = {
          TextButton(onClick = onDismissRemoveDialog) {
            Text("বাতিল", color = AccentCyan)
          }
        },
        containerColor = CardBackground
      )
    }

    // Zoom Dialog
    if (showZoomDialog && bitmap != null) {
      AlertDialog(
        onDismissRequest = { showZoomDialog = false },
        text = {
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .aspectRatio(bitmap.width.toFloat() / bitmap.height.toFloat().coerceAtLeast(1f))
          ) {
            Image(
              bitmap = bitmap.asImageBitmap(),
              contentDescription = "Zoomed Preview",
              modifier = Modifier.fillMaxSize()
            )
          }
        },
        confirmButton = {
          TextButton(onClick = { showZoomDialog = false }) {
            Text("বন্ধ করুন", color = AccentCyan)
          }
        },
        containerColor = CardBackground
      )
    }
  }
}
