package com.example.enhancer.engine

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import com.example.enhancer.config.ModelConfig
import com.example.enhancer.model.ModelSlotType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.security.MessageDigest
import java.util.concurrent.TimeUnit
import kotlin.math.roundToInt

sealed interface DownloadStatus {
  object Idle : DownloadStatus

  data class Downloading(
    val slotType: ModelSlotType,
    val bytesDownloaded: Long,
    val totalBytes: Long,
    val percent: Int,
    val speedText: String,
    val isResuming: Boolean
  ) : DownloadStatus {
    val downloadedMb: String
      get() = String.format("%.1f", bytesDownloaded / (1024.0 * 1024.0))

    val totalMb: String
      get() = if (totalBytes > 0) {
        String.format("%.1f", totalBytes / (1024.0 * 1024.0))
      } else {
        "?"
      }
  }

  data class Validating(val slotType: ModelSlotType) : DownloadStatus

  data class Success(val slotType: ModelSlotType) : DownloadStatus

  data class Error(
    val slotType: ModelSlotType,
    val message: String,
    val canRetry: Boolean = true
  ) : DownloadStatus
}

class ModelDownloadManager(
  private val context: Context,
  private val modelManager: ModelManager
) {

  private val okHttpClient: OkHttpClient by lazy {
    OkHttpClient.Builder()
      .connectTimeout(30, TimeUnit.SECONDS)
      .readTimeout(60, TimeUnit.SECONDS)
      .followRedirects(true)
      .followSslRedirects(true)
      .build()
  }

  // Active status mapped by slot
  private val _downloadStatusMap = MutableStateFlow<Map<ModelSlotType, DownloadStatus>>(emptyMap())
  val downloadStatusMap: StateFlow<Map<ModelSlotType, DownloadStatus>> = _downloadStatusMap.asStateFlow()

  private val activeJobs = mutableMapOf<ModelSlotType, Job>()

  fun getStatusForSlot(slotType: ModelSlotType): DownloadStatus {
    return _downloadStatusMap.value[slotType] ?: DownloadStatus.Idle
  }

  fun isMobileDataActive(): Boolean {
    val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
    val network = cm.activeNetwork ?: return false
    val caps = cm.getNetworkCapabilities(network) ?: return false
    return caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) &&
        !caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) &&
        !caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
  }

  fun isNetworkAvailable(): Boolean {
    val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
    val network = cm.activeNetwork ?: return false
    val caps = cm.getNetworkCapabilities(network) ?: return false
    return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
  }

  fun cancelDownload(slotType: ModelSlotType) {
    activeJobs[slotType]?.cancel()
    activeJobs.remove(slotType)
    updateStatus(slotType, DownloadStatus.Idle)
  }

  private fun updateStatus(slotType: ModelSlotType, status: DownloadStatus) {
    val updated = _downloadStatusMap.value.toMutableMap()
    updated[slotType] = status
    _downloadStatusMap.value = updated
  }

  /**
   * Starts downloading the AI model for the specified slot with HTTP Range resume support.
   */
  suspend fun startDownload(slotType: ModelSlotType) = withContext(Dispatchers.IO) {
    val url = ModelConfig.getModelUrl(slotType)

    // Check if URL is properly configured
    if (!ModelConfig.isUrlConfigured(url)) {
      updateStatus(
        slotType,
        DownloadStatus.Error(
          slotType = slotType,
          message = "ডাউনলোড লিংক এখনও কনফিগার করা হয়নি। ModelConfig.kt ফাইলে আসল লিংক বসান অথবা নিচ থেকে সরাসরি .onnx ফাইল ইমপোর্ট করুন।",
          canRetry = false
        )
      )
      return@withContext
    }

    // Check internet connectivity
    if (!isNetworkAvailable()) {
      updateStatus(
        slotType,
        DownloadStatus.Error(
          slotType = slotType,
          message = "ইন্টারনেট সংযোগ নেই। ইন্টারনেট সংযোগ চালু করে আবার চেষ্টা করুন।",
          canRetry = true
        )
      )
      return@withContext
    }

    val expectedSizeBytes = ModelConfig.getExpectedSizeBytes(slotType)
    val modelsDir = modelManager.modelsDir
    if (modelsDir.usableSpace < expectedSizeBytes && expectedSizeBytes > 0) {
      updateStatus(
        slotType,
        DownloadStatus.Error(
          slotType = slotType,
          message = "ডিভাইসের স্টোরেজ পূর্ণ। কমপক্ষে ${expectedSizeBytes / (1024 * 1024)} MB জায়গা খালি করুন।",
          canRetry = true
        )
      )
      return@withContext
    }

    val tempPartFile = File(modelsDir, "${slotType.recommendedFileName}.part")
    var existingBytes = if (tempPartFile.exists()) tempPartFile.length() else 0L

    try {
      // Build request, supporting HTTP Range resume
      val requestBuilder = Request.Builder().url(url)
      var isResuming = false
      if (existingBytes > 0) {
        requestBuilder.header("Range", "bytes=$existingBytes-")
        isResuming = true
      }

      val request = requestBuilder.build()
      val response = okHttpClient.newCall(request).execute()

      if (!response.isSuccessful) {
        // If range was unsatisfiable (e.g. 416), delete temp file and try from start
        if (response.code == 416) {
          tempPartFile.delete()
          existingBytes = 0L
          val freshResponse = okHttpClient.newCall(Request.Builder().url(url).build()).execute()
          if (!freshResponse.isSuccessful) {
            response.close()
            freshResponse.close()
            updateStatus(
              slotType,
              DownloadStatus.Error(
                slotType = slotType,
                message = "সার্ভার এরর (HTTP ${freshResponse.code})। ফাইলটি পাওয়া যায়নি বা লিংকটি মেয়াদোত্তীর্ণ।",
                canRetry = true
              )
            )
            return@withContext
          }
          processResponseBody(freshResponse, tempPartFile, slotType, 0L, false)
        } else {
          response.close()
          updateStatus(
            slotType,
            DownloadStatus.Error(
              slotType = slotType,
              message = "সার্ভার থেকে ফাইল ডাউনলোড করা সম্ভব হয়নি (HTTP ${response.code})।",
              canRetry = true
            )
          )
          return@withContext
        }
      } else {
        val isPartial = response.code == 206
        val resumeOffset = if (isPartial) existingBytes else 0L
        processResponseBody(response, tempPartFile, slotType, resumeOffset, isPartial)
      }

    } catch (e: Exception) {
      if (!coroutineContext.isActive) {
        // Cancelled by user
        updateStatus(slotType, DownloadStatus.Idle)
      } else {
        updateStatus(
          slotType,
          DownloadStatus.Error(
            slotType = slotType,
            message = "ডাউনলোড বিঘ্নিত হয়েছে: ${e.localizedMessage ?: "সংযোগ বিচ্ছিন্ন"}। আবার চেষ্টা করুন।",
            canRetry = true
          )
        )
      }
    }
  }

  private suspend fun processResponseBody(
    response: okhttp3.Response,
    tempPartFile: File,
    slotType: ModelSlotType,
    existingBytes: Long,
    isResuming: Boolean
  ) = withContext(Dispatchers.IO) {
    val body = response.body ?: throw IllegalStateException("সার্ভার কোনো ডেটা পাঠায়নি")
    val contentLength = body.contentLength()
    val totalExpected = if (contentLength > 0) {
      if (isResuming) existingBytes + contentLength else contentLength
    } else {
      ModelConfig.getExpectedSizeBytes(slotType)
    }

    val append = isResuming && existingBytes > 0
    val outputStream = FileOutputStream(tempPartFile, append)
    val inputStream: InputStream = body.byteStream()

    val buffer = ByteArray(32 * 1024) // 32 KB chunk
    var bytesRead: Int
    var currentBytes = existingBytes
    var lastUpdateTime = System.currentTimeMillis()
    var bytesSinceLastUpdate = 0L
    var speedText = "গণনা করা হচ্ছে..."

    try {
      while (inputStream.read(buffer).also { bytesRead = it } != -1) {
        if (!coroutineContext.isActive) {
          break
        }
        outputStream.write(buffer, 0, bytesRead)
        currentBytes += bytesRead
        bytesSinceLastUpdate += bytesRead

        val now = System.currentTimeMillis()
        val deltaMs = now - lastUpdateTime
        if (deltaMs >= 400) {
          val speedBytesPerSec = (bytesSinceLastUpdate * 1000) / deltaMs
          speedText = formatSpeed(speedBytesPerSec)
          lastUpdateTime = now
          bytesSinceLastUpdate = 0L

          val percent = if (totalExpected > 0) {
            ((currentBytes.toDouble() / totalExpected) * 100).roundToInt().coerceIn(0, 99)
          } else {
            0
          }

          updateStatus(
            slotType,
            DownloadStatus.Downloading(
              slotType = slotType,
              bytesDownloaded = currentBytes,
              totalBytes = totalExpected,
              percent = percent,
              speedText = speedText,
              isResuming = isResuming
            )
          )
        }
      }
      outputStream.flush()
    } finally {
      outputStream.close()
      inputStream.close()
      response.close()
    }

    if (!coroutineContext.isActive) {
      // Kept partial file for resume
      updateStatus(slotType, DownloadStatus.Idle)
      return@withContext
    }

    // Step 2: Validate the downloaded file
    updateStatus(slotType, DownloadStatus.Validating(slotType))

    // Optional SHA-256 verification if set in ModelConfig
    val expectedSha = ModelConfig.getSha256(slotType)
    if (expectedSha.isNotBlank()) {
      val actualSha = calculateFileSha256(tempPartFile)
      if (!actualSha.equals(expectedSha.trim(), ignoreCase = true)) {
        tempPartFile.delete()
        updateStatus(
          slotType,
          DownloadStatus.Error(
            slotType = slotType,
            message = "ফাইলের সিকিউরিটি হ্যাশ (SHA-256) মেলেনি। ফাইলটি ক্ষতিগ্রস্ত হয়েছে।",
            canRetry = true
          )
        )
        return@withContext
      }
    }

    // ONNX Runtime validation
    val validation = modelManager.validateModelFile(tempPartFile)
    if (validation.isFailure) {
      tempPartFile.delete()
      val error = validation.exceptionOrNull()?.localizedMessage ?: "ইনভ্যালিড ফরম্যাট"
      updateStatus(
        slotType,
        DownloadStatus.Error(
          slotType = slotType,
          message = "ডাউনলোড করা ফাইলটি সঠিক ONNX AI মডেল নয় ($error)।",
          canRetry = true
        )
      )
      return@withContext
    }

    // Validation passed: rename to final model file
    val targetFile = File(modelManager.modelsDir, slotType.recommendedFileName)
    if (targetFile.exists()) targetFile.delete()
    val renamed = tempPartFile.renameTo(targetFile)
    if (!renamed) {
      tempPartFile.copyTo(targetFile, overwrite = true)
      tempPartFile.delete()
    }

    modelManager.refreshSlots()
    updateStatus(slotType, DownloadStatus.Success(slotType))
  }

  private fun formatSpeed(bytesPerSec: Long): String {
    return when {
      bytesPerSec >= 1024 * 1024 -> String.format("%.1f MB/s", bytesPerSec / (1024.0 * 1024.0))
      bytesPerSec >= 1024 -> String.format("%d KB/s", bytesPerSec / 1024)
      else -> String.format("%d B/s", bytesPerSec)
    }
  }

  private fun calculateFileSha256(file: File): String {
    val digest = MessageDigest.getInstance("SHA-256")
    file.inputStream().use { input ->
      val buffer = ByteArray(16 * 1024)
      var read: Int
      while (input.read(buffer).also { read = it } != -1) {
        digest.update(buffer, 0, read)
      }
    }
    return digest.digest().joinToString("") { "%02x".format(it) }
  }
}
