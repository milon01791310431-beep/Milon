package com.example.enhancer.engine

import android.os.SystemClock
import android.util.Log

/**
 * Manages the processing time budget (default 9000 ms) for the enhancement pipeline.
 *
 * Keeps processing fast (5-8 seconds usually, hard target under 10 seconds on mid-range phones).
 * Every optional stage checks the remaining budget before starting and is skipped
 * with a Logcat line if it would not finish.
 */
class PipelineBudget(
  val totalBudgetMs: Long = 9000L,
  private val clock: () -> Long = { SystemClock.elapsedRealtime() }
) {
  val startTimeMs: Long = clock()

  fun elapsedMs(): Long = clock() - startTimeMs

  fun remainingMs(): Long = (totalBudgetMs - elapsedMs()).coerceAtLeast(0L)

  fun hasBudgetFor(estimatedMs: Long): Boolean = remainingMs() >= estimatedMs

  fun elapsedFraction(): Float = (elapsedMs().toFloat() / totalBudgetMs).coerceIn(0f, 1f)

  /**
   * Checks whether [stageName] can run within the remaining budget given [estimatedMs].
   * If remaining budget is less than [estimatedMs], logs to Logcat and returns false.
   */
  fun checkOrSkip(stageName: String, estimatedMs: Long): Boolean {
    val rem = remainingMs()
    return if (rem >= estimatedMs) {
      true
    } else {
      try {
        Log.i(
          "PerformanceTiming",
          "Stage [$stageName] skipped: estimated ${estimatedMs} ms exceeds remaining ${rem} ms"
        )
      } catch (_: Throwable) {
        println("PerformanceTiming: Stage [$stageName] skipped: estimated ${estimatedMs} ms exceeds remaining ${rem} ms")
      }
      false
    }
  }
}
