package com.example.enhancer.engine

import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import ai.onnxruntime.TensorInfo
import android.content.Context
import android.net.Uri
import com.example.enhancer.model.ModelSlotInfo
import com.example.enhancer.model.ModelSlotType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

class ModelManager(private val context: Context) {

  val modelsDir: File by lazy {
    File(context.filesDir, "models").apply {
      if (!exists()) mkdirs()
    }
  }

  private val _modelSlots = MutableStateFlow<Map<ModelSlotType, ModelSlotInfo>>(emptyMap())
  val modelSlots: StateFlow<Map<ModelSlotType, ModelSlotInfo>> = _modelSlots.asStateFlow()

  init {
    refreshSlots()
  }

  fun refreshSlots() {
    val imageFile = resolveImageModelFile()
    val faceFile = resolveFaceModelFile()

    val imageSlot = ModelSlotInfo(
      slotType = ModelSlotType.IMAGE_MODEL,
      title = ModelSlotType.IMAGE_MODEL.title,
      recommendedFileName = ModelSlotType.IMAGE_MODEL.recommendedFileName,
      isInstalled = imageFile != null && imageFile.exists() && imageFile.length() > 0,
      fileSizeBytes = imageFile?.length() ?: 0L,
      filePath = imageFile?.absolutePath,
      modelDescription = if (imageFile != null && imageFile.exists()) {
        "ইনস্টল করা আছে (${imageFile.name}) • NCHW Real-ESRGAN Super-Resolution"
      } else {
        "ইনস্টল করা নেই • Real-ESRGAN .onnx ফাইল ডাউনলোড বা ইমপোর্ট করুন"
      }
    )

    val faceSlot = ModelSlotInfo(
      slotType = ModelSlotType.FACE_MODEL,
      title = ModelSlotType.FACE_MODEL.title,
      recommendedFileName = ModelSlotType.FACE_MODEL.recommendedFileName,
      isInstalled = faceFile != null && faceFile.exists() && faceFile.length() > 0,
      fileSizeBytes = faceFile?.length() ?: 0L,
      filePath = faceFile?.absolutePath,
      modelDescription = if (faceFile != null && faceFile.exists()) {
        "ইনস্টল করা আছে (${faceFile.name}) • 512×512 GFPGAN / CodeFormer Face Restoration"
      } else {
        "ইনস্টল করা নেই • GFPGAN বা CodeFormer .onnx ফেস মডেল"
      }
    )

    _modelSlots.value = mapOf(
      ModelSlotType.IMAGE_MODEL to imageSlot,
      ModelSlotType.FACE_MODEL to faceSlot
    )
  }

  /**
   * Resolves the Image Super-Resolution model file.
   * Checks filesDir/models/ first, then assets/models/.
   */
  fun resolveImageModelFile(): File? {
    val candidates = listOf("image_model.onnx", "realesrgan.onnx", "realesrgan_x2.onnx", "realesrgan_x4.onnx")
    for (name in candidates) {
      val file = File(modelsDir, name)
      if (file.exists() && file.length() > 0) return file
    }

    // Check assets/models/ fallback
    try {
      val assetList = context.assets.list("models") ?: emptyArray()
      for (name in candidates) {
        if (assetList.contains(name)) {
          val target = File(modelsDir, name)
          if (!target.exists() || target.length() == 0L) {
            context.assets.open("models/$name").use { input ->
              FileOutputStream(target).use { output ->
                input.copyTo(output)
              }
            }
          }
          if (target.exists() && target.length() > 0) return target
        }
      }
    } catch (_: Exception) {}

    return null
  }

  /**
   * Resolves the Face Restoration model file.
   * Checks filesDir/models/ first, then assets/models/.
   */
  fun resolveFaceModelFile(): File? {
    val candidates = listOf("face_model.onnx", "gfpgan.onnx", "codeformer.onnx", "face_restoration.onnx")
    for (name in candidates) {
      val file = File(modelsDir, name)
      if (file.exists() && file.length() > 0) return file
    }

    // Check assets/models/ fallback
    try {
      val assetList = context.assets.list("models") ?: emptyArray()
      for (name in candidates) {
        if (assetList.contains(name)) {
          val target = File(modelsDir, name)
          if (!target.exists() || target.length() == 0L) {
            context.assets.open("models/$name").use { input ->
              FileOutputStream(target).use { output ->
                input.copyTo(output)
              }
            }
          }
          if (target.exists() && target.length() > 0) return target
        }
      }
    } catch (_: Exception) {}

    return null
  }

  fun isImageModelReady(): Boolean {
    val file = resolveImageModelFile()
    return file != null && file.exists() && file.length() > 0
  }

  fun isFaceModelReady(): Boolean {
    val file = resolveFaceModelFile()
    return file != null && file.exists() && file.length() > 0
  }

  /**
   * Reusable validation for any ONNX model file.
   * Tests session creation, inputs, and outputs with ONNX Runtime.
   */
  fun validateModelFile(file: File): Result<Unit> {
    if (!file.exists() || file.length() == 0L) {
      return Result.failure(IllegalArgumentException("ফাইলটি খালি বা অনুপলব্ধ।"))
    }

    var session: OrtSession? = null
    return try {
      val env = OrtEnvironment.getEnvironment()
      val opts = OrtSession.SessionOptions()
      session = env.createSession(file.absolutePath, opts)

      val inputInfo = session.inputInfo
      val outputInfo = session.outputInfo

      if (inputInfo.isEmpty() || outputInfo.isEmpty()) {
        return Result.failure(IllegalArgumentException("মডেলে কোনো বৈধ ইনপুট বা আউটপুট টেন্সর নেই"))
      }

      val firstInput = inputInfo.values.first()
      val tensorInfo = firstInput.info as? TensorInfo
      if (tensorInfo != null) {
        val shape = tensorInfo.shape
        if (shape.isNotEmpty() && shape.size != 4 && shape.size != 0) {
          return Result.failure(
            IllegalArgumentException("মডেলটির ইনপুট ডাইমেনশন [Batch, Channel, Height, Width] ৪-মাত্রিক নয় (পাওয়া গেছে: ${shape.size}D)")
          )
        }
      }

      Result.success(Unit)
    } catch (e: Exception) {
      Result.failure(e)
    } finally {
      session?.close()
    }
  }

  suspend fun importModel(uri: Uri, slotType: ModelSlotType): Result<ModelSlotInfo> = withContext(Dispatchers.IO) {
    var tempFile: File? = null
    try {
      tempFile = File(context.cacheDir, "temp_import_${System.currentTimeMillis()}.onnx")

      context.contentResolver.openInputStream(uri)?.use { input ->
        FileOutputStream(tempFile).use { output ->
          input.copyTo(output)
        }
      } ?: return@withContext Result.failure(Exception("ফাইল রিড করা যায়নি। অনুগ্রহ করে আবার চেষ্টা করুন।"))

      if (!tempFile.exists() || tempFile.length() == 0L) {
        return@withContext Result.failure(Exception("ফাইলটি খালি বা অনুপলব্ধ।"))
      }

      val validation = validateModelFile(tempFile)
      if (validation.isFailure) {
        tempFile.delete()
        val errorMsg = validation.exceptionOrNull()?.localizedMessage ?: "ইনভ্যালিড ফরম্যাট"
        return@withContext Result.failure(
          Exception("ভুল বা অকার্যকর ONNX ফাইল: এটি সঠিক Real-ESRGAN বা GFPGAN/CodeFormer মডেল নয় ($errorMsg)")
        )
      }

      // Valid model: Move to permanent modelsDir
      val targetFileName = slotType.recommendedFileName
      val targetFile = File(modelsDir, targetFileName)
      if (targetFile.exists()) targetFile.delete()

      val copied = tempFile.renameTo(targetFile)
      if (!copied) {
        tempFile.copyTo(targetFile, overwrite = true)
        tempFile.delete()
      }

      refreshSlots()
      val updatedSlot = _modelSlots.value[slotType]
        ?: return@withContext Result.failure(Exception("মডেল সংরক্ষিত হতে পারেনি।"))

      Result.success(updatedSlot)
    } catch (e: Exception) {
      tempFile?.delete()
      Result.failure(e)
    }
  }

  suspend fun deleteModel(slotType: ModelSlotType): Result<Unit> = withContext(Dispatchers.IO) {
    try {
      when (slotType) {
        ModelSlotType.IMAGE_MODEL -> {
          resolveImageModelFile()?.delete()
        }
        ModelSlotType.FACE_MODEL -> {
          resolveFaceModelFile()?.delete()
        }
      }
      refreshSlots()
      Result.success(Unit)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }
}
