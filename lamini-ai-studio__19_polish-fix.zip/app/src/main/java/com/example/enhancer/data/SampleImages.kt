package com.example.enhancer.data

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import kotlin.random.Random

object SampleImages {

  data class SamplePhotoItem(
    val title: String,
    val category: String,
    val description: String,
    val generator: () -> Bitmap
  )

  val samplePhotos = listOf(
    SamplePhotoItem(
      title = "Portrait Studio",
      category = "Face & Skin",
      description = "Low-light portrait test with skin textures, eyes, and hair details"
    ) { createPortraitSample() },
    SamplePhotoItem(
      title = "Vintage Grain",
      category = "Denoise & Clarity",
      description = "Old film photo with heavy compression noise and muted colors"
    ) { createVintageSample() },
    SamplePhotoItem(
      title = "Cyber Cityscape",
      category = "Super-Resolution",
      description = "Night skyline with fine architecture edges and neon light refractions"
    ) { createCityscapeSample() }
  )

  private fun createPortraitSample(): Bitmap {
    val width = 800
    val height = 1000
    val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)

    // Studio background gradient
    val bgPaint = Paint().apply {
      shader = RadialGradient(
        400f, 450f, 600f,
        intArrayOf(Color.rgb(65, 50, 75), Color.rgb(20, 15, 30)),
        null,
        Shader.TileMode.CLAMP
      )
    }
    canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)

    // Draw shoulders / neck
    val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
      color = Color.rgb(40, 42, 54)
    }
    val bodyPath = Path().apply {
      moveTo(150f, 1000f)
      quadTo(400f, 750f, 650f, 1000f)
      close()
    }
    canvas.drawPath(bodyPath, bodyPaint)

    // Neck
    val neckPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
      color = Color.rgb(215, 170, 145)
    }
    canvas.drawRect(340f, 600f, 460f, 780f, neckPaint)

    // Face oval
    val skinPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
      shader = RadialGradient(
        400f, 460f, 240f,
        intArrayOf(Color.rgb(240, 195, 170), Color.rgb(205, 155, 130)),
        null,
        Shader.TileMode.CLAMP
      )
    }
    canvas.drawOval(260f, 280f, 540f, 660f, skinPaint)

    // Hair
    val hairPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
      color = Color.rgb(35, 25, 20)
    }
    canvas.drawOval(230f, 220f, 570f, 450f, hairPaint)

    // Eyes
    val eyeWhitePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(245, 245, 245) }
    canvas.drawOval(320f, 430f, 375f, 460f, eyeWhitePaint)
    canvas.drawOval(425f, 430f, 480f, 460f, eyeWhitePaint)

    val irisPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(45, 75, 100) }
    canvas.drawCircle(348f, 445f, 14f, irisPaint)
    canvas.drawCircle(452f, 445f, 14f, irisPaint)

    val pupilPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(15, 15, 20) }
    canvas.drawCircle(348f, 445f, 7f, pupilPaint)
    canvas.drawCircle(452f, 445f, 7f, pupilPaint)

    // Eye catchlights
    val sparkPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    canvas.drawCircle(345f, 442f, 3f, sparkPaint)
    canvas.drawCircle(449f, 442f, 3f, sparkPaint)

    // Nose bridge and tip
    val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
      color = Color.argb(45, 120, 70, 50)
    }
    canvas.drawOval(385f, 460f, 415f, 530f, shadowPaint)

    // Lips
    val lipPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
      color = Color.rgb(195, 100, 105)
    }
    canvas.drawOval(355f, 560f, 445f, 595f, lipPaint)

    // Add mild camera sensor noise to simulate a real un-enhanced photo
    addCameraSensorNoise(bitmap, noiseAmount = 18)

    return bitmap
  }

  private fun createVintageSample(): Bitmap {
    val width = 900
    val height = 675
    val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)

    // Sky with vintage amber tint
    val skyPaint = Paint().apply {
      shader = LinearGradient(
        0f, 0f, 0f, height.toFloat(),
        intArrayOf(Color.rgb(160, 145, 130), Color.rgb(190, 160, 120), Color.rgb(140, 110, 80)),
        null,
        Shader.TileMode.CLAMP
      )
    }
    canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), skyPaint)

    // Mountains
    val mountainPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
      color = Color.rgb(90, 80, 70)
    }
    val path = Path().apply {
      moveTo(0f, 400f)
      lineTo(200f, 260f)
      lineTo(420f, 370f)
      lineTo(650f, 210f)
      lineTo(900f, 390f)
      lineTo(900f, 675f)
      lineTo(0f, 675f)
      close()
    }
    canvas.drawPath(path, mountainPaint)

    // Lake reflection
    val waterPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
      color = Color.rgb(75, 70, 65)
    }
    canvas.drawRect(0f, 480f, width.toFloat(), height.toFloat(), waterPaint)

    // Add film grain noise
    addCameraSensorNoise(bitmap, noiseAmount = 30)

    return bitmap
  }

  private fun createCityscapeSample(): Bitmap {
    val width = 850
    val height = 600
    val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)

    // Night sky
    val skyPaint = Paint().apply {
      shader = LinearGradient(
        0f, 0f, 0f, height.toFloat(),
        intArrayOf(Color.rgb(15, 20, 35), Color.rgb(30, 25, 55)),
        null,
        Shader.TileMode.CLAMP
      )
    }
    canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), skyPaint)

    // Building silhouettes
    val bldgPaint = Paint().apply { color = Color.rgb(20, 25, 40) }
    val windowPaint = Paint().apply { color = Color.rgb(255, 230, 150) }
    val neonCyan = Paint().apply { color = Color.rgb(0, 220, 255) }

    val random = Random(42)
    var currX = 20f
    while (currX < width - 40) {
      val bWidth = random.nextInt(60, 110).toFloat()
      val bHeight = random.nextInt(220, 480).toFloat()
      val top = height - bHeight
      canvas.drawRect(currX, top, currX + bWidth, height.toFloat(), bldgPaint)

      // Lighted windows
      for (wy in (top.toInt() + 15) until (height - 30) step 28) {
        for (wx in (currX.toInt() + 10) until (currX + bWidth - 15).toInt() step 18) {
          if (random.nextFloat() > 0.4f) {
            canvas.drawRect(wx.toFloat(), wy.toFloat(), wx + 10f, wy + 16f, windowPaint)
          }
        }
      }

      // Neon rooftop strip
      if (random.nextBoolean()) {
        canvas.drawRect(currX, top, currX + bWidth, top + 4f, neonCyan)
      }

      currX += bWidth + random.nextInt(5, 15)
    }

    addCameraSensorNoise(bitmap, noiseAmount = 14)
    return bitmap
  }

  private fun addCameraSensorNoise(bitmap: Bitmap, noiseAmount: Int) {
    val random = Random(1337)
    val width = bitmap.width
    val height = bitmap.height
    val pixels = IntArray(width * height)
    bitmap.getPixels(pixels, 0, width, 0, 0, width, height)

    for (i in pixels.indices) {
      val p = pixels[i]
      val a = (p shr 24) and 0xFF
      var r = (p shr 16) and 0xFF
      var g = (p shr 8) and 0xFF
      var b = p and 0xFF

      val noise = random.nextInt(-noiseAmount, noiseAmount)
      r = (r + noise).coerceIn(0, 255)
      g = (g + noise).coerceIn(0, 255)
      b = (b + noise).coerceIn(0, 255)

      pixels[i] = (a shl 24) or (r shl 16) or (g shl 8) or b
    }
    bitmap.setPixels(pixels, 0, width, 0, 0, width, height)
  }
}
