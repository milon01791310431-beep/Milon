package com.example.enhancer.ui.viewmodel

import android.app.Application
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.provider.OpenableColumns
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.enhancer.data.history.AppDatabase
import com.example.enhancer.data.history.EnhancedPhotoEntity
import com.example.enhancer.data.history.HistoryRepository
import com.example.enhancer.engine.DownloadStatus
import com.example.enhancer.engine.ModelDownloadManager
import com.example.enhancer.engine.ModelManager
import com.example.enhancer.engine.OnnxModelEngine
import com.example.enhancer.engine.PhotoEnhancerEngine
import com.example.enhancer.model.AppTab
import com.example.enhancer.model.EngineStatus
import com.example.enhancer.model.EngineStatusInfo
import com.example.enhancer.model.EngineType
import com.example.enhancer.model.EnhancementConfig
import com.example.enhancer.model.EnhancementMode
import com.example.enhancer.model.ExportFormat
import com.example.enhancer.model.ImageMetadata
import com.example.enhancer.model.ModelSlotInfo
import com.example.enhancer.model.ModelSlotType
import com.example.enhancer.model.ProcessingProgress
import com.example.enhancer.model.UpscaleFactor
import com.example.enhancer.model.WorkflowStep
import com.example.enhancer.utils.ImageStorageHelper
import com.example.enhancer.utils.MemorySafetyCalculator
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class EnhancerUiState(
  val currentTab: AppTab = AppTab.HOME,
  val currentStep: WorkflowStep = WorkflowStep.IDLE,
  val selectedUri: Uri? = null,
  val originalBitmap: Bitmap? = null,
  val enhancedBitmap: Bitmap? = null,
  val originalMetadata: ImageMetadata? = null,
  val enhancedMetadata: ImageMetadata? = null,
  val config: EnhancementConfig = EnhancementConfig(),
  val engineType: EngineType = EngineType.ONNX_LOCAL_AI,
  val engineStatusInfo: EngineStatusInfo? = null,
  val modelSlots: Map<ModelSlotType, ModelSlotInfo> = emptyMap(),
  val importingSlotType: ModelSlotType? = null,
  val importErrorMessage: String? = null,
  val usedEngineName: String = "",
  val usedEngineIsAi: Boolean = false,
  val aiUpscaleSkippedNote: String? = null,
  val progress: ProcessingProgress = ProcessingProgress(),
  val errorMessage: String? = null,
  val sliderPosition: Float = 0.5f,
  val comparisonMode: ComparisonMode = ComparisonMode.SPLIT_SLIDER,
  val exportFormat: ExportFormat = ExportFormat.JPEG,
  val saveNotification: String? = null,
  val isSaving: Boolean = false,
  val isImageModelInstalled: Boolean = false,
  val isFaceModelInstalled: Boolean = false,
  val isFaceCardDismissed: Boolean = false,
  val downloadStatusMap: Map<ModelSlotType, DownloadStatus> = emptyMap(),
  val isMobileData: Boolean = false,
  val showRemoveConfirmDialog: Boolean = false,
  val showClearHistoryDialog: Boolean = false,
  val viewingHistoryEntity: EnhancedPhotoEntity? = null
)

enum class ComparisonMode(val label: String) {
  SPLIT_SLIDER("Split Slider"),
  SIDE_BY_SIDE("Side-by-Side"),
  AFTER_ONLY("Enhanced Only")
}

class EnhancerViewModel(application: Application) : AndroidViewModel(application) {

  private val _uiState = MutableStateFlow(EnhancerUiState())
  val uiState: StateFlow<EnhancerUiState> = _uiState.asStateFlow()

  private val database = AppDatabase.getDatabase(application)
  private val historyRepository = HistoryRepository(application, database.enhancedPhotoDao())

  val modelManager = ModelManager(application)
  val downloadManager = ModelDownloadManager(application, modelManager)
  val builtInEngine = PhotoEnhancerEngine(application)
  val onnxEngine = OnnxModelEngine(application, modelManager)

  private var enhancementJob: Job? = null

  val allHistoryPhotos: StateFlow<List<EnhancedPhotoEntity>> = historyRepository.allPhotos
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val recentHistoryPhotos: StateFlow<List<EnhancedPhotoEntity>> = historyRepository.recentPhotos
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val historyCount: StateFlow<Int> = historyRepository.photoCount
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

  init {
    val initialImageReady = modelManager.isImageModelReady()
    val initialFaceReady = modelManager.isFaceModelReady()
    _uiState.update {
      it.copy(
        isImageModelInstalled = initialImageReady,
        isFaceModelInstalled = initialFaceReady,
        isMobileData = downloadManager.isMobileDataActive()
      )
    }

    viewModelScope.launch {
      modelManager.modelSlots.collect { slots ->
        val imageReady = modelManager.isImageModelReady()
        val faceReady = modelManager.isFaceModelReady()
        _uiState.update {
          it.copy(
            modelSlots = slots,
            isImageModelInstalled = imageReady,
            isFaceModelInstalled = faceReady
          )
        }
        refreshEngineStatus()
      }
    }

    viewModelScope.launch {
      downloadManager.downloadStatusMap.collect { statusMap ->
        _uiState.update { state ->
          val imageStatus = statusMap[ModelSlotType.IMAGE_MODEL]
          val isImageReady = modelManager.isImageModelReady()
          val isFaceReady = modelManager.isFaceModelReady()

          val notification = if (!state.isImageModelInstalled && isImageReady && imageStatus is DownloadStatus.Success) {
            "মডেল প্রস্তুত! এখন যেকোনো ছবি ফ্রেশ করতে পারবেন"
          } else {
            state.saveNotification
          }

          state.copy(
            downloadStatusMap = statusMap,
            isImageModelInstalled = isImageReady,
            isFaceModelInstalled = isFaceReady,
            saveNotification = notification
          )
        }
      }
    }
  }

  fun refreshEngineStatus() {
    viewModelScope.launch {
      val isImageReady = modelManager.isImageModelReady()
      val useAi = _uiState.value.config.useAiModelIfAvailable

      val status = if (useAi && isImageReady) {
        onnxEngine.getStatusInfo()
      } else {
        builtInEngine.getStatusInfo()
      }

      val activeType = if (useAi && isImageReady) {
        EngineType.ONNX_LOCAL_AI
      } else {
        EngineType.BUILT_IN_CV
      }

      _uiState.update {
        it.copy(
          engineType = activeType,
          engineStatusInfo = status
        )
      }
    }
  }

  fun selectTab(tab: AppTab) {
    _uiState.update { it.copy(currentTab = tab) }
  }

  fun onImageSelected(uri: Uri) {
    viewModelScope.launch {
      try {
        val resolver = getApplication<Application>().contentResolver
        var fileName: String? = null
        var fileSize = 0L

        resolver.query(uri, null, null, null, null)?.use { cursor ->
          val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
          val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
          if (cursor.moveToFirst()) {
            if (nameIndex != -1) fileName = cursor.getString(nameIndex)
            if (sizeIndex != -1) fileSize = cursor.getLong(sizeIndex)
          }
        }

        val boundsOptions = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { stream ->
          BitmapFactory.decodeStream(stream, null, boundsOptions)
        }

        val rawWidth = boundsOptions.outWidth
        val rawHeight = boundsOptions.outHeight
        val mimeType = boundsOptions.outMimeType ?: "image/jpeg"

        if (rawWidth <= 0 || rawHeight <= 0) {
          _uiState.update { it.copy(errorMessage = "নির্বাচিত ফাইলটি কোনো বৈধ ছবি নয়।") }
          return@launch
        }

        var sampleSize = 1
        val maxMemory = Runtime.getRuntime().maxMemory()
        val estimatedBytes = MemorySafetyCalculator.estimateBitmapMemoryBytes(rawWidth, rawHeight, 4)
        while (estimatedBytes / (sampleSize * sampleSize) > (maxMemory * 0.35)) {
          sampleSize *= 2
        }

        val decodeOptions = BitmapFactory.Options().apply {
          inSampleSize = sampleSize
          inPreferredConfig = Bitmap.Config.ARGB_8888
        }

        val decodedBitmap: Bitmap? = resolver.openInputStream(uri)?.use { stream ->
          BitmapFactory.decodeStream(stream, null, decodeOptions)
        }

        if (decodedBitmap == null) {
          _uiState.update { it.copy(errorMessage = "ছবিটি লোড করা যায়নি। JPG, PNG অথবা WebP ফরম্যাট ব্যবহার করুন।") }
          return@launch
        }

        // Respect EXIF orientation so portrait/rotated camera shots are never misoriented
        val exifOrientation = try {
          resolver.openInputStream(uri)?.use { stream ->
            val exif = ExifInterface(stream)
            exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
          } ?: ExifInterface.ORIENTATION_NORMAL
        } catch (_: Exception) {
          ExifInterface.ORIENTATION_NORMAL
        }

        val matrix = Matrix()
        when (exifOrientation) {
          ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f)
          ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
          ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
          ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.postScale(-1f, 1f)
          ExifInterface.ORIENTATION_FLIP_VERTICAL -> matrix.postScale(1f, -1f)
          ExifInterface.ORIENTATION_TRANSPOSE -> {
            matrix.postRotate(90f)
            matrix.postScale(-1f, 1f)
          }
          ExifInterface.ORIENTATION_TRANSVERSE -> {
            matrix.postRotate(270f)
            matrix.postScale(-1f, 1f)
          }
        }

        val bitmap = if (!matrix.isIdentity) {
          val rotated = Bitmap.createBitmap(decodedBitmap, 0, 0, decodedBitmap.width, decodedBitmap.height, matrix, true)
          if (rotated != decodedBitmap) {
            decodedBitmap.recycle()
          }
          rotated
        } else {
          decodedBitmap
        }

        val measuredSize = if (fileSize > 0) fileSize else MemorySafetyCalculator.calculateActualEncodedSize(bitmap, ExportFormat.JPEG, 95)

        val metadata = ImageMetadata(
          width = bitmap.width,
          height = bitmap.height,
          sizeBytes = measuredSize,
          mimeType = mimeType,
          fileName = fileName ?: "photo.jpg"
        )

        _uiState.update {
          it.copy(
            currentTab = AppTab.ENHANCE,
            currentStep = WorkflowStep.IDLE,
            selectedUri = uri,
            originalBitmap = bitmap,
            originalMetadata = metadata,
            enhancedBitmap = null,
            enhancedMetadata = null,
            viewingHistoryEntity = null,
            errorMessage = null,
            saveNotification = null
          )
        }
      } catch (e: Exception) {
        _uiState.update {
          it.copy(errorMessage = "ছবি নির্বাচন করতে সমস্যা হয়েছে: ${e.localizedMessage}")
        }
      }
    }
  }

  fun onSampleSelected(generator: () -> Bitmap, title: String) {
    viewModelScope.launch {
      try {
        val bitmap = generator()
        val realBytes = MemorySafetyCalculator.calculateActualEncodedSize(bitmap, ExportFormat.JPEG, 95)
        val metadata = ImageMetadata(
          width = bitmap.width,
          height = bitmap.height,
          sizeBytes = realBytes,
          mimeType = "image/jpeg",
          fileName = "$title.jpg"
        )
        _uiState.update {
          it.copy(
            currentTab = AppTab.ENHANCE,
            currentStep = WorkflowStep.IDLE,
            selectedUri = null,
            originalBitmap = bitmap,
            originalMetadata = metadata,
            enhancedBitmap = null,
            enhancedMetadata = null,
            viewingHistoryEntity = null,
            errorMessage = null,
            saveNotification = null
          )
        }
      } catch (e: Exception) {
        _uiState.update { it.copy(errorMessage = "নমুনা ছবি লোড করা যায়নি: ${e.localizedMessage}") }
      }
    }
  }

  fun rotatePhoto() {
    val current = _uiState.value.originalBitmap ?: return
    viewModelScope.launch {
      val rotated = rotateBitmap(current, 90f)
      val oldMeta = _uiState.value.originalMetadata
      val newMeta = oldMeta?.copy(width = rotated.width, height = rotated.height)
      _uiState.update {
        it.copy(
          originalBitmap = rotated,
          originalMetadata = newMeta
        )
      }
    }
  }

  private fun rotateBitmap(source: Bitmap, degrees: Float): Bitmap {
    val matrix = android.graphics.Matrix().apply { postRotate(degrees) }
    return Bitmap.createBitmap(source, 0, 0, source.width, source.height, matrix, true)
  }

  fun promptRemovePhoto() {
    _uiState.update { it.copy(showRemoveConfirmDialog = true) }
  }

  fun dismissRemovePhotoDialog() {
    _uiState.update { it.copy(showRemoveConfirmDialog = false) }
  }

  fun confirmRemovePhoto() {
    _uiState.update {
      it.copy(
        selectedUri = null,
        originalBitmap = null,
        originalMetadata = null,
        enhancedBitmap = null,
        enhancedMetadata = null,
        currentStep = WorkflowStep.IDLE,
        showRemoveConfirmDialog = false,
        errorMessage = null,
        saveNotification = null
      )
    }
  }

  fun startEnhancement() {
    val original = _uiState.value.originalBitmap
    if (original == null) {
      _uiState.update { it.copy(errorMessage = "প্রথমে একটি ছবি নির্বাচন করুন।") }
      return
    }

    val config = _uiState.value.config
    val isImageReady = modelManager.isImageModelReady()
    val preferAi = config.useAiModelIfAvailable

    _uiState.update {
      it.copy(
        currentStep = WorkflowStep.PROCESSING,
        errorMessage = null,
        saveNotification = null,
        progress = ProcessingProgress(
          stage = "ছবি প্রস্তুত করা হচ্ছে...",
          percent = 0.05f,
          isIndeterminate = false,
          detail = "রেজোলিউশন ও মেমোরি যাচাই করা হচ্ছে..."
        )
      )
    }

    enhancementJob?.cancel()
    enhancementJob = viewModelScope.launch {
      try {
        var finalResultBitmap: Bitmap? = null
        var finalEngineLabel: String
        var finalIsNeuralAi: Boolean
        var finalAiUpscaleSkippedNote: String? = null

        if (preferAi && isImageReady) {
          val aiResult = onnxEngine.enhance(original, config) { progressUpdate ->
            _uiState.update { it.copy(progress = progressUpdate) }
          }

          if (aiResult.isSuccess) {
            finalResultBitmap = aiResult.getOrNull()
            finalIsNeuralAi = true
            val facesCount = onnxEngine.lastFacesRestoredCount
            val faceMissing = onnxEngine.lastFaceModelMissingNotice

            finalAiUpscaleSkippedNote = if (faceMissing) {
              "মুখের আরও ভালো ফলাফলের জন্য ফেস মডেল ইনস্টল করুন"
            } else {
              null
            }

            finalEngineLabel = if (facesCount > 0) {
              "Real-ESRGAN AI + ফেস রিস্টোর (${facesCount}টি মুখ)"
            } else {
              "Real-ESRGAN AI (ফ্রেশ)"
            }
          } else {
            // Automatic graceful fallback to classical CV
            _uiState.update {
              it.copy(
                progress = ProcessingProgress(
                  stage = "বেসিক মোডে এনহান্স হচ্ছে...",
                  percent = 0.3f,
                  detail = "AI মডেল ফলব্যাক: ক্লাসিক্যাল ইঞ্জিন চালু হচ্ছে..."
                )
              )
            }
            val fallbackResult = builtInEngine.enhance(original, config) { progressUpdate ->
              _uiState.update { it.copy(progress = progressUpdate) }
            }
            finalResultBitmap = fallbackResult.getOrThrow()
            finalIsNeuralAi = false
            finalEngineLabel = "AI মডেল নেই, বেসিক এনহান্সমেন্ট ব্যবহার হয়েছে"
            finalAiUpscaleSkippedNote = null
          }
        } else {
          // Classical CV basic enhancement
          val basicResult = builtInEngine.enhance(original, config) { progressUpdate ->
            _uiState.update { it.copy(progress = progressUpdate) }
          }
          finalResultBitmap = basicResult.getOrThrow()
          finalIsNeuralAi = false
          finalEngineLabel = "AI মডেল নেই, বেসিক এনহান্সমেন্ট ব্যবহার হয়েছে"
          finalAiUpscaleSkippedNote = null
        }

        val resultBitmap = finalResultBitmap ?: throw IllegalStateException("ফলাফল প্রক্রিয়া করা সম্ভব হয়নি।")

        val realEncodedSizeBytes = MemorySafetyCalculator.calculateActualEncodedSize(
          resultBitmap,
          _uiState.value.exportFormat,
          quality = 95
        )

        val origMeta = _uiState.value.originalMetadata
        val enhancedMeta = ImageMetadata(
          width = resultBitmap.width,
          height = resultBitmap.height,
          sizeBytes = realEncodedSizeBytes,
          mimeType = _uiState.value.exportFormat.mimeType,
          fileName = "Enhanced_${origMeta?.fileName ?: "photo"}.${_uiState.value.exportFormat.extension}",
          modelIdentifier = finalEngineLabel,
          enhancementMode = config.mode.displayName,
          upscaleFactor = config.upscaleFactor.label
        )

        // Save to Room History
        val savedEntity = historyRepository.saveEnhancementToHistory(
          originalBitmap = original,
          enhancedBitmap = resultBitmap,
          mode = finalEngineLabel,
          upscaleFactor = "${resultBitmap.width}×${resultBitmap.height}",
          format = _uiState.value.exportFormat.extension.uppercase()
        )

        _uiState.update {
          it.copy(
            enhancedBitmap = resultBitmap,
            enhancedMetadata = enhancedMeta,
            usedEngineName = finalEngineLabel,
            usedEngineIsAi = finalIsNeuralAi,
            aiUpscaleSkippedNote = finalAiUpscaleSkippedNote,
            currentStep = WorkflowStep.RESULT,
            sliderPosition = 0.5f,
            viewingHistoryEntity = savedEntity,
            errorMessage = null
          )
        }
      } catch (e: Exception) {
        _uiState.update {
          it.copy(
            currentStep = WorkflowStep.PROCESSING,
            errorMessage = e.localizedMessage ?: "এনহান্সমেন্ট সম্পন্ন করা যায়নি। অনুগ্রহ করে আবার চেষ্টা করুন।"
          )
        }
      }
    }
  }

  fun cancelEnhancement() {
    enhancementJob?.cancel()
    _uiState.update {
      it.copy(
        currentStep = WorkflowStep.IDLE,
        errorMessage = "এনহান্সমেন্ট ব্যবহারকারী দ্বারা বাতিল করা হয়েছে।"
      )
    }
  }

  fun openHistoryItem(entity: EnhancedPhotoEntity) {
    viewModelScope.launch {
      val orig = historyRepository.loadBitmap(entity.originalFilePath)
      val enh = historyRepository.loadBitmap(entity.enhancedFilePath)
      if (orig != null && enh != null) {
        val origMeta = ImageMetadata(
          width = entity.originalWidth,
          height = entity.originalHeight,
          sizeBytes = entity.originalSizeBytes,
          mimeType = "image/jpeg",
          fileName = "History_Original"
        )
        val enhMeta = ImageMetadata(
          width = entity.enhancedWidth,
          height = entity.enhancedHeight,
          sizeBytes = entity.enhancedSizeBytes,
          mimeType = "image/jpeg",
          fileName = "History_Enhanced",
          modelIdentifier = entity.enhancementMode,
          enhancementMode = entity.enhancementMode,
          upscaleFactor = entity.upscaleFactor
        )
        _uiState.update {
          it.copy(
            originalBitmap = orig,
            originalMetadata = origMeta,
            enhancedBitmap = enh,
            enhancedMetadata = enhMeta,
            usedEngineName = entity.enhancementMode,
            usedEngineIsAi = entity.enhancementMode.contains("AI"),
            viewingHistoryEntity = entity,
            currentTab = AppTab.HOME,
            currentStep = WorkflowStep.RESULT,
            sliderPosition = 0.5f
          )
        }
      } else {
        _uiState.update { it.copy(errorMessage = "হিস্ট্রি ফাইলটি লোড করা যায়নি।") }
      }
    }
  }

  fun deleteHistoryItem(entity: EnhancedPhotoEntity) {
    viewModelScope.launch {
      historyRepository.deletePhoto(entity)
      if (_uiState.value.viewingHistoryEntity?.id == entity.id) {
        _uiState.update { it.copy(viewingHistoryEntity = null) }
      }
    }
  }

  fun promptClearHistory() {
    _uiState.update { it.copy(showClearHistoryDialog = true) }
  }

  fun dismissClearHistoryDialog() {
    _uiState.update { it.copy(showClearHistoryDialog = false) }
  }

  fun confirmClearHistory() {
    viewModelScope.launch {
      historyRepository.clearHistory()
      _uiState.update { it.copy(showClearHistoryDialog = false) }
    }
  }

  fun importModel(uri: Uri, slotType: ModelSlotType) {
    viewModelScope.launch {
      _uiState.update { it.copy(importingSlotType = slotType, importErrorMessage = null) }
      val result = modelManager.importModel(uri, slotType)
      val isSuccess = result.isSuccess
      _uiState.update {
        it.copy(
          importingSlotType = null,
          importErrorMessage = if (result.isFailure) result.exceptionOrNull()?.message else null,
          isImageModelInstalled = modelManager.isImageModelReady(),
          isFaceModelInstalled = modelManager.isFaceModelReady(),
          saveNotification = if (isSuccess && slotType == ModelSlotType.IMAGE_MODEL) "AI মডেল প্রস্তুত! এখন যেকোনো ছবি ফ্রেশ করতে পারবেন" else it.saveNotification
        )
      }
      refreshEngineStatus()
    }
  }

  fun deleteModel(slotType: ModelSlotType) {
    viewModelScope.launch {
      modelManager.deleteModel(slotType)
      _uiState.update {
        it.copy(
          isImageModelInstalled = modelManager.isImageModelReady(),
          isFaceModelInstalled = modelManager.isFaceModelReady()
        )
      }
      refreshEngineStatus()
    }
  }

  fun startModelDownload(slotType: ModelSlotType) {
    _uiState.update { it.copy(isMobileData = downloadManager.isMobileDataActive()) }
    viewModelScope.launch {
      downloadManager.startDownload(slotType)
    }
  }

  fun cancelModelDownload(slotType: ModelSlotType) {
    downloadManager.cancelDownload(slotType)
  }

  fun dismissFaceDownloadCard() {
    _uiState.update { it.copy(isFaceCardDismissed = true) }
  }

  fun setUseAiModel(enabled: Boolean) {
    _uiState.update { it.copy(config = it.config.copy(useAiModelIfAvailable = enabled)) }
    refreshEngineStatus()
  }

  fun setHighQualitySlowMode(enabled: Boolean) {
    _uiState.update { it.copy(config = it.config.copy(highQualitySlowMode = enabled)) }
  }

  fun setFaceStrength(strength: Float) {
    _uiState.update { it.copy(config = it.config.copy(faceStrength = strength)) }
  }

  fun setEnhancementMode(mode: EnhancementMode) {
    _uiState.update { it.copy(config = it.config.copy(mode = mode)) }
  }

  fun setUpscaleFactor(factor: UpscaleFactor) {
    _uiState.update { it.copy(config = it.config.copy(upscaleFactor = factor)) }
  }

  fun toggleFaceEnhancement(enabled: Boolean) {
    _uiState.update { it.copy(config = it.config.copy(faceEnhancement = enabled)) }
  }

  fun updateSliderPosition(pos: Float) {
    _uiState.update { it.copy(sliderPosition = pos.coerceIn(0f, 1f)) }
  }

  fun setComparisonMode(mode: ComparisonMode) {
    _uiState.update { it.copy(comparisonMode = mode) }
  }

  fun setExportFormat(format: ExportFormat) {
    _uiState.update { it.copy(exportFormat = format) }
  }

  fun saveEnhancedImage() {
    val bitmap = _uiState.value.enhancedBitmap ?: return
    viewModelScope.launch {
      _uiState.update { it.copy(isSaving = true, saveNotification = null) }
      // Never use bitmap.hasAlpha(). Save JPG quality 95 for all normal photos.
      // Use PNG only if the original input file was PNG/WEBP and actually contains pixels with alpha < 255.
      val origMeta = _uiState.value.originalMetadata
      val mime = origMeta?.mimeType?.lowercase() ?: ""
      val fileName = origMeta?.fileName?.lowercase() ?: ""
      val isPngOrWebp = mime.contains("png") || mime.contains("webp") ||
        fileName.endsWith(".png") || fileName.endsWith(".webp")

      val hasActualTransparency = isPngOrWebp && (
        (_uiState.value.originalBitmap?.let { hasActualTransparentPixels(it) } == true) ||
        hasActualTransparentPixels(bitmap)
      )

      val fixedFormat = if (hasActualTransparency) ExportFormat.PNG else ExportFormat.JPEG
      val result = ImageStorageHelper.saveBitmapToGallery(
        context = getApplication(),
        bitmap = bitmap,
        format = fixedFormat
      )
      _uiState.update {
        it.copy(
          isSaving = false,
          saveNotification = if (result.isSuccess) {
            val saveResult = result.getOrNull()
            val sizeMb = (saveResult?.sizeBytes ?: 0) / (1024.0 * 1024.0)
            val sizeFormatted = String.format(java.util.Locale.US, "%.2f MB", sizeMb)
            "✓ Gallery-তে সেভ হয়েছে: Pictures/Lamini ($sizeFormatted)"
          } else {
            "ত্রুটি: ${result.exceptionOrNull()?.message}"
          }
        )
      }
    }
  }

  /**
   * Checks whether the bitmap actually contains any pixels with alpha < 255.
   * Does NOT rely on bitmap.hasAlpha(), which is true for all ARGB_8888 bitmaps regardless of actual opacity.
   */
  private fun hasActualTransparentPixels(bitmap: Bitmap): Boolean {
    val width = bitmap.width
    val height = bitmap.height
    val chunkHeight = minOf(256, height)
    val pixels = IntArray(width * chunkHeight)
    var y = 0
    while (y < height) {
      val linesToRead = minOf(chunkHeight, height - y)
      bitmap.getPixels(pixels, 0, width, 0, y, width, linesToRead)
      val totalPixels = width * linesToRead
      for (i in 0 until totalPixels) {
        val alpha = (pixels[i] ushr 24) and 0xFF
        if (alpha < 255) {
          return true
        }
      }
      y += linesToRead
    }
    return false
  }

  fun shareEnhancedImage() {
    val bitmap = _uiState.value.enhancedBitmap ?: return
    viewModelScope.launch {
      ImageStorageHelper.shareBitmap(getApplication(), bitmap)
    }
  }

  fun updateEnhancedBitmap(newBitmap: Bitmap) {
    _uiState.update {
      it.copy(
        enhancedBitmap = newBitmap,
        enhancedMetadata = it.enhancedMetadata?.copy(
          width = newBitmap.width,
          height = newBitmap.height
        )
      )
    }
  }

  fun dismissNotification() {
    _uiState.update { it.copy(saveNotification = null, errorMessage = null, importErrorMessage = null) }
  }

  fun backToPhoto() {
    _uiState.update {
      it.copy(
        currentStep = WorkflowStep.IDLE,
        saveNotification = null,
        errorMessage = null
      )
    }
  }

  fun enhanceAnotherPhoto() {
    _uiState.update {
      it.copy(
        selectedUri = null,
        originalBitmap = null,
        originalMetadata = null,
        enhancedBitmap = null,
        enhancedMetadata = null,
        currentStep = WorkflowStep.IDLE,
        viewingHistoryEntity = null,
        saveNotification = null,
        errorMessage = null
      )
    }
  }

  override fun onCleared() {
    super.onCleared()
    enhancementJob?.cancel()
    builtInEngine.release()
    onnxEngine.release()
  }
}
