package com.example.enhancer.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.enhancer.model.AppTab
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.BorderColor
import com.example.ui.theme.CardBackground
import com.example.ui.theme.PrimaryGradient
import com.example.ui.theme.PrimaryPurple
import com.example.ui.theme.SecondaryBackground
import com.example.ui.theme.SecondaryBlue
import com.example.ui.theme.SecondaryText
import com.example.ui.theme.TextMuted

@Composable
fun LaminiBottomNavBar(
  currentTab: AppTab,
  onTabSelected: (AppTab) -> Unit,
  modifier: Modifier = Modifier
) {
  Surface(
    color = SecondaryBackground,
    tonalElevation = 8.dp,
    border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor.copy(alpha = 0.8f)),
    modifier = modifier.fillMaxWidth()
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .navigationBarsPadding()
        .padding(horizontal = 16.dp, vertical = 8.dp),
      horizontalArrangement = Arrangement.SpaceAround,
      verticalAlignment = Alignment.CenterVertically
    ) {
      NavTabItem(
        tab = AppTab.HOME,
        label = "হোম",
        activeIcon = Icons.Filled.Home,
        inactiveIcon = Icons.Outlined.Home,
        isSelected = currentTab == AppTab.HOME,
        onClick = { onTabSelected(AppTab.HOME) }
      )

      NavTabItem(
        tab = AppTab.ENHANCE,
        label = "প্রিভিউ",
        activeIcon = Icons.Filled.AutoAwesome,
        inactiveIcon = Icons.Outlined.AutoAwesome,
        isSelected = currentTab == AppTab.ENHANCE,
        onClick = { onTabSelected(AppTab.ENHANCE) }
      )

      NavTabItem(
        tab = AppTab.HISTORY,
        label = "হিস্ট্রি",
        activeIcon = Icons.Filled.History,
        inactiveIcon = Icons.Outlined.History,
        isSelected = currentTab == AppTab.HISTORY,
        onClick = { onTabSelected(AppTab.HISTORY) }
      )

      NavTabItem(
        tab = AppTab.SETTINGS,
        label = "সেটিংস",
        activeIcon = Icons.Filled.Settings,
        inactiveIcon = Icons.Outlined.Settings,
        isSelected = currentTab == AppTab.SETTINGS,
        onClick = { onTabSelected(AppTab.SETTINGS) }
      )
    }
  }
}

@Composable
private fun NavTabItem(
  tab: AppTab,
  label: String,
  activeIcon: ImageVector,
  inactiveIcon: ImageVector,
  isSelected: Boolean,
  onClick: () -> Unit
) {
  Column(
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.Center,
    modifier = Modifier
      .clip(RoundedCornerShape(12.dp))
      .clickable(onClick = onClick)
      .padding(horizontal = 14.dp, vertical = 4.dp)
      .testTag("nav_tab_${tab.name.lowercase()}")
  ) {
    if (isSelected) {
      Box(
        modifier = Modifier
          .size(36.dp)
          .clip(CircleShape)
          .background(PrimaryGradient),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          imageVector = activeIcon,
          contentDescription = label,
          tint = androidx.compose.ui.graphics.Color.White,
          modifier = Modifier.size(19.dp)
        )
      }
    } else {
      Box(
        modifier = Modifier.size(36.dp),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          imageVector = inactiveIcon,
          contentDescription = label,
          tint = SecondaryText,
          modifier = Modifier.size(20.dp)
        )
      }
    }

    Spacer(modifier = Modifier.height(2.dp))

    Text(
      text = label,
      fontSize = 11.sp,
      fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
      color = if (isSelected) AccentCyan else SecondaryText
    )
  }
}
