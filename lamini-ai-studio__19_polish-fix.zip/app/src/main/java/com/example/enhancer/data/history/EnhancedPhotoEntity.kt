package com.example.enhancer.data.history

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Entity(tableName = "enhanced_photos")
data class EnhancedPhotoEntity(
  @PrimaryKey(autoGenerate = true)
  val id: Long = 0,
  val originalFilePath: String,
  val enhancedFilePath: String,
  val timestamp: Long = System.currentTimeMillis(),
  val originalWidth: Int,
  val originalHeight: Int,
  val enhancedWidth: Int,
  val enhancedHeight: Int,
  val originalSizeBytes: Long,
  val enhancedSizeBytes: Long,
  val enhancementMode: String = "Balanced",
  val upscaleFactor: String = "2×",
  val format: String = "PNG"
) {
  val formattedDate: String
    get() {
      val sdf = SimpleDateFormat("MMM d, yyyy • h:mm a", Locale.getDefault())
      return sdf.format(Date(timestamp))
    }

  val formattedOriginalResolution: String
    get() = "$originalWidth × $originalHeight"

  val formattedEnhancedResolution: String
    get() = "$enhancedWidth × $enhancedHeight"
}
