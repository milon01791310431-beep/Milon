package com.example.enhancer.data.history

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

class HistoryRepository(private val context: Context, private val dao: EnhancedPhotoDao) {

  val allPhotos: Flow<List<EnhancedPhotoEntity>> = dao.getAllPhotos()
  val recentPhotos: Flow<List<EnhancedPhotoEntity>> = dao.getRecentPhotos()
  val photoCount: Flow<Int> = dao.getPhotoCount()

  suspend fun saveEnhancementToHistory(
    originalBitmap: Bitmap,
    enhancedBitmap: Bitmap,
    mode: String,
    upscaleFactor: String,
    format: String
  ): EnhancedPhotoEntity = withContext(Dispatchers.IO) {
    val tSaveStart = System.currentTimeMillis()
    val dir = File(context.filesDir, "history_photos")
    if (!dir.exists()) dir.mkdirs()

    val timestamp = System.currentTimeMillis()
    val origFile = File(dir, "orig_$timestamp.jpg")
    val enhancedFile = File(dir, "enh_$timestamp.jpg")

    FileOutputStream(origFile).use { out ->
      originalBitmap.compress(Bitmap.CompressFormat.JPEG, 90, out)
    }

    FileOutputStream(enhancedFile).use { out ->
      enhancedBitmap.compress(Bitmap.CompressFormat.JPEG, 92, out)
    }

    val entity = EnhancedPhotoEntity(
      originalFilePath = origFile.absolutePath,
      enhancedFilePath = enhancedFile.absolutePath,
      timestamp = timestamp,
      originalWidth = originalBitmap.width,
      originalHeight = originalBitmap.height,
      enhancedWidth = enhancedBitmap.width,
      enhancedHeight = enhancedBitmap.height,
      originalSizeBytes = origFile.length(),
      enhancedSizeBytes = enhancedFile.length(),
      enhancementMode = mode,
      upscaleFactor = upscaleFactor,
      format = format
    )

    val insertedId = dao.insertPhoto(entity)
    val saveDuration = System.currentTimeMillis() - tSaveStart
    Log.i("PerformanceTiming", "Stage [save]: ${saveDuration} ms")
    entity.copy(id = insertedId)
  }

  suspend fun deletePhoto(photo: EnhancedPhotoEntity) = withContext(Dispatchers.IO) {
    File(photo.originalFilePath).delete()
    File(photo.enhancedFilePath).delete()
    dao.deletePhotoById(photo.id)
  }

  suspend fun clearHistory() = withContext(Dispatchers.IO) {
    val dir = File(context.filesDir, "history_photos")
    if (dir.exists()) {
      dir.listFiles()?.forEach { it.delete() }
    }
    dao.clearAllPhotos()
  }

  suspend fun loadBitmap(filePath: String): Bitmap? = withContext(Dispatchers.IO) {
    val file = File(filePath)
    if (file.exists()) {
      BitmapFactory.decodeFile(file.absolutePath)
    } else {
      null
    }
  }
}
