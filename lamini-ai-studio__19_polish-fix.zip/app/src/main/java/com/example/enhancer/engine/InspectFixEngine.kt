package com.example.enhancer.engine

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect
import androidx.compose.ui.geometry.Offset
import java.util.ArrayDeque
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * Data model for a freehand brush stroke in IMAGE pixel coordinates.
 */
data class ImageStroke(
  val points: List<Offset>,
  val radiusPx: Float
)

/**
 * Lightweight undo/redo patch storing only the bounding box pixels before and after an edit.
 */
data class EditPatch(
  val rect: Rect,
  val beforePixels: IntArray,
  val afterPixels: IntArray
) {
  override fun equals(other: Any?): Boolean {
    if (this === other) return true
    if (other !is EditPatch) return false
    return rect == other.rect &&
        beforePixels.contentEquals(other.beforePixels) &&
        afterPixels.contentEquals(other.afterPixels)
  }

  override fun hashCode(): Int {
    var result = rect.hashCode()
    result = 31 * result + beforePixels.contentHashCode()
    result = 31 * result + afterPixels.contentHashCode()
    return result
  }
}

/**
 * Undo/Redo stack manager that holds at most [maxCapacity] patches.
 */
class PatchHistoryManager(private val maxCapacity: Int = 10) {
  private val undoStack = ArrayDeque<EditPatch>()
  private val redoStack = ArrayDeque<EditPatch>()

  val canUndo: Boolean get() = undoStack.isNotEmpty()
  val canRedo: Boolean get() = redoStack.isNotEmpty()

  fun recordEdit(patch: EditPatch) {
    if (undoStack.size >= maxCapacity) {
      undoStack.removeFirst()
    }
    undoStack.addLast(patch)
    redoStack.clear()
  }

  fun undo(bitmap: Bitmap): Boolean {
    val patch = undoStack.pollLast() ?: return false
    // Write beforePixels back into bitmap
    bitmap.setPixels(
      patch.beforePixels,
      0,
      patch.rect.width(),
      patch.rect.left,
      patch.rect.top,
      patch.rect.width(),
      patch.rect.height()
    )
    redoStack.addLast(patch)
    return true
  }

  fun redo(bitmap: Bitmap): Boolean {
    val patch = redoStack.pollLast() ?: return false
    // Write afterPixels back into bitmap
    bitmap.setPixels(
      patch.afterPixels,
      0,
      patch.rect.width(),
      patch.rect.left,
      patch.rect.top,
      patch.rect.width(),
      patch.rect.height()
    )
    undoStack.addLast(patch)
    return true
  }

  fun clear() {
    undoStack.clear()
    redoStack.clear()
  }
}

/**
 * Core engine for "Inspect & Fix" offline image editing:
 * - Screen-to-image and image-to-screen coordinate mapping
 * - Stroke bounding box calculation with safety checks
 * - Morphological dilation & Gaussian feather mask generation
 * - "আসল ফেরান" (Blend original photo back into marked spot)
 * - "দাগ মুছুন" (Offline Pyramidal Push-Pull Diffusion inpainting + grain synthesis)
 */
object InspectFixEngine {

  const val MAX_AREA_RATIO = 0.08f // 8% of total image pixels
  const val PADDING_PX = 32

  /**
   * Converts a screen coordinate [screenPos] to image pixel coordinates,
   * given canvas dimensions, image dimensions, zoom scale, and pan offsets.
   */
  fun screenToImageCoordinates(
    screenPos: Offset,
    canvasWidth: Float,
    canvasHeight: Float,
    imageWidth: Int,
    imageHeight: Int,
    zoom: Float,
    panX: Float,
    panY: Float
  ): Offset? {
    if (canvasWidth <= 0 || canvasHeight <= 0 || imageWidth <= 0 || imageHeight <= 0) return null

    val baseScale = min(canvasWidth / imageWidth.toFloat(), canvasHeight / imageHeight.toFloat())
    val scale = baseScale * zoom
    val dispW = imageWidth * scale
    val dispH = imageHeight * scale

    val screenImgLeft = (canvasWidth - dispW) / 2f + panX
    val screenImgTop = (canvasHeight - dispH) / 2f + panY

    val imgX = (screenPos.x - screenImgLeft) / scale
    val imgY = (screenPos.y - screenImgTop) / scale

    return Offset(imgX, imgY)
  }

  /**
   * Converts image pixel coordinates [imagePos] to screen coordinates.
   */
  fun imageToScreenCoordinates(
    imagePos: Offset,
    canvasWidth: Float,
    canvasHeight: Float,
    imageWidth: Int,
    imageHeight: Int,
    zoom: Float,
    panX: Float,
    panY: Float
  ): Offset {
    val baseScale = min(canvasWidth / imageWidth.toFloat(), canvasHeight / imageHeight.toFloat())
    val scale = baseScale * zoom
    val dispW = imageWidth * scale
    val dispH = imageHeight * scale

    val screenImgLeft = (canvasWidth - dispW) / 2f + panX
    val screenImgTop = (canvasHeight - dispH) / 2f + panY

    return Offset(
      imagePos.x * scale + screenImgLeft,
      imagePos.y * scale + screenImgTop
    )
  }

  /**
   * Calculates the bounding box for a list of strokes in image pixel coordinates,
   * padded by [paddingPx] and clamped to image boundaries [imageWidth] x [imageHeight].
   */
  fun calculateStrokeBounds(
    strokes: List<ImageStroke>,
    imageWidth: Int,
    imageHeight: Int,
    paddingPx: Int = PADDING_PX
  ): Rect? {
    if (strokes.isEmpty()) return null

    var minX = Float.MAX_VALUE
    var minY = Float.MAX_VALUE
    var maxX = Float.MIN_VALUE
    var maxY = Float.MIN_VALUE

    for (stroke in strokes) {
      val r = stroke.radiusPx
      for (p in stroke.points) {
        if (p.x - r < minX) minX = p.x - r
        if (p.x + r > maxX) maxX = p.x + r
        if (p.y - r < minY) minY = p.y - r
        if (p.y + r > maxY) maxY = p.y + r
      }
    }

    if (minX > maxX || minY > maxY) return null

    val left = (minX.roundToInt() - paddingPx).coerceIn(0, imageWidth - 1)
    val top = (minY.roundToInt() - paddingPx).coerceIn(0, imageHeight - 1)
    val right = (maxX.roundToInt() + paddingPx).coerceIn(0, imageWidth - 1)
    val bottom = (maxY.roundToInt() + paddingPx).coerceIn(0, imageHeight - 1)

    if (right <= left || bottom <= top) return null

    return Rect(left, top, right + 1, bottom + 1)
  }

  /**
   * Returns true if the marked area is larger than [MAX_AREA_RATIO] (8%) of the total image area.
   */
  fun isMarkedAreaTooLarge(
    bounds: Rect,
    imageWidth: Int,
    imageHeight: Int,
    maxRatio: Float = MAX_AREA_RATIO
  ): Boolean {
    val totalImagePixels = imageWidth.toLong() * imageHeight.toLong()
    if (totalImagePixels <= 0) return false
    val markedPixels = bounds.width().toLong() * bounds.height().toLong()
    return (markedPixels.toFloat() / totalImagePixels.toFloat()) > maxRatio
  }

  /**
   * Generates a feathered alpha mask (values 0.0f .. 1.0f) inside [bounds] from the strokes.
   * Dilates by [dilationPx] (default 3) and applies Gaussian feathering of [featherPx] (default 8).
   */
  fun buildFeatheredMask(
    strokes: List<ImageStroke>,
    bounds: Rect,
    dilationPx: Int = 3,
    featherPx: Int = 8
  ): FloatArray {
    val w = bounds.width()
    val h = bounds.height()
    val mask = FloatArray(w * h)

    // 1. Rasterize lines and circle caps onto local coordinate grid
    for (stroke in strokes) {
      val r = stroke.radiusPx + dilationPx
      val rSquared = r * r
      val pts = stroke.points
      if (pts.isEmpty()) continue

      for (i in pts.indices) {
        val p1 = pts[i]
        val localX1 = p1.x - bounds.left
        val localY1 = p1.y - bounds.top

        // Circle stamp at vertex
        rasterizeCircle(mask, w, h, localX1, localY1, r, rSquared)

        // Line segment connecting to previous point
        if (i > 0) {
          val p0 = pts[i - 1]
          val localX0 = p0.x - bounds.left
          val localY0 = p0.y - bounds.top
          rasterizeCapsule(mask, w, h, localX0, localY0, localX1, localY1, r, rSquared)
        }
      }
    }

    // 2. Feathering: 3-pass fast horizontal and vertical box blur approximating Gaussian blur
    if (featherPx > 0) {
      val radius = featherPx.coerceIn(1, 15)
      boxBlurFloat(mask, w, h, radius)
      boxBlurFloat(mask, w, h, radius)
    }

    return mask
  }

  private fun rasterizeCircle(
    mask: FloatArray,
    w: Int,
    h: Int,
    cx: Float,
    cy: Float,
    r: Float,
    rSquared: Float
  ) {
    val minX = (cx - r).toInt().coerceIn(0, w - 1)
    val maxX = (cx + r).toInt().coerceIn(0, w - 1)
    val minY = (cy - r).toInt().coerceIn(0, h - 1)
    val maxY = (cy + r).toInt().coerceIn(0, h - 1)

    for (y in minY..maxY) {
      val dy = y - cy
      val dy2 = dy * dy
      val rowOffset = y * w
      for (x in minX..maxX) {
        val dx = x - cx
        if (dx * dx + dy2 <= rSquared) {
          mask[rowOffset + x] = 1.0f
        }
      }
    }
  }

  private fun rasterizeCapsule(
    mask: FloatArray,
    w: Int,
    h: Int,
    x0: Float,
    y0: Float,
    x1: Float,
    y1: Float,
    r: Float,
    rSquared: Float
  ) {
    val minX = (min(x0, x1) - r).toInt().coerceIn(0, w - 1)
    val maxX = (max(x0, x1) + r).toInt().coerceIn(0, w - 1)
    val minY = (min(y0, y1) - r).toInt().coerceIn(0, h - 1)
    val maxY = (max(y0, y1) + r).toInt().coerceIn(0, h - 1)

    val segDx = x1 - x0
    val segDy = y1 - y0
    val segLenSq = segDx * segDx + segDy * segDy

    for (y in minY..maxY) {
      val rowOffset = y * w
      for (x in minX..maxX) {
        val distSq = if (segLenSq <= 0.0001f) {
          val dx = x - x0
          val dy = y - y0
          dx * dx + dy * dy
        } else {
          val t = (((x - x0) * segDx + (y - y0) * segDy) / segLenSq).coerceIn(0f, 1f)
          val projX = x0 + t * segDx
          val projY = y0 + t * segDy
          val dx = x - projX
          val dy = y - projY
          dx * dx + dy * dy
        }
        if (distSq <= rSquared) {
          mask[rowOffset + x] = 1.0f
        }
      }
    }
  }

  /**
   * Fast separable 2D box blur for floating-point mask (horizontal + vertical passes).
   */
  private fun boxBlurFloat(data: FloatArray, w: Int, h: Int, r: Int) {
    val temp = FloatArray(data.size)
    val div = 2 * r + 1

    // Horizontal pass
    for (y in 0 until h) {
      val rowOffset = y * w
      var sum = 0f
      for (i in -r..r) {
        val x = i.coerceIn(0, w - 1)
        sum += data[rowOffset + x]
      }
      for (x in 0 until w) {
        temp[rowOffset + x] = sum / div
        val left = (x - r).coerceIn(0, w - 1)
        val right = (x + r + 1).coerceIn(0, w - 1)
        sum += data[rowOffset + right] - data[rowOffset + left]
      }
    }

    // Vertical pass
    for (x in 0 until w) {
      var sum = 0f
      for (i in -r..r) {
        val y = i.coerceIn(0, h - 1)
        sum += temp[y * w + x]
      }
      for (y in 0 until h) {
        data[y * w + x] = (sum / div).coerceIn(0f, 1f)
        val top = (y - r).coerceIn(0, h - 1)
        val bottom = (y + r + 1).coerceIn(0, h - 1)
        sum += temp[bottom * w + x] - temp[top * w + x]
      }
    }
  }

  /**
   * "আসল ফেরান" (Revert to Original):
   * Blends pixels from the [originalBitmap] back into the [enhancedBitmap] inside [bounds]
   * weighted by the feathered [mask]. Returns an [EditPatch] for undo/redo.
   */
  fun applyRevertToOriginal(
    enhancedBitmap: Bitmap,
    originalBitmap: Bitmap,
    bounds: Rect,
    mask: FloatArray
  ): EditPatch {
    val w = bounds.width()
    val h = bounds.height()

    val beforePixels = IntArray(w * h)
    val afterPixels = IntArray(w * h)
    enhancedBitmap.getPixels(beforePixels, 0, w, bounds.left, bounds.top, w, h)

    // Ensure we sample the original bitmap at the matching coordinates
    val origW = originalBitmap.width
    val origH = originalBitmap.height
    val scaleX = origW.toFloat() / enhancedBitmap.width.toFloat()
    val scaleY = origH.toFloat() / enhancedBitmap.height.toFloat()

    val origCropPixels = IntArray(w * h)
    if (origW == enhancedBitmap.width && origH == enhancedBitmap.height) {
      originalBitmap.getPixels(origCropPixels, 0, w, bounds.left, bounds.top, w, h)
    } else {
      // Map coordinates if original had different dimensions
      for (y in 0 until h) {
        val srcY = ((bounds.top + y) * scaleY).toInt().coerceIn(0, origH - 1)
        val row = y * w
        for (x in 0 until w) {
          val srcX = ((bounds.left + x) * scaleX).toInt().coerceIn(0, origW - 1)
          origCropPixels[row + x] = originalBitmap.getPixel(srcX, srcY)
        }
      }
    }

    for (i in 0 until w * h) {
      val alpha = mask[i]
      if (alpha <= 0.001f) {
        afterPixels[i] = beforePixels[i]
      } else {
        val curr = beforePixels[i]
        val orig = origCropPixels[i]

        val cR = Color.red(curr)
        val cG = Color.green(curr)
        val cB = Color.blue(curr)

        val oR = Color.red(orig)
        val oG = Color.green(orig)
        val oB = Color.blue(orig)

        val newR = ((1f - alpha) * cR + alpha * oR).roundToInt().coerceIn(0, 255)
        val newG = ((1f - alpha) * cG + alpha * oG).roundToInt().coerceIn(0, 255)
        val newB = ((1f - alpha) * cB + alpha * oB).roundToInt().coerceIn(0, 255)

        afterPixels[i] = Color.rgb(newR, newG, newB)
      }
    }

    // Apply back into enhancedBitmap
    enhancedBitmap.setPixels(afterPixels, 0, w, bounds.left, bounds.top, w, h)

    return EditPatch(bounds, beforePixels, afterPixels)
  }

  /**
   * "দাগ মুছুন" (Inpaint / Erase Blemish):
   * Inpaints the masked pixels using a fast pyramid push-pull diffusion fill,
   * adds surrounding texture grain so the patch matches real image noise,
   * and blends seamlessly using the feathered [mask].
   */
  fun applyInpaintBlemish(
    enhancedBitmap: Bitmap,
    bounds: Rect,
    mask: FloatArray
  ): EditPatch {
    val w = bounds.width()
    val h = bounds.height()

    val beforePixels = IntArray(w * h)
    val afterPixels = IntArray(w * h)
    enhancedBitmap.getPixels(beforePixels, 0, w, bounds.left, bounds.top, w, h)

    // 1. Pyramid Push-Pull inpainting
    val inpainted = runPyramidPushPull(beforePixels, mask, w, h)

    // 2. Measure local grain / standard deviation from clean border pixels
    val localNoiseStdDev = measureCleanSurroundingGrain(beforePixels, mask, w, h)

    // 3. Synthesize matching grain and blend with feathered mask
    val random = Random(42)
    for (i in 0 until w * h) {
      val alpha = mask[i]
      if (alpha <= 0.001f) {
        afterPixels[i] = beforePixels[i]
      } else {
        val inpPixel = inpainted[i]
        var r = Color.red(inpPixel)
        var g = Color.green(inpPixel)
        var b = Color.blue(inpPixel)

        if (localNoiseStdDev > 0.5f) {
          // Slight gaussian-like noise perturbation
          val noise = ((random.nextFloat() + random.nextFloat() - 1f) * localNoiseStdDev).roundToInt()
          r = (r + noise).coerceIn(0, 255)
          g = (g + noise).coerceIn(0, 255)
          b = (b + noise).coerceIn(0, 255)
        }

        val origPixel = beforePixels[i]
        val oR = Color.red(origPixel)
        val oG = Color.green(origPixel)
        val oB = Color.blue(origPixel)

        val blendedR = ((1f - alpha) * oR + alpha * r).roundToInt().coerceIn(0, 255)
        val blendedG = ((1f - alpha) * oG + alpha * g).roundToInt().coerceIn(0, 255)
        val blendedB = ((1f - alpha) * oB + alpha * b).roundToInt().coerceIn(0, 255)

        afterPixels[i] = Color.rgb(blendedR, blendedG, blendedB)
      }
    }

    // Apply back into enhancedBitmap
    enhancedBitmap.setPixels(afterPixels, 0, w, bounds.left, bounds.top, w, h)

    return EditPatch(bounds, beforePixels, afterPixels)
  }

  /**
   * Pyramid Push-Pull diffusion inpainting algorithm:
   * Level 0 is the crop. We downscale (push) building lower resolution representations,
   * then upscale (pull) interpolating values into holes where weight was 0.
   */
  private fun runPyramidPushPull(
    pixels: IntArray,
    mask: FloatArray,
    width: Int,
    height: Int
  ): IntArray {
    // Determine pyramid levels (up to 5 levels)
    val maxLevels = 5
    val levelsW = mutableListOf<Int>()
    val levelsH = mutableListOf<Int>()
    var curW = width
    var curH = height

    while (levelsW.size < maxLevels && curW > 2 && curH > 2) {
      levelsW.add(curW)
      levelsH.add(curH)
      curW = (curW + 1) / 2
      curH = (curH + 1) / 2
    }

    val numLevels = levelsW.size
    val pyrR = Array(numLevels) { FloatArray(levelsW[it] * levelsH[it]) }
    val pyrG = Array(numLevels) { FloatArray(levelsW[it] * levelsH[it]) }
    val pyrB = Array(numLevels) { FloatArray(levelsW[it] * levelsH[it]) }
    val pyrWeight = Array(numLevels) { FloatArray(levelsW[it] * levelsH[it]) }

    // Initialize Level 0
    for (i in 0 until width * height) {
      val weight = (1f - mask[i]).coerceIn(0f, 1f)
      val p = pixels[i]
      pyrR[0][i] = Color.red(p) * weight
      pyrG[0][i] = Color.green(p) * weight
      pyrB[0][i] = Color.blue(p) * weight
      pyrWeight[0][i] = weight
    }

    // PUSH phase: downsample to coarser levels
    for (lvl in 0 until numLevels - 1) {
      val srcW = levelsW[lvl]
      val srcH = levelsH[lvl]
      val dstW = levelsW[lvl + 1]
      val dstH = levelsH[lvl + 1]

      val sR = pyrR[lvl]
      val sG = pyrG[lvl]
      val sB = pyrB[lvl]
      val sW = pyrWeight[lvl]

      val dR = pyrR[lvl + 1]
      val dG = pyrG[lvl + 1]
      val dB = pyrB[lvl + 1]
      val dW = pyrWeight[lvl + 1]

      for (dy in 0 until dstH) {
        val sy0 = dy * 2
        val sy1 = min(sy0 + 1, srcH - 1)
        for (dx in 0 until dstW) {
          val sx0 = dx * 2
          val sx1 = min(sx0 + 1, srcW - 1)

          var sumR = 0f
          var sumG = 0f
          var sumB = 0f
          var sumW = 0f

          val offsets = intArrayOf(
            sy0 * srcW + sx0,
            sy0 * srcW + sx1,
            sy1 * srcW + sx0,
            sy1 * srcW + sx1
          )

          for (off in offsets) {
            sumR += sR[off]
            sumG += sG[off]
            sumB += sB[off]
            sumW += sW[off]
          }

          val dstOff = dy * dstW + dx
          dR[dstOff] = sumR / 4f
          dG[dstOff] = sumG / 4f
          dB[dstOff] = sumB / 4f
          dW[dstOff] = sumW / 4f
        }
      }
    }

    // PULL phase: upscale and interpolate missing holes
    for (lvl in numLevels - 1 downTo 1) {
      val coarseW = levelsW[lvl]
      val coarseH = levelsH[lvl]
      val fineW = levelsW[lvl - 1]
      val fineH = levelsH[lvl - 1]

      val cR = pyrR[lvl]
      val cG = pyrG[lvl]
      val cB = pyrB[lvl]
      val cW = pyrWeight[lvl]

      val fR = pyrR[lvl - 1]
      val fG = pyrG[lvl - 1]
      val fB = pyrB[lvl - 1]
      val fW = pyrWeight[lvl - 1]

      for (fy in 0 until fineH) {
        val cy = (fy / 2).coerceIn(0, coarseH - 1)
        for (fx in 0 until fineW) {
          val cx = (fx / 2).coerceIn(0, coarseW - 1)
          val fIdx = fy * fineW + fx
          val curWeight = fW[fIdx]

          if (curWeight < 0.99f) {
            val cIdx = cy * coarseW + cx
            val coarseWeight = cW[cIdx]
            if (coarseWeight > 0.001f) {
              val coarseMeanR = cR[cIdx] / coarseWeight
              val coarseMeanG = cG[cIdx] / coarseWeight
              val coarseMeanB = cB[cIdx] / coarseWeight

              val fillFactor = 1f - curWeight
              fR[fIdx] += coarseMeanR * fillFactor
              fG[fIdx] += coarseMeanG * fillFactor
              fB[fIdx] += coarseMeanB * fillFactor
              fW[fIdx] = 1f
            }
          }
        }
      }
    }

    // Reconstruct level 0 pixels
    val result = IntArray(width * height)
    val r0 = pyrR[0]
    val g0 = pyrG[0]
    val b0 = pyrB[0]
    val w0 = pyrWeight[0]

    for (i in 0 until width * height) {
      val weight = w0[i]
      if (weight > 0.001f) {
        val r = (r0[i] / weight).roundToInt().coerceIn(0, 255)
        val g = (g0[i] / weight).roundToInt().coerceIn(0, 255)
        val b = (b0[i] / weight).roundToInt().coerceIn(0, 255)
        result[i] = Color.rgb(r, g, b)
      } else {
        result[i] = pixels[i]
      }
    }

    return result
  }

  /**
   * Measures local noise / high-frequency texture variation from clean (unmasked) pixels
   * around the border of the bounding box.
   */
  private fun measureCleanSurroundingGrain(
    pixels: IntArray,
    mask: FloatArray,
    width: Int,
    height: Int
  ): Float {
    var count = 0
    var sumDiff = 0.0

    // Check pixels with mask == 0 and compare with horizontal neighbors
    for (y in 0 until height) {
      val row = y * width
      for (x in 0 until width - 1) {
        val idx = row + x
        if (mask[idx] < 0.05f && mask[idx + 1] < 0.05f) {
          val p0 = pixels[idx]
          val p1 = pixels[idx + 1]
          val diff = (Color.red(p0) - Color.red(p1) +
              Color.green(p0) - Color.green(p1) +
              Color.blue(p0) - Color.blue(p1)) / 3.0
          sumDiff += diff * diff
          count++
        }
      }
    }

    if (count < 10) return 1.5f
    val variance = sumDiff / count
    return sqrt(variance).toFloat().coerceIn(0.5f, 5.0f)
  }
}
