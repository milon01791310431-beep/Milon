package com.example.enhancer.ui.screens

import android.graphics.Bitmap
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.enhancer.model.ProcessingProgress
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.BorderColor
import com.example.ui.theme.CardBackground
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.MainBackground
import com.example.ui.theme.MainText
import com.example.ui.theme.PrimaryGradient
import com.example.ui.theme.PrimaryPurple
import com.example.ui.theme.SecondaryBackground
import com.example.ui.theme.SecondaryBlue
import com.example.ui.theme.SecondaryText
import com.example.ui.theme.TextMuted
import kotlin.math.roundToInt

@Composable
fun ProcessingScreen(
  originalBitmap: Bitmap?,
  progress: ProcessingProgress,
  errorMessage: String?,
  onCancel: () -> Unit,
  onTryAgain: () -> Unit,
  onBackToPhoto: () -> Unit,
  modifier: Modifier = Modifier
) {
  val animatedProgress by animateFloatAsState(
    targetValue = progress.percent ?: 0.5f,
    animationSpec = tween(durationMillis = 350, easing = FastOutSlowInEasing),
    label = "processing_progress_anim"
  )

  val infiniteTransition = rememberInfiniteTransition(label = "processing_effects")
  val rotationAngle by infiniteTransition.animateFloat(
    initialValue = 0f,
    targetValue = 360f,
    animationSpec = infiniteRepeatable(
      animation = tween(durationMillis = 3500, easing = LinearEasing),
      repeatMode = RepeatMode.Restart
    ),
    label = "rotation"
  )

  val pulseScale by infiniteTransition.animateFloat(
    initialValue = 0.95f,
    targetValue = 1.05f,
    animationSpec = infiniteRepeatable(
      animation = tween(durationMillis = 1200, easing = FastOutSlowInEasing),
      repeatMode = RepeatMode.Reverse
    ),
    label = "pulse"
  )

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(MainBackground)
      .verticalScroll(rememberScrollState())
      .padding(horizontal = 24.dp, vertical = 20.dp),
    horizontalAlignment = Alignment.CenterHorizontally
  ) {
    // Header
    Text(
      text = if (errorMessage != null) "ছবি ফ্রেশ করতে সমস্যা হয়েছে" else "ছবি ফ্রেশ করা হচ্ছে",
      fontSize = 24.sp,
      fontWeight = FontWeight.Bold,
      color = if (errorMessage != null) ErrorRed else MainText,
      textAlign = TextAlign.Center
    )

    Spacer(modifier = Modifier.height(4.dp))

    Text(
      text = if (errorMessage != null) "প্রসেসিংয়ের সময় একটি সমস্যা হয়েছে।" else "AI আপনার ছবিতে কাজ করছে",
      fontSize = 14.sp,
      color = SecondaryText,
      textAlign = TextAlign.Center
    )

    Spacer(modifier = Modifier.height(24.dp))

    // Stable Original Image Preview Card
    if (originalBitmap != null) {
      Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = CardBackground),
        border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor),
        modifier = Modifier
          .fillMaxWidth()
          .height(230.dp)
      ) {
        Column(
          modifier = Modifier
            .fillMaxSize()
            .padding(14.dp)
        ) {
          // Label at the top-left corner of the card, not on the photo
          Surface(
            shape = RoundedCornerShape(8.dp),
            color = Color.Black.copy(alpha = 0.50f),
            border = androidx.compose.foundation.BorderStroke(0.5.dp, BorderColor),
            modifier = Modifier.padding(bottom = 8.dp)
          ) {
            Text(
              text = "মূল ছবি",
              color = AccentCyan,
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold,
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
            )
          }

          Box(
            modifier = Modifier
              .fillMaxWidth()
              .weight(1f),
            contentAlignment = Alignment.Center
          ) {
            Image(
              bitmap = originalBitmap.asImageBitmap(),
              contentDescription = "মূল ছবি",
              contentScale = ContentScale.Fit,
              modifier = Modifier.fillMaxSize()
            )
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(30.dp))

    if (errorMessage != null) {
      // Error State
      Surface(
        shape = RoundedCornerShape(16.dp),
        color = ErrorRed.copy(alpha = 0.12f),
        border = androidx.compose.foundation.BorderStroke(1.dp, ErrorRed.copy(alpha = 0.4f)),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(
          modifier = Modifier.padding(20.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          Icon(
            imageVector = Icons.Default.ErrorOutline,
            contentDescription = null,
            tint = ErrorRed,
            modifier = Modifier.size(36.dp)
          )
          Spacer(modifier = Modifier.height(10.dp))
          Text(
            text = errorMessage,
            fontSize = 14.sp,
            color = MainText,
            textAlign = TextAlign.Center
          )
        }
      }

      Spacer(modifier = Modifier.height(24.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        OutlinedButton(
          onClick = onBackToPhoto,
          shape = RoundedCornerShape(14.dp),
          colors = ButtonDefaults.outlinedButtonColors(contentColor = SecondaryText),
          border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor),
          modifier = Modifier.weight(1f).height(48.dp)
        ) {
          Text("ছবিতে ফিরে যান", fontSize = 13.sp)
        }

        Button(
          onClick = onTryAgain,
          shape = RoundedCornerShape(14.dp),
          colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
          modifier = Modifier
            .weight(1f)
            .height(48.dp)
            .background(PrimaryGradient, RoundedCornerShape(14.dp))
        ) {
          Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp), tint = MainText)
          Spacer(modifier = Modifier.width(6.dp))
          Text("আবার চেষ্টা করুন", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MainText)
        }
      }
    } else {
      // Active Processing State
      // Animated AI Aperture Ring
      Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier.size(160.dp)
      ) {
        Canvas(modifier = Modifier.size(150.dp * pulseScale)) {
          drawCircle(
            brush = Brush.radialGradient(
              listOf(PrimaryPurple.copy(alpha = 0.25f), Color.Transparent),
              center = center,
              radius = size.width / 2f
            )
          )
        }

        Canvas(
          modifier = Modifier
            .size(130.dp)
            .rotate(rotationAngle)
        ) {
          drawArc(
            brush = Brush.sweepGradient(
              listOf(PrimaryPurple, SecondaryBlue, AccentCyan, Color.Transparent)
            ),
            startAngle = 0f,
            sweepAngle = 290f,
            useCenter = false,
            style = Stroke(width = 5.dp.toPx(), cap = StrokeCap.Round)
          )
        }

        Surface(
          shape = CircleShape,
          color = CardBackground,
          modifier = Modifier
            .size(96.dp)
            .border(1.5.dp, BorderColor, CircleShape)
        ) {
          Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.fillMaxSize()
          ) {
            Icon(
              imageVector = Icons.Default.AutoAwesome,
              contentDescription = null,
              tint = AccentCyan,
              modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.height(4.dp))
            if (progress.isIndeterminate || progress.percent == null) {
              Text(
                text = "AI",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = AccentCyan
              )
            } else {
              Text(
                text = "${(animatedProgress * 100).roundToInt()}%",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = MainText
              )
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(26.dp))

      // Status Title
      Text(
        text = progress.stage,
        fontSize = 20.sp,
        fontWeight = FontWeight.Bold,
        color = MainText,
        textAlign = TextAlign.Center
      )

      Spacer(modifier = Modifier.height(8.dp))

      // Subtext Detail
      Text(
        text = progress.detail,
        fontSize = 13.sp,
        color = SecondaryText,
        textAlign = TextAlign.Center,
        modifier = Modifier.padding(horizontal = 16.dp)
      )

      Spacer(modifier = Modifier.height(24.dp))

      // Linear Progress Bar (Indeterminate when remote or unmeasured, Determinate when stage measured)
      if (progress.isIndeterminate || progress.percent == null) {
        LinearProgressIndicator(
          modifier = Modifier
            .fillMaxWidth(0.9f)
            .height(8.dp)
            .clip(RoundedCornerShape(4.dp)),
          color = AccentCyan,
          trackColor = SecondaryBackground
        )
      } else {
        LinearProgressIndicator(
          progress = { animatedProgress },
          modifier = Modifier
            .fillMaxWidth(0.9f)
            .height(8.dp)
            .clip(RoundedCornerShape(4.dp)),
          color = AccentCyan,
          trackColor = SecondaryBackground,
          drawStopIndicator = {}
        )
      }

      Spacer(modifier = Modifier.height(30.dp))

      // Cancel button
      OutlinedButton(
        onClick = onCancel,
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = SecondaryText),
        border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor),
        modifier = Modifier.testTag("cancel_processing_button")
      ) {
        Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text("বাতিল করুন", fontSize = 13.sp)
      }
    }
  }
}
