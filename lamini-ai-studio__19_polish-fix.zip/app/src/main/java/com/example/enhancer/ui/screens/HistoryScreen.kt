package com.example.enhancer.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.enhancer.data.history.EnhancedPhotoEntity
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.BorderColor
import com.example.ui.theme.CardBackground
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.MainBackground
import com.example.ui.theme.MainText
import com.example.ui.theme.PrimaryGradient
import com.example.ui.theme.PrimaryPurple
import com.example.ui.theme.SecondaryBackground
import com.example.ui.theme.SecondaryBlue
import com.example.ui.theme.SecondaryText
import com.example.ui.theme.TextMuted
import java.io.File

@Composable
fun HistoryScreen(
  photos: List<EnhancedPhotoEntity>,
  showClearDialog: Boolean,
  onOpenPhoto: (EnhancedPhotoEntity) -> Unit,
  onDeletePhoto: (EnhancedPhotoEntity) -> Unit,
  onPromptClearHistory: () -> Unit,
  onDismissClearDialog: () -> Unit,
  onConfirmClearHistory: () -> Unit,
  onNavigateToEnhance: () -> Unit,
  modifier: Modifier = Modifier
) {
  Column(
    modifier = modifier
      .fillMaxSize()
      .background(MainBackground)
      .padding(horizontal = 20.dp, vertical = 12.dp)
  ) {
    // Header
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Column {
        Text(
          text = "Your Creations",
          fontSize = 24.sp,
          fontWeight = FontWeight.Bold,
          color = MainText
        )
        Text(
          text = "All your enhanced photos in one place",
          fontSize = 13.sp,
          color = SecondaryText
        )
      }

      if (photos.isNotEmpty()) {
        IconButton(
          onClick = onPromptClearHistory,
          modifier = Modifier.testTag("clear_all_history_button")
        ) {
          Icon(
            imageVector = Icons.Default.DeleteSweep,
            contentDescription = "Clear All History",
            tint = ErrorRed
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(16.dp))

    if (photos.isEmpty()) {
      // Empty State
      Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
      ) {
        Card(
          shape = RoundedCornerShape(22.dp),
          colors = CardDefaults.cardColors(containerColor = CardBackground),
          border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(
            modifier = Modifier.padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            Box(
              modifier = Modifier
                .size(64.dp)
                .clip(CircleShape)
                .background(SecondaryBackground),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = Icons.Default.History,
                contentDescription = null,
                tint = SecondaryText,
                modifier = Modifier.size(32.dp)
              )
            }
            Spacer(modifier = Modifier.height(16.dp))
            Text(
              text = "No creations yet.",
              fontSize = 18.sp,
              fontWeight = FontWeight.Bold,
              color = MainText
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
              text = "Your enhanced photos will appear here after your first successful enhancement.",
              fontSize = 13.sp,
              color = SecondaryText,
              textAlign = TextAlign.Center,
              lineHeight = 18.sp
            )
            Spacer(modifier = Modifier.height(24.dp))
            Button(
              onClick = onNavigateToEnhance,
              shape = RoundedCornerShape(14.dp),
              colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
              modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .background(PrimaryGradient, RoundedCornerShape(14.dp))
            ) {
              Text("Enhance a Photo", fontWeight = FontWeight.Bold, color = MainText)
            }
          }
        }
      }
    } else {
      // Responsive Grid of Creations
      LazyVerticalGrid(
        columns = GridCells.Adaptive(minSize = 150.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(bottom = 24.dp),
        modifier = Modifier.fillMaxSize()
      ) {
        items(photos, key = { it.id }) { photo ->
          HistoryPhotoCard(
            photo = photo,
            onOpen = { onOpenPhoto(photo) },
            onDelete = { onDeletePhoto(photo) }
          )
        }
      }
    }
  }

  // Clear All History Confirmation Dialog
  if (showClearDialog) {
    AlertDialog(
      onDismissRequest = onDismissClearDialog,
      containerColor = CardBackground,
      title = {
        Text("Clear All Creations?", color = MainText, fontWeight = FontWeight.Bold)
      },
      text = {
        Text(
          "Are you sure you want to permanently delete all saved history and temporary files from your device? This cannot be undone.",
          color = SecondaryText,
          fontSize = 14.sp
        )
      },
      confirmButton = {
        Button(
          onClick = onConfirmClearHistory,
          colors = ButtonDefaults.buttonColors(containerColor = ErrorRed)
        ) {
          Text("Clear All", color = MainText)
        }
      },
      dismissButton = {
        TextButton(onClick = onDismissClearDialog) {
          Text("Cancel", color = SecondaryText)
        }
      }
    )
  }
}

@Composable
private fun HistoryPhotoCard(
  photo: EnhancedPhotoEntity,
  onOpen: () -> Unit,
  onDelete: () -> Unit
) {
  var menuExpanded by remember { mutableStateOf(false) }

  Card(
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = CardBackground),
    border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor),
    modifier = Modifier
      .fillMaxWidth()
      .clickable(onClick = onOpen)
      .testTag("history_item_${photo.id}")
  ) {
    Column {
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(130.dp)
          .background(SecondaryBackground)
      ) {
        AsyncImage(
          model = File(photo.enhancedFilePath),
          contentDescription = "Creation Thumbnail",
          contentScale = ContentScale.Crop,
          modifier = Modifier.fillMaxSize()
        )

        // Upscale badge
        Surface(
          shape = RoundedCornerShape(6.dp),
          color = PrimaryPurple.copy(alpha = 0.85f),
          modifier = Modifier
            .align(Alignment.TopStart)
            .padding(8.dp)
        ) {
          Text(
            text = photo.upscaleFactor,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            color = MainText,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
          )
        }

        // Three dots action menu
        Box(
          modifier = Modifier
            .align(Alignment.TopEnd)
            .padding(4.dp)
        ) {
          IconButton(
            onClick = { menuExpanded = true },
            modifier = Modifier.size(28.dp)
          ) {
            Surface(shape = CircleShape, color = Color.Black.copy(alpha = 0.5f)) {
              Icon(
                imageVector = Icons.Default.MoreVert,
                contentDescription = "Options",
                tint = Color.White,
                modifier = Modifier.size(16.dp)
              )
            }
          }

          DropdownMenu(
            expanded = menuExpanded,
            onDismissRequest = { menuExpanded = false },
            modifier = Modifier.background(CardBackground)
          ) {
            DropdownMenuItem(
              text = { Text("View & Compare", color = MainText) },
              onClick = {
                menuExpanded = false
                onOpen()
              },
              leadingIcon = {
                Icon(Icons.Default.Visibility, contentDescription = null, tint = AccentCyan)
              }
            )
            DropdownMenuItem(
              text = { Text("Delete", color = ErrorRed) },
              onClick = {
                menuExpanded = false
                onDelete()
              },
              leadingIcon = {
                Icon(Icons.Default.Delete, contentDescription = null, tint = ErrorRed)
              }
            )
          }
        }
      }

      Column(modifier = Modifier.padding(10.dp)) {
        Text(
          text = photo.enhancementMode,
          fontSize = 13.sp,
          fontWeight = FontWeight.SemiBold,
          color = MainText,
          maxLines = 1
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
          text = photo.formattedEnhancedResolution,
          fontSize = 11.sp,
          color = SecondaryBlue,
          fontWeight = FontWeight.Medium
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
          text = photo.formattedDate,
          fontSize = 10.sp,
          color = TextMuted,
          maxLines = 1
        )
      }
    }
  }
}
