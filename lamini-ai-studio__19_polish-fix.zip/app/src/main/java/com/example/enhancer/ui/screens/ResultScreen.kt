package com.example.enhancer.ui.screens

import android.graphics.Bitmap
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.enhancer.model.EnhancementConfig
import com.example.enhancer.model.ExportFormat
import com.example.enhancer.model.ImageMetadata
import com.example.enhancer.ui.components.ComparisonSliderView
import com.example.enhancer.ui.viewmodel.ComparisonMode
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.MainBackground
import com.example.ui.theme.MainText
import com.example.ui.theme.PrimaryGradient
import com.example.ui.theme.PrimaryPurple
import com.example.ui.theme.SecondaryText
import com.example.ui.theme.SuccessGreen

@Composable
fun ResultScreen(
  originalBitmap: Bitmap,
  enhancedBitmap: Bitmap,
  originalMetadata: ImageMetadata? = null,
  enhancedMetadata: ImageMetadata? = null,
  config: EnhancementConfig = EnhancementConfig(),
  sliderPosition: Float = 0.5f,
  comparisonMode: ComparisonMode = ComparisonMode.SPLIT_SLIDER,
  exportFormat: ExportFormat = ExportFormat.JPEG,
  saveNotification: String? = null,
  isSaving: Boolean = false,
  usedEngineName: String = "",
  usedEngineIsAi: Boolean = false,
  aiUpscaleSkippedNote: String? = null,
  onSliderPositionChange: (Float) -> Unit,
  onComparisonModeChange: (ComparisonMode) -> Unit = {},
  onExportFormatChange: (ExportFormat) -> Unit = {},
  onDownload: () -> Unit,
  onShare: () -> Unit = {},
  onTryAgain: () -> Unit,
  onEnhanceAnother: () -> Unit = {},
  onDismissNotification: () -> Unit = {},
  onBitmapModified: (Bitmap) -> Unit = {},
  modifier: Modifier = Modifier
) {
  var isInspectViewerOpen by remember { mutableStateOf(false) }

  if (isInspectViewerOpen) {
    InspectFixViewer(
      originalBitmap = originalBitmap,
      enhancedBitmap = enhancedBitmap,
      isSaving = isSaving,
      saveNotification = saveNotification,
      onBitmapModified = onBitmapModified,
      onSaveToGallery = onDownload,
      onDismissNotification = onDismissNotification,
      onClose = { isInspectViewerOpen = false }
    )
  } else {
    Column(
      modifier = modifier
        .fillMaxSize()
        .background(MainBackground)
        .verticalScroll(rememberScrollState())
        .padding(horizontal = 20.dp, vertical = 14.dp)
    ) {
    // Minimal Header: Only the back arrow (returns to photo selection)
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically
    ) {
      IconButton(
        onClick = onTryAgain,
        modifier = Modifier.testTag("result_back_button")
      ) {
        Icon(
          imageVector = Icons.AutoMirrored.Filled.ArrowBack,
          contentDescription = "Back",
          tint = MainText
        )
      }
    }

    Spacer(modifier = Modifier.height(8.dp))

    // Save notification toast/banner (if saved to gallery)
    AnimatedVisibility(
      visible = saveNotification != null,
      enter = fadeIn() + expandVertically(),
      exit = fadeOut() + shrinkVertically()
    ) {
      if (saveNotification != null) {
        val isError = saveNotification.startsWith("ত্রুটি") || saveNotification.startsWith("Error")
        Surface(
          shape = RoundedCornerShape(14.dp),
          color = if (isError) ErrorRed.copy(alpha = 0.15f) else SuccessGreen.copy(alpha = 0.15f),
          border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isError) ErrorRed else SuccessGreen
          ),
          modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 12.dp)
        ) {
          Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.weight(1f)
            ) {
              Icon(
                imageVector = Icons.Default.CheckCircle,
                contentDescription = null,
                tint = if (isError) ErrorRed else SuccessGreen,
                modifier = Modifier.size(20.dp)
              )
              Spacer(modifier = Modifier.width(10.dp))
              Text(
                text = saveNotification,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                color = MainText
              )
            }
            IconButton(onClick = onDismissNotification, modifier = Modifier.size(24.dp)) {
              Icon(Icons.Default.Close, contentDescription = "Dismiss", tint = SecondaryText, modifier = Modifier.size(16.dp))
            }
          }
        }
      }
    }

    // Single interactive before/after drag slider (ORIGINAL left, ENHANCED right)
    ComparisonSliderView(
      originalBitmap = originalBitmap,
      enhancedBitmap = enhancedBitmap,
      sliderPosition = sliderPosition,
      onSliderPositionChange = onSliderPositionChange,
      onImageClick = { isInspectViewerOpen = true },
      modifier = Modifier.fillMaxWidth()
    )

    Spacer(modifier = Modifier.height(28.dp))

    // One big button at the bottom: "Gallery-তে সেভ করুন"
    Button(
      onClick = onDownload,
      enabled = !isSaving,
      shape = RoundedCornerShape(18.dp),
      colors = ButtonDefaults.buttonColors(
        containerColor = Color.Transparent,
        contentColor = MainText
      ),
      modifier = Modifier
        .fillMaxWidth()
        .height(58.dp)
        .shadow(16.dp, RoundedCornerShape(18.dp), spotColor = PrimaryPurple)
        .background(PrimaryGradient, RoundedCornerShape(18.dp))
        .testTag("download_hd_button")
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
      ) {
        if (isSaving) {
          CircularProgressIndicator(
            modifier = Modifier.size(20.dp),
            strokeWidth = 2.dp,
            color = MainText
          )
          Spacer(modifier = Modifier.width(10.dp))
          Text("গ্যালারিতে সেভ হচ্ছে...", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = MainText)
        } else {
          Icon(Icons.Default.Download, contentDescription = null, tint = MainText, modifier = Modifier.size(22.dp))
          Spacer(modifier = Modifier.width(10.dp))
          Text(
            text = "Gallery-তে সেভ করুন",
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = MainText
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(24.dp))
  }
}
}
