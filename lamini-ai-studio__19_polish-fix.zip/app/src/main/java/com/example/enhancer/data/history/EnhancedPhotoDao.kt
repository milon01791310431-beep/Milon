package com.example.enhancer.data.history

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface EnhancedPhotoDao {

  @Query("SELECT * FROM enhanced_photos ORDER BY timestamp DESC")
  fun getAllPhotos(): Flow<List<EnhancedPhotoEntity>>

  @Query("SELECT * FROM enhanced_photos ORDER BY timestamp DESC LIMIT 6")
  fun getRecentPhotos(): Flow<List<EnhancedPhotoEntity>>

  @Query("SELECT * FROM enhanced_photos WHERE id = :id LIMIT 1")
  suspend fun getPhotoById(id: Long): EnhancedPhotoEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertPhoto(photo: EnhancedPhotoEntity): Long

  @Query("DELETE FROM enhanced_photos WHERE id = :id")
  suspend fun deletePhotoById(id: Long)

  @Query("DELETE FROM enhanced_photos")
  suspend fun clearAllPhotos()

  @Query("SELECT COUNT(*) FROM enhanced_photos")
  fun getPhotoCount(): Flow<Int>
}
