package com.example.enhancer.engine

import android.graphics.Bitmap
import com.example.enhancer.model.EngineStatusInfo
import com.example.enhancer.model.EngineType
import com.example.enhancer.model.EnhancementConfig
import com.example.enhancer.model.ProcessingProgress

/**
 * Common abstraction contract separating image-processing pipelines from AI model inference implementations.
 */
interface AiInferenceEngine {
  val engineType: EngineType

  suspend fun getStatusInfo(): EngineStatusInfo

  suspend fun checkReadiness(): Result<EngineStatusInfo>

  suspend fun enhance(
    sourceBitmap: Bitmap,
    config: EnhancementConfig,
    onProgress: (ProcessingProgress) -> Unit
  ): Result<Bitmap>

  /**
   * Release any native sessions, memory buffers, or cached model state.
   */
  fun release() {}
}
