package com.example.enhancer.utils

import android.graphics.Bitmap
import android.os.Build
import com.example.enhancer.model.ExportFormat
import java.io.ByteArrayOutputStream

object MemorySafetyCalculator {

  data class Dimensions(val width: Int, val height: Int) {
    val totalPixels: Long
      get() = width.toLong() * height.toLong()

    val formattedString: String
      get() = "$width × $height px"
  }

  fun calculateTargetDimensions(inputWidth: Int, inputHeight: Int, scale: Int): Dimensions {
    require(inputWidth > 0 && inputHeight > 0) { "Dimensions must be positive" }
    require(scale in listOf(1, 2, 4)) { "Supported scale factors are 1, 2, or 4" }
    return Dimensions(inputWidth * scale, inputHeight * scale)
  }

  /**
   * Calculates target output dimensions preserving exact input size and aspect ratio,
   * capped at maxLongSide (4096 px) only if larger to prevent out-of-memory.
   */
  fun calculateTargetOutputDimensions(srcWidth: Int, srcHeight: Int, maxLongSide: Int = 4096): Dimensions {
    require(srcWidth > 0 && srcHeight > 0) { "Dimensions must be positive" }
    val maxDim = kotlin.math.max(srcWidth, srcHeight)
    if (maxDim > maxLongSide) {
      val factor = maxLongSide.toDouble() / maxDim
      val targetW = (srcWidth * factor).toInt().coerceAtLeast(1)
      val targetH = (srcHeight * factor).toInt().coerceAtLeast(1)
      return Dimensions(targetW, targetH)
    }
    return Dimensions(srcWidth, srcHeight)
  }

  /**
   * Calculates coordinate steps for tiled inference with overlap.
   */
  fun calculateTilingCoordinates(dimension: Int, tileSize: Int = 128, overlap: Int = 10): List<Int> {
    require(dimension > 0) { "Dimension must be positive" }
    val step = (tileSize - overlap).coerceAtLeast(1)
    val coords = mutableListOf<Int>()
    var curr = 0
    while (curr < dimension) {
      coords.add(curr)
      if (curr + tileSize >= dimension) break
      curr += step
    }
    return coords
  }

  fun validateOutputDimensions(actualBitmap: Bitmap, expectedDimensions: Dimensions, tolerancePercent: Float = 0.05f): Boolean {
    val expectedW = expectedDimensions.width
    val expectedH = expectedDimensions.height
    val actualW = actualBitmap.width
    val actualH = actualBitmap.height

    if (actualW == expectedW && actualH == expectedH) return true

    // Allow slight tolerance if tiled inference padded slightly
    val wDiff = kotlin.math.abs(actualW - expectedW).toFloat() / expectedW
    val hDiff = kotlin.math.abs(actualH - expectedH).toFloat() / expectedH
    return wDiff <= tolerancePercent && hDiff <= tolerancePercent
  }

  fun estimateBitmapMemoryBytes(width: Int, height: Int, bytesPerPixel: Int = 4): Long {
    return width.toLong() * height.toLong() * bytesPerPixel.toLong()
  }

  fun checkHeapAllocationSafety(targetWidth: Int, targetHeight: Int): AllocationSafetyResult {
    val runtime = Runtime.getRuntime()
    val maxMemory = runtime.maxMemory()
    val allocatedMemory = runtime.totalMemory() - runtime.freeMemory()
    val freeHeap = maxMemory - allocatedMemory

    val targetBitmapBytes = estimateBitmapMemoryBytes(targetWidth, targetHeight, 4)
    // Image processing pipelines require ~2-3x the target bitmap size for intermediate pixel arrays / filters
    val requiredWorkingMemory = (targetBitmapBytes * 2.5).toLong()

    return if (requiredWorkingMemory < freeHeap * 0.75) {
      AllocationSafetyResult(
        isSafe = true,
        estimatedBytes = targetBitmapBytes,
        availableHeapBytes = freeHeap,
        message = "Memory safe for on-device processing."
      )
    } else {
      AllocationSafetyResult(
        isSafe = false,
        estimatedBytes = targetBitmapBytes,
        availableHeapBytes = freeHeap,
        message = "Image target size (${targetWidth}×${targetHeight}, ~${targetBitmapBytes / (1024 * 1024)}MB) exceeds safe on-device heap limit. Recommend 2× scale or using the Self-Hosted Inference Server."
      )
    }
  }

  fun calculateActualEncodedSize(bitmap: Bitmap, format: ExportFormat, quality: Int = 95): Long {
    val stream = ByteArrayOutputStream()
    val compressFormat = when (format) {
      ExportFormat.PNG -> Bitmap.CompressFormat.PNG
      ExportFormat.JPEG -> Bitmap.CompressFormat.JPEG
      ExportFormat.WEBP -> {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
          Bitmap.CompressFormat.WEBP_LOSSLESS
        } else {
          @Suppress("DEPRECATION")
          Bitmap.CompressFormat.WEBP
        }
      }
    }
    bitmap.compress(compressFormat, quality, stream)
    return stream.size().toLong()
  }

  data class AllocationSafetyResult(
    val isSafe: Boolean,
    val estimatedBytes: Long,
    val availableHeapBytes: Long,
    val message: String
  )
}
