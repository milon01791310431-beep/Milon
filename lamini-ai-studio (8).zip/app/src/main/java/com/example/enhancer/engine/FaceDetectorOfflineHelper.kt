package com.example.enhancer.engine

import android.graphics.Bitmap
import android.graphics.PointF
import android.graphics.Rect
import android.media.FaceDetector
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume

object FaceDetectorOfflineHelper {

  data class DetectedFaceBox(
    val rect: Rect,
    val confidence: Float = 1.0f
  )

  suspend fun detectFaces(bitmap: Bitmap, maxFaces: Int = 5): List<DetectedFaceBox> = withContext(Dispatchers.Default) {
    try {
      val mlKitFaces = detectWithMlKit(bitmap)
      if (mlKitFaces.isNotEmpty()) {
        return@withContext mlKitFaces.take(maxFaces)
      }
    } catch (_: Exception) {
      // Fall back to Android system FaceDetector
    }

    try {
      detectWithAndroidFaceDetector(bitmap, maxFaces)
    } catch (_: Exception) {
      emptyList()
    }
  }

  private suspend fun detectWithMlKit(bitmap: Bitmap): List<DetectedFaceBox> =
    suspendCancellableCoroutine { continuation ->
      try {
        val options = FaceDetectorOptions.Builder()
          .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
          .setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_NONE)
          .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_NONE)
          .setMinFaceSize(0.1f)
          .build()

        val detector = FaceDetection.getClient(options)
        val image = InputImage.fromBitmap(bitmap, 0)

        detector.process(image)
          .addOnSuccessListener { faces ->
            val result = faces.map { face ->
              DetectedFaceBox(
                rect = face.boundingBox,
                confidence = 1.0f
              )
            }.sortedByDescending { it.rect.width() * it.rect.height() }
            detector.close()
            continuation.resume(result)
          }
          .addOnFailureListener { error ->
            detector.close()
            continuation.resume(emptyList())
          }
      } catch (e: Exception) {
        continuation.resume(emptyList())
      }
    }

  private fun detectWithAndroidFaceDetector(bitmap: Bitmap, maxFaces: Int): List<DetectedFaceBox> {
    var rgb565: Bitmap? = null
    return try {
      val width = bitmap.width
      val height = bitmap.height
      // Android FaceDetector requires even width and RGB_565
      val evenWidth = if (width % 2 == 0) width else width - 1
      rgb565 = Bitmap.createBitmap(evenWidth, height, Bitmap.Config.RGB_565)
      val canvas = android.graphics.Canvas(rgb565)
      canvas.drawBitmap(bitmap, 0f, 0f, null)

      val detector = FaceDetector(evenWidth, height, maxFaces)
      val faces = Array<FaceDetector.Face?>(maxFaces) { null }
      val count = detector.findFaces(rgb565, faces)

      val result = mutableListOf<DetectedFaceBox>()
      val midPoint = PointF()

      for (i in 0 until count) {
        val face = faces[i] ?: continue
        face.getMidPoint(midPoint)
        val eyeDistance = face.eyesDistance()
        val confidence = face.confidence()

        val halfBox = (eyeDistance * 1.6f).toInt()
        val left = (midPoint.x - halfBox).toInt().coerceAtLeast(0)
        val top = (midPoint.y - halfBox * 1.1f).toInt().coerceAtLeast(0)
        val right = (midPoint.x + halfBox).toInt().coerceAtMost(width)
        val bottom = (midPoint.y + halfBox * 1.5f).toInt().coerceAtMost(height)

        if (right > left && bottom > top) {
          result.add(
            DetectedFaceBox(
              rect = Rect(left, top, right, bottom),
              confidence = confidence
            )
          )
        }
      }
      result.sortedByDescending { it.rect.width() * it.rect.height() }
    } catch (_: Exception) {
      emptyList()
    } finally {
      rgb565?.recycle()
    }
  }
}
