package com.example.enhancer.ui.components

import android.graphics.Bitmap
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.CompareArrows
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.CardBackground
import com.example.ui.theme.MainBackground
import com.example.ui.theme.PrimaryGradient
import com.example.ui.theme.PrimaryPurple
import kotlin.math.max
import kotlin.math.roundToInt

@Composable
fun ComparisonSliderView(
  originalBitmap: Bitmap,
  enhancedBitmap: Bitmap,
  sliderPosition: Float,
  onSliderPositionChange: (Float) -> Unit,
  modifier: Modifier = Modifier
) {
  // Always keep a fresh reference to the callback to prevent stale captures
  val currentOnPositionChange by rememberUpdatedState(onSliderPositionChange)

  // Screen-sized preview bitmaps (long side max 1600 px) for smooth dragging without GPU memory overload
  val previewOriginal = remember(originalBitmap) {
    createPreviewBitmap(originalBitmap, maxDimension = 1600)
  }
  val previewEnhanced = remember(enhancedBitmap) {
    createPreviewBitmap(enhancedBitmap, maxDimension = 1600)
  }

  val originalImageBitmap = remember(previewOriginal) { previewOriginal.asImageBitmap() }
  val enhancedImageBitmap = remember(previewEnhanced) { previewEnhanced.asImageBitmap() }

  val aspect = remember(originalBitmap.width, originalBitmap.height) {
    if (originalBitmap.height > 0) {
      (originalBitmap.width.toFloat() / originalBitmap.height.toFloat()).coerceIn(0.2f, 5.0f)
    } else 1.0f
  }

  BoxWithConstraints(
    modifier = modifier
      .fillMaxWidth()
      .aspectRatio(aspect)
      .clip(RoundedCornerShape(20.dp))
      .background(CardBackground)
      .pointerInput(Unit) {
        detectTapGestures { tapOffset ->
          if (size.width > 0) {
            val ratio = (tapOffset.x / size.width.toFloat()).coerceIn(0f, 1f)
            currentOnPositionChange(ratio)
          }
        }
      }
      .pointerInput(Unit) {
        detectDragGestures { change, _ ->
          change.consume()
          if (size.width > 0) {
            val ratio = (change.position.x / size.width.toFloat()).coerceIn(0f, 1f)
            currentOnPositionChange(ratio)
          }
        }
      }
      .testTag("comparison_slider_container")
  ) {
    val totalWidthPx = constraints.maxWidth.toFloat()
    val totalHeightPx = constraints.maxHeight.toFloat()
    val dividerX = (sliderPosition * totalWidthPx).coerceIn(0f, totalWidthPx)

    // Canvas drawing both bitmaps with hardware-accelerated clipRect (NO per-frame Path allocations)
    Canvas(modifier = Modifier.fillMaxSize()) {
      val canvasW = size.width
      val canvasH = size.height
      val dstSize = IntSize(canvasW.roundToInt(), canvasH.roundToInt())

      // 1. Left Side: ORIGINAL image (clip from 0 to dividerX)
      clipRect(left = 0f, top = 0f, right = dividerX, bottom = canvasH) {
        drawImage(
          image = originalImageBitmap,
          dstSize = dstSize,
          dstOffset = IntOffset.Zero,
          filterQuality = FilterQuality.Medium
        )
      }

      // 2. Right Side: ENHANCED image (clip from dividerX to canvasW)
      clipRect(left = dividerX, top = 0f, right = canvasW, bottom = canvasH) {
        drawImage(
          image = enhancedImageBitmap,
          dstSize = dstSize,
          dstOffset = IntOffset.Zero,
          filterQuality = FilterQuality.Medium
        )
      }

      // 3. Vertical divider bar with subtle glow
      drawLine(
        color = AccentCyan.copy(alpha = 0.40f),
        start = Offset(dividerX, 0f),
        end = Offset(dividerX, canvasH),
        strokeWidth = 5.dp.toPx()
      )
      drawLine(
        color = Color.White,
        start = Offset(dividerX, 0f),
        end = Offset(dividerX, canvasH),
        strokeWidth = 2.dp.toPx()
      )
    }

    // PURELY VISUAL center circular handle (no separate drag detector to prevent jitter)
    val density = LocalDensity.current
    val handleSize = 44.dp
    val handleSizePx = with(density) { handleSize.toPx() }
    val handleOffsetX = (dividerX - handleSizePx / 2f).coerceIn(4f, totalWidthPx - handleSizePx - 4f)
    val handleOffsetY = (totalHeightPx / 2f - handleSizePx / 2f).coerceAtLeast(0f)

    Box(
      modifier = Modifier
        .offset { IntOffset(handleOffsetX.roundToInt(), handleOffsetY.roundToInt()) }
        .size(handleSize)
        .shadow(12.dp, CircleShape, spotColor = PrimaryPurple)
        .background(MainBackground, CircleShape)
        .clip(CircleShape)
        .testTag("slider_handle"),
      contentAlignment = Alignment.Center
    ) {
      Box(
        modifier = Modifier
          .size(38.dp)
          .clip(CircleShape)
          .background(PrimaryGradient),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          imageVector = Icons.AutoMirrored.Filled.CompareArrows,
          contentDescription = "Compare original and enhanced",
          tint = Color.White,
          modifier = Modifier.size(22.dp)
        )
      }
    }

    // "ORIGINAL" Badge (Left side)
    Surface(
      shape = RoundedCornerShape(10.dp),
      color = Color.Black.copy(alpha = 0.65f),
      modifier = Modifier
        .align(Alignment.TopStart)
        .padding(14.dp)
    ) {
      Text(
        text = "ORIGINAL",
        color = Color.White.copy(alpha = 0.85f),
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.sp,
        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
      )
    }

    // "ENHANCED ✨" Badge (Right side)
    Surface(
      shape = RoundedCornerShape(10.dp),
      color = PrimaryPurple.copy(alpha = 0.90f),
      modifier = Modifier
        .align(Alignment.TopEnd)
        .padding(14.dp)
    ) {
      Text(
        text = "ENHANCED ✨",
        color = Color.White,
        fontSize = 11.sp,
        fontWeight = FontWeight.ExtraBold,
        letterSpacing = 1.sp,
        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
      )
    }
  }
}

/**
 * Creates a display-optimized preview bitmap with long side at most maxDimension.
 * Keeps memory usage and drag compositing latency low.
 */
private fun createPreviewBitmap(src: Bitmap, maxDimension: Int = 1600): Bitmap {
  val w = src.width
  val h = src.height
  val maxDim = max(w, h)
  if (maxDim <= maxDimension) return src
  val factor = maxDimension.toFloat() / maxDim
  val targetW = (w * factor).roundToInt().coerceAtLeast(1)
  val targetH = (h * factor).roundToInt().coerceAtLeast(1)
  return Bitmap.createScaledBitmap(src, targetW, targetH, true)
}
