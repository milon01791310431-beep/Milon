package com.example.enhancer.engine

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import ai.onnxruntime.TensorInfo
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.Shader
import com.example.enhancer.model.EngineStatus
import com.example.enhancer.model.EngineStatusInfo
import com.example.enhancer.model.EngineType
import com.example.enhancer.model.EnhancementConfig
import com.example.enhancer.model.ProcessingProgress
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.FloatBuffer
import kotlin.coroutines.coroutineContext
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

class OnnxModelEngine(
  private val context: Context,
  private val modelManager: ModelManager
) : AiInferenceEngine {

  override val engineType: EngineType = EngineType.ONNX_LOCAL_AI

  var lastRealEsrganRan: Boolean = false
    private set

  var lastFacesRestoredCount: Int = 0
    private set

  var lastFaceModelMissingNotice: Boolean = false
    private set

  private var ortEnvironment: OrtEnvironment? = null
  private var imageSession: OrtSession? = null
  private var faceSession: OrtSession? = null
  private var loadedImagePath: String? = null
  private var loadedFacePath: String? = null

  // Cache detected scale per model file path (e.g. 2 or 4)
  private val modelScaleCache = mutableMapOf<String, Int>()

  private fun getOrCreateEnv(): OrtEnvironment {
    var env = ortEnvironment
    if (env == null) {
      env = OrtEnvironment.getEnvironment()
      ortEnvironment = env
    }
    return env
  }

  @Synchronized
  private fun getImageSession(modelFile: File): OrtSession {
    if (imageSession != null && loadedImagePath == modelFile.absolutePath) {
      return imageSession!!
    }
    imageSession?.close()
    val env = getOrCreateEnv()
    val opts = OrtSession.SessionOptions().apply {
      try {
        addNnapi()
      } catch (_: Exception) {
        // Fall back to CPU execution provider
      }
    }
    imageSession = env.createSession(modelFile.absolutePath, opts)
    loadedImagePath = modelFile.absolutePath
    return imageSession!!
  }

  @Synchronized
  private fun getFaceSession(modelFile: File): OrtSession {
    if (faceSession != null && loadedFacePath == modelFile.absolutePath) {
      return faceSession!!
    }
    faceSession?.close()
    val env = getOrCreateEnv()
    val opts = OrtSession.SessionOptions().apply {
      try {
        addNnapi()
      } catch (_: Exception) {
        // Fall back to CPU
      }
    }
    faceSession = env.createSession(modelFile.absolutePath, opts)
    loadedFacePath = modelFile.absolutePath
    return faceSession!!
  }

  override suspend fun getStatusInfo(): EngineStatusInfo {
    val imageReady = modelManager.isImageModelReady()
    val faceReady = modelManager.isFaceModelReady()

    return if (imageReady) {
      val imageFile = modelManager.resolveImageModelFile()
      val cachedScale = imageFile?.let { modelScaleCache[it.absolutePath] } ?: 2
      EngineStatusInfo(
        engineType = EngineType.ONNX_LOCAL_AI,
        status = EngineStatus.READY,
        modelName = "Real-ESRGAN (x$cachedScale)" + (if (faceReady) " + GFPGAN Face" else ""),
        modelVersion = "ONNX Mobile",
        runtimeEnvironment = "Local ONNX Runtime (NNAPI / CPU)",
        computeDevice = "On-Device NPU/CPU",
        statusMessage = "অন-ডিভাইস নিউরাল মডেল প্রস্তুত (${cachedScale}x সুপার-রেজোলিউশন)। 100% অফলাইন মোডে কার্যকর।",
        isNeuralAi = true,
        supportedScales = listOf(2, 4),
        supportsFaceRestoration = faceReady,
        diagnosticNotes = "মডেল ফাইল: ${imageFile?.name ?: "image_model.onnx"} (Scale: ${cachedScale}x)"
      )
    } else {
      EngineStatusInfo(
        engineType = EngineType.ONNX_LOCAL_AI,
        status = EngineStatus.NOT_CONFIGURED,
        modelName = "AI মডেল ইনস্টল নেই",
        modelVersion = null,
        runtimeEnvironment = "Local ONNX Runtime",
        computeDevice = "On-Device",
        statusMessage = "AI মডেল নেই, বেসিক এনহান্সমেন্ট ব্যবহার হয়েছে",
        isNeuralAi = false,
        supportedScales = listOf(2, 4),
        supportsFaceRestoration = false,
        diagnosticNotes = "সেটিংস থেকে Real-ESRGAN .onnx মডেল ফাইল ইমপোর্ট বা ডাউনলোড করুন।"
      )
    }
  }

  override suspend fun checkReadiness(): Result<EngineStatusInfo> {
    val info = getStatusInfo()
    return if (info.status == EngineStatus.READY) {
      Result.success(info)
    } else {
      Result.failure(IllegalStateException("AI মডেল কনফিগার করা নেই। সেটিংস থেকে মডেল ইমপোর্ট করুন।"))
    }
  }

  override suspend fun enhance(
    sourceBitmap: Bitmap,
    config: EnhancementConfig,
    onProgress: (ProcessingProgress) -> Unit
  ): Result<Bitmap> = withContext(Dispatchers.Default) {
    var workingInput: Bitmap? = null
    var upscaledBitmap: Bitmap? = null
    var workingBitmap: Bitmap? = null

    lastRealEsrganRan = false
    lastFacesRestoredCount = 0
    lastFaceModelMissingNotice = false

    try {
      coroutineContext.ensureActive()

      val imageModelFile = modelManager.resolveImageModelFile()
      if (imageModelFile == null || !imageModelFile.exists()) {
        return@withContext Result.failure(
          IllegalStateException("AI মডেল নেই, বেসিক এনহান্সমেন্ট ব্যবহার হয়েছে")
        )
      }

      val session = getImageSession(imageModelFile)
      val env = getOrCreateEnv()
      val scale = getOrDetectImageScale(session, env, imageModelFile)

      // Step 1: Input sizing & memory safety
      // maxInputLongSide = 3840 / scale (e.g. 960 for x4, 1920 for x2)
      // Cap input so the intermediate upscaled bitmap never exceeds 3840 px
      val maxInputLongSide = 3840 / scale
      val currentLongSide = max(sourceBitmap.width, sourceBitmap.height)
      val needsResize = currentLongSide > maxInputLongSide

      workingInput = if (needsResize) {
        val factor = maxInputLongSide.toFloat() / currentLongSide
        val safeW = (sourceBitmap.width * factor).roundToInt().coerceAtLeast(1)
        val safeH = (sourceBitmap.height * factor).roundToInt().coerceAtLeast(1)
        Bitmap.createScaledBitmap(sourceBitmap, safeW, safeH, true)
      } else {
        sourceBitmap.copy(Bitmap.Config.ARGB_8888, true)
      }

      onProgress(
        ProcessingProgress(
          stage = "AI ব্যাকগ্রাউন্ড এনহান্সমেন্ট...",
          percent = 0.10f,
          isIndeterminate = false,
          detail = "Real-ESRGAN (${scale}x) প্রসেসিং শুরু হচ্ছে..."
        )
      )

      // Step 2: FIRST run Real-ESRGAN for the whole image (clean background)
      upscaledBitmap = runRealEsrganTiled(
        inputBitmap = workingInput,
        modelFile = imageModelFile,
        scale = scale,
        onProgress = onProgress
      )
      if (workingInput != sourceBitmap) {
        workingInput.recycle()
      }
      workingInput = null
      lastRealEsrganRan = true
      workingBitmap = upscaledBitmap

      coroutineContext.ensureActive()

      // Step 3: THEN detect faces on the upscaled image & restore with face model
      val faceModelFile = modelManager.resolveFaceModelFile()
      val faceModelReady = faceModelFile != null && faceModelFile.exists()

      if (faceModelReady && config.faceEnhancement) {
        onProgress(
          ProcessingProgress(
            stage = "মুখমণ্ডল শনাক্ত করা হচ্ছে...",
            percent = 0.70f,
            isIndeterminate = false,
            detail = "আপস্কেলড ছবিতে ফেস ডিটেকশন চলছে..."
          )
        )

        val detectedFaces = FaceDetectorOfflineHelper.detectFaces(workingBitmap, maxFaces = 5)
        if (detectedFaces.isNotEmpty()) {
          onProgress(
            ProcessingProgress(
              stage = "AI ফেস রিস্টোরেশন চলছে...",
              percent = 0.78f,
              isIndeterminate = false,
              detail = "${detectedFaces.size}টি পোর্ট্রেট এরিয়া রিস্টোর করা হচ্ছে..."
            )
          )

          val restoredBitmap = restoreFacesWithOnnx(
            workingBitmap,
            detectedFaces,
            faceModelFile,
            faceStrength = config.faceStrength // default 0.8
          )
          workingBitmap.recycle()
          workingBitmap = restoredBitmap
          lastFacesRestoredCount = detectedFaces.size
        } else {
          lastFacesRestoredCount = 0
        }
      } else {
        lastFacesRestoredCount = 0
        if (!faceModelReady) {
          lastFaceModelMissingNotice = true
        }
      }

      coroutineContext.ensureActive()

      // Step 3.5: "Remini-look" tone and skin step (offline, no API)
      // Runs after Real-ESRGAN and face restoration, before final resize to original size.
      // Adaptive auto exposure (target mean L* ~57), contrast/highlights stretch (95th -> 80, 5th -> 20, gentle local contrast, S-curve, soft highlights),
      // warmth (b* +3, saturation capped +5%), skin smoothing inside face regions (excluding eyes, brows, lips, hair),
      // and background mild denoise (strength 0.3).
      onProgress(
        ProcessingProgress(
          stage = "টোন ও স্কিন অপ্টিমাইজেশন চলছে...",
          percent = 0.85f,
          isIndeterminate = false,
          detail = "রেমিনি-লুক অটো-এক্সপোজার, ওয়ার্মথ ও ন্যাচারাল স্কিন ব্যালেন্স..."
        )
      )

      val facesForTone = FaceDetectorOfflineHelper.detectFaces(workingBitmap, maxFaces = 5)
      val reminiToned = ReminiToneSkinEngine.applyReminiLook(workingBitmap, facesForTone)
      if (reminiToned != workingBitmap) {
        workingBitmap.recycle()
      }
      workingBitmap = reminiToned

      coroutineContext.ensureActive()

      // Step 4: Output size = Input size (Remini style)
      // Resize the final image to the exact width x height of the original photo,
      // keeping the aspect ratio (no stretch, no crop).
      // Safety: only if the original long side is above 4096 px, cap the output to 4096 on the long side.
      // If the AI result is much larger than the original, downscale in steps of 2 (halving)
      // and finish with one bicubic resize, to keep it sharp.
      val origW = sourceBitmap.width
      val origH = sourceBitmap.height
      val origLongSide = max(origW, origH)
      val (targetW, targetH) = if (origLongSide > 4096) {
        val f = 4096f / origLongSide
        Pair((origW * f).roundToInt().coerceAtLeast(1), (origH * f).roundToInt().coerceAtLeast(1))
      } else {
        Pair(origW, origH)
      }

      onProgress(
        ProcessingProgress(
          stage = "আউটপুট রেজোলিউশন অ্যাডজাস্ট হচ্ছে...",
          percent = 0.90f,
          isIndeterminate = false,
          detail = "রেজোলিউশন সাইজ: ${targetW} × ${targetH} px..."
        )
      )

      val resizedBmp = resizeToTargetDimensions(workingBitmap, targetW, targetH)
      if (resizedBmp != workingBitmap) {
        workingBitmap.recycle()
      }
      workingBitmap = resizedBmp

      coroutineContext.ensureActive()

      // Step 5: Light final polish: mild sharpen (0.2) and slight contrast/clarity
      onProgress(
        ProcessingProgress(
          stage = "ফাইনাল পলিশ প্রয়োগ হচ্ছে...",
          percent = 0.96f,
          isIndeterminate = false,
          detail = "মাইল্ড শার্পেন (0.2) ও ক্ল্যারিটি ব্যালেন্স..."
        )
      )

      val polishedBmp = applyLightPolish(workingBitmap)
      workingBitmap.recycle()
      workingBitmap = null

      Result.success(polishedBmp)
    } catch (e: Exception) {
      workingInput?.recycle()
      upscaledBitmap?.recycle()
      workingBitmap?.recycle()
      Result.failure(e)
    }
  }

  /**
   * Light final polish: mild sharpen (0.20) and gentle contrast/clarity.
   * Preserves natural skin tone, age, and identity without oversaturation or plastic look.
   */
  private fun applyLightPolish(input: Bitmap): Bitmap {
    val width = input.width
    val height = input.height
    val output = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    val pixels = IntArray(width * height)
    input.getPixels(pixels, 0, width, 0, 0, width, height)
    val outPixels = pixels.clone()

    val sharpenFactor = 0.20f // mild sharpen (0.2)

    for (y in 1 until height - 1) {
      val prevRow = (y - 1) * width
      val currRow = y * width
      val nextRow = (y + 1) * width

      for (x in 1 until width - 1) {
        val c = pixels[currRow + x]
        val cR = (c shr 16) and 0xFF
        val cG = (c shr 8) and 0xFF
        val cB = c and 0xFF

        val top = pixels[prevRow + x]
        val bottom = pixels[nextRow + x]
        val left = pixels[currRow + x - 1]
        val right = pixels[currRow + x + 1]

        // Laplacian sharpening
        val lapR = (4 * cR) - (((top shr 16) and 0xFF) + ((bottom shr 16) and 0xFF) + ((left shr 16) and 0xFF) + ((right shr 16) and 0xFF))
        val lapG = (4 * cG) - (((top shr 8) and 0xFF) + ((bottom shr 8) and 0xFF) + ((left shr 8) and 0xFF) + ((right shr 8) and 0xFF))
        val lapB = (4 * cB) - ((top and 0xFF) + (bottom and 0xFF) + (left and 0xFF) + (right and 0xFF))

        val sR = cR + sharpenFactor * lapR
        val sG = cG + sharpenFactor * lapG
        val sB = cB + sharpenFactor * lapB

        // Gentle contrast/clarity without oversaturation:
        // Adjust luminance midtone curve by 4% and apply offset uniformly across R, G, B channels
        val lum = 0.299f * sR + 0.587f * sG + 0.114f * sB
        val contrastLum = (lum - 128f) * 1.04f + 128f
        val diff = (contrastLum - lum).coerceIn(-8f, 8f)

        val finalR = (sR + diff).roundToInt().coerceIn(0, 255)
        val finalG = (sG + diff).roundToInt().coerceIn(0, 255)
        val finalB = (sB + diff).roundToInt().coerceIn(0, 255)

        outPixels[currRow + x] = (0xFF shl 24) or (finalR shl 16) or (finalG shl 8) or finalB
      }
    }
    output.setPixels(outPixels, 0, width, 0, 0, width, height)
    return output
  }

  private suspend fun restoreFacesWithOnnx(
    source: Bitmap,
    faces: List<FaceDetectorOfflineHelper.DetectedFaceBox>,
    faceModelFile: File,
    faceStrength: Float
  ): Bitmap = withContext(Dispatchers.Default) {
    val session = getFaceSession(faceModelFile)
    val env = getOrCreateEnv()
    val inputName = session.inputNames.iterator().next()

    val resultBitmap = source.copy(Bitmap.Config.ARGB_8888, true)
    val canvas = Canvas(resultBitmap)

    for (faceBox in faces) {
      coroutineContext.ensureActive()
      val rect = faceBox.rect
      val width = rect.width()
      val height = rect.height()
      if (width <= 10 || height <= 10) continue

      // 30% padding, centered square
      val pad = (max(width, height) * 0.30f).toInt()
      val side = max(width, height) + pad * 2
      val cx = rect.centerX()
      val cy = rect.centerY()

      val cropLeft = (cx - side / 2).coerceIn(0, source.width - 1)
      val cropTop = (cy - side / 2).coerceIn(0, source.height - 1)
      val cropRight = (cropLeft + side).coerceIn(cropLeft + 1, source.width)
      val cropBottom = (cropTop + side).coerceIn(cropTop + 1, source.height)
      val cropW = cropRight - cropLeft
      val cropH = cropBottom - cropTop
      if (cropW <= 0 || cropH <= 0) continue

      val faceCrop = Bitmap.createBitmap(source, cropLeft, cropTop, cropW, cropH)
      val resized512 = Bitmap.createScaledBitmap(faceCrop, 512, 512, true)
      faceCrop.recycle()

      // Convert 512x512 to FloatBuffer NCHW [1, 3, 512, 512] normalized [-1, 1]
      val floatBuffer = FloatBuffer.allocate(1 * 3 * 512 * 512)
      val pixels = IntArray(512 * 512)
      resized512.getPixels(pixels, 0, 512, 0, 0, 512, 512)

      // R channel
      for (i in pixels.indices) {
        val r = (pixels[i] shr 16) and 0xFF
        floatBuffer.put((r / 255.0f - 0.5f) / 0.5f)
      }
      // G channel
      for (i in pixels.indices) {
        val g = (pixels[i] shr 8) and 0xFF
        floatBuffer.put((g / 255.0f - 0.5f) / 0.5f)
      }
      // B channel
      for (i in pixels.indices) {
        val b = pixels[i] and 0xFF
        floatBuffer.put((b / 255.0f - 0.5f) / 0.5f)
      }
      floatBuffer.rewind()
      resized512.recycle()

      val tensor = OnnxTensor.createTensor(env, floatBuffer, longArrayOf(1, 3, 512, 512))
      val sessionResult = session.run(mapOf(inputName to tensor))
      tensor.close()

      val outputTensor = sessionResult.get(0) as OnnxTensor
      val outBuffer = outputTensor.floatBuffer
      val outPixels = IntArray(512 * 512)

      val channelStride = 512 * 512
      for (p in 0 until channelStride) {
        val rVal = outBuffer.get(p)
        val gVal = outBuffer.get(p + channelStride)
        val bVal = outBuffer.get(p + channelStride * 2)

        val r = (((rVal * 0.5f) + 0.5f) * 255f).toInt().coerceIn(0, 255)
        val g = (((gVal * 0.5f) + 0.5f) * 255f).toInt().coerceIn(0, 255)
        val b = (((bVal * 0.5f) + 0.5f) * 255f).toInt().coerceIn(0, 255)
        outPixels[p] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
      }
      sessionResult.close()

      val restored512 = Bitmap.createBitmap(outPixels, 512, 512, Bitmap.Config.ARGB_8888)
      val scaledBack = Bitmap.createScaledBitmap(restored512, cropW, cropH, true)
      restored512.recycle()

      // Feathered blend onto resultBitmap using faceStrength (default 0.8)
      blendFaceOntoCanvas(
        canvas = canvas,
        restoredFace = scaledBack,
        x = cropLeft.toFloat(),
        y = cropTop.toFloat(),
        strength = faceStrength.coerceIn(0.1f, 1.0f)
      )
      scaledBack.recycle()
    }

    resultBitmap
  }

  private fun blendFaceOntoCanvas(
    canvas: Canvas,
    restoredFace: Bitmap,
    x: Float,
    y: Float,
    strength: Float
  ) {
    val w = restoredFace.width
    val h = restoredFace.height
    val maskBitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val maskCanvas = Canvas(maskBitmap)

    // Soft feathered circular/oval mask
    val radius = min(w, h) * 0.48f
    val shader = RadialGradient(
      w / 2f, h / 2f, radius,
      intArrayOf(Color.BLACK, Color.BLACK, Color.TRANSPARENT),
      floatArrayOf(0f, 0.75f, 1.0f),
      Shader.TileMode.CLAMP
    )
    val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
      this.shader = shader
    }
    maskCanvas.drawCircle(w / 2f, h / 2f, radius, paint)

    // Apply strength to mask alpha
    val blendPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
      alpha = (strength * 255).toInt().coerceIn(0, 255)
      xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN)
    }

    val maskedFace = restoredFace.copy(Bitmap.Config.ARGB_8888, true)
    val faceCanvas = Canvas(maskedFace)
    faceCanvas.drawBitmap(maskBitmap, 0f, 0f, blendPaint)
    maskBitmap.recycle()

    canvas.drawBitmap(maskedFace, x, y, null)
    maskedFace.recycle()
  }

  /**
   * Auto-detect the scale factor from the session output tensor shape.
   * Checks static shape first, then runs a probe tile tensor if dynamic.
   * Caches result per loaded model. Supports x2 and x4.
   */
  private fun getOrDetectImageScale(
    session: OrtSession,
    env: OrtEnvironment,
    modelFile: File,
    tileSize: Int = 128
  ): Int {
    modelScaleCache[modelFile.absolutePath]?.let { return it }

    // 1. Try static shape inspection if available
    try {
      val outNode = session.outputInfo.values.firstOrNull()?.info as? TensorInfo
      val inNode = session.inputInfo.values.firstOrNull()?.info as? TensorInfo
      val outShape = outNode?.shape
      val inShape = inNode?.shape
      if (outShape != null && inShape != null && outShape.size >= 4 && inShape.size >= 4) {
        val outH = outShape[2]
        val inH = inShape[2]
        if (outH > 0 && inH > 0) {
          val s = (outH / inH).toInt()
          if (s in listOf(2, 4)) {
            modelScaleCache[modelFile.absolutePath] = s
            return s
          }
        }
      }
    } catch (_: Exception) {}

    // 2. Probe with a dummy tile tensor
    try {
      val inputName = session.inputNames.iterator().next()
      val dummyBuffer = FloatBuffer.allocate(1 * 3 * tileSize * tileSize)
      val tensor = OnnxTensor.createTensor(
        env,
        dummyBuffer,
        longArrayOf(1, 3, tileSize.toLong(), tileSize.toLong())
      )
      val result = session.run(mapOf(inputName to tensor))
      tensor.close()
      val outTensor = result.get(0) as OnnxTensor
      val outShape = outTensor.info.shape
      val realOutH = if (outShape.size >= 4) outShape[2].toInt() else tileSize * 2
      result.close()
      val detectedScale = (realOutH / tileSize).let { if (it >= 3) 4 else 2 }
      modelScaleCache[modelFile.absolutePath] = detectedScale
      return detectedScale
    } catch (_: Exception) {
      val fallback = 2
      modelScaleCache[modelFile.absolutePath] = fallback
      return fallback
    }
  }

  private suspend fun runRealEsrganTiled(
    inputBitmap: Bitmap,
    modelFile: File,
    scale: Int,
    onProgress: (ProcessingProgress) -> Unit
  ): Bitmap = withContext(Dispatchers.Default) {
    val session = getImageSession(modelFile)
    val env = getOrCreateEnv()
    val inputName = session.inputNames.iterator().next()

    val tileSize = 128
    val overlap = 10
    val step = (tileSize - overlap).coerceAtLeast(1)

    // Run AI upscale on the input at its resolution
    val inW = inputBitmap.width
    val inH = inputBitmap.height
    val outW = inW * scale
    val outH = inH * scale

    val outputBitmap = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
    val outputCanvas = Canvas(outputBitmap)

    // Coordinate steps covering the full dimensions with native tile size (no stretching)
    val xCoords = mutableListOf<Int>()
    var currX = 0
    if (inW <= tileSize) {
      xCoords.add(0)
    } else {
      while (currX + tileSize < inW) {
        xCoords.add(currX)
        currX += step
      }
      val lastX = inW - tileSize
      if (xCoords.isEmpty() || xCoords.last() != lastX) {
        xCoords.add(lastX)
      }
    }

    val yCoords = mutableListOf<Int>()
    var currY = 0
    if (inH <= tileSize) {
      yCoords.add(0)
    } else {
      while (currY + tileSize < inH) {
        yCoords.add(currY)
        currY += step
      }
      val lastY = inH - tileSize
      if (yCoords.isEmpty() || yCoords.last() != lastY) {
        yCoords.add(lastY)
      }
    }

    val totalTiles = xCoords.size * yCoords.size
    var processedTiles = 0

    val tilePixels = IntArray(tileSize * tileSize)

    for ((yi, y) in yCoords.withIndex()) {
      for ((xi, x) in xCoords.withIndex()) {
        coroutineContext.ensureActive()

        val actualW = min(tileSize, inW - x)
        val actualH = min(tileSize, inH - y)

        val tileBmp = Bitmap.createBitmap(inputBitmap, x, y, actualW, actualH)
        val uniformTile = if (actualW != tileSize || actualH != tileSize) {
          // If image dimension is smaller than tileSize, pad onto tileSize x tileSize
          val padded = Bitmap.createBitmap(tileSize, tileSize, Bitmap.Config.ARGB_8888)
          val pCanvas = Canvas(padded)
          pCanvas.drawBitmap(tileBmp, 0f, 0f, null)
          tileBmp.recycle()
          padded
        } else {
          tileBmp
        }

        uniformTile.getPixels(tilePixels, 0, tileSize, 0, 0, tileSize, tileSize)
        uniformTile.recycle()

        // NCHW float32 RGB in [0.0f, 1.0f]
        val floatBuffer = FloatBuffer.allocate(1 * 3 * tileSize * tileSize)
        val channelSize = tileSize * tileSize

        // R
        for (i in 0 until channelSize) {
          floatBuffer.put(((tilePixels[i] shr 16) and 0xFF) / 255.0f)
        }
        // G
        for (i in 0 until channelSize) {
          floatBuffer.put(((tilePixels[i] shr 8) and 0xFF) / 255.0f)
        }
        // B
        for (i in 0 until channelSize) {
          floatBuffer.put((tilePixels[i] and 0xFF) / 255.0f)
        }
        floatBuffer.rewind()

        val tensor = OnnxTensor.createTensor(
          env,
          floatBuffer,
          longArrayOf(1, 3, tileSize.toLong(), tileSize.toLong())
        )
        val runResult = session.run(mapOf(inputName to tensor))
        tensor.close()

        val outTensor = runResult.get(0) as OnnxTensor
        val outBuf = outTensor.floatBuffer
        val outShape = outTensor.info.shape // [1, 3, realOutH, realOutW]

        // Read output with its real dimensions from output tensor shape
        val realOutH = if (outShape.size >= 4) outShape[2].toInt() else tileSize * scale
        val realOutW = if (outShape.size >= 4) outShape[3].toInt() else tileSize * scale

        // Update cached scale
        val tensorScale = (realOutH / tileSize).let { if (it >= 3) 4 else 2 }
        modelScaleCache[modelFile.absolutePath] = tensorScale

        val outChannelSize = realOutW * realOutH
        val outTilePixels = IntArray(outChannelSize)

        // Linear feathering to avoid seams:
        val hasLeftOverlap = xi > 0
        val overlapW = if (hasLeftOverlap) {
          ((xCoords[xi - 1] + tileSize - x) * scale).coerceIn(1, realOutW)
        } else 0

        val hasTopOverlap = yi > 0
        val overlapH = if (hasTopOverlap) {
          ((yCoords[yi - 1] + tileSize - y) * scale).coerceIn(1, realOutH)
        } else 0

        for (py in 0 until realOutH) {
          val weightY = if (hasTopOverlap && py < overlapH) {
            py.toFloat() / overlapH.toFloat()
          } else {
            1.0f
          }

          val rowOffset = py * realOutW

          for (px in 0 until realOutW) {
            val weightX = if (hasLeftOverlap && px < overlapW) {
              px.toFloat() / overlapW.toFloat()
            } else {
              1.0f
            }

            val p = rowOffset + px
            val r = (outBuf.get(p) * 255.0f).toInt().coerceIn(0, 255)
            val g = (outBuf.get(p + outChannelSize) * 255.0f).toInt().coerceIn(0, 255)
            val b = (outBuf.get(p + outChannelSize * 2) * 255.0f).toInt().coerceIn(0, 255)

            // Linear feather alpha blending
            val alphaF = weightX * weightY
            val alpha = (alphaF * 255.0f).roundToInt().coerceIn(0, 255)

            outTilePixels[p] = (alpha shl 24) or (r shl 16) or (g shl 8) or b
          }
        }
        runResult.close()

        val outTileBmp = Bitmap.createBitmap(outTilePixels, realOutW, realOutH, Bitmap.Config.ARGB_8888)

        // If actual input was smaller than tileSize, draw only the valid region
        val drawW = actualW * scale
        val drawH = actualH * scale
        val finalCropTile = if (drawW != realOutW || drawH != realOutH) {
          Bitmap.createBitmap(outTileBmp, 0, 0, drawW, drawH).also { outTileBmp.recycle() }
        } else {
          outTileBmp
        }

        outputCanvas.drawBitmap(finalCropTile, (x * scale).toFloat(), (y * scale).toFloat(), null)
        finalCropTile.recycle()

        processedTiles++
        val progressPercent = 0.10f + 0.58f * (processedTiles.toFloat() / totalTiles.toFloat())
        onProgress(
          ProcessingProgress(
            stage = "AI ব্যাকগ্রাউন্ড প্রসেসিং...",
            percent = progressPercent,
            isIndeterminate = false,
            detail = "টাইল $processedTiles / $totalTiles সম্পন্ন (${(progressPercent * 100).roundToInt()}%)"
          )
        )
      }
    }

    outputBitmap
  }

  /**
   * Resizes image to target dimensions (exact width x height of original photo, capped at 4096).
   * If the AI result is much larger than the target, downscales in steps of 2 (halving)
   * and finishes with one high-quality bicubic resize to keep it sharp.
   */
  fun resizeToTargetDimensions(
    bitmap: Bitmap,
    targetWidth: Int,
    targetHeight: Int
  ): Bitmap {
    if (bitmap.width == targetWidth && bitmap.height == targetHeight) {
      return bitmap
    }

    var current = bitmap
    while (current.width > targetWidth * 2 && current.height > targetHeight * 2) {
      val nextW = current.width / 2
      val nextH = current.height / 2
      val halfBmp = Bitmap.createScaledBitmap(current, nextW, nextH, true)
      if (current != bitmap) {
        current.recycle()
      }
      current = halfBmp
    }

    val finalBmp = Bitmap.createScaledBitmap(current, targetWidth, targetHeight, true)
    if (current != bitmap && current != finalBmp) {
      current.recycle()
    }
    return finalBmp
  }

  override fun release() {
    try {
      imageSession?.close()
      imageSession = null
      loadedImagePath = null
      modelScaleCache.clear()
    } catch (_: Exception) {}

    try {
      faceSession?.close()
      faceSession = null
      loadedFacePath = null
    } catch (_: Exception) {}

    try {
      ortEnvironment?.close()
      ortEnvironment = null
    } catch (_: Exception) {}
  }
}
