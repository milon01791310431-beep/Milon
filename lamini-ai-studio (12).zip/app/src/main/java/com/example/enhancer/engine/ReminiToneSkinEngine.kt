package com.example.enhancer.engine

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Offline "Remini-look" tone and skin enhancement engine.
 *
 * Runs after Real-ESRGAN and face restoration, before the final resize to original size.
 *
 * Pipeline features:
 * 1. AUTO EXPOSURE: compute mean L* (LAB, 0-100). Target mean ~57. Lift with a gamma curve
 *    toward target, capped at +12 L*. If already >= 57, no lift is applied.
 * 2. CONTRAST/HIGHLIGHTS: stretch levels so 95th percentile L* reaches ~80 (gain cap 1.25)
 *    while 5th percentile stays near 20. Adds gentle local contrast (radius 20-30 px, amount 0.15)
 *    and an S-curve. Soft highlights compression ensures highlights on skin never hard clip.
 * 3. WARMTH: shift LAB b* by +3 (slightly warmer), a* unchanged. Chroma is clamped within +5%
 *    of original saturation to prevent oversaturation.
 * 4. SKIN SMOOTHING: edge-preserving bilateral filter (radius 5, strength 0.5) applied strictly
 *    inside face regions. Excludes eyes, eyebrows, lips and hair via ML Kit face contours
 *    or landmark geometry, keeping eyes razor sharp and skin natural without plastic look.
 * 5. BACKGROUND: mild edge-preserving denoise (strength 0.3), retaining fabric and texture detail.
 * 6. Naturalness: identity, face shape, eye size and skin tone remain completely natural (no reshaping).
 * 7. Scaled by internal constant [REMINI_LOOK_INTENSITY] = 0.8.
 * 8. Memory-safe: processed in row bands.
 */
object ReminiToneSkinEngine {

  /**
   * Internal intensity scalar (range 0..1) that scales all Remini-look adjustments.
   */
  const val REMINI_LOOK_INTENSITY: Float = 0.8f

  // Precomputed sRGB to linear conversion table
  val SRGB_TO_LIN = FloatArray(256) { i ->
    val c = i / 255f
    if (c <= 0.04045f) c / 12.92f else ((c + 0.055f) / 1.055f).pow(2.4f)
  }

  // D65 standard constants for CIELAB
  private const val EPS = 216f / 24389f // ~0.008856
  private const val KAPPA = 24389f / 27f // ~903.3
  private const val XN = 0.95047f
  private const val YN = 1.00000f
  private const val ZN = 1.08883f

  fun linearToSrgb(c: Float): Float {
    val clamped = c.coerceIn(0f, 1f)
    return if (clamped <= 0.0031308f) 12.92f * clamped else 1.055f * clamped.pow(1f / 2.4f) - 0.055f
  }

  fun rgbToLstar(r: Int, g: Int, b: Int): Float {
    val yNorm = 0.2126729f * SRGB_TO_LIN[r] + 0.7151522f * SRGB_TO_LIN[g] + 0.0721750f * SRGB_TO_LIN[b]
    return if (yNorm > EPS) 116f * yNorm.pow(1f / 3f) - 16f else KAPPA * yNorm
  }

  fun rgbToLab(r: Int, g: Int, b: Int): FloatArray {
    val rLin = SRGB_TO_LIN[r]
    val gLin = SRGB_TO_LIN[g]
    val bLin = SRGB_TO_LIN[b]

    val X = (0.4124564f * rLin + 0.3575761f * gLin + 0.1804375f * bLin) / XN
    val Y = (0.2126729f * rLin + 0.7151522f * gLin + 0.0721750f * bLin) / YN
    val Z = (0.0193339f * rLin + 0.1191920f * gLin + 0.9503041f * bLin) / ZN

    val fx = if (X > EPS) X.pow(1f / 3f) else (KAPPA * X + 16f) / 116f
    val fy = if (Y > EPS) Y.pow(1f / 3f) else (KAPPA * Y + 16f) / 116f
    val fz = if (Z > EPS) Z.pow(1f / 3f) else (KAPPA * Z + 16f) / 116f

    val L = (116f * fy - 16f).coerceIn(0f, 100f)
    val a = 500f * (fx - fy)
    val bStar = 200f * (fy - fz)
    return floatArrayOf(L, a, bStar)
  }

  fun labToRgb(L: Float, a: Float, b: Float): Int {
    val fy = (L.coerceIn(0f, 100f) + 16f) / 116f
    val fx = fy + a / 500f
    val fz = fy - b / 200f

    val fx3 = fx * fx * fx
    val fz3 = fz * fz * fz

    val xr = if (fx3 > EPS) fx3 else (116f * fx - 16f) / KAPPA
    val yr = if (L > KAPPA * EPS) ((L + 16f) / 116f).pow(3f) else L / KAPPA
    val zr = if (fz3 > EPS) fz3 else (116f * fz - 16f) / KAPPA

    val X = xr * XN
    val Y = yr * YN
    val Z = zr * ZN

    val rLin = 3.2404542f * X - 1.5371385f * Y - 0.4985314f * Z
    val gLin = -0.9692660f * X + 1.8760108f * Y + 0.0415560f * Z
    val bLin = 0.0556434f * X - 0.2040259f * Y + 1.0572252f * Z

    val r = (linearToSrgb(rLin) * 255f).roundToInt().coerceIn(0, 255)
    val g = (linearToSrgb(gLin) * 255f).roundToInt().coerceIn(0, 255)
    val bInt = (linearToSrgb(bLin) * 255f).roundToInt().coerceIn(0, 255)

    return (0xFF shl 24) or (r shl 16) or (g shl 8) or bInt
  }

  /**
   * Computes calibrated tone-mapped L* combining exposure, contrast stretch, strong toe S-curve,
   * and soft shoulder rolloff.
   *
   * 2. PROTECT BLACKS: keep the 5th percentile where it is. Anchor the curve so L* below about 25 is unchanged
   * (no black lift, no haze). Use a stronger toe in the S-curve instead of lifting shadows.
   * Limit the 95th percentile to about 80 (soft shoulder from 80 instead of 85).
   */
  fun computeToneMappedLstar(
    lStar: Float,
    gamma: Float,
    p5: Float,
    p95: Float,
    intensity: Float = REMINI_LOOK_INTENSITY
  ): Float {
    if (lStar <= 25.0f || intensity <= 0f) {
      return lStar
    }

    // Normalized tone in range [25, 100]
    val v = (lStar - 25.0f) / 75.0f
    val vLift = v.pow(gamma)
    val lAe = 25.0f + 75.0f * vLift

    // Contrast stretch: keep 5th percentile where it is, stretch 95th toward 80 (gain cap 1.25)
    val targetSpan = 80.0f - 25.0f
    val currentSpan = max(p95 - 25.0f, 15.0f)
    val rawGain = (targetSpan / currentSpan).coerceIn(1.0f, 1.25f)
    val gain = 1.0f + (rawGain - 1.0f) * intensity
    val lStretch = 25.0f + (lAe - 25.0f) * gain

    // S-curve with stronger toe instead of lifting shadows
    val u = ((lStretch - 25.0f) / 75.0f).coerceIn(0f, 1f)
    val sCurveAmount = 0.040f * intensity
    val sCurveU = u - sCurveAmount * sin((2 * Math.PI * u).toFloat())
    val lAfterS = 25.0f + 75.0f * sCurveU

    // Soft shoulder from 80 instead of 85 (limit 95th percentile to about 80)
    return if (lAfterS > 80.0f) {
      80.0f + 20.0f * (1.0f - exp(-((lAfterS - 80.0f) / 20.0f).toDouble()).toFloat())
    } else {
      lAfterS.coerceIn(0f, 100f)
    }
  }

  fun computeAutoExposureLstar(
    lStar: Float,
    meanL: Float,
    intensity: Float = REMINI_LOOK_INTENSITY
  ): Float {
    if (meanL >= 57f || intensity <= 0f || lStar <= 25f) return lStar
    val maxLift = 10f * intensity
    val desiredLift = (57f - meanL) * intensity
    val actualLift = min(desiredLift, maxLift)
    if (actualLift <= 0.001f) return lStar

    val m = ((meanL - 25f) / 75f).coerceIn(0.01f, 0.99f)
    val t = (((meanL + actualLift) - 25f) / 75f).coerceIn(m, 0.999f)
    val gamma = ln(t) / ln(m)
    val v = ((lStar - 25f) / 75f).coerceIn(0f, 1f)
    return (25f + 75f * v.pow(gamma)).coerceIn(0f, 100f)
  }

  fun computeContrastLstar(
    lStar: Float,
    p5: Float,
    p95: Float,
    intensity: Float = REMINI_LOOK_INTENSITY
  ): Float {
    return computeToneMappedLstar(lStar, gamma = 1.0f, p5 = p5, p95 = p95, intensity = intensity)
  }

  fun evaluateMeanForGamma(
    gamma: Float,
    hist: IntArray,
    totalPixels: Int,
    p5: Float,
    p95: Float,
    intensity: Float
  ): Float {
    if (totalPixels <= 0) return 50f
    var sum = 0.0
    for (bin in 0..1000) {
      val count = hist[bin]
      if (count == 0) continue
      val inL = bin / 10.0f
      val outL = computeToneMappedLstar(inL, gamma, p5, p95, intensity)
      sum += outL.toDouble() * count
    }
    return (sum / totalPixels).toFloat()
  }

  /**
   * Calibrates auto-exposure gamma using binary search over the histogram so that the mean L*
   * AFTER the full tone LUT (exposure + contrast + S-curve) is about 57. Max total lift +10 L*.
   * If the input mean is already 57 or higher, do nothing.
   */
  fun calibrateToneLut(
    hist: IntArray,
    totalPixels: Int,
    meanL: Float,
    p5: Float,
    p95: Float,
    intensity: Float = REMINI_LOOK_INTENSITY
  ): FloatArray {
    if (meanL >= 57.0f || intensity <= 0.001f) {
      return FloatArray(1001) { bin -> bin / 10.0f }
    }

    val maxLift = 10.0f
    val targetMean = min(57.0f, meanL + maxLift)

    var lowGamma = 0.10f
    var highGamma = 1.0f
    var bestGamma = 1.0f

    val meanAt1 = evaluateMeanForGamma(1.0f, hist, totalPixels, p5, p95, intensity)
    if (meanAt1 >= targetMean) {
      bestGamma = 1.0f
    } else {
      var minDiff = Float.MAX_VALUE
      for (iter in 0 until 20) {
        val midGamma = (lowGamma + highGamma) / 2f
        val simMean = evaluateMeanForGamma(midGamma, hist, totalPixels, p5, p95, intensity)
        val diff = abs(simMean - targetMean)
        if (diff < minDiff) {
          minDiff = diff
          bestGamma = midGamma
        }
        if (simMean > targetMean) {
          lowGamma = midGamma
        } else {
          highGamma = midGamma
        }
      }
    }

    return FloatArray(1001) { bin ->
      computeToneMappedLstar(bin / 10.0f, bestGamma, p5, p95, intensity)
    }
  }

  fun labToLinearRgb(L: Float, a: Float, b: Float): FloatArray {
    val fy = (L.coerceIn(0f, 100f) + 16f) / 116f
    val fx = fy + a / 500f
    val fz = fy - b / 200f

    val fx3 = fx * fx * fx
    val fz3 = fz * fz * fz

    val xr = if (fx3 > EPS) fx3 else (116f * fx - 16f) / KAPPA
    val yr = if (L > KAPPA * EPS) ((L + 16f) / 116f).pow(3f) else L / KAPPA
    val zr = if (fz3 > EPS) fz3 else (116f * fz - 16f) / KAPPA

    val X = xr * XN
    val Y = yr * YN
    val Z = zr * ZN

    val rLin = 3.2404542f * X - 1.5371385f * Y - 0.4985314f * Z
    val gLin = -0.9692660f * X + 1.8760108f * Y + 0.0415560f * Z
    val bLin = 0.0556434f * X - 0.2040259f * Y + 1.0572252f * Z
    return floatArrayOf(rLin, gLin, bLin)
  }

  fun clampChromaToSrgbGamut(L: Float, a: Float, b: Float): FloatArray {
    val lin = labToLinearRgb(L, a, b)
    if (lin[0] in 0f..1f && lin[1] in 0f..1f && lin[2] in 0f..1f) {
      return floatArrayOf(a, b)
    }

    var low = 0f
    var high = 1f
    for (i in 0 until 6) {
      val mid = (low + high) / 2f
      val testLin = labToLinearRgb(L, a * mid, b * mid)
      if (testLin[0] in 0f..1f && testLin[1] in 0f..1f && testLin[2] in 0f..1f) {
        low = mid
      } else {
        high = mid
      }
    }
    return floatArrayOf(a * low, b * low)
  }

  /**
   * Applies the complete Remini-look tone, warmth, and skin enhancement pipeline to [inputBitmap].
   *
   * @param inputBitmap The upscaled & face-restored intermediate bitmap.
   * @param faces List of detected face bounding boxes with contour exclusion regions.
   * @param intensity Global intensity scalar (defaults to [REMINI_LOOK_INTENSITY]).
   * @return Enhanced bitmap with Remini-look tone, warmth, skin smoothing, and texture.
   */
  fun applyReminiLook(
    inputBitmap: Bitmap,
    faces: List<FaceDetectorOfflineHelper.DetectedFaceBox> = emptyList(),
    intensity: Float = REMINI_LOOK_INTENSITY
  ): Bitmap {
    if (intensity <= 0.001f) {
      return inputBitmap.copy(Bitmap.Config.ARGB_8888, true)
    }

    val width = inputBitmap.width
    val height = inputBitmap.height

    // 1. Compute Image Luminance Statistics (Mean L*, 5th & 95th Percentile) in row bands
    val bandHeight = 256
    val bandPixels = IntArray(width * bandHeight)
    var sumL = 0.0
    val hist = IntArray(1001) // 0..1000 for L* 0.0..100.0 (0.1 precision)
    var totalPixels = 0

    for (y in 0 until height step bandHeight) {
      val rows = min(bandHeight, height - y)
      inputBitmap.getPixels(bandPixels, 0, width, 0, y, width, rows)
      val count = width * rows
      totalPixels += count
      for (i in 0 until count) {
        val pixel = bandPixels[i]
        val r = (pixel shr 16) and 0xFF
        val g = (pixel shr 8) and 0xFF
        val b = pixel and 0xFF
        val lStar = rgbToLstar(r, g, b)
        sumL += lStar
        val bin = (lStar * 10f).toInt().coerceIn(0, 1000)
        hist[bin]++
      }
    }

    val meanL = if (totalPixels > 0) (sumL / totalPixels).toFloat() else 50f
    val p5Count = (0.05 * totalPixels).toInt()
    val p95Count = (0.95 * totalPixels).toInt()
    var accum = 0
    var p5 = 20f
    var p95 = 80f
    var foundP5 = false
    for (bin in 0..1000) {
      accum += hist[bin]
      val lVal = bin / 10f
      if (!foundP5 && accum >= p5Count) {
        p5 = lVal
        foundP5 = true
      }
      if (accum >= p95Count) {
        p95 = lVal
        break
      }
    }

    // 2. Calibrate Tone Mapping LUT via binary search so final mean L* is about 57 (max lift +10 L*)
    val toneLut = calibrateToneLut(hist, totalPixels, meanL, p5, p95, intensity)

    // 3. Compute Low-Frequency Luminance Grid for gentle local contrast (radius ~24px)
    val dsScale = 4
    val dw = max(1, width / dsScale)
    val dh = max(1, height / dsScale)
    val dsLum = FloatArray(dw * dh)
    val dsCounts = IntArray(dw * dh)

    for (y in 0 until height step bandHeight) {
      val rows = min(bandHeight, height - y)
      inputBitmap.getPixels(bandPixels, 0, width, 0, y, width, rows)
      for (r in 0 until rows) {
        val imgY = y + r
        val dsY = (imgY / dsScale).coerceIn(0, dh - 1)
        val rowOffset = r * width
        for (imgX in 0 until width) {
          val dsX = (imgX / dsScale).coerceIn(0, dw - 1)
          val pixel = bandPixels[rowOffset + imgX]
          val pr = (pixel shr 16) and 0xFF
          val pg = (pixel shr 8) and 0xFF
          val pb = pixel and 0xFF
          val l = rgbToLstar(pr, pg, pb)
          val idx = dsY * dw + dsX
          dsLum[idx] += l
          dsCounts[idx]++
        }
      }
    }
    for (i in 0 until dw * dh) {
      if (dsCounts[i] > 0) dsLum[i] /= dsCounts[i]
    }
    val blurredLum = boxBlurFloat(dsLum, dw, dh, radius = 6)

    // 4. Create Output Bitmap and Apply Global Tone, Warmth (+4 b*), Saturation boost (+15%), Local Contrast, and Background Denoise
    val outputBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    val outBandPixels = IntArray(width * bandHeight)
    val warmthShift = 4.0f * intensity
    val localContrastAmount = 0.15f * intensity
    val bgDenoiseStrength = 0.30f * intensity

    for (y in 0 until height step bandHeight) {
      val rows = min(bandHeight, height - y)
      inputBitmap.getPixels(bandPixels, 0, width, 0, y, width, rows)

      for (r in 0 until rows) {
        val imgY = y + r
        val dsY = (imgY.toFloat() / dsScale).coerceIn(0f, (dh - 1).toFloat())
        val rowOffset = r * width

        for (x in 0 until width) {
          val pixel = bandPixels[rowOffset + x]
          val pr = (pixel shr 16) and 0xFF
          val pg = (pixel shr 8) and 0xFF
          val pb = pixel and 0xFF

          // Background mild denoise
          var smoothedR = pr.toFloat()
          var smoothedG = pg.toFloat()
          var smoothedB = pb.toFloat()
          if (bgDenoiseStrength > 0.01f) {
            var neighborCount = 1
            val left = if (x > 0) bandPixels[rowOffset + x - 1] else pixel
            val right = if (x < width - 1) bandPixels[rowOffset + x + 1] else pixel
            val top = if (r > 0) bandPixels[(r - 1) * width + x] else pixel
            val bottom = if (r < rows - 1) bandPixels[(r + 1) * width + x] else pixel

            for (np in intArrayOf(left, right, top, bottom)) {
              val nr = (np shr 16) and 0xFF
              val ng = (np shr 8) and 0xFF
              val nb = np and 0xFF
              val diff = abs(pr - nr) + abs(pg - ng) + abs(pb - nb)
              if (diff < 22) {
                smoothedR += nr
                smoothedG += ng
                smoothedB += nb
                neighborCount++
              }
            }
            smoothedR /= neighborCount
            smoothedG /= neighborCount
            smoothedB /= neighborCount
          }

          val effR = ((1f - bgDenoiseStrength) * pr + bgDenoiseStrength * smoothedR).roundToInt().coerceIn(0, 255)
          val effG = ((1f - bgDenoiseStrength) * pg + bgDenoiseStrength * smoothedG).roundToInt().coerceIn(0, 255)
          val effB = ((1f - bgDenoiseStrength) * pb + bgDenoiseStrength * smoothedB).roundToInt().coerceIn(0, 255)

          // Convert to LAB
          val lab = rgbToLab(effR, effG, effB)
          val origL = lab[0]
          val aStar = lab[1]
          val bStar = lab[2]

          // Apply Global Tone curve from calibrated LUT
          val lutIdx = (origL * 10f).toInt().coerceIn(0, 1000)
          val toneL = toneLut[lutIdx]

          // Local contrast adjustment
          val dsX = (x.toFloat() / dsScale).coerceIn(0f, (dw - 1).toFloat())
          val lBlur = sampleBilinear(blurredLum, dw, dh, dsX, dsY)
          val localL = if (origL <= 25f) toneL else (toneL + (origL - lBlur) * localContrastAmount).coerceIn(0f, 100f)

          // 3. Warmth: shift b* by +4
          val shiftedB = bStar + warmthShift

          // 3. Saturation: boost up to +15% chroma (scaled by intensity),
          // strongest on reds and skin tones and weaker on neutrals, clamped to sRGB gamut
          val origChroma = sqrt(aStar * aStar + shiftedB * shiftedB)
          val h = Math.atan2(shiftedB.toDouble(), aStar.toDouble()).toFloat()
          val hDeg = Math.toDegrees(h.toDouble()).toFloat().let { if (it < 0f) it + 360f else it }

          val diffDeg = abs(hDeg - 45f)
          val skinAffinity = if (diffDeg < 55f) (1.0f - diffDeg / 55f) else 0f
          val chromaWeight = (origChroma / 20.0f).coerceIn(0f, 1f)
          val maxChromaBoost = 0.15f * intensity
          val boost = maxChromaBoost * chromaWeight * (0.35f + 0.65f * skinAffinity)

          var targetA = aStar * (1.0f + boost)
          var targetB = shiftedB * (1.0f + boost)

          val clampedChroma = clampChromaToSrgbGamut(localL, targetA, targetB)
          targetA = clampedChroma[0]
          targetB = clampedChroma[1]

          outBandPixels[rowOffset + x] = labToRgb(localL, targetA, targetB)
        }
      }
      outputBitmap.setPixels(outBandPixels, 0, width, 0, y, width, rows)
    }

    // 5. Apply Skin Smoothing and Face Relight Inside Face Regions
    applySkinSmoothing(outputBitmap, faces, intensity)

    return outputBitmap
  }

  /**
   * Applies edge-preserving bilateral skin smoothing strictly inside face regions.
   * Excludes eyes, eyebrows, lips, and hairline using contours or facial landmark geometry.
   */
  private fun applySkinSmoothing(
    bitmap: Bitmap,
    faces: List<FaceDetectorOfflineHelper.DetectedFaceBox>,
    intensity: Float
  ) {
    if (faces.isEmpty() || intensity <= 0.001f) return
    val bmpW = bitmap.width
    val bmpH = bitmap.height
    val smoothingStrength = 0.50f * intensity // default 0.50 scaled by intensity

    for (face in faces) {
      val rawRect = face.rect
      // Expand bounding box slightly for natural edge blending
      val padX = (rawRect.width() * 0.10f).toInt()
      val padY = (rawRect.height() * 0.10f).toInt()
      val left = (rawRect.left - padX).coerceIn(0, bmpW - 1)
      val top = (rawRect.top - padY).coerceIn(0, bmpH - 1)
      val right = (rawRect.right + padX).coerceIn(left + 1, bmpW)
      val bottom = (rawRect.bottom + padY).coerceIn(top + 1, bmpH)
      val cropW = right - left
      val cropH = bottom - top

      if (cropW < 20 || cropH < 20) continue

      val cropPixels = IntArray(cropW * cropH)
      bitmap.getPixels(cropPixels, 0, cropW, left, top, cropW, cropH)

      // Generate skin mask for this face crop (1.0 = skin, 0.0 = eyes/brows/lips/hair/outside)
      val skinMask = FloatArray(cropW * cropH)
      val cx = cropW / 2f
      val cy = cropH * 0.52f
      val rx = cropW * 0.44f
      val ry = cropH * 0.48f

      for (y in 0 until cropH) {
        val ny = (y - cy) / ry
        for (x in 0 until cropW) {
          val nx = (x - cx) / rx
          val dist = nx * nx + ny * ny
          if (dist <= 1.0f) {
            // Smooth falloff near boundary of face oval
            val falloff = if (dist > 0.70f) ((1.0f - dist) / 0.30f).coerceIn(0f, 1f) else 1.0f
            skinMask[y * cropW + x] = falloff
          }
        }
      }

      // 1. Exclude Hair / Hairline (top 18% of face)
      val hairCutoff = (cropH * 0.18f).toInt()
      val hairRamp = (cropH * 0.06f).toInt()
      for (y in 0 until min(cropH, hairCutoff + hairRamp)) {
        val factor = if (y < hairCutoff) 0f else ((y - hairCutoff).toFloat() / hairRamp)
        val rowOffset = y * cropW
        for (x in 0 until cropW) {
          skinMask[rowOffset + x] *= factor
        }
      }

      // 2. Exclude Eyes, Eyebrows, and Lips using ML Kit contours if available
      val hasMlKitFeatures = face.eyeBounds.isNotEmpty() || face.lipBounds.isNotEmpty()

      if (hasMlKitFeatures) {
        // Zero out eye regions with a 25% margin
        for (eyeRect in face.eyeBounds) {
          val ex1 = (eyeRect.left - left - eyeRect.width() * 0.20f).toInt().coerceIn(0, cropW)
          val ey1 = (eyeRect.top - top - eyeRect.height() * 0.20f).toInt().coerceIn(0, cropH)
          val ex2 = (eyeRect.right - left + eyeRect.width() * 0.20f).toInt().coerceIn(0, cropW)
          val ey2 = (eyeRect.bottom - top + eyeRect.height() * 0.20f).toInt().coerceIn(0, cropH)
          zeroOutMaskRect(skinMask, cropW, cropH, ex1, ey1, ex2, ey2)
        }

        // Zero out eyebrow regions
        for (browRect in face.eyebrowBounds) {
          val bx1 = (browRect.left - left - browRect.width() * 0.15f).toInt().coerceIn(0, cropW)
          val by1 = (browRect.top - top - browRect.height() * 0.15f).toInt().coerceIn(0, cropH)
          val bx2 = (browRect.right - left + browRect.width() * 0.15f).toInt().coerceIn(0, cropW)
          val by2 = (browRect.bottom - top + browRect.height() * 0.15f).toInt().coerceIn(0, cropH)
          zeroOutMaskRect(skinMask, cropW, cropH, bx1, by1, bx2, by2)
        }

        // Zero out lips/mouth
        for (lipRect in face.lipBounds) {
          val lx1 = (lipRect.left - left - lipRect.width() * 0.20f).toInt().coerceIn(0, cropW)
          val ly1 = (lipRect.top - top - lipRect.height() * 0.20f).toInt().coerceIn(0, cropH)
          val lx2 = (lipRect.right - left + lipRect.width() * 0.20f).toInt().coerceIn(0, cropW)
          val ly2 = (lipRect.bottom - top + lipRect.height() * 0.20f).toInt().coerceIn(0, cropH)
          zeroOutMaskRect(skinMask, cropW, cropH, lx1, ly1, lx2, ly2)
        }
      } else {
        // Fallback: anatomical geometry exclusion for eyes, eyebrows, and mouth
        val leftEyeX1 = (cropW * 0.18f).toInt()
        val leftEyeX2 = (cropW * 0.44f).toInt()
        val rightEyeX1 = (cropW * 0.56f).toInt()
        val rightEyeX2 = (cropW * 0.82f).toInt()
        val eyeY1 = (cropH * 0.35f).toInt()
        val eyeY2 = (cropH * 0.50f).toInt()

        val browY1 = (cropH * 0.26f).toInt()
        val browY2 = (cropH * 0.37f).toInt()

        val mouthX1 = (cropW * 0.28f).toInt()
        val mouthX2 = (cropW * 0.72f).toInt()
        val mouthY1 = (cropH * 0.68f).toInt()
        val mouthY2 = (cropH * 0.85f).toInt()

        // Exclude eyes
        zeroOutMaskRect(skinMask, cropW, cropH, leftEyeX1, eyeY1, leftEyeX2, eyeY2)
        zeroOutMaskRect(skinMask, cropW, cropH, rightEyeX1, eyeY1, rightEyeX2, eyeY2)

        // Exclude eyebrows
        zeroOutMaskRect(skinMask, cropW, cropH, leftEyeX1, browY1, leftEyeX2, browY2)
        zeroOutMaskRect(skinMask, cropW, cropH, rightEyeX1, browY1, rightEyeX2, browY2)

        // Exclude lips/mouth
        zeroOutMaskRect(skinMask, cropW, cropH, mouthX1, mouthY1, mouthX2, mouthY2)
      }

      // Feather the skin mask with a 3-pixel box blur for seamless transitions
      val featheredMask = boxBlurFloat(skinMask, cropW, cropH, radius = 3)

      // 3. Apply Edge-Preserving Bilateral Smoothing (radius 5, strength 0.5)
      val radius = 5
      val outCropPixels = cropPixels.clone()

      for (y in 0 until cropH) {
        val rowOffset = y * cropW
        for (x in 0 until cropW) {
          val maskVal = featheredMask[rowOffset + x]
          if (maskVal < 0.02f) continue // Eyes, brows, lips, hair remain 100% sharp

          val centerPixel = cropPixels[rowOffset + x]
          val cr = (centerPixel shr 16) and 0xFF
          val cg = (centerPixel shr 8) and 0xFF
          val cb = centerPixel and 0xFF

          var sumR = 0f
          var sumG = 0f
          var sumB = 0f
          var totalWeight = 0f

          val yStart = max(0, y - radius)
          val yEnd = min(cropH - 1, y + radius)
          val xStart = max(0, x - radius)
          val xEnd = min(cropW - 1, x + radius)

          for (ny in yStart..yEnd) {
            val nRowOffset = ny * cropW
            val dy = ny - y
            for (nx in xStart..xEnd) {
              val dx = nx - x
              val spatialDistSq = dx * dx + dy * dy
              if (spatialDistSq > radius * radius) continue

              val np = cropPixels[nRowOffset + nx]
              val nr = (np shr 16) and 0xFF
              val ng = (np shr 8) and 0xFF
              val nb = np and 0xFF

              val colorDist = abs(cr - nr) + abs(cg - ng) + abs(cb - nb)
              // Bilateral range weight: preserve facial features & contours, smooth pores & skin tones
              val rangeWeight = (1.0f - (colorDist / 60f)).coerceAtLeast(0f)
              if (rangeWeight <= 0f) continue

              val spatialWeight = 1.0f - (sqrt(spatialDistSq.toFloat()) / (radius + 1))
              val weight = spatialWeight * rangeWeight

              sumR += nr * weight
              sumG += ng * weight
              sumB += nb * weight
              totalWeight += weight
            }
          }

          val blendAlpha = (smoothingStrength * maskVal).coerceIn(0f, 1f)
          val blendedR: Int
          val blendedG: Int
          val blendedB: Int
          if (totalWeight > 0.001f) {
            val smoothR = sumR / totalWeight
            val smoothG = sumG / totalWeight
            val smoothB = sumB / totalWeight
            blendedR = ((1f - blendAlpha) * cr + blendAlpha * smoothR).roundToInt().coerceIn(0, 255)
            blendedG = ((1f - blendAlpha) * cg + blendAlpha * smoothG).roundToInt().coerceIn(0, 255)
            blendedB = ((1f - blendAlpha) * cb + blendAlpha * smoothB).roundToInt().coerceIn(0, 255)
          } else {
            blendedR = cr
            blendedG = cg
            blendedB = cb
          }

          // 4. FACE RELIGHT: inside the existing face skin mask (feathered, excluding eyes, brows, lips, hair)
          // add +5 L* and a* +2 (slightly pinker) so faces are a little brighter and healthier than the background.
          // Keep skin texture, no plastic look, no change to face shape.
          val relightWeight = maskVal * intensity
          val faceLab = rgbToLab(blendedR, blendedG, blendedB)
          val relitL = (faceLab[0] + 5.0f * relightWeight).coerceIn(0f, 100f)
          val relitA = faceLab[1] + 2.0f * relightWeight
          val relitB = faceLab[2]
          val clampedChroma = clampChromaToSrgbGamut(relitL, relitA, relitB)
          outCropPixels[rowOffset + x] = labToRgb(relitL, clampedChroma[0], clampedChroma[1])
        }
      }

      // Write enhanced face crop back to the bitmap
      bitmap.setPixels(outCropPixels, 0, cropW, left, top, cropW, cropH)
    }
  }

  private fun zeroOutMaskRect(
    mask: FloatArray,
    w: Int,
    h: Int,
    x1: Int,
    y1: Int,
    x2: Int,
    y2: Int
  ) {
    val startX = x1.coerceIn(0, w - 1)
    val endX = x2.coerceIn(0, w - 1)
    val startY = y1.coerceIn(0, h - 1)
    val endY = y2.coerceIn(0, h - 1)
    for (y in startY..endY) {
      val rowOffset = y * w
      for (x in startX..endX) {
        mask[rowOffset + x] = 0f
      }
    }
  }

  private fun boxBlurFloat(input: FloatArray, w: Int, h: Int, radius: Int): FloatArray {
    if (radius <= 0 || w <= 0 || h <= 0) return input.clone()
    val temp = FloatArray(w * h)
    val output = FloatArray(w * h)

    // Horizontal pass
    for (y in 0 until h) {
      val row = y * w
      var sum = 0f
      val count = radius * 2 + 1
      for (x in -radius..radius) {
        sum += input[row + x.coerceIn(0, w - 1)]
      }
      for (x in 0 until w) {
        temp[row + x] = sum / count
        val xRemove = (x - radius).coerceIn(0, w - 1)
        val xAdd = (x + radius + 1).coerceIn(0, w - 1)
        sum += input[row + xAdd] - input[row + xRemove]
      }
    }

    // Vertical pass
    for (x in 0 until w) {
      var sum = 0f
      val count = radius * 2 + 1
      for (y in -radius..radius) {
        sum += temp[y.coerceIn(0, h - 1) * w + x]
      }
      for (y in 0 until h) {
        output[y * w + x] = sum / count
        val yRemove = (y - radius).coerceIn(0, h - 1)
        val yAdd = (y + radius + 1).coerceIn(0, h - 1)
        sum += temp[yAdd * w + x] - temp[yRemove * w + x]
      }
    }

    return output
  }

  private fun sampleBilinear(grid: FloatArray, w: Int, h: Int, x: Float, y: Float): Float {
    val x0 = x.toInt().coerceIn(0, w - 1)
    val y0 = y.toInt().coerceIn(0, h - 1)
    val x1 = (x0 + 1).coerceIn(0, w - 1)
    val y1 = (y0 + 1).coerceIn(0, h - 1)
    val fx = x - x0
    val fy = y - y0

    val v00 = grid[y0 * w + x0]
    val v10 = grid[y0 * w + x1]
    val v01 = grid[y1 * w + x0]
    val v11 = grid[y1 * w + x1]

    val top = (1f - fx) * v00 + fx * v10
    val bottom = (1f - fx) * v01 + fx * v11
    return (1f - fy) * top + fy * bottom
  }
}
