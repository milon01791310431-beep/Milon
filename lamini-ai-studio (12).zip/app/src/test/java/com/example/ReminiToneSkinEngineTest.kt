package com.example

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect
import com.example.enhancer.engine.FaceDetectorOfflineHelper
import com.example.enhancer.engine.ReminiToneSkinEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ReminiToneSkinEngineTest {

  private fun computeMeanLstar(bitmap: Bitmap): Float {
    val w = bitmap.width
    val h = bitmap.height
    val pixels = IntArray(w * h)
    bitmap.getPixels(pixels, 0, w, 0, 0, w, h)
    var sum = 0.0
    for (p in pixels) {
      val r = Color.red(p)
      val g = Color.green(p)
      val b = Color.blue(p)
      sum += ReminiToneSkinEngine.rgbToLstar(r, g, b)
    }
    return (sum / (w * h)).toFloat()
  }

  @Test
  fun testFullPipeline_DarkImage_LandsWithin55To59_AndBlacksProtected() {
    // Dark test image: mean L* < 57 (around 47), with shadow/black pixels below L* 20
    val w = 100
    val h = 100
    val darkBitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)

    // Fill with RGB(116, 116, 116) (~48.9 L*) and top 5 rows with RGB(30, 30, 30) (~11.2 L*)
    val pixels = IntArray(w * h) { i ->
      val y = i / w
      if (y < 5) Color.rgb(30, 30, 30) else Color.rgb(116, 116, 116)
    }
    darkBitmap.setPixels(pixels, 0, w, 0, 0, w, h)

    val inMeanL = computeMeanLstar(darkBitmap)
    assertTrue("Input dark image must be below 57 L*, was $inMeanL", inMeanL < 57.0f)

    val enhanced = ReminiToneSkinEngine.applyReminiLook(darkBitmap)
    val outMeanL = computeMeanLstar(enhanced)

    // 1 & 5: Calibrated auto-exposure gamma lands final mean L* within 55..59
    assertTrue("Dark image mean L* ($outMeanL) after full pipeline must land within 55..59", outMeanL in 55.0f..59.0f)

    // 2 & 5: Black pixels below L* 20 stay below L* 22 (no haze, protected blacks)
    val blackSample = enhanced.getPixel(10, 2)
    val blackL = ReminiToneSkinEngine.rgbToLstar(Color.red(blackSample), Color.green(blackSample), Color.blue(blackSample))
    assertTrue("Black pixel below L* 20 must stay below L* 22, was $blackL", blackL <= 22.0f)
  }

  @Test
  fun testFullPipeline_NormalImage_LandsWithin55To59_AndBlacksProtected() {
    // Normal test image: mean L* around 50..52 (slightly below 57)
    val w = 100
    val h = 100
    val normalBitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)

    val pixels = IntArray(w * h) { i ->
      val y = i / w
      if (y < 5) Color.rgb(30, 30, 30) else Color.rgb(124, 124, 124) // ~52.3 L*
    }
    normalBitmap.setPixels(pixels, 0, w, 0, 0, w, h)

    val inMeanL = computeMeanLstar(normalBitmap)
    assertTrue("Input normal image must be below 57 L*, was $inMeanL", inMeanL < 57.0f)

    val enhanced = ReminiToneSkinEngine.applyReminiLook(normalBitmap)
    val outMeanL = computeMeanLstar(enhanced)

    // Mean L* lands within 55..59
    assertTrue("Normal image mean L* ($outMeanL) after full pipeline must land within 55..59", outMeanL in 55.0f..59.0f)

    // Black pixels below L* 20 stay below L* 22
    val blackSample = enhanced.getPixel(10, 2)
    val blackL = ReminiToneSkinEngine.rgbToLstar(Color.red(blackSample), Color.green(blackSample), Color.blue(blackSample))
    assertTrue("Black pixel below L* 20 must stay below L* 22, was $blackL", blackL <= 22.0f)
  }

  @Test
  fun testFullPipeline_BrightImage_Unchanged_AndBlacksProtected() {
    // Bright test image: mean L* >= 57 (around 63..64)
    val w = 100
    val h = 100
    val brightBitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)

    val pixels = IntArray(w * h) { i ->
      val y = i / w
      if (y < 5) Color.rgb(30, 30, 30) else Color.rgb(160, 160, 160) // ~66.2 L*
    }
    brightBitmap.setPixels(pixels, 0, w, 0, 0, w, h)

    val inMeanL = computeMeanLstar(brightBitmap)
    assertTrue("Input bright image must be >= 57 L*, was $inMeanL", inMeanL >= 57.0f)

    val enhanced = ReminiToneSkinEngine.applyReminiLook(brightBitmap)
    val outMeanL = computeMeanLstar(enhanced)

    // "or unchanged if already above 57": mean L* stays within 0.5 of input
    assertEquals("Bright image mean L* must remain unchanged when already above 57", inMeanL, outMeanL, 0.5f)

    // Black pixels below L* 20 stay below L* 22
    val blackSample = enhanced.getPixel(10, 2)
    val blackL = ReminiToneSkinEngine.rgbToLstar(Color.red(blackSample), Color.green(blackSample), Color.blue(blackSample))
    assertTrue("Black pixel below L* 20 must stay below L* 22, was $blackL", blackL <= 22.0f)
  }

  @Test
  fun testProtectBlacks_AnchoredBelow25() {
    // Anchor the curve so L* below about 25 is unchanged (no black lift, no haze)
    for (l in 0..25) {
      val outL = ReminiToneSkinEngine.computeToneMappedLstar(
        lStar = l.toFloat(),
        gamma = 0.5f,
        p5 = 20f,
        p95 = 80f
      )
      assertEquals("L* <= 25 must remain strictly unchanged", l.toFloat(), outL, 0.001f)
    }
  }

  @Test
  fun testContrastHighlightsNeverHardClipSkin() {
    // Test that extreme highlights (L* near 100) are softly compressed and never exceed 100
    for (l in 80..100) {
      val outL = ReminiToneSkinEngine.computeContrastLstar(l.toFloat(), p5 = 20f, p95 = 80f)
      assertTrue("Highlights must never exceed 100 L*", outL <= 100f)
      assertTrue("Highlights must not invert order", outL >= 80f)
    }
  }

  @Test
  fun testSaturationBoostAndWarmthShift() {
    // sRGB skin tone
    val r = 180
    val g = 140
    val b = 120

    val lab = ReminiToneSkinEngine.rgbToLab(r, g, b)
    val origB = lab[2]

    // Warmth shifts b* by +4 * intensity
    val warmthShift = 4.0f * ReminiToneSkinEngine.REMINI_LOOK_INTENSITY
    val expectedShiftedB = origB + warmthShift

    // Clamping to sRGB gamut must not clip
    val clamped = ReminiToneSkinEngine.clampChromaToSrgbGamut(lab[0], lab[1], expectedShiftedB)
    val linRgb = ReminiToneSkinEngine.labToLinearRgb(lab[0], clamped[0], clamped[1])

    for (c in linRgb) {
      assertTrue("Gamut clamping must ensure linear RGB is within [0, 1]", c in -0.01f..1.01f)
    }
  }

  @Test
  fun testFaceRelight_BrighterAndPinkerInsideSkinMask() {
    // Test face relight (+5 L* and a* +2) inside the feathered skin mask
    val w = 100
    val h = 100
    val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    bmp.eraseColor(Color.rgb(180, 140, 120)) // Warm skin tone

    val faceBox = FaceDetectorOfflineHelper.DetectedFaceBox(
      rect = Rect(10, 10, 90, 90),
      eyeBounds = listOf(Rect(25, 35, 45, 50), Rect(55, 35, 75, 50)),
      lipBounds = listOf(Rect(35, 65, 65, 80))
    )

    val enhanced = ReminiToneSkinEngine.applyReminiLook(bmp, listOf(faceBox))
    assertEquals(100, enhanced.width)
    assertEquals(100, enhanced.height)

    // Center forehead skin pixel (x=50, y=28): inside feathered skin mask, away from eyes & lips
    val skinPixel = enhanced.getPixel(50, 28)
    val skinLab = ReminiToneSkinEngine.rgbToLab(Color.red(skinPixel), Color.green(skinPixel), Color.blue(skinPixel))

    // Background pixel outside face (x=5, y=5)
    val bgPixel = enhanced.getPixel(5, 5)
    val bgLab = ReminiToneSkinEngine.rgbToLab(Color.red(bgPixel), Color.green(bgPixel), Color.blue(bgPixel))

    // Face skin should be brighter (+L*) and pinker (+a*) than the background
    assertTrue("Face skin L* (${skinLab[0]}) should be brighter than background L* (${bgLab[0]})", skinLab[0] > bgLab[0])
    assertTrue("Face skin a* (${skinLab[1]}) should be pinker than background a* (${bgLab[1]})", skinLab[1] > bgLab[1])
  }
}
