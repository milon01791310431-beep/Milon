package com.example.enhancer.engine

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * Smart Auto Analyzer that assesses photo characteristics (exposure, color cast,
 * saturation, noise, blur, faces, scene hint) on a 512px downscaled copy
 * and decides the optimal adaptive enhancement plan.
 *
 * Runs completely offline without API calls, executing in under 1 second.
 */
object SmartAutoAnalyzer {

  enum class SceneHint {
    PORTRAIT,
    FOOD,
    LANDSCAPE,
    NIGHT,
    DOCUMENT,
    GENERAL
  }

  data class FaceInfo(
    val sizeRatio: Float,
    val skinMeanL: Float,
    val skinMeanA: Float,
    val skinMeanB: Float
  )

  data class PhotoAnalysis(
    val meanL: Float,
    val p5: Float,
    val p95: Float,
    val clippedShadowShare: Float,
    val clippedHighlightShare: Float,
    val castA: Float,
    val castB: Float,
    val meanChroma: Float,
    val isBlackAndWhite: Boolean,
    val noiseLevel: Float,
    val blurLevel: Float,
    val width: Int,
    val height: Int,
    val faces: List<FaceInfo> = emptyList(),
    val sceneHint: SceneHint = SceneHint.GENERAL
  )

  data class EnhancePlan(
    val exposureTarget: Float,
    val maxLift: Float,
    val castCorrectA: Float,
    val castCorrectB: Float,
    val warmth: Float,
    val chromaBoost: Float,
    val denoise: Float,
    val sharpen: Float,
    val runFaceStage: Boolean,
    val faceRelightScale: Float,
    val skinSmoothing: Float,
    val applyColor: Boolean
  )

  /**
   * Analyzes the provided bitmap and face bounding boxes on a downscaled 512px copy.
   */
  fun analyze(
    bitmap: Bitmap,
    faceBoxes: List<FaceDetectorOfflineHelper.DetectedFaceBox> = emptyList()
  ): PhotoAnalysis {
    val origW = bitmap.width
    val origH = bitmap.height

    // 1. Downscale to max 512px on the longest dimension for ultra-fast processing (< 1s)
    val maxDim = max(origW, origH)
    val scale = if (maxDim > 512) 512f / maxDim else 1.0f
    val targetW = max(1, (origW * scale).roundToInt())
    val targetH = max(1, (origH * scale).roundToInt())

    val downscaled = if (scale < 1.0f) {
      Bitmap.createScaledBitmap(bitmap, targetW, targetH, true)
    } else {
      bitmap
    }

    val w = downscaled.width
    val h = downscaled.height
    val totalPixels = w * h
    val pixels = IntArray(totalPixels)
    downscaled.getPixels(pixels, 0, w, 0, 0, w, h)

    // Precompute LAB values, histogram and luminance stats
    val lValues = FloatArray(totalPixels)
    val aValues = FloatArray(totalPixels)
    val bValues = FloatArray(totalPixels)
    val chromas = FloatArray(totalPixels)
    val lHist = IntArray(101)

    var sumL = 0.0
    var sumChroma = 0.0
    var shadowClipCount = 0
    var highlightClipCount = 0

    // Gray-world color cast accumulators over low-chroma pixels
    var graySumA = 0.0
    var graySumB = 0.0
    var grayPixelCount = 0

    for (i in 0 until totalPixels) {
      val px = pixels[i]
      val r = (px ushr 16) and 0xFF
      val g = (px ushr 8) and 0xFF
      val b = px and 0xFF

      val lab = ReminiToneSkinEngine.rgbToLab(r, g, b)
      val lVal = lab[0].coerceIn(0f, 100f)
      val aVal = lab[1]
      val bVal = lab[2]
      val chroma = sqrt(aVal * aVal + bVal * bVal)

      lValues[i] = lVal
      aValues[i] = aVal
      bValues[i] = bVal
      chromas[i] = chroma

      sumL += lVal
      sumChroma += chroma

      val lBucket = lVal.roundToInt().coerceIn(0, 100)
      lHist[lBucket]++

      if (lVal <= 5f) shadowClipCount++
      if (lVal >= 98f) highlightClipCount++

      // Low chroma pixels (neutral tones, chroma < 20.0) for gray-world cast estimation
      // Exclude extreme darks/lights where hue is unreliable
      if (chroma < 20f && lVal in 10f..95f) {
        graySumA += aVal
        graySumB += bVal
        grayPixelCount++
      }
    }

    val meanL = (sumL / totalPixels).toFloat()
    val meanChroma = (sumChroma / totalPixels).toFloat()
    val isBlackAndWhite = meanChroma < 3.0f

    val clippedShadowShare = shadowClipCount.toFloat() / totalPixels
    val clippedHighlightShare = highlightClipCount.toFloat() / totalPixels

    // Percentiles p5 and p95
    val target5 = totalPixels * 0.05f
    val target95 = totalPixels * 0.95f
    var acc = 0
    var p5 = 0f
    var p95 = 100f
    var found5 = false
    var found95 = false

    for (bin in 0..100) {
      acc += lHist[bin]
      if (!found5 && acc >= target5) {
        p5 = bin.toFloat()
        found5 = true
      }
      if (!found95 && acc >= target95) {
        p95 = bin.toFloat()
        found95 = true
      }
    }

    // Color cast capped at +/- 6
    val castA = if (grayPixelCount >= 10) {
      (graySumA / grayPixelCount).toFloat().coerceIn(-6f, 6f)
    } else {
      // Fallback: average over all pixels if scene has higher saturation throughout
      var allA = 0.0
      for (i in 0 until totalPixels) allA += aValues[i]
      (allA / totalPixels).toFloat().coerceIn(-6f, 6f)
    }

    val castB = if (grayPixelCount >= 10) {
      (graySumB / grayPixelCount).toFloat().coerceIn(-6f, 6f)
    } else {
      // Fallback: average over all pixels if scene has higher saturation throughout
      var allB = 0.0
      for (i in 0 until totalPixels) allB += bValues[i]
      (allB / totalPixels).toFloat().coerceIn(-6f, 6f)
    }

    // 2. Noise & Blur estimation via Laplacian on L*
    // Laplacian kernel: [0, 1, 0; 1, -4, 1; 0, 1, 0]
    val (noiseLevel, blurLevel) = estimateNoiseAndBlur(lValues, w, h)

    // 3. Face Analysis
    val faceInfos = mutableListOf<FaceInfo>()
    val origArea = (origW * origH).toFloat()

    for (faceBox in faceBoxes) {
      val r = faceBox.rect
      val faceArea = (r.width() * r.height()).toFloat()
      val sizeRatio = if (origArea > 0f) faceArea / origArea else 0f

      // Sample skin color using toneMask geometry scaled to downscaled bitmap
      val downLeft = (r.left * scale).roundToInt().coerceIn(0, w - 1)
      val downTop = (r.top * scale).roundToInt().coerceIn(0, h - 1)
      val downRight = (r.right * scale).roundToInt().coerceIn(downLeft + 1, w)
      val downBottom = (r.bottom * scale).roundToInt().coerceIn(downTop + 1, h)
      val cropW = downRight - downLeft
      val cropH = downBottom - downTop

      if (cropW > 4 && cropH > 4) {
        var skinSumL = 0.0
        var skinSumA = 0.0
        var skinSumB = 0.0
        var skinWeightSum = 0.0

        val cx = cropW * 0.5f
        val cy = cropH * 0.52f
        val rx = max(1f, cropW * 0.44f)
        val ry = max(1f, cropH * 0.48f)

        for (cyIdx in 0 until cropH) {
          val py = downTop + cyIdx
          val dy = (cyIdx - cy) / ry
          val dy2 = dy * dy
          if (dy2 > 1.0f) continue

          val ramp = (cyIdx / (cropH * 0.15f)).coerceIn(0f, 1f)
          val hairFactor = ramp * ramp * (3f - 2f * ramp)

          for (cxIdx in 0 until cropW) {
            val px = downLeft + cxIdx
            val dx = (cxIdx - cx) / rx
            val dist = sqrt(dx * dx + dy2)
            if (dist <= 1.0f) {
              val falloff = if (dist > 0.65f) ((1.0f - dist) / 0.35f).coerceIn(0f, 1f) else 1.0f
              val maskWeight = falloff * hairFactor
              if (maskWeight > 0.1f) {
                val idx = py * w + px
                val lPix = lValues[idx]
                val aPix = aValues[idx]
                val bPix = bValues[idx]
                skinSumL += lPix * maskWeight
                skinSumA += aPix * maskWeight
                skinSumB += bPix * maskWeight
                skinWeightSum += maskWeight
              }
            }
          }
        }

        if (skinWeightSum > 1.0) {
          faceInfos.add(
            FaceInfo(
              sizeRatio = sizeRatio,
              skinMeanL = (skinSumL / skinWeightSum).toFloat(),
              skinMeanA = (skinSumA / skinWeightSum).toFloat(),
              skinMeanB = (skinSumB / skinWeightSum).toFloat()
            )
          )
        } else {
          faceInfos.add(
            FaceInfo(
              sizeRatio = sizeRatio,
              skinMeanL = meanL,
              skinMeanA = 14f,
              skinMeanB = 14f
            )
          )
        }
      }
    }

    // 4. Scene Hint classification (ML Kit Image Labeling with graceful heuristic fallback)
    val sceneHint = detectSceneHint(downscaled, faceBoxes, meanL)

    return PhotoAnalysis(
      meanL = meanL,
      p5 = p5,
      p95 = p95,
      clippedShadowShare = clippedShadowShare,
      clippedHighlightShare = clippedHighlightShare,
      castA = castA,
      castB = castB,
      meanChroma = meanChroma,
      isBlackAndWhite = isBlackAndWhite,
      noiseLevel = noiseLevel,
      blurLevel = blurLevel,
      width = origW,
      height = origH,
      faces = faceInfos,
      sceneHint = sceneHint
    )
  }

  /**
   * Decides an optimal adaptive EnhancePlan from the PhotoAnalysis.
   */
  fun decide(a: PhotoAnalysis): EnhancePlan {
    // 1. Exposure target by scene
    val exposureTarget = when (a.sceneHint) {
      SceneHint.PORTRAIT -> 57f
      SceneHint.FOOD -> 55f
      SceneHint.LANDSCAPE -> 52f
      SceneHint.NIGHT -> 45f
      SceneHint.DOCUMENT -> 55f
      SceneHint.GENERAL -> 54f
    }

    // Night scenes must never be lifted by more than +6 L*
    // If meanL < 35: maxLift = 13 (instead of 10)
    // If meanL >= 35: keep today's 10f limit
    val maxLift = if (a.sceneHint == SceneHint.NIGHT) {
      min(6f, max(0f, exposureTarget - a.meanL))
    } else if (a.meanL < 35f) {
      13f
    } else {
      10f
    }

    // 2. Color cast correction (cap 6)
    val castCorrectA = (-a.castA).coerceIn(-6f, 6f)
    val castCorrectB = (-a.castB).coerceIn(-6f, 6f)

    // 3. Warmth
    val warmth = when {
      a.sceneHint == SceneHint.DOCUMENT -> 0f
      a.sceneHint == SceneHint.PORTRAIT -> {
        val primarySkinB = a.faces.firstOrNull()?.skinMeanB ?: 12f
        if (primarySkinB < 14f) {
          // Warm up by +4 if skin is not already warm
          4f
        } else {
          // Scaled down progressively if skin is already warm
          val excess = primarySkinB - 14f
          (4f - excess * 0.5f).coerceIn(0f, 4f)
        }
      }
      a.sceneHint == SceneHint.FOOD -> 2.5f
      a.sceneHint == SceneHint.NIGHT -> 1.0f
      else -> 2.0f
    }

    // 4. Chroma boost:
    // Base boost 0.15 when meanChroma < 35, ramping linearly down to 0 at meanChroma 45.
    // Very dark photos (meanL < 35, non-Night):
    //   extra up to 0.15 scaled by planned lift / 13, total cap 0.30.
    // Normal photos (meanL >= 35) and Night scenes:
    //   extra up to 0.05 scaled by planned lift / 10, total cap 0.20.
    // Black and white stays 0.
    val chromaBoost = when {
      a.isBlackAndWhite -> 0f
      a.meanChroma >= 45f -> 0f
      else -> {
        val baseBoost = if (a.meanChroma < 35f) {
          0.15f
        } else {
          0.15f * ((45f - a.meanChroma) / 10f)
        }
        val plannedLift = (exposureTarget - a.meanL).coerceAtMost(maxLift).coerceAtLeast(0f)
        if (a.meanL < 35f && a.sceneHint != SceneHint.NIGHT) {
          val extra = 0.15f * (plannedLift / 13f).coerceIn(0f, 1f)
          (baseBoost + extra).coerceIn(0f, 0.30f)
        } else {
          val extra = 0.05f * (plannedLift / 10f).coerceIn(0f, 1f)
          (baseBoost + extra).coerceIn(0f, 0.20f)
        }
      }
    }

    // 5. Denoise (0.1 to 0.6 from noiseLevel) and Sharpen (0.1 to 0.4 from blurLevel)
    // Typical noiseLevel ranges ~0 to 10+. Map to 0.1..0.6
    val denoise = (0.1f + (a.noiseLevel / 12f) * 0.5f).coerceIn(0.1f, 0.6f)

    // BlurLevel: lower Laplacian variance means blurrier image -> needs more sharpening
    // Typical blur variance: < 100 is blurry, > 500 is sharp
    val sharpen = (0.4f - ((a.blurLevel.coerceIn(0f, 600f)) / 600f) * 0.3f).coerceIn(0.1f, 0.4f)

    // 6. Run face stage
    // Skip face stage if no faces or all detected faces are smaller than 64px in original image
    val hasValidFace = a.faces.isNotEmpty() && a.faces.any { face ->
      val faceDimPx = sqrt(face.sizeRatio * a.width * a.height)
      faceDimPx >= 64f
    }
    val runFaceStage = hasValidFace

    // 7. Face relight scale
    val targetFaceL = 55f
    val primaryFace = a.faces.firstOrNull()
    val faceRelightScale = if (primaryFace != null) {
      val faceL = primaryFace.skinMeanL
      ((targetFaceL - faceL) / 9f).coerceIn(0f, 1f)
    } else {
      0.5f
    }

    // 8. Skin smoothing (0.3 to 0.6)
    val skinSmoothing = (0.3f + (a.noiseLevel / 15f) * 0.3f).coerceIn(0.3f, 0.6f)

    // 9. Black and white photo rules: applyColor = false
    val applyColor = !a.isBlackAndWhite

    return if (!applyColor) {
      EnhancePlan(
        exposureTarget = exposureTarget,
        maxLift = maxLift,
        castCorrectA = 0f,
        castCorrectB = 0f,
        warmth = 0f,
        chromaBoost = 0f,
        denoise = denoise,
        sharpen = sharpen,
        runFaceStage = runFaceStage,
        faceRelightScale = faceRelightScale,
        skinSmoothing = skinSmoothing,
        applyColor = false
      )
    } else {
      EnhancePlan(
        exposureTarget = exposureTarget,
        maxLift = maxLift,
        castCorrectA = castCorrectA,
        castCorrectB = castCorrectB,
        warmth = warmth,
        chromaBoost = chromaBoost,
        denoise = denoise,
        sharpen = sharpen,
        runFaceStage = runFaceStage,
        faceRelightScale = faceRelightScale,
        skinSmoothing = skinSmoothing,
        applyColor = true
      )
    }
  }

  /**
   * Estimates noise level (MAD of Laplacian on flat areas) and blur level (Laplacian variance).
   */
  private fun estimateNoiseAndBlur(lValues: FloatArray, w: Int, h: Int): Pair<Float, Float> {
    if (w < 3 || h < 3) return Pair(0f, 100f)

    val laplacianValues = mutableListOf<Float>()
    var sumLap = 0.0
    var sumSqLap = 0.0
    var lapCount = 0

    // Compute discrete Laplacian: L[x+1,y] + L[x-1,y] + L[x,y+1] + L[x,y-1] - 4*L[x,y]
    // Step by 2 for speed
    for (y in 1 until h - 1 step 2) {
      val rowIdx = y * w
      val upIdx = (y - 1) * w
      val downIdx = (y + 1) * w

      for (x in 1 until w - 1 step 2) {
        val center = lValues[rowIdx + x]
        val lap = lValues[rowIdx + x + 1] +
          lValues[rowIdx + x - 1] +
          lValues[downIdx + x] +
          lValues[upIdx + x] - 4f * center

        laplacianValues.add(lap)
        sumLap += lap
        sumSqLap += (lap * lap)
        lapCount++
      }
    }

    if (lapCount == 0) return Pair(0f, 100f)

    // Blur level: variance of Laplacian
    val meanLap = sumLap / lapCount
    val blurVar = max(0.0, (sumSqLap / lapCount) - (meanLap * meanLap)).toFloat()

    // Noise level: Median Absolute Deviation (MAD) of the Laplacian
    // On flat areas, Laplacian responds primarily to noise.
    val absLap = FloatArray(laplacianValues.size) { i -> abs(laplacianValues[i]) }
    absLap.sort()
    val medianAbsLap = if (absLap.isNotEmpty()) absLap[absLap.size / 2] else 0f
    // MAD scale factor for Gaussian noise is ~1.4826 / sqrt(6) ~ 0.605
    val noiseLevel = medianAbsLap * 0.6f

    return Pair(noiseLevel, blurVar)
  }

  /**
   * Attempts scene classification via ML Kit Image Labeling inside try/catch.
   * If it fails or returns inconclusive results, falls back cleanly to heuristics.
   */
  private fun detectSceneHint(
    bitmap: Bitmap,
    faceBoxes: List<FaceDetectorOfflineHelper.DetectedFaceBox>,
    meanL: Float
  ): SceneHint {
    try {
      val image = InputImage.fromBitmap(bitmap, 0)
      val labeler = ImageLabeling.getClient(ImageLabelerOptions.DEFAULT_OPTIONS)
      val task = labeler.process(image)
      // Wait up to 350ms synchronously on background thread
      val labels = Tasks.await(task, 350, TimeUnit.MILLISECONDS)

      for (label in labels) {
        val text = label.text.lowercase()
        val conf = label.confidence
        if (conf > 0.45f) {
          when {
            text.contains("food") || text.contains("dish") || text.contains("meal") || text.contains("cuisine") ->
              return SceneHint.FOOD
            text.contains("document") || text.contains("text") || text.contains("paper") || text.contains("receipt") ->
              return SceneHint.DOCUMENT
            text.contains("night") || text.contains("darkness") || text.contains("midnight") ->
              return SceneHint.NIGHT
            text.contains("landscape") || text.contains("sky") || text.contains("mountain") || text.contains("nature") || text.contains("cloud") ->
              return SceneHint.LANDSCAPE
            text.contains("portrait") || text.contains("person") || text.contains("face") || text.contains("selfie") ->
              return SceneHint.PORTRAIT
          }
        }
      }
    } catch (_: Exception) {
      // Graceful fallback to heuristic classification
    }

    // Heuristic fallback
    if (faceBoxes.isNotEmpty()) {
      return SceneHint.PORTRAIT
    }
    if (meanL < 35f) {
      return SceneHint.NIGHT
    }
    return SceneHint.GENERAL
  }
}
