package com.example.enhancer.engine

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Offline "Remini-look" tone and skin enhancement engine.
 *
 * Runs after Real-ESRGAN and face restoration, before the final resize to original size.
 *
 * Pipeline features:
 * 1. AUTO EXPOSURE: compute mean L* (LAB, 0-100). Target mean ~57. Lift with a gamma curve
 *    toward target, capped at +12 L*. If already >= 57, no lift is applied.
 * 2. CONTRAST/HIGHLIGHTS: stretch levels so 95th percentile L* reaches ~80 (gain cap 1.25)
 *    while 5th percentile stays near 20. Adds gentle local contrast (radius 20-30 px, amount 0.15)
 *    and an S-curve. Soft highlights compression ensures highlights on skin never hard clip.
 * 3. WARMTH: shift LAB b* by +3 (slightly warmer), a* unchanged. Chroma is clamped within +5%
 *    of original saturation to prevent oversaturation.
 * 4. SKIN SMOOTHING: edge-preserving bilateral filter (radius 5, strength 0.5) applied strictly
 *    inside face regions. Excludes eyes, eyebrows, lips and hair via ML Kit face contours
 *    or landmark geometry, keeping eyes razor sharp and skin natural without plastic look.
 * 5. BACKGROUND: mild edge-preserving denoise (strength 0.3), retaining fabric and texture detail.
 * 6. Naturalness: identity, face shape, eye size and skin tone remain completely natural (no reshaping).
 * 7. Scaled by internal constant [REMINI_LOOK_INTENSITY] = 0.8.
 * 8. Memory-safe: processed in row bands.
 */
object ReminiToneSkinEngine {

  /**
   * Internal intensity scalar (range 0..1) that scales all Remini-look adjustments.
   */
  const val REMINI_LOOK_INTENSITY: Float = 0.8f

  // Precomputed sRGB to linear conversion table
  val SRGB_TO_LIN = FloatArray(256) { i ->
    val c = i / 255f
    if (c <= 0.04045f) c / 12.92f else ((c + 0.055f) / 1.055f).pow(2.4f)
  }

  // D65 standard constants for CIELAB
  private const val EPS = 216f / 24389f // ~0.008856
  private const val KAPPA = 24389f / 27f // ~903.3
  private const val XN = 0.95047f
  private const val YN = 1.00000f
  private const val ZN = 1.08883f

  fun linearToSrgb(c: Float): Float {
    val clamped = c.coerceIn(0f, 1f)
    return if (clamped <= 0.0031308f) 12.92f * clamped else 1.055f * clamped.pow(1f / 2.4f) - 0.055f
  }

  fun rgbToLstar(r: Int, g: Int, b: Int): Float {
    val yNorm = 0.2126729f * SRGB_TO_LIN[r] + 0.7151522f * SRGB_TO_LIN[g] + 0.0721750f * SRGB_TO_LIN[b]
    return if (yNorm > EPS) 116f * yNorm.pow(1f / 3f) - 16f else KAPPA * yNorm
  }

  fun rgbToLab(r: Int, g: Int, b: Int): FloatArray {
    val rLin = SRGB_TO_LIN[r]
    val gLin = SRGB_TO_LIN[g]
    val bLin = SRGB_TO_LIN[b]

    val X = (0.4124564f * rLin + 0.3575761f * gLin + 0.1804375f * bLin) / XN
    val Y = (0.2126729f * rLin + 0.7151522f * gLin + 0.0721750f * bLin) / YN
    val Z = (0.0193339f * rLin + 0.1191920f * gLin + 0.9503041f * bLin) / ZN

    val fx = if (X > EPS) X.pow(1f / 3f) else (KAPPA * X + 16f) / 116f
    val fy = if (Y > EPS) Y.pow(1f / 3f) else (KAPPA * Y + 16f) / 116f
    val fz = if (Z > EPS) Z.pow(1f / 3f) else (KAPPA * Z + 16f) / 116f

    val L = (116f * fy - 16f).coerceIn(0f, 100f)
    val a = 500f * (fx - fy)
    val bStar = 200f * (fy - fz)
    return floatArrayOf(L, a, bStar)
  }

  fun labToRgb(L: Float, a: Float, b: Float): Int {
    val fy = (L.coerceIn(0f, 100f) + 16f) / 116f
    val fx = fy + a / 500f
    val fz = fy - b / 200f

    val fx3 = fx * fx * fx
    val fz3 = fz * fz * fz

    val xr = if (fx3 > EPS) fx3 else (116f * fx - 16f) / KAPPA
    val yr = if (L > KAPPA * EPS) ((L + 16f) / 116f).pow(3f) else L / KAPPA
    val zr = if (fz3 > EPS) fz3 else (116f * fz - 16f) / KAPPA

    val X = xr * XN
    val Y = yr * YN
    val Z = zr * ZN

    val rLin = 3.2404542f * X - 1.5371385f * Y - 0.4985314f * Z
    val gLin = -0.9692660f * X + 1.8760108f * Y + 0.0415560f * Z
    val bLin = 0.0556434f * X - 0.2040259f * Y + 1.0572252f * Z

    val r = (linearToSrgb(rLin) * 255f).roundToInt().coerceIn(0, 255)
    val g = (linearToSrgb(gLin) * 255f).roundToInt().coerceIn(0, 255)
    val bInt = (linearToSrgb(bLin) * 255f).roundToInt().coerceIn(0, 255)

    return (0xFF shl 24) or (r shl 16) or (g shl 8) or bInt
  }

  /**
   * Computes calibrated tone-mapped L* combining exposure, contrast stretch, strong toe S-curve,
   * and soft shoulder rolloff.
   *
   * 2. PROTECT BLACKS: keep the 5th percentile where it is. Anchor the curve so L* below about 25 is unchanged
   * (no black lift, no haze). Use a stronger toe in the S-curve instead of lifting shadows.
   * Limit the 95th percentile to about 80 (soft shoulder from 80 instead of 85).
   */
  fun computeToneMappedLstar(
    lStar: Float,
    gamma: Float,
    p5: Float,
    p95: Float,
    intensity: Float = REMINI_LOOK_INTENSITY
  ): Float {
    if (lStar <= 25.0f || intensity <= 0f) {
      return lStar
    }

    // Normalized tone in range [25, 100]
    val v = (lStar - 25.0f) / 75.0f
    val vLift = v.pow(gamma)
    val lAe = 25.0f + 75.0f * vLift

    // Contrast stretch: keep 5th percentile where it is, stretch 95th toward 80 (gain cap 1.25)
    val targetSpan = 80.0f - 25.0f
    val currentSpan = max(p95 - 25.0f, 15.0f)
    val rawGain = (targetSpan / currentSpan).coerceIn(1.0f, 1.25f)
    val gain = 1.0f + (rawGain - 1.0f) * intensity
    val lStretch = 25.0f + (lAe - 25.0f) * gain

    // S-curve with stronger toe instead of lifting shadows
    val u = ((lStretch - 25.0f) / 75.0f).coerceIn(0f, 1f)
    val sCurveAmount = 0.040f * intensity
    val sCurveU = u - sCurveAmount * sin((2 * Math.PI * u).toFloat())
    val lAfterS = 25.0f + 75.0f * sCurveU

    // Soft shoulder from 80 instead of 85 (limit 95th percentile to about 80)
    return if (lAfterS > 80.0f) {
      80.0f + 20.0f * (1.0f - exp(-((lAfterS - 80.0f) / 20.0f).toDouble()).toFloat())
    } else {
      lAfterS.coerceIn(0f, 100f)
    }
  }

  fun computeAutoExposureLstar(
    lStar: Float,
    meanL: Float,
    intensity: Float = REMINI_LOOK_INTENSITY
  ): Float {
    if (meanL >= 57f || intensity <= 0f || lStar <= 25f) return lStar
    val maxLift = 10f * intensity
    val desiredLift = (57f - meanL) * intensity
    val actualLift = min(desiredLift, maxLift)
    if (actualLift <= 0.001f) return lStar

    val m = ((meanL - 25f) / 75f).coerceIn(0.01f, 0.99f)
    val t = (((meanL + actualLift) - 25f) / 75f).coerceIn(m, 0.999f)
    val gamma = ln(t) / ln(m)
    val v = ((lStar - 25f) / 75f).coerceIn(0f, 1f)
    return (25f + 75f * v.pow(gamma)).coerceIn(0f, 100f)
  }

  fun computeContrastLstar(
    lStar: Float,
    p5: Float,
    p95: Float,
    intensity: Float = REMINI_LOOK_INTENSITY
  ): Float {
    return computeToneMappedLstar(lStar, gamma = 1.0f, p5 = p5, p95 = p95, intensity = intensity)
  }

  fun evaluateMeanForGamma(
    gamma: Float,
    hist: IntArray,
    totalPixels: Int,
    p5: Float,
    p95: Float,
    intensity: Float
  ): Float {
    if (totalPixels <= 0) return 50f
    var sum = 0.0
    for (bin in 0..1000) {
      val count = hist[bin]
      if (count == 0) continue
      val inL = bin / 10.0f
      val outL = computeToneMappedLstar(inL, gamma, p5, p95, intensity)
      sum += outL.toDouble() * count
    }
    return (sum / totalPixels).toFloat()
  }

  /**
   * Calibrates auto-exposure gamma using binary search over the histogram so that the mean L*
   * AFTER the full tone LUT (exposure + contrast + S-curve) is about exposureTarget. Max total lift maxLift.
   * If the input mean is already exposureTarget or higher, do nothing.
   */
  fun calibrateToneLut(
    hist: IntArray,
    totalPixels: Int,
    meanL: Float,
    p5: Float,
    p95: Float,
    intensity: Float = REMINI_LOOK_INTENSITY,
    exposureTarget: Float = 57.0f,
    maxLift: Float = 10.0f
  ): FloatArray {
    if (meanL >= exposureTarget || intensity <= 0.001f) {
      return FloatArray(1001) { bin -> bin / 10.0f }
    }

    val targetMean = min(exposureTarget, meanL + maxLift)

    var lowGamma = 0.10f
    var highGamma = 1.0f
    var bestGamma = 1.0f

    val meanAt1 = evaluateMeanForGamma(1.0f, hist, totalPixels, p5, p95, intensity)
    if (meanAt1 >= targetMean) {
      bestGamma = 1.0f
    } else {
      var minDiff = Float.MAX_VALUE
      for (iter in 0 until 20) {
        val midGamma = (lowGamma + highGamma) / 2f
        val simMean = evaluateMeanForGamma(midGamma, hist, totalPixels, p5, p95, intensity)
        val diff = abs(simMean - targetMean)
        if (diff < minDiff) {
          minDiff = diff
          bestGamma = midGamma
        }
        if (simMean > targetMean) {
          lowGamma = midGamma
        } else {
          highGamma = midGamma
        }
      }
    }

    return FloatArray(1001) { bin ->
      computeToneMappedLstar(bin / 10.0f, bestGamma, p5, p95, intensity)
    }
  }

  fun labToLinearRgb(L: Float, a: Float, b: Float): FloatArray {
    val fy = (L.coerceIn(0f, 100f) + 16f) / 116f
    val fx = fy + a / 500f
    val fz = fy - b / 200f

    val fx3 = fx * fx * fx
    val fz3 = fz * fz * fz

    val xr = if (fx3 > EPS) fx3 else (116f * fx - 16f) / KAPPA
    val yr = if (L > KAPPA * EPS) ((L + 16f) / 116f).pow(3f) else L / KAPPA
    val zr = if (fz3 > EPS) fz3 else (116f * fz - 16f) / KAPPA

    val X = xr * XN
    val Y = yr * YN
    val Z = zr * ZN

    val rLin = 3.2404542f * X - 1.5371385f * Y - 0.4985314f * Z
    val gLin = -0.9692660f * X + 1.8760108f * Y + 0.0415560f * Z
    val bLin = 0.0556434f * X - 0.2040259f * Y + 1.0572252f * Z
    return floatArrayOf(rLin, gLin, bLin)
  }

  fun clampChromaToSrgbGamut(L: Float, a: Float, b: Float): FloatArray {
    val lin = labToLinearRgb(L, a, b)
    if (lin[0] in 0f..1f && lin[1] in 0f..1f && lin[2] in 0f..1f) {
      return floatArrayOf(a, b)
    }

    var low = 0f
    var high = 1f
    for (i in 0 until 6) {
      val mid = (low + high) / 2f
      val testLin = labToLinearRgb(L, a * mid, b * mid)
      if (testLin[0] in 0f..1f && testLin[1] in 0f..1f && testLin[2] in 0f..1f) {
        low = mid
      } else {
        high = mid
      }
    }
    return floatArrayOf(a * low, b * low)
  }

  /**
   * Applies the complete Remini-look tone, warmth, and skin enhancement pipeline to [inputBitmap].
   *
   * @param inputBitmap The upscaled & face-restored intermediate bitmap.
   * @param faces List of detected face bounding boxes with contour exclusion regions.
   * @param intensity Global intensity scalar (defaults to [REMINI_LOOK_INTENSITY]).
   * @return Enhanced bitmap with Remini-look tone, warmth, skin smoothing, and texture.
   */
  /**
   * Applies the complete Remini-look tone, warmth, and skin enhancement pipeline to [inputBitmap].
   *
   * @param inputBitmap The upscaled & face-restored intermediate bitmap.
   * @param faces List of detected face bounding boxes with contour exclusion regions.
   * @param intensity Global intensity scalar (defaults to [REMINI_LOOK_INTENSITY]).
   * @param plan Optional adaptive plan generated by [SmartAutoAnalyzer.decide]. If null, defaults to fixed constants.
   * @return Enhanced bitmap with Remini-look tone, warmth, skin smoothing, and texture.
   */
  fun applyReminiLook(
    inputBitmap: Bitmap,
    faces: List<FaceDetectorOfflineHelper.DetectedFaceBox> = emptyList(),
    intensity: Float = REMINI_LOOK_INTENSITY,
    plan: SmartAutoAnalyzer.EnhancePlan? = null
  ): Bitmap {
    if (intensity <= 0.001f) {
      return inputBitmap.copy(Bitmap.Config.ARGB_8888, true)
    }

    val width = inputBitmap.width
    val height = inputBitmap.height

    // Extract adaptive parameters from plan if present, otherwise use standard fixed defaults
    val exposureTarget = plan?.exposureTarget ?: 57.0f
    val maxLift = plan?.maxLift ?: 10.0f
    val castCorrectA = plan?.castCorrectA ?: 0.0f
    val castCorrectB = plan?.castCorrectB ?: 0.0f
    val warmth = plan?.warmth ?: 4.0f
    val chromaBoost = plan?.chromaBoost ?: 0.15f
    val denoise = plan?.denoise ?: 0.30f
    val skinSmoothing = plan?.skinSmoothing ?: 0.50f
    val faceRelightScale = plan?.faceRelightScale ?: 1.0f
    val runFaceStage = plan?.runFaceStage ?: true
    val applyColor = plan?.applyColor ?: true

    // 1. Compute Image Luminance Statistics (Mean L*, 5th & 95th Percentile) in row bands
    val bandHeight = 256
    val bandPixels = IntArray(width * bandHeight)
    var sumL = 0.0
    val hist = IntArray(1001) // 0..1000 for L* 0.0..100.0 (0.1 precision)
    var totalPixels = 0

    for (y in 0 until height step bandHeight) {
      val rows = min(bandHeight, height - y)
      inputBitmap.getPixels(bandPixels, 0, width, 0, y, width, rows)
      val count = width * rows
      totalPixels += count
      for (i in 0 until count) {
        val pixel = bandPixels[i]
        val r = (pixel shr 16) and 0xFF
        val g = (pixel shr 8) and 0xFF
        val b = pixel and 0xFF
        val lStar = rgbToLstar(r, g, b)
        sumL += lStar
        val bin = (lStar * 10f).toInt().coerceIn(0, 1000)
        hist[bin]++
      }
    }

    val meanL = if (totalPixels > 0) (sumL / totalPixels).toFloat() else 50f
    val p5Count = (0.05 * totalPixels).toInt()
    val p95Count = (0.95 * totalPixels).toInt()
    var accum = 0
    var p5 = 20f
    var p95 = 80f
    var foundP5 = false
    for (bin in 0..1000) {
      accum += hist[bin]
      val lVal = bin / 10f
      if (!foundP5 && accum >= p5Count) {
        p5 = lVal
        foundP5 = true
      }
      if (accum >= p95Count) {
        p95 = lVal
        break
      }
    }

    // 2. Calibrate Tone Mapping LUT via binary search so final mean L* reaches exposureTarget (max total lift maxLift)
    val toneLut = calibrateToneLut(hist, totalPixels, meanL, p5, p95, intensity, exposureTarget, maxLift)

    // 3. Compute Low-Frequency Luminance Grid for gentle local contrast (radius ~24px)
    val dsScale = 4
    val dw = max(1, width / dsScale)
    val dh = max(1, height / dsScale)
    val dsLum = FloatArray(dw * dh)
    val dsCounts = IntArray(dw * dh)

    for (y in 0 until height step bandHeight) {
      val rows = min(bandHeight, height - y)
      inputBitmap.getPixels(bandPixels, 0, width, 0, y, width, rows)
      for (r in 0 until rows) {
        val imgY = y + r
        val dsY = (imgY / dsScale).coerceIn(0, dh - 1)
        val rowOffset = r * width
        for (imgX in 0 until width) {
          val dsX = (imgX / dsScale).coerceIn(0, dw - 1)
          val pixel = bandPixels[rowOffset + imgX]
          val pr = (pixel shr 16) and 0xFF
          val pg = (pixel shr 8) and 0xFF
          val pb = pixel and 0xFF
          val l = rgbToLstar(pr, pg, pb)
          val idx = dsY * dw + dsX
          dsLum[idx] += l
          dsCounts[idx]++
        }
      }
    }
    for (i in 0 until dw * dh) {
      if (dsCounts[i] > 0) dsLum[i] /= dsCounts[i]
    }
    val blurredLum = boxBlurFloat(dsLum, dw, dh, radius = 6)

    // 4. Create Output Bitmap and Apply Global Tone, Warmth, Saturation boost, Local Contrast, and Background Denoise
    val outputBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    val outBandPixels = IntArray(width * bandHeight)
    val effWarmth = if (applyColor) warmth * intensity else 0f
    val effCastA = if (applyColor) castCorrectA * intensity else 0f
    val effCastB = if (applyColor) castCorrectB * intensity else 0f
    val localContrastAmount = 0.15f * intensity
    val bgDenoiseStrength = denoise * intensity

    for (y in 0 until height step bandHeight) {
      val rows = min(bandHeight, height - y)
      inputBitmap.getPixels(bandPixels, 0, width, 0, y, width, rows)

      for (r in 0 until rows) {
        val imgY = y + r
        val dsY = (imgY.toFloat() / dsScale).coerceIn(0f, (dh - 1).toFloat())
        val rowOffset = r * width

        for (x in 0 until width) {
          val pixel = bandPixels[rowOffset + x]
          val pr = (pixel shr 16) and 0xFF
          val pg = (pixel shr 8) and 0xFF
          val pb = pixel and 0xFF

          // Background mild denoise
          var smoothedR = pr.toFloat()
          var smoothedG = pg.toFloat()
          var smoothedB = pb.toFloat()
          if (bgDenoiseStrength > 0.01f) {
            var neighborCount = 1
            val left = if (x > 0) bandPixels[rowOffset + x - 1] else pixel
            val right = if (x < width - 1) bandPixels[rowOffset + x + 1] else pixel
            val top = if (r > 0) bandPixels[(r - 1) * width + x] else pixel
            val bottom = if (r < rows - 1) bandPixels[(r + 1) * width + x] else pixel

            for (np in intArrayOf(left, right, top, bottom)) {
              val nr = (np shr 16) and 0xFF
              val ng = (np shr 8) and 0xFF
              val nb = np and 0xFF
              val diff = abs(pr - nr) + abs(pg - ng) + abs(pb - nb)
              if (diff < 22) {
                smoothedR += nr
                smoothedG += ng
                smoothedB += nb
                neighborCount++
              }
            }
            smoothedR /= neighborCount
            smoothedG /= neighborCount
            smoothedB /= neighborCount
          }

          val effR = ((1f - bgDenoiseStrength) * pr + bgDenoiseStrength * smoothedR).roundToInt().coerceIn(0, 255)
          val effG = ((1f - bgDenoiseStrength) * pg + bgDenoiseStrength * smoothedG).roundToInt().coerceIn(0, 255)
          val effB = ((1f - bgDenoiseStrength) * pb + bgDenoiseStrength * smoothedB).roundToInt().coerceIn(0, 255)

          // Convert to LAB
          val lab = rgbToLab(effR, effG, effB)
          val origL = lab[0]
          val aStar = lab[1]
          val bStar = lab[2]

          // Apply Global Tone curve from calibrated LUT
          val lutIdx = (origL * 10f).toInt().coerceIn(0, 1000)
          val toneL = toneLut[lutIdx]

          // Local contrast adjustment
          val dsX = (x.toFloat() / dsScale).coerceIn(0f, (dw - 1).toFloat())
          val lBlur = sampleBilinear(blurredLum, dw, dh, dsX, dsY)
          val localL = if (origL <= 25f) toneL else (toneL + (origL - lBlur) * localContrastAmount).coerceIn(0f, 100f)

          var targetA = aStar
          var targetB = bStar

          if (applyColor) {
            // Apply color cast correction: castCorrectA / castCorrectB
            val castAdjustedA = aStar + effCastA
            val castAdjustedB = bStar + effCastB

            // Warmth: shift b*
            val shiftedB = castAdjustedB + effWarmth

            // Saturation: boost chroma
            val origChroma = sqrt(castAdjustedA * castAdjustedA + shiftedB * shiftedB)
            val h = Math.atan2(shiftedB.toDouble(), castAdjustedA.toDouble()).toFloat()
            val hDeg = Math.toDegrees(h.toDouble()).toFloat().let { if (it < 0f) it + 360f else it }

            val diffDeg = abs(hDeg - 45f)
            val skinAffinity = if (diffDeg < 55f) (1.0f - diffDeg / 55f) else 0f
            val chromaWeight = (origChroma / 20.0f).coerceIn(0f, 1f)
            val maxChromaBoost = chromaBoost * intensity
            val boost = maxChromaBoost * chromaWeight * (0.35f + 0.65f * skinAffinity)

            targetA = castAdjustedA * (1.0f + boost)
            targetB = shiftedB * (1.0f + boost)

            val clampedChroma = clampChromaToSrgbGamut(localL, targetA, targetB)
            targetA = clampedChroma[0]
            targetB = clampedChroma[1]
          } else {
            // Black and white: keep original a* and b* (or neutral 0 if BW)
            targetA = aStar
            targetB = bStar
          }

          outBandPixels[rowOffset + x] = labToRgb(localL, targetA, targetB)
        }
      }
      outputBitmap.setPixels(outBandPixels, 0, width, 0, y, width, rows)
    }

    // 5. Apply Skin Smoothing and Face Relight Inside Face Regions (skip if runFaceStage is false)
    if (runFaceStage) {
      applySkinSmoothing(outputBitmap, faces, intensity, skinSmoothing, faceRelightScale, applyColor)
    }

    return outputBitmap
  }

  /**
   * Applies edge-preserving bilateral skin smoothing and face relighting strictly inside face regions.
   * Uses separate masks:
   * - smoothMask: excludes eyes, eyebrows, lips via soft ellipses and Gaussian blur so features stay sharp.
   * - toneMask: smooth face ellipse including eyes, brows, lips with smooth hairline ramp and Gaussian feathering.
   */
  private fun applySkinSmoothing(
    bitmap: Bitmap,
    faces: List<FaceDetectorOfflineHelper.DetectedFaceBox>,
    intensity: Float,
    smoothingAmount: Float = 0.50f,
    faceRelightScale: Float = 1.0f,
    applyColor: Boolean = true
  ) {
    if (faces.isEmpty() || intensity <= 0.001f) return
    val bmpW = bitmap.width
    val bmpH = bitmap.height
    val smoothingStrength = smoothingAmount * intensity

    for (face in faces) {
      val rawRect = face.rect
      // Expand bounding box slightly for natural edge blending
      val padX = (rawRect.width() * 0.10f).toInt()
      val padY = (rawRect.height() * 0.10f).toInt()
      val left = (rawRect.left - padX).coerceIn(0, bmpW - 1)
      val top = (rawRect.top - padY).coerceIn(0, bmpH - 1)
      val right = (rawRect.right + padX).coerceIn(left + 1, bmpW)
      val bottom = (rawRect.bottom + padY).coerceIn(top + 1, bmpH)
      val cropW = right - left
      val cropH = bottom - top

      if (cropW < 20 || cropH < 20) continue

      val cropPixels = IntArray(cropW * cropH)
      bitmap.getPixels(cropPixels, 0, cropW, left, top, cropW, cropH)

      // 1. Generate toneMask: smooth face ellipse from forehead to chin that INCLUDES eyes, brows, and lips
      val rawToneMask = FloatArray(cropW * cropH)
      val cx = cropW / 2f
      val cy = cropH * 0.52f
      val rx = cropW * 0.44f
      val ry = cropH * 0.48f

      for (y in 0 until cropH) {
        val ny = (y - cy) / ry
        val nySq = ny * ny
        for (x in 0 until cropW) {
          val nx = (x - cx) / rx
          val dist = nx * nx + nySq
          if (dist <= 1.0f) {
            // Smooth falloff near boundary of face oval
            val falloff = if (dist > 0.65f) ((1.0f - dist) / 0.35f).coerceIn(0f, 1f) else 1.0f
            rawToneMask[y * cropW + x] = falloff
          }
        }
      }

      // Replace hard "top 18% hair cutoff" band with smooth vertical ramp over about 15% of face height
      val hairRampHeight = max(1f, cropH * 0.15f)
      val rampLimit = min(cropH, (cropH * 0.15f).toInt() + 1)
      for (y in 0 until rampLimit) {
        val ramp = (y / hairRampHeight).coerceIn(0f, 1f)
        val factor = ramp * ramp * (3f - 2f * ramp)
        val rowOffset = y * cropW
        for (x in 0 until cropW) {
          rawToneMask[rowOffset + x] *= factor
        }
      }

      // Feather toneMask with Gaussian radius of about 12% of face width
      val toneBlurRadius = max(2, (cropW * 0.12f).roundToInt())
      val toneMask = gaussianBlurFloat(rawToneMask, cropW, cropH, toneBlurRadius)

      // 2. Generate smoothMask: starts from rawToneMask, soft elliptical exclusions for eyes/brows/lips
      val rawSmoothMask = rawToneMask.clone()
      val hasMlKitFeatures = face.eyeBounds.isNotEmpty() || face.lipBounds.isNotEmpty()

      if (hasMlKitFeatures) {
        for (eyeRect in face.eyeBounds) {
          val ecx = (eyeRect.centerX() - left).toFloat()
          val ecy = (eyeRect.centerY() - top).toFloat()
          val erx = max(1f, eyeRect.width() * 0.60f)
          val ery = max(1f, eyeRect.height() * 0.60f)
          softExcludeEllipse(rawSmoothMask, cropW, cropH, ecx, ecy, erx, ery)
        }
        for (browRect in face.eyebrowBounds) {
          val bcx = (browRect.centerX() - left).toFloat()
          val bcy = (browRect.centerY() - top).toFloat()
          val brx = max(1f, browRect.width() * 0.55f)
          val bry = max(1f, browRect.height() * 0.55f)
          softExcludeEllipse(rawSmoothMask, cropW, cropH, bcx, bcy, brx, bry)
        }
        for (lipRect in face.lipBounds) {
          val lcx = (lipRect.centerX() - left).toFloat()
          val lcy = (lipRect.centerY() - top).toFloat()
          val lrx = max(1f, lipRect.width() * 0.60f)
          val lry = max(1f, lipRect.height() * 0.60f)
          softExcludeEllipse(rawSmoothMask, cropW, cropH, lcx, lcy, lrx, lry)
        }
      } else {
        val leftEyeCx = cropW * 0.31f
        val leftEyeCy = cropH * 0.425f
        val eyeRx = cropW * 0.13f
        val eyeRy = cropH * 0.08f
        softExcludeEllipse(rawSmoothMask, cropW, cropH, leftEyeCx, leftEyeCy, eyeRx, eyeRy)

        val rightEyeCx = cropW * 0.69f
        val rightEyeCy = cropH * 0.425f
        softExcludeEllipse(rawSmoothMask, cropW, cropH, rightEyeCx, rightEyeCy, eyeRx, eyeRy)

        val leftBrowCx = cropW * 0.31f
        val leftBrowCy = cropH * 0.315f
        val browRx = cropW * 0.13f
        val browRy = cropH * 0.06f
        softExcludeEllipse(rawSmoothMask, cropW, cropH, leftBrowCx, leftBrowCy, browRx, browRy)

        val rightBrowCx = cropW * 0.69f
        val rightBrowCy = cropH * 0.315f
        softExcludeEllipse(rawSmoothMask, cropW, cropH, rightBrowCx, rightBrowCy, browRx, browRy)

        val mouthCx = cropW * 0.50f
        val mouthCy = cropH * 0.765f
        val mouthRx = cropW * 0.22f
        val mouthRy = cropH * 0.09f
        softExcludeEllipse(rawSmoothMask, cropW, cropH, mouthCx, mouthCy, mouthRx, mouthRy)
      }

      // Blur smoothMask with a Gaussian of radius about 8% of face width
      val smoothBlurRadius = max(2, (cropW * 0.08f).roundToInt())
      val smoothMask = gaussianBlurFloat(rawSmoothMask, cropW, cropH, smoothBlurRadius)

      // 3. Compute faceMeanL and heavily blurred L* (radius ~12% face width) for EVEN LIGHTING
      val cropL = FloatArray(cropW * cropH)
      var sumToneWeight = 0.0
      var sumToneL = 0.0
      for (i in 0 until cropW * cropH) {
        val cp = cropPixels[i]
        val cr = (cp shr 16) and 0xFF
        val cg = (cp shr 8) and 0xFF
        val cb = cp and 0xFF
        val l = rgbToLstar(cr, cg, cb)
        cropL[i] = l
        val tm = toneMask[i]
        if (tm > 0.05f) {
          sumToneWeight += tm
          sumToneL += l * tm
        }
      }
      val faceMeanL = if (sumToneWeight > 0.0) (sumToneL / sumToneWeight).toFloat() else 50f
      val lBlurRadius = max(2, (cropW * 0.12f).roundToInt())
      val lBlur = gaussianBlurFloat(cropL, cropW, cropH, lBlurRadius)

      // 4. Bilateral smoothing with smoothMask + Even lighting & Face tone with toneMask
      val radius = 5
      val outCropPixels = cropPixels.clone()

      for (y in 0 until cropH) {
        val rowOffset = y * cropW
        for (x in 0 until cropW) {
          val idx = rowOffset + x
          val tMaskVal = toneMask[idx]
          val sMaskVal = smoothMask[idx]

          if (tMaskVal < 0.01f && sMaskVal < 0.01f) continue

          val centerPixel = cropPixels[idx]
          val cr = (centerPixel shr 16) and 0xFF
          val cg = (centerPixel shr 8) and 0xFF
          val cb = centerPixel and 0xFF

          // Bilateral filter for skin smoothing (only if sMaskVal > 0.02f)
          var blendedR = cr
          var blendedG = cg
          var blendedB = cb

          if (sMaskVal > 0.02f) {
            var sumR = 0f
            var sumG = 0f
            var sumB = 0f
            var totalWeight = 0f

            val yStart = max(0, y - radius)
            val yEnd = min(cropH - 1, y + radius)
            val xStart = max(0, x - radius)
            val xEnd = min(cropW - 1, x + radius)

            for (ny in yStart..yEnd) {
              val nRowOffset = ny * cropW
              val dy = ny - y
              for (nx in xStart..xEnd) {
                val dx = nx - x
                val spatialDistSq = dx * dx + dy * dy
                if (spatialDistSq > radius * radius) continue

                val np = cropPixels[nRowOffset + nx]
                val nr = (np shr 16) and 0xFF
                val ng = (np shr 8) and 0xFF
                val nb = np and 0xFF

                val colorDist = abs(cr - nr) + abs(cg - ng) + abs(cb - nb)
                val rangeWeight = (1.0f - (colorDist / 60f)).coerceAtLeast(0f)
                if (rangeWeight <= 0f) continue

                val spatialWeight = 1.0f - (sqrt(spatialDistSq.toFloat()) / (radius + 1))
                val weight = spatialWeight * rangeWeight

                sumR += nr * weight
                sumG += ng * weight
                sumB += nb * weight
                totalWeight += weight
              }
            }

            if (totalWeight > 0.001f) {
              val smoothR = sumR / totalWeight
              val smoothG = sumG / totalWeight
              val smoothB = sumB / totalWeight
              val blendAlpha = (smoothingStrength * sMaskVal).coerceIn(0f, 1f)
              blendedR = ((1f - blendAlpha) * cr + blendAlpha * smoothR).roundToInt().coerceIn(0, 255)
              blendedG = ((1f - blendAlpha) * cg + blendAlpha * smoothG).roundToInt().coerceIn(0, 255)
              blendedB = ((1f - blendAlpha) * cb + blendAlpha * smoothB).roundToInt().coerceIn(0, 255)
            }
          }

          if (tMaskVal > 0.01f) {
            val faceLab = rgbToLab(blendedR, blendedG, blendedB)
            val curL = faceLab[0]
            val curA = faceLab[1]
            val curB = faceLab[2]

            // 3. EVEN LIGHTING: L' = L + 0.4 * (faceMeanL - Lblur) * toneMask
            val evenL = curL + 0.40f * (faceMeanL - lBlur[idx]) * tMaskVal

            // 2. FACE TONE: L* +9 * faceRelightScale, a* +5, b* +6 (scaled by intensity, faceRelightScale, applyColor, toneMask)
            val toneMultiplier = intensity * tMaskVal
            val targetL = (evenL + 9.0f * faceRelightScale * toneMultiplier).coerceIn(0f, 100f)
            val targetA = if (applyColor) curA + 5.0f * faceRelightScale * toneMultiplier else curA
            val targetB = if (applyColor) curB + 6.0f * faceRelightScale * toneMultiplier else curB

            val clampedChroma = if (applyColor) {
              clampChromaToSrgbGamut(targetL, targetA, targetB)
            } else {
              floatArrayOf(targetA, targetB)
            }
            outCropPixels[idx] = labToRgb(targetL, clampedChroma[0], clampedChroma[1])
          } else {
            outCropPixels[idx] = (0xFF shl 24) or (blendedR shl 16) or (blendedG shl 8) or blendedB
          }
        }
      }

      // Write enhanced face crop back to the bitmap
      bitmap.setPixels(outCropPixels, 0, cropW, left, top, cropW, cropH)
    }
  }

  private fun softExcludeEllipse(
    mask: FloatArray,
    w: Int,
    h: Int,
    cx: Float,
    cy: Float,
    rx: Float,
    ry: Float
  ) {
    if (rx <= 0f || ry <= 0f) return
    val xMin = max(0, (cx - rx).toInt())
    val xMax = min(w - 1, (cx + rx + 1).toInt())
    val yMin = max(0, (cy - ry).toInt())
    val yMax = min(h - 1, (cy + ry + 1).toInt())

    for (y in yMin..yMax) {
      val dy = (y - cy) / ry
      val dySq = dy * dy
      if (dySq >= 1f) continue
      val rowOffset = y * w
      for (x in xMin..xMax) {
        val dx = (x - cx) / rx
        val distSq = dx * dx + dySq
        if (distSq < 1f) {
          // Soft ellipse transition: 0 at center up to 1 at perimeter
          val t = if (distSq < 0.25f) 0f else ((distSq - 0.25f) / 0.75f).coerceIn(0f, 1f)
          val factor = t * t * (3f - 2f * t)
          mask[rowOffset + x] *= factor
        }
      }
    }
  }

  private fun gaussianBlurFloat(input: FloatArray, w: Int, h: Int, radius: Int): FloatArray {
    if (radius <= 0 || w <= 0 || h <= 0) return input.clone()
    val sigma = max(0.5f, radius / 2.0f)
    val twoSigmaSq = 2f * sigma * sigma
    val kSize = radius * 2 + 1
    val kernel = FloatArray(kSize)
    var kSum = 0f
    for (i in -radius..radius) {
      val wgt = exp(-(i * i) / twoSigmaSq)
      kernel[i + radius] = wgt
      kSum += wgt
    }
    for (i in 0 until kSize) {
      kernel[i] /= kSum
    }

    val temp = FloatArray(w * h)
    val output = FloatArray(w * h)

    // Horizontal pass
    for (y in 0 until h) {
      val row = y * w
      for (x in 0 until w) {
        var sum = 0f
        for (k in -radius..radius) {
          val px = (x + k).coerceIn(0, w - 1)
          sum += input[row + px] * kernel[k + radius]
        }
        temp[row + x] = sum
      }
    }

    // Vertical pass
    for (x in 0 until w) {
      for (y in 0 until h) {
        var sum = 0f
        for (k in -radius..radius) {
          val py = (y + k).coerceIn(0, h - 1)
          sum += temp[py * w + x] * kernel[k + radius]
        }
        output[y * w + x] = sum
      }
    }

    return output
  }

  private fun boxBlurFloat(input: FloatArray, w: Int, h: Int, radius: Int): FloatArray {
    if (radius <= 0 || w <= 0 || h <= 0) return input.clone()
    val temp = FloatArray(w * h)
    val output = FloatArray(w * h)

    // Horizontal pass
    for (y in 0 until h) {
      val row = y * w
      var sum = 0f
      val count = radius * 2 + 1
      for (x in -radius..radius) {
        sum += input[row + x.coerceIn(0, w - 1)]
      }
      for (x in 0 until w) {
        temp[row + x] = sum / count
        val xRemove = (x - radius).coerceIn(0, w - 1)
        val xAdd = (x + radius + 1).coerceIn(0, w - 1)
        sum += input[row + xAdd] - input[row + xRemove]
      }
    }

    // Vertical pass
    for (x in 0 until w) {
      var sum = 0f
      val count = radius * 2 + 1
      for (y in -radius..radius) {
        sum += temp[y.coerceIn(0, h - 1) * w + x]
      }
      for (y in 0 until h) {
        output[y * w + x] = sum / count
        val yRemove = (y - radius).coerceIn(0, h - 1)
        val yAdd = (y + radius + 1).coerceIn(0, h - 1)
        sum += temp[yAdd * w + x] - temp[yRemove * w + x]
      }
    }

    return output
  }

  private fun sampleBilinear(grid: FloatArray, w: Int, h: Int, x: Float, y: Float): Float {
    val x0 = x.toInt().coerceIn(0, w - 1)
    val y0 = y.toInt().coerceIn(0, h - 1)
    val x1 = (x0 + 1).coerceIn(0, w - 1)
    val y1 = (y0 + 1).coerceIn(0, h - 1)
    val fx = x - x0
    val fy = y - y0

    val v00 = grid[y0 * w + x0]
    val v10 = grid[y0 * w + x1]
    val v01 = grid[y1 * w + x0]
    val v11 = grid[y1 * w + x1]

    val top = (1f - fx) * v00 + fx * v10
    val bottom = (1f - fx) * v01 + fx * v11
    return (1f - fy) * top + fy * bottom
  }

  /**
   * Compares the before and after enhancement on a downscaled ~512px copy.
   * Calculates:
   * 1. Mean color shift (CIE delta E 1976 = sqrt((dL)^2 + (da)^2 + (db)^2))
   * 2. Face region shift (if faces are present)
   *
   * @return Pair(meanDeltaE, faceDeltaE)
   */
  fun computeDeltaEAndFaceShift(
    original: Bitmap,
    enhanced: Bitmap,
    faces: List<FaceDetectorOfflineHelper.DetectedFaceBox> = emptyList()
  ): Pair<Float, Float> {
    val maxDim = max(original.width, original.height)
    val scale = if (maxDim > 512) 512f / maxDim else 1.0f
    val dw = max(1, (original.width * scale).roundToInt())
    val dh = max(1, (original.height * scale).roundToInt())

    val dsOrig = if (original.width == dw && original.height == dh) {
      original
    } else {
      Bitmap.createScaledBitmap(original, dw, dh, true)
    }

    val dsEnh = if (enhanced.width == dw && enhanced.height == dh) {
      enhanced
    } else {
      Bitmap.createScaledBitmap(enhanced, dw, dh, true)
    }

    val origPixels = IntArray(dw * dh)
    val enhPixels = IntArray(dw * dh)
    dsOrig.getPixels(origPixels, 0, dw, 0, 0, dw, dh)
    dsEnh.getPixels(enhPixels, 0, dw, 0, 0, dw, dh)

    var sumDeltaE = 0.0
    val totalPixels = dw * dh

    // Scale face boxes to downscaled space
    val scaleX = dw.toFloat() / original.width
    val scaleY = dh.toFloat() / original.height
    val scaledFaceRects = faces.map { face ->
      Rect(
        (face.rect.left * scaleX).toInt(),
        (face.rect.top * scaleY).toInt(),
        (face.rect.right * scaleX).toInt(),
        (face.rect.bottom * scaleY).toInt()
      )
    }

    var faceSumDeltaE = 0.0
    var facePixelCount = 0

    for (y in 0 until dh) {
      val row = y * dw
      for (x in 0 until dw) {
        val op = origPixels[row + x]
        val ep = enhPixels[row + x]

        val ol = rgbToLab((op shr 16) and 0xFF, (op shr 8) and 0xFF, op and 0xFF)
        val el = rgbToLab((ep shr 16) and 0xFF, (ep shr 8) and 0xFF, ep and 0xFF)

        val dL = ol[0] - el[0]
        val da = ol[1] - el[1]
        val db = ol[2] - el[2]
        val de = sqrt(dL * dL + da * da + db * db)

        sumDeltaE += de

        if (scaledFaceRects.isNotEmpty() && scaledFaceRects.any { it.contains(x, y) }) {
          faceSumDeltaE += de
          facePixelCount++
        }
      }
    }

    if (dsOrig != original) dsOrig.recycle()
    if (dsEnh != enhanced) dsEnh.recycle()

    val meanDeltaE = if (totalPixels > 0) (sumDeltaE / totalPixels).toFloat() else 0f
    val faceDeltaE = if (facePixelCount > 0) (faceSumDeltaE / facePixelCount).toFloat() else 0f
    return Pair(meanDeltaE, faceDeltaE)
  }
}

