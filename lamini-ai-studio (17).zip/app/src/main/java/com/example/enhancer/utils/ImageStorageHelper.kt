package com.example.enhancer.utils

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import com.example.enhancer.model.ExportFormat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object ImageStorageHelper {

  data class SaveResult(
    val uri: Uri?,
    val displayPath: String,
    val fileName: String,
    val sizeBytes: Long,
    val mimeType: String,
    val width: Int,
    val height: Int
  )

  suspend fun saveBitmapToGallery(
    context: Context,
    bitmap: Bitmap,
    format: ExportFormat
  ): Result<SaveResult> = withContext(Dispatchers.IO) {
    try {
      val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
      val fileName = "Lamini_Enhanced_${timeStamp}.${format.extension}"

      val compressFormat = when (format) {
        ExportFormat.PNG -> Bitmap.CompressFormat.PNG
        ExportFormat.JPEG -> Bitmap.CompressFormat.JPEG
        ExportFormat.WEBP -> {
          if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Bitmap.CompressFormat.WEBP_LOSSLESS
          } else {
            @Suppress("DEPRECATION")
            Bitmap.CompressFormat.WEBP
          }
        }
      }

      val quality = if (format == ExportFormat.JPEG) 95 else 100

      // Calculate actual encoded bytes
      val byteStream = ByteArrayOutputStream()
      bitmap.compress(compressFormat, quality, byteStream)
      val encodedBytes = byteStream.toByteArray()
      val actualSizeBytes = encodedBytes.size.toLong()

      var savedUri: Uri? = null
      val displayPath: String

      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        val contentValues = ContentValues().apply {
          put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
          put(MediaStore.MediaColumns.MIME_TYPE, format.mimeType)
          put(
            MediaStore.MediaColumns.RELATIVE_PATH,
            "${Environment.DIRECTORY_PICTURES}/Lamini"
          )
          put(MediaStore.MediaColumns.IS_PENDING, 1)
        }

        val resolver = context.contentResolver
        savedUri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
          ?: return@withContext Result.failure(Exception("Could not create MediaStore entry."))

        val outputStream: OutputStream = resolver.openOutputStream(savedUri)
          ?: return@withContext Result.failure(Exception("Could not open MediaStore stream."))

        outputStream.write(encodedBytes)
        outputStream.flush()
        outputStream.close()

        contentValues.clear()
        contentValues.put(MediaStore.MediaColumns.IS_PENDING, 0)
        resolver.update(savedUri, contentValues, null, null)

        displayPath = "Gallery / Pictures / Lamini / $fileName"

        // Verify reopened stream to ensure integrity
        resolver.openInputStream(savedUri)?.use { verifyStream ->
          val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
          BitmapFactory.decodeStream(verifyStream, null, opts)
          if (opts.outWidth <= 0 || opts.outHeight <= 0) {
            return@withContext Result.failure(IllegalStateException("Saved file verification failed: Invalid image header."))
          }
        }
      } else {
        val picturesDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
        val laminiDir = File(picturesDir, "Lamini")
        if (!laminiDir.exists()) laminiDir.mkdirs()

        val destFile = File(laminiDir, fileName)
        val outputStream = FileOutputStream(destFile)
        outputStream.write(encodedBytes)
        outputStream.flush()
        outputStream.close()

        @Suppress("DEPRECATION")
        MediaStore.Images.Media.insertImage(
          context.contentResolver,
          destFile.absolutePath,
          fileName,
          "Enhanced with Lamini AI Studio"
        )

        displayPath = destFile.absolutePath

        // Verify reopened file
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(destFile.absolutePath, opts)
        if (opts.outWidth <= 0 || opts.outHeight <= 0) {
          return@withContext Result.failure(IllegalStateException("Saved file verification failed."))
        }
      }

      val result = SaveResult(
        uri = savedUri,
        displayPath = displayPath,
        fileName = fileName,
        sizeBytes = actualSizeBytes,
        mimeType = format.mimeType,
        width = bitmap.width,
        height = bitmap.height
      )

      Result.success(result)
    } catch (e: Exception) {
      Result.failure(Exception("Failed to save HD photo: ${e.localizedMessage ?: "Storage error"}"))
    }
  }

  suspend fun shareBitmap(context: Context, bitmap: Bitmap): Result<Unit> = withContext(Dispatchers.IO) {
    try {
      val cachePath = File(context.cacheDir, "shared_images")
      cachePath.mkdirs()
      val file = File(cachePath, "lamini_enhanced_share.jpg")
      val stream = FileOutputStream(file)
      bitmap.compress(Bitmap.CompressFormat.JPEG, 95, stream)
      stream.close()

      val contentUri = FileProvider.getUriForFile(
        context,
        "${context.packageName}.fileprovider",
        file
      )

      val shareIntent = Intent(Intent.ACTION_SEND).apply {
        type = "image/jpeg"
        putExtra(Intent.EXTRA_STREAM, contentUri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
      }

      val chooser = Intent.createChooser(shareIntent, "Share Enhanced HD Photo").apply {
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      }
      context.startActivity(chooser)

      Result.success(Unit)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }
}
