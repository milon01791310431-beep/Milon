package com.example.enhancer.ui.components

import android.graphics.Bitmap
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.CompareArrows
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.CardBackground
import com.example.ui.theme.MainBackground
import com.example.ui.theme.PrimaryGradient
import com.example.ui.theme.PrimaryPurple
import com.example.ui.theme.SecondaryBackground
import com.example.ui.theme.SecondaryBlue
import kotlin.math.roundToInt

@Composable
fun ComparisonSliderView(
  originalBitmap: Bitmap,
  enhancedBitmap: Bitmap,
  sliderPosition: Float,
  onSliderPositionChange: (Float) -> Unit,
  modifier: Modifier = Modifier
) {
  val originalImageBitmap = remember(originalBitmap) { originalBitmap.asImageBitmap() }
  val enhancedImageBitmap = remember(enhancedBitmap) { enhancedBitmap.asImageBitmap() }

  BoxWithConstraints(
    modifier = modifier
      .clip(RoundedCornerShape(20.dp))
      .background(CardBackground)
      .testTag("comparison_slider_container")
  ) {
    val totalWidthPx = constraints.maxWidth.toFloat()
    val totalHeightPx = constraints.maxHeight.toFloat()
    val dividerX = (sliderPosition * totalWidthPx).coerceIn(0f, totalWidthPx)

    // Canvas drawing both bitmaps with split clipping
    Canvas(
      modifier = Modifier
        .fillMaxSize()
        .pointerInput(totalWidthPx) {
          detectTapGestures { tapOffset ->
            val newRatio = (tapOffset.x / totalWidthPx).coerceIn(0f, 1f)
            onSliderPositionChange(newRatio)
          }
        }
        .pointerInput(totalWidthPx) {
          detectDragGestures { change, _ ->
            change.consume()
            val newRatio = (change.position.x / totalWidthPx).coerceIn(0f, 1f)
            onSliderPositionChange(newRatio)
          }
        }
    ) {
      val canvasW = size.width
      val canvasH = size.height

      // 1. Draw Right Side: Enhanced Image
      val rightClipPath = Path().apply {
        moveTo(dividerX, 0f)
        lineTo(canvasW, 0f)
        lineTo(canvasW, canvasH)
        lineTo(dividerX, canvasH)
        close()
      }
      clipPath(rightClipPath) {
        drawImage(
          image = enhancedImageBitmap,
          dstSize = IntSize(canvasW.roundToInt(), canvasH.roundToInt()),
          dstOffset = androidx.compose.ui.unit.IntOffset.Zero
        )
      }

      // 2. Draw Left Side: Original Image
      val leftClipPath = Path().apply {
        moveTo(0f, 0f)
        lineTo(dividerX, 0f)
        lineTo(dividerX, canvasH)
        lineTo(0f, canvasH)
        close()
      }
      clipPath(leftClipPath) {
        drawImage(
          image = originalImageBitmap,
          dstSize = IntSize(canvasW.roundToInt(), canvasH.roundToInt()),
          dstOffset = androidx.compose.ui.unit.IntOffset.Zero
        )
      }

      // 3. Draw vertical divider bar with subtle glow
      drawLine(
        color = AccentCyan.copy(alpha = 0.45f),
        start = Offset(dividerX, 0f),
        end = Offset(dividerX, canvasH),
        strokeWidth = 6.dp.toPx()
      )
      drawLine(
        color = Color.White,
        start = Offset(dividerX, 0f),
        end = Offset(dividerX, canvasH),
        strokeWidth = 2.dp.toPx()
      )
    }

    // Draggable center circular handle
    val density = LocalDensity.current
    val handleSize = 44.dp
    val handleSizePx = with(density) { handleSize.toPx() }
    val handleOffsetX = (dividerX - handleSizePx / 2f).coerceIn(4f, totalWidthPx - handleSizePx - 4f)

    Box(
      modifier = Modifier
        .offset { IntOffset(handleOffsetX.roundToInt(), (totalHeightPx / 2f - handleSizePx / 2f).roundToInt()) }
        .size(handleSize)
        .shadow(12.dp, CircleShape, spotColor = PrimaryPurple)
        .background(MainBackground, CircleShape)
        .clip(CircleShape)
        .pointerInput(totalWidthPx) {
          detectDragGestures { change, _ ->
            change.consume()
            val newRatio = (change.position.x + handleOffsetX) / totalWidthPx
            onSliderPositionChange(newRatio.coerceIn(0f, 1f))
          }
        }
        .testTag("slider_handle"),
      contentAlignment = Alignment.Center
    ) {
      Box(
        modifier = Modifier
          .size(38.dp)
          .clip(CircleShape)
          .background(PrimaryGradient),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          imageVector = Icons.AutoMirrored.Filled.CompareArrows,
          contentDescription = "Slide to compare before and after",
          tint = Color.White,
          modifier = Modifier.size(22.dp)
        )
      }
    }

    // "ORIGINAL" Badge (Left side)
    Surface(
      shape = RoundedCornerShape(10.dp),
      color = Color.Black.copy(alpha = 0.65f),
      modifier = Modifier
        .align(Alignment.TopStart)
        .padding(14.dp)
    ) {
      Text(
        text = "ORIGINAL",
        color = Color.White.copy(alpha = 0.85f),
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.sp,
        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
      )
    }

    // "ENHANCED ✨" Badge (Right side)
    Surface(
      shape = RoundedCornerShape(10.dp),
      color = PrimaryPurple.copy(alpha = 0.90f),
      modifier = Modifier
        .align(Alignment.TopEnd)
        .padding(14.dp)
    ) {
      Text(
        text = "ENHANCED ✨",
        color = Color.White,
        fontSize = 11.sp,
        fontWeight = FontWeight.ExtraBold,
        letterSpacing = 1.sp,
        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
      )
    }

    // Interaction hint at bottom center
    Surface(
      shape = RoundedCornerShape(20.dp),
      color = Color.Black.copy(alpha = 0.55f),
      modifier = Modifier
        .align(Alignment.BottomCenter)
        .padding(bottom = 12.dp)
    ) {
      Text(
        text = "Drag slider or tap anywhere to inspect",
        color = Color.White.copy(alpha = 0.75f),
        fontSize = 11.sp,
        modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
      )
    }
  }
}
