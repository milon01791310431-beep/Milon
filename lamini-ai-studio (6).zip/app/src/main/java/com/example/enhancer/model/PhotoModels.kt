package com.example.enhancer.model

enum class AppTab(val title: String) {
  HOME("হোম"),
  ENHANCE("প্রিভিউ"),
  HISTORY("হিস্ট্রি"),
  SETTINGS("সেটিংস")
}

enum class WorkflowStep {
  IDLE,
  PROCESSING,
  RESULT
}

enum class EnhancementMode(val displayName: String, val description: String) {
  BALANCED("Balanced", "ক্লিন ফেস ও ন্যাচারাল ডিটেইল এনহান্সমেন্ট"),
  HIGH_DETAIL("High Detail", "উচ্চ স্পষ্টতা এবং মাইক্রো-টেক্সচার শার্পনিং"),
  FACE_RESTORATION("Face Restoration", "মুখমণ্ডলের স্পষ্টতা ও চোখ-ত্বক পুনরুদ্ধার")
}

enum class UpscaleFactor(val factor: Int, val label: String) {
  X2(2, "Full HD (2×)"),
  X4(4, "Ultra HD (4×)")
}

enum class EngineType(val displayName: String) {
  ONNX_LOCAL_AI("অন-ডিভাইস AI মডেল (Real-ESRGAN / GFPGAN)"),
  BUILT_IN_CV("বেসিক এনহান্সমেন্ট (Classical CV)")
}

enum class EngineStatus(val label: String) {
  READY("প্রস্তুত (Ready)"),
  LOADING("লোড হচ্ছে..."),
  NOT_CONFIGURED("মডেল নেই (Not Installed)"),
  PROCESSING("প্রসেসিং..."),
  ERROR("ত্রুটি (Error)")
}

data class EngineStatusInfo(
  val engineType: EngineType,
  val status: EngineStatus,
  val modelName: String,
  val modelVersion: String? = null,
  val runtimeEnvironment: String,
  val computeDevice: String? = null,
  val statusMessage: String,
  val isNeuralAi: Boolean = false,
  val supportedScales: List<Int> = listOf(2, 4),
  val supportsFaceRestoration: Boolean = false,
  val diagnosticNotes: String? = null
)

enum class ModelSlotType(val title: String, val recommendedFileName: String) {
  IMAGE_MODEL("Image model (Real-ESRGAN .onnx)", "image_model.onnx"),
  FACE_MODEL("Face model (GFPGAN/CodeFormer .onnx)", "face_model.onnx")
}

data class ModelSlotInfo(
  val slotType: ModelSlotType,
  val title: String,
  val recommendedFileName: String,
  val isInstalled: Boolean,
  val fileSizeBytes: Long = 0L,
  val filePath: String? = null,
  val modelDescription: String = "",
  val errorMessage: String? = null
) {
  val formattedSize: String
    get() {
      if (fileSizeBytes <= 0) return "0 MB"
      val mb = fileSizeBytes / (1024.0 * 1024.0)
      return String.format(java.util.Locale.US, "%.1f MB", mb)
    }
}

enum class ExportFormat(val extension: String, val mimeType: String, val label: String) {
  JPEG("jpg", "image/jpeg", "JPG (Quality 95 - প্রস্তাবিত)"),
  PNG("png", "image/png", "PNG (Lossless Quality)"),
  WEBP("webp", "image/webp", "WebP (Compact)")
}

data class ImageMetadata(
  val width: Int,
  val height: Int,
  val sizeBytes: Long,
  val mimeType: String,
  val fileName: String? = null,
  val modelIdentifier: String? = null,
  val enhancementMode: String? = null,
  val upscaleFactor: String? = null
) {
  val formattedDimensions: String
    get() = "${width} × ${height} px"

  val formattedSize: String
    get() {
      if (sizeBytes <= 0) return "0 B"
      val kb = sizeBytes / 1024.0
      val mb = kb / 1024.0
      return if (mb >= 1.0) {
        String.format(java.util.Locale.US, "%.2f MB", mb)
      } else {
        String.format(java.util.Locale.US, "%.1f KB", kb)
      }
    }
}

data class EnhancementConfig(
  val mode: EnhancementMode = EnhancementMode.BALANCED,
  val upscaleFactor: UpscaleFactor = UpscaleFactor.X2,
  val faceEnhancement: Boolean = true,
  val faceStrength: Float = 0.7f,
  val noiseReduction: Boolean = true,
  val sharpnessBoost: Boolean = true,
  val autoColorBalancing: Boolean = true,
  val useAiModelIfAvailable: Boolean = true
)

data class ProcessingProgress(
  val stage: String = "ছবি প্রস্তুত করা হচ্ছে...",
  val percent: Float? = 0f,
  val isIndeterminate: Boolean = false,
  val detail: String = ""
)
