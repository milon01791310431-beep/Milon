package com.example.enhancer.ui.screens

import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.enhancer.data.SampleImages
import com.example.enhancer.data.history.EnhancedPhotoEntity
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.BorderColor
import com.example.ui.theme.CardBackground
import com.example.ui.theme.CardGlowBorder
import com.example.ui.theme.MainBackground
import com.example.ui.theme.MainText
import com.example.ui.theme.PrimaryGradient
import com.example.ui.theme.PrimaryPurple
import com.example.ui.theme.SecondaryBackground
import com.example.ui.theme.SecondaryText
import com.example.ui.theme.TextMuted
import java.io.File

import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.CircularProgressIndicator
import com.example.enhancer.engine.DownloadStatus
import com.example.ui.theme.ErrorRed

@Composable
fun HomeScreen(
  recentPhotos: List<EnhancedPhotoEntity>,
  hasSelectedPhoto: Boolean = false,
  isFaceModelInstalled: Boolean = false,
  isFaceCardDismissed: Boolean = false,
  faceDownloadStatus: DownloadStatus = DownloadStatus.Idle,
  onDownloadFaceModel: () -> Unit = {},
  onCancelDownloadFaceModel: () -> Unit = {},
  onDismissFaceCard: () -> Unit = {},
  onImageSelected: (Uri) -> Unit,
  onSampleSelected: (() -> Bitmap, String) -> Unit,
  onOpenHistoryItem: (EnhancedPhotoEntity) -> Unit,
  onNavigateToHistory: () -> Unit,
  onNavigateToSettings: () -> Unit,
  onNavigateToPreview: () -> Unit,
  modifier: Modifier = Modifier
) {
  val photoPickerLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.PickVisualMedia()
  ) { uri: Uri? ->
    if (uri != null) {
      onImageSelected(uri)
    }
  }

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(MainBackground)
      .verticalScroll(rememberScrollState())
      .padding(horizontal = 20.dp, vertical = 12.dp)
  ) {
    // Top Header
    HomeTopHeader(onOpenSettings = onNavigateToSettings)

    Spacer(modifier = Modifier.height(20.dp))

    // Welcome Hero
    WelcomeHeroSection()

    // Optional Face Model Download Card
    if (!isFaceModelInstalled && !isFaceCardDismissed) {
      Spacer(modifier = Modifier.height(20.dp))
      FaceModelDownloadCard(
        status = faceDownloadStatus,
        onDownload = onDownloadFaceModel,
        onCancel = onCancelDownloadFaceModel,
        onDismiss = onDismissFaceCard
      )
    }

    Spacer(modifier = Modifier.height(24.dp))

    // Step 1: ONE Big Button "ছবি বাছুন" (Pick photo)
    MainUploadCard(
      onChooseFromGallery = {
        photoPickerLauncher.launch(
          PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
        )
      },
      onTakeSamplePhoto = {
        val sample = SampleImages.samplePhotos.first()
        onSampleSelected(sample.generator, sample.title)
      }
    )

    if (hasSelectedPhoto) {
      Spacer(modifier = Modifier.height(16.dp))
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = SecondaryBackground),
        border = androidx.compose.foundation.BorderStroke(1.dp, PrimaryPurple.copy(alpha = 0.5f)),
        modifier = Modifier
          .fillMaxWidth()
          .clickable { onNavigateToPreview() }
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(14.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.PhotoLibrary, contentDescription = null, tint = AccentCyan)
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text("একটি ছবি লোড করা আছে", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MainText)
              Text("প্রিভিউ দেখতে ও Full HD করতে ট্যাপ করুন", fontSize = 12.sp, color = SecondaryText)
            }
          }
          Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = PrimaryPurple)
        }
      }
    }

    Spacer(modifier = Modifier.height(28.dp))

    // History section (small history tab / list)
    RecentHistorySection(
      recentPhotos = recentPhotos,
      onOpenItem = onOpenHistoryItem,
      onViewAllHistory = onNavigateToHistory,
      onPickPhoto = {
        photoPickerLauncher.launch(
          PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
        )
      }
    )

    Spacer(modifier = Modifier.height(36.dp))
  }
}

@Composable
private fun HomeTopHeader(onOpenSettings: () -> Unit) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically
  ) {
    Row(verticalAlignment = Alignment.CenterVertically) {
      Box(
        modifier = Modifier
          .size(42.dp)
          .clip(CircleShape)
          .background(PrimaryGradient)
          .padding(2.dp)
      ) {
        Surface(
          shape = CircleShape,
          color = CardBackground,
          modifier = Modifier.fillMaxSize()
        ) {
          Box(contentAlignment = Alignment.Center) {
            Icon(
              imageVector = Icons.Default.AutoAwesome,
              contentDescription = "Logo",
              tint = AccentCyan,
              modifier = Modifier.size(20.dp)
            )
          }
        }
      }

      Spacer(modifier = Modifier.width(12.dp))

      Column {
        Text(
          text = "Lamini AI Studio",
          fontSize = 19.sp,
          fontWeight = FontWeight.Bold,
          color = MainText
        )
        Text(
          text = "Offline On-Device Enhancer",
          fontSize = 12.sp,
          color = SecondaryText
        )
      }
    }

    IconButton(
      onClick = onOpenSettings,
      modifier = Modifier
        .clip(CircleShape)
        .background(SecondaryBackground)
        .size(42.dp)
        .testTag("home_settings_button")
    ) {
      Icon(
        imageVector = Icons.Default.Settings,
        contentDescription = "Open Settings",
        tint = SecondaryText,
        modifier = Modifier.size(20.dp)
      )
    }
  }
}

@Composable
private fun WelcomeHeroSection() {
  Box(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(22.dp))
      .background(
        Brush.radialGradient(
          colors = listOf(PrimaryPurple.copy(alpha = 0.22f), SecondaryBackground.copy(alpha = 0.5f), Color.Transparent),
          radius = 500f
        )
      )
      .padding(vertical = 14.dp, horizontal = 6.dp)
  ) {
    Column {
      Text(
        text = "Make Every Photo Look Amazing",
        fontSize = 24.sp,
        fontWeight = FontWeight.ExtraBold,
        color = MainText,
        lineHeight = 31.sp
      )
      Spacer(modifier = Modifier.height(6.dp))
      Text(
        text = "100% অফলাইনে আপনার ছবির কোয়ালিটি Full HD করুন।",
        fontSize = 13.sp,
        color = SecondaryText,
        lineHeight = 18.sp
      )
    }
  }
}

@Composable
private fun MainUploadCard(
  onChooseFromGallery: () -> Unit,
  onTakeSamplePhoto: () -> Unit
) {
  Card(
    shape = RoundedCornerShape(24.dp),
    colors = CardDefaults.cardColors(containerColor = CardBackground),
    border = androidx.compose.foundation.BorderStroke(1.5.dp, CardGlowBorder),
    modifier = Modifier
      .fillMaxWidth()
      .shadow(16.dp, RoundedCornerShape(24.dp), spotColor = PrimaryPurple)
      .testTag("main_upload_card")
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(24.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
          .size(76.dp)
          .clip(CircleShape)
          .background(PrimaryPurple.copy(alpha = 0.18f))
          .border(1.dp, PrimaryPurple.copy(alpha = 0.45f), CircleShape)
      ) {
        Icon(
          imageVector = Icons.Default.AddPhotoAlternate,
          contentDescription = null,
          tint = AccentCyan,
          modifier = Modifier.size(38.dp)
        )
      }

      Spacer(modifier = Modifier.height(16.dp))

      Text(
        text = "ছবি এনহান্স করুন",
        fontSize = 21.sp,
        fontWeight = FontWeight.Bold,
        color = MainText
      )

      Spacer(modifier = Modifier.height(6.dp))

      Text(
        text = "গ্যালারি থেকে ছবি সিলেক্ট করুন এবং সরাসরি Full HD রেজোলিউশনে কনভার্ট করুন।",
        fontSize = 13.sp,
        color = SecondaryText,
        textAlign = TextAlign.Center,
        lineHeight = 18.sp
      )

      Spacer(modifier = Modifier.height(24.dp))

      // ONE BIG BUTTON: "ছবি বাছুন" (Pick photo)
      Button(
        onClick = onChooseFromGallery,
        shape = RoundedCornerShape(18.dp),
        colors = ButtonDefaults.buttonColors(
          containerColor = Color.Transparent,
          contentColor = MainText
        ),
        modifier = Modifier
          .fillMaxWidth()
          .height(58.dp)
          .background(PrimaryGradient, RoundedCornerShape(18.dp))
          .shadow(12.dp, RoundedCornerShape(18.dp), spotColor = PrimaryPurple)
          .testTag("choose_from_gallery_button")
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.Center
        ) {
          Icon(
            imageVector = Icons.Default.PhotoLibrary,
            contentDescription = null,
            tint = MainText,
            modifier = Modifier.size(22.dp)
          )
          Spacer(modifier = Modifier.width(10.dp))
          Text(
            text = "ছবি বাছুন",
            fontSize = 17.sp,
            fontWeight = FontWeight.ExtraBold,
            color = MainText
          )
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      OutlinedButton(
        onClick = onTakeSamplePhoto,
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = SecondaryText),
        border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor),
        modifier = Modifier
          .fillMaxWidth()
          .height(44.dp)
          .testTag("try_sample_button")
      ) {
        Icon(
          imageVector = Icons.Default.AutoAwesome,
          contentDescription = null,
          tint = AccentCyan,
          modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = "নমুনা ছবি দিয়ে ট্রাই করুন",
          fontSize = 13.sp,
          fontWeight = FontWeight.Medium
        )
      }
    }
  }
}

@Composable
private fun RecentHistorySection(
  recentPhotos: List<EnhancedPhotoEntity>,
  onOpenItem: (EnhancedPhotoEntity) -> Unit,
  onViewAllHistory: () -> Unit,
  onPickPhoto: () -> Unit
) {
  Column(modifier = Modifier.fillMaxWidth()) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.History, contentDescription = null, tint = AccentCyan, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = "পূর্ববর্তী কাজ (History)",
          fontSize = 16.sp,
          fontWeight = FontWeight.Bold,
          color = MainText
        )
      }

      if (recentPhotos.isNotEmpty()) {
        Text(
          text = "সব দেখুন",
          fontSize = 13.sp,
          fontWeight = FontWeight.SemiBold,
          color = AccentCyan,
          modifier = Modifier
            .clickable { onViewAllHistory() }
            .padding(4.dp)
        )
      }
    }

    Spacer(modifier = Modifier.height(12.dp))

    if (recentPhotos.isEmpty()) {
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CardBackground),
        border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(20.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          Text(
            text = "এখনও কোনো ছবি সেভ করা হয়নি",
            fontSize = 14.sp,
            fontWeight = FontWeight.SemiBold,
            color = MainText
          )
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = "আপনার প্রথম ছবি এনহান্স করে রেজাল্ট দেখুন।",
            fontSize = 12.sp,
            color = SecondaryText
          )
        }
      }
    } else {
      LazyRow(
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(horizontal = 2.dp)
      ) {
        items(recentPhotos) { photo ->
          Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = CardBackground),
            border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor),
            modifier = Modifier
              .width(130.dp)
              .clickable { onOpenItem(photo) }
          ) {
            Column {
              val file = File(photo.enhancedFilePath)
              Box(
                modifier = Modifier
                  .fillMaxWidth()
                  .height(120.dp)
                  .background(SecondaryBackground)
              ) {
                if (file.exists()) {
                  AsyncImage(
                    model = file,
                    contentDescription = "Enhanced Photo",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                  )
                }
              }
              Column(modifier = Modifier.padding(8.dp)) {
                Text(
                  text = photo.upscaleFactor,
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold,
                  color = AccentCyan
                )
                Text(
                  text = "${photo.enhancedWidth}×${photo.enhancedHeight}",
                  fontSize = 10.sp,
                  color = TextMuted
                )
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun FaceModelDownloadCard(
  status: DownloadStatus,
  onDownload: () -> Unit,
  onCancel: () -> Unit,
  onDismiss: () -> Unit,
  modifier: Modifier = Modifier
) {
  val isDownloading = status is DownloadStatus.Downloading
  val isValidating = status is DownloadStatus.Validating
  val isError = status is DownloadStatus.Error

  Card(
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = SecondaryBackground),
    border = androidx.compose.foundation.BorderStroke(1.dp, PrimaryPurple.copy(alpha = 0.6f)),
    modifier = modifier.fillMaxWidth()
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Surface(
          shape = CircleShape,
          color = PrimaryPurple.copy(alpha = 0.2f),
          modifier = Modifier.size(38.dp)
        ) {
          Box(contentAlignment = Alignment.Center) {
            Icon(
              imageVector = Icons.Default.Face,
              contentDescription = null,
              tint = AccentCyan,
              modifier = Modifier.size(22.dp)
            )
          }
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = "মুখের ডিটেইল আরও ভালো করতে ফেস মডেল ডাউনলোড করুন (প্রায় ৩৪০ MB)",
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = MainText,
            lineHeight = 18.sp
          )
          Spacer(modifier = Modifier.height(2.dp))
          Text(
            text = "GFPGAN অন-ডিভাইস রিস্টোরেশন — ইনস্টল থাকলে ফেস স্টেজ স্বয়ংক্রিয়ভাবে কাজ করবে",
            fontSize = 11.sp,
            color = SecondaryText,
            lineHeight = 15.sp
          )
        }
      }

      if (isDownloading) {
        val downloadInfo = status as DownloadStatus.Downloading
        Spacer(modifier = Modifier.height(14.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "${downloadInfo.percent}% ডাউনলোড হচ্ছে...",
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            color = AccentCyan
          )
          Text(
            text = "${downloadInfo.downloadedMb} / ${downloadInfo.totalMb} MB (${downloadInfo.speedText})",
            fontSize = 11.sp,
            color = SecondaryText
          )
        }
        Spacer(modifier = Modifier.height(8.dp))
        LinearProgressIndicator(
          progress = { downloadInfo.percent / 100f },
          modifier = Modifier
            .fillMaxWidth()
            .height(6.dp)
            .clip(RoundedCornerShape(3.dp)),
          color = AccentCyan,
          trackColor = BorderColor
        )
        Spacer(modifier = Modifier.height(12.dp))
        OutlinedButton(
          onClick = onCancel,
          colors = ButtonDefaults.outlinedButtonColors(contentColor = ErrorRed),
          border = androidx.compose.foundation.BorderStroke(1.dp, ErrorRed.copy(alpha = 0.4f)),
          shape = RoundedCornerShape(10.dp),
          modifier = Modifier.fillMaxWidth().height(38.dp)
        ) {
          Text("বাতিল করুন", fontSize = 12.sp)
        }
      } else if (isValidating) {
        Spacer(modifier = Modifier.height(14.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
          CircularProgressIndicator(modifier = Modifier.size(18.dp), color = AccentCyan, strokeWidth = 2.dp)
          Spacer(modifier = Modifier.width(8.dp))
          Text("ফেস মডেল যাচাই করা হচ্ছে...", fontSize = 12.sp, color = SecondaryText)
        }
      } else if (isError) {
        val errorInfo = status as DownloadStatus.Error
        Spacer(modifier = Modifier.height(10.dp))
        Text(
          text = errorInfo.message,
          fontSize = 11.sp,
          color = ErrorRed
        )
        Spacer(modifier = Modifier.height(10.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Button(
            onClick = onDownload,
            colors = ButtonDefaults.buttonColors(containerColor = ErrorRed),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.weight(1f).height(38.dp)
          ) {
            Text("আবার চেষ্টা করুন", fontSize = 12.sp, fontWeight = FontWeight.Bold)
          }
          OutlinedButton(
            onClick = onDismiss,
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = SecondaryText),
            border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor),
            modifier = Modifier.height(38.dp)
          ) {
            Text("পরে", fontSize = 12.sp)
          }
        }
      } else {
        Spacer(modifier = Modifier.height(14.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          Button(
            onClick = onDownload,
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
            modifier = Modifier
              .weight(1f)
              .height(40.dp)
              .background(PrimaryGradient, RoundedCornerShape(10.dp))
          ) {
            Icon(Icons.Default.FileDownload, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("ডাউনলোড করুন", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
          }

          OutlinedButton(
            onClick = onDismiss,
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = SecondaryText),
            border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor),
            modifier = Modifier.height(40.dp)
          ) {
            Text("পরে", fontSize = 13.sp)
          }
        }
      }
    }
  }
}

