package com.example.enhancer.ui.screens

import android.graphics.Bitmap
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Hd
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.ViewColumn
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.enhancer.model.EnhancementConfig
import com.example.enhancer.model.ExportFormat
import com.example.enhancer.model.ImageMetadata
import com.example.enhancer.ui.components.ComparisonSliderView
import com.example.enhancer.ui.viewmodel.ComparisonMode
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.BorderColor
import com.example.ui.theme.CardBackground
import com.example.ui.theme.CardGlowBorder
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.MainBackground
import com.example.ui.theme.MainText
import com.example.ui.theme.PrimaryGradient
import com.example.ui.theme.PrimaryPurple
import com.example.ui.theme.SecondaryBackground
import com.example.ui.theme.SecondaryBlue
import com.example.ui.theme.SecondaryText
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextMuted

@Composable
fun ResultScreen(
  originalBitmap: Bitmap,
  enhancedBitmap: Bitmap,
  originalMetadata: ImageMetadata?,
  enhancedMetadata: ImageMetadata?,
  config: EnhancementConfig,
  sliderPosition: Float,
  comparisonMode: ComparisonMode,
  exportFormat: ExportFormat,
  saveNotification: String?,
  isSaving: Boolean,
  usedEngineName: String = "",
  usedEngineIsAi: Boolean = false,
  aiUpscaleSkippedNote: String? = null,
  onSliderPositionChange: (Float) -> Unit,
  onComparisonModeChange: (ComparisonMode) -> Unit,
  onExportFormatChange: (ExportFormat) -> Unit,
  onDownload: () -> Unit,
  onShare: () -> Unit,
  onTryAgain: () -> Unit,
  onEnhanceAnother: () -> Unit,
  onDismissNotification: () -> Unit,
  modifier: Modifier = Modifier
) {
  Column(
    modifier = modifier
      .fillMaxSize()
      .background(MainBackground)
      .verticalScroll(rememberScrollState())
      .padding(horizontal = 20.dp, vertical = 12.dp)
  ) {
    // Header
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        IconButton(
          onClick = onTryAgain,
          modifier = Modifier.testTag("result_back_button")
        ) {
          Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
            contentDescription = "Back",
            tint = MainText
          )
        }
        Spacer(modifier = Modifier.width(4.dp))
        Text(
          text = "Full HD ফলাফল",
          fontSize = 19.sp,
          fontWeight = FontWeight.Bold,
          color = MainText
        )
      }

      IconButton(
        onClick = onShare,
        modifier = Modifier.testTag("result_share_button")
      ) {
        Icon(Icons.Default.Share, contentDescription = "Share", tint = AccentCyan)
      }
    }

    Spacer(modifier = Modifier.height(12.dp))

    // Save notification toast/banner
    AnimatedVisibility(
      visible = saveNotification != null,
      enter = fadeIn() + expandVertically(),
      exit = fadeOut() + shrinkVertically()
    ) {
      if (saveNotification != null) {
        val isError = saveNotification.startsWith("ত্রুটি") || saveNotification.startsWith("Error")
        Surface(
          shape = RoundedCornerShape(14.dp),
          color = if (isError) ErrorRed.copy(alpha = 0.15f) else SuccessGreen.copy(alpha = 0.15f),
          border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isError) ErrorRed else SuccessGreen
          ),
          modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 12.dp)
        ) {
          Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.weight(1f)
            ) {
              Icon(
                imageVector = Icons.Default.CheckCircle,
                contentDescription = null,
                tint = if (isError) ErrorRed else SuccessGreen,
                modifier = Modifier.size(20.dp)
              )
              Spacer(modifier = Modifier.width(10.dp))
              Text(
                text = saveNotification,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                color = MainText
              )
            }
            IconButton(onClick = onDismissNotification, modifier = Modifier.size(24.dp)) {
              Icon(Icons.Default.Close, contentDescription = "Dismiss", tint = SecondaryText, modifier = Modifier.size(16.dp))
            }
          }
        }
      }
    }

    // Engine Used Banner (MANDATORY TRANSPARENCY)
    Card(
      shape = RoundedCornerShape(14.dp),
      colors = CardDefaults.cardColors(
        containerColor = if (usedEngineIsAi) Color(0xFF13231F) else Color(0xFF221F17)
      ),
      border = androidx.compose.foundation.BorderStroke(
        1.dp,
        if (usedEngineIsAi) SuccessGreen.copy(alpha = 0.6f) else Color(0xFFF59E0B)
      ),
      modifier = Modifier.fillMaxWidth()
    ) {
      Row(
        modifier = Modifier.padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Surface(
          shape = CircleShape,
          color = if (usedEngineIsAi) SuccessGreen.copy(alpha = 0.2f) else Color(0xFFF59E0B).copy(alpha = 0.2f),
          modifier = Modifier.size(28.dp)
        ) {
          Box(contentAlignment = Alignment.Center) {
            Icon(
              imageVector = if (usedEngineIsAi) Icons.Default.Tune else Icons.Default.Memory,
              contentDescription = null,
              tint = if (usedEngineIsAi) SuccessGreen else Color(0xFFF59E0B),
              modifier = Modifier.size(16.dp)
            )
          }
        }
        Spacer(modifier = Modifier.width(10.dp))
        Column {
          Text(
            text = if (usedEngineIsAi) "ব্যবহৃত ইঞ্জিন: $usedEngineName" else usedEngineName.ifBlank { "AI মডেল নেই, বেসিক এনহান্সমেন্ট ব্যবহার হয়েছে" },
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = if (usedEngineIsAi) SuccessGreen else Color(0xFFFDE68A)
          )
          Text(
            text = if (usedEngineIsAi) "প্রকৃত অন-ডিভাইস নিউরাল নেটওয়ার্ক দ্বারা রিস্টোর করা হয়েছে" else "ক্লাসিক্যাল নন-নিউরাল CV পাইপলাইন (নয়েজ ফিল্টার, শার্পনিং ও কালার)",
            fontSize = 10.sp,
            color = SecondaryText
          )
        }
      }
    }

    if (!aiUpscaleSkippedNote.isNullOrBlank()) {
      Spacer(modifier = Modifier.height(10.dp))
      Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = SecondaryBackground),
        border = androidx.compose.foundation.BorderStroke(1.dp, AccentCyan.copy(alpha = 0.5f)),
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier.padding(12.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(
            imageVector = Icons.Default.Info,
            contentDescription = null,
            tint = AccentCyan,
            modifier = Modifier.size(18.dp)
          )
          Spacer(modifier = Modifier.width(10.dp))
          Text(
            text = aiUpscaleSkippedNote,
            fontSize = 12.sp,
            color = MainText,
            lineHeight = 16.sp,
            fontWeight = FontWeight.Medium
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(14.dp))

    // Comparison Mode Tabs
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(12.dp))
        .background(SecondaryBackground)
        .padding(4.dp),
      horizontalArrangement = Arrangement.SpaceEvenly
    ) {
      ComparisonModeTab(
        label = "স্লাইডার",
        icon = Icons.Default.ViewColumn,
        selected = comparisonMode == ComparisonMode.SPLIT_SLIDER,
        onClick = { onComparisonModeChange(ComparisonMode.SPLIT_SLIDER) },
        modifier = Modifier.weight(1f)
      )
      ComparisonModeTab(
        label = "পাশাপাশি",
        icon = Icons.Default.Visibility,
        selected = comparisonMode == ComparisonMode.SIDE_BY_SIDE,
        onClick = { onComparisonModeChange(ComparisonMode.SIDE_BY_SIDE) },
        modifier = Modifier.weight(1f)
      )
      ComparisonModeTab(
        label = "শুধু এনহান্সড",
        icon = Icons.Default.Hd,
        selected = comparisonMode == ComparisonMode.AFTER_ONLY,
        onClick = { onComparisonModeChange(ComparisonMode.AFTER_ONLY) },
        modifier = Modifier.weight(1f)
      )
    }

    Spacer(modifier = Modifier.height(14.dp))

    // Interactive Comparison Viewer
    when (comparisonMode) {
      ComparisonMode.SPLIT_SLIDER -> {
        ComparisonSliderView(
          originalBitmap = originalBitmap,
          enhancedBitmap = enhancedBitmap,
          sliderPosition = sliderPosition,
          onSliderPositionChange = onSliderPositionChange,
          modifier = Modifier
            .fillMaxWidth()
            .height(350.dp)
        )
      }
      ComparisonMode.SIDE_BY_SIDE -> {
        Column(modifier = Modifier.fillMaxWidth()) {
          Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = CardBackground),
            modifier = Modifier
              .fillMaxWidth()
              .height(190.dp)
          ) {
            Box(modifier = Modifier.fillMaxSize()) {
              androidx.compose.foundation.Image(
                bitmap = originalBitmap.asImageBitmap(),
                contentDescription = "Original",
                modifier = Modifier.fillMaxSize()
              )
              Surface(
                shape = RoundedCornerShape(bottomEnd = 8.dp),
                color = CardBackground.copy(alpha = 0.85f),
                modifier = Modifier.align(Alignment.TopStart)
              ) {
                Text("আসল (Original)", fontSize = 11.sp, color = SecondaryText, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
              }
            }
          }
          Spacer(modifier = Modifier.height(10.dp))
          Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = CardBackground),
            border = androidx.compose.foundation.BorderStroke(1.5.dp, CardGlowBorder),
            modifier = Modifier
              .fillMaxWidth()
              .height(190.dp)
          ) {
            Box(modifier = Modifier.fillMaxSize()) {
              androidx.compose.foundation.Image(
                bitmap = enhancedBitmap.asImageBitmap(),
                contentDescription = "Enhanced",
                modifier = Modifier.fillMaxSize()
              )
              Surface(
                shape = RoundedCornerShape(bottomEnd = 8.dp),
                color = PrimaryPurple.copy(alpha = 0.85f),
                modifier = Modifier.align(Alignment.TopStart)
              ) {
                Text("Full HD এনহান্সড", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MainText, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
              }
            }
          }
        }
      }
      ComparisonMode.AFTER_ONLY -> {
        Card(
          shape = RoundedCornerShape(20.dp),
          colors = CardDefaults.cardColors(containerColor = CardBackground),
          border = androidx.compose.foundation.BorderStroke(1.5.dp, CardGlowBorder),
          modifier = Modifier
            .fillMaxWidth()
            .height(350.dp)
        ) {
          Box(modifier = Modifier.fillMaxSize()) {
            androidx.compose.foundation.Image(
              bitmap = enhancedBitmap.asImageBitmap(),
              contentDescription = "Enhanced Only",
              modifier = Modifier.fillMaxSize()
            )
            Surface(
              shape = RoundedCornerShape(bottomEnd = 10.dp),
              color = PrimaryPurple.copy(alpha = 0.85f),
              modifier = Modifier.align(Alignment.TopStart)
            ) {
              Text("Full HD Result", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MainText, modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp))
            }
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(16.dp))

    // Dimension stats
    Card(
      shape = RoundedCornerShape(16.dp),
      colors = CardDefaults.cardColors(containerColor = CardBackground),
      border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor),
      modifier = Modifier.fillMaxWidth()
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(14.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text("রেজোলিউশন", fontSize = 11.sp, color = SecondaryText)
          Spacer(modifier = Modifier.height(2.dp))
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text("${originalBitmap.width} × ${originalBitmap.height}", fontSize = 12.sp, color = SecondaryText)
            Text(" ➔ ", fontSize = 12.sp, color = AccentCyan)
            Text("${enhancedBitmap.width} × ${enhancedBitmap.height} (Full HD)", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = AccentCyan)
          }
        }

        Column(horizontalAlignment = Alignment.End) {
          Text("আউটপুট সাইজ", fontSize = 11.sp, color = SecondaryText)
          Spacer(modifier = Modifier.height(2.dp))
          Text(
            enhancedMetadata?.formattedSize ?: "",
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            color = PrimaryPurple
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(16.dp))

    // Export Format Selector
    Text(
      text = "ফরম্যাট নির্বাচন",
      fontSize = 11.sp,
      fontWeight = FontWeight.Bold,
      color = TextMuted,
      letterSpacing = 1.sp
    )

    Spacer(modifier = Modifier.height(8.dp))

    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      ExportFormat.entries.forEach { format ->
        val isSelected = exportFormat == format
        Surface(
          shape = RoundedCornerShape(12.dp),
          color = if (isSelected) PrimaryPurple.copy(alpha = 0.2f) else CardBackground,
          border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isSelected) PrimaryPurple else BorderColor
          ),
          modifier = Modifier
            .weight(1f)
            .clickable { onExportFormatChange(format) }
            .testTag("export_format_${format.extension}")
        ) {
          Column(
            modifier = Modifier.padding(vertical = 10.dp, horizontal = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            Text(
              text = format.extension.uppercase(),
              fontSize = 13.sp,
              fontWeight = FontWeight.Bold,
              color = if (isSelected) AccentCyan else MainText
            )
            Text(
              text = when (format) {
                ExportFormat.JPEG -> "Quality 95"
                ExportFormat.PNG -> "Lossless"
                ExportFormat.WEBP -> "Compact"
              },
              fontSize = 10.sp,
              color = TextMuted
            )
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(20.dp))

    // STEP 3 PRIMARY BUTTON 1: "Gallery-তে সেভ করুন"
    Button(
      onClick = onDownload,
      enabled = !isSaving,
      shape = RoundedCornerShape(18.dp),
      colors = ButtonDefaults.buttonColors(
        containerColor = Color.Transparent,
        contentColor = MainText
      ),
      modifier = Modifier
        .fillMaxWidth()
        .height(58.dp)
        .shadow(16.dp, RoundedCornerShape(18.dp), spotColor = PrimaryPurple)
        .background(PrimaryGradient, RoundedCornerShape(18.dp))
        .testTag("download_hd_button")
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
      ) {
        if (isSaving) {
          CircularProgressIndicator(
            modifier = Modifier.size(20.dp),
            strokeWidth = 2.dp,
            color = MainText
          )
          Spacer(modifier = Modifier.width(10.dp))
          Text("গ্যালারিতে সেভ হচ্ছে...", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = MainText)
        } else {
          Icon(Icons.Default.Download, contentDescription = null, tint = MainText, modifier = Modifier.size(22.dp))
          Spacer(modifier = Modifier.width(10.dp))
          Text(
            text = "Gallery-তে সেভ করুন",
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = MainText
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(10.dp))

    // STEP 3 PRIMARY BUTTON 2: "শেয়ার করুন"
    OutlinedButton(
      onClick = onShare,
      shape = RoundedCornerShape(16.dp),
      colors = ButtonDefaults.outlinedButtonColors(contentColor = AccentCyan),
      border = androidx.compose.foundation.BorderStroke(1.dp, AccentCyan),
      modifier = Modifier
        .fillMaxWidth()
        .height(50.dp)
        .testTag("share_hd_button")
    ) {
      Icon(Icons.Default.Share, contentDescription = null, tint = AccentCyan, modifier = Modifier.size(18.dp))
      Spacer(modifier = Modifier.width(8.dp))
      Text("শেয়ার করুন", fontSize = 15.sp, fontWeight = FontWeight.Bold)
    }

    Spacer(modifier = Modifier.height(10.dp))

    // Another Photo
    TextButton(
      onClick = onEnhanceAnother,
      modifier = Modifier
        .fillMaxWidth()
        .testTag("enhance_another_button")
    ) {
      Icon(Icons.Default.Refresh, contentDescription = null, tint = SecondaryText, modifier = Modifier.size(16.dp))
      Spacer(modifier = Modifier.width(6.dp))
      Text("অন্য ছবি বাছুন", fontSize = 14.sp, color = SecondaryText)
    }

    Spacer(modifier = Modifier.height(28.dp))
  }
}

@Composable
private fun ComparisonModeTab(
  label: String,
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  selected: Boolean,
  onClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  Box(
    modifier = modifier
      .clip(RoundedCornerShape(10.dp))
      .background(if (selected) PrimaryPurple else Color.Transparent)
      .clickable(onClick = onClick)
      .padding(vertical = 8.dp),
    contentAlignment = Alignment.Center
  ) {
    Row(verticalAlignment = Alignment.CenterVertically) {
      Icon(
        imageVector = icon,
        contentDescription = null,
        tint = if (selected) MainText else SecondaryText,
        modifier = Modifier.size(15.dp)
      )
      Spacer(modifier = Modifier.width(5.dp))
      Text(
        text = label,
        fontSize = 11.sp,
        fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
        color = if (selected) MainText else SecondaryText
      )
    }
  }
}
