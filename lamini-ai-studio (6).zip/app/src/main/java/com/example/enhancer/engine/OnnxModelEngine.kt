package com.example.enhancer.engine

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import ai.onnxruntime.TensorInfo
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.Shader
import com.example.enhancer.model.EngineStatus
import com.example.enhancer.model.EngineStatusInfo
import com.example.enhancer.model.EngineType
import com.example.enhancer.model.EnhancementConfig
import com.example.enhancer.model.ProcessingProgress
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.FloatBuffer
import kotlin.coroutines.coroutineContext
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

class OnnxModelEngine(
  private val context: Context,
  private val modelManager: ModelManager
) : AiInferenceEngine {

  override val engineType: EngineType = EngineType.ONNX_LOCAL_AI

  var lastAiUpscaleWasSkipped: Boolean = false
    private set

  private var ortEnvironment: OrtEnvironment? = null
  private var imageSession: OrtSession? = null
  private var faceSession: OrtSession? = null
  private var loadedImagePath: String? = null
  private var loadedFacePath: String? = null

  // Cache detected scale per model file path (e.g. 2 or 4)
  private val modelScaleCache = mutableMapOf<String, Int>()

  private fun getOrCreateEnv(): OrtEnvironment {
    var env = ortEnvironment
    if (env == null) {
      env = OrtEnvironment.getEnvironment()
      ortEnvironment = env
    }
    return env
  }

  @Synchronized
  private fun getImageSession(modelFile: File): OrtSession {
    if (imageSession != null && loadedImagePath == modelFile.absolutePath) {
      return imageSession!!
    }
    imageSession?.close()
    val env = getOrCreateEnv()
    val opts = OrtSession.SessionOptions().apply {
      try {
        addNnapi()
      } catch (_: Exception) {
        // Fall back to CPU execution provider
      }
    }
    imageSession = env.createSession(modelFile.absolutePath, opts)
    loadedImagePath = modelFile.absolutePath
    return imageSession!!
  }

  @Synchronized
  private fun getFaceSession(modelFile: File): OrtSession {
    if (faceSession != null && loadedFacePath == modelFile.absolutePath) {
      return faceSession!!
    }
    faceSession?.close()
    val env = getOrCreateEnv()
    val opts = OrtSession.SessionOptions().apply {
      try {
        addNnapi()
      } catch (_: Exception) {
        // Fall back to CPU
      }
    }
    faceSession = env.createSession(modelFile.absolutePath, opts)
    loadedFacePath = modelFile.absolutePath
    return faceSession!!
  }

  override suspend fun getStatusInfo(): EngineStatusInfo {
    val imageReady = modelManager.isImageModelReady()
    val faceReady = modelManager.isFaceModelReady()

    return if (imageReady) {
      val imageFile = modelManager.resolveImageModelFile()
      val cachedScale = imageFile?.let { modelScaleCache[it.absolutePath] } ?: 2
      EngineStatusInfo(
        engineType = EngineType.ONNX_LOCAL_AI,
        status = EngineStatus.READY,
        modelName = "Real-ESRGAN (x$cachedScale)" + (if (faceReady) " + GFPGAN Face" else ""),
        modelVersion = "ONNX Mobile",
        runtimeEnvironment = "Local ONNX Runtime (NNAPI / CPU)",
        computeDevice = "On-Device NPU/CPU",
        statusMessage = "অন-ডিভাইস নিউরাল মডেল প্রস্তুত (${cachedScale}x সুপার-রেজোলিউশন)। 100% অফলাইন মোডে কার্যকর।",
        isNeuralAi = true,
        supportedScales = listOf(2, 4),
        supportsFaceRestoration = faceReady,
        diagnosticNotes = "মডেল ফাইল: ${imageFile?.name ?: "image_model.onnx"} (Scale: ${cachedScale}x)"
      )
    } else {
      EngineStatusInfo(
        engineType = EngineType.ONNX_LOCAL_AI,
        status = EngineStatus.NOT_CONFIGURED,
        modelName = "AI মডেল ইনস্টল নেই",
        modelVersion = null,
        runtimeEnvironment = "Local ONNX Runtime",
        computeDevice = "On-Device",
        statusMessage = "AI মডেল নেই, বেসিক এনহান্সমেন্ট ব্যবহার হয়েছে",
        isNeuralAi = false,
        supportedScales = listOf(2, 4),
        supportsFaceRestoration = false,
        diagnosticNotes = "সেটিংস থেকে Real-ESRGAN .onnx মডেল ফাইল ইমপোর্ট বা ডাউনলোড করুন।"
      )
    }
  }

  override suspend fun checkReadiness(): Result<EngineStatusInfo> {
    val info = getStatusInfo()
    return if (info.status == EngineStatus.READY) {
      Result.success(info)
    } else {
      Result.failure(IllegalStateException("AI মডেল কনফিগার করা নেই। সেটিংস থেকে মডেল ইমপোর্ট করুন।"))
    }
  }

  override suspend fun enhance(
    sourceBitmap: Bitmap,
    config: EnhancementConfig,
    onProgress: (ProcessingProgress) -> Unit
  ): Result<Bitmap> = withContext(Dispatchers.Default) {
    var workingBitmap: Bitmap? = null
    var intermediateBitmap: Bitmap? = null
    lastAiUpscaleWasSkipped = false

    try {
      coroutineContext.ensureActive()

      val imageModelFile = modelManager.resolveImageModelFile()
      if (imageModelFile == null || !imageModelFile.exists()) {
        return@withContext Result.failure(
          IllegalStateException("AI মডেল নেই, বেসিক এনহান্সমেন্ট ব্যবহার হয়েছে")
        )
      }

      val session = getImageSession(imageModelFile)
      val env = getOrCreateEnv()
      val scale = getOrDetectImageScale(session, env, imageModelFile)

      // Memory cap rule:
      // maxOutputLongSide = 3840
      // maxInputLongSide = maxOutputLongSide / scale (960 for x4, 1920 for x2)
      val maxOutputLongSide = 3840
      val maxInputLongSide = maxOutputLongSide / scale
      val inputLongSide = max(sourceBitmap.width, sourceBitmap.height)

      onProgress(
        ProcessingProgress(
          stage = "ছবি প্রস্তুত করা হচ্ছে...",
          percent = 0.05f,
          isIndeterminate = false,
          detail = "ইনপুট রেজোলিউশন: ${sourceBitmap.width} × ${sourceBitmap.height} px"
        )
      )

      workingBitmap = sourceBitmap.copy(Bitmap.Config.ARGB_8888, true)

      // STAGE 1: Face stage (kept for both small and large inputs)
      val faceModelFile = modelManager.resolveFaceModelFile()
      if (config.faceEnhancement && faceModelFile != null && faceModelFile.exists()) {
        onProgress(
          ProcessingProgress(
            stage = "মুখমণ্ডল শনাক্ত করা হচ্ছে...",
            percent = 0.12f,
            isIndeterminate = false,
            detail = "অফলাইন ফেস ডিটেক্টর চলছে..."
          )
        )

        val detectedFaces = FaceDetectorOfflineHelper.detectFaces(workingBitmap, maxFaces = 5)
        if (detectedFaces.isNotEmpty()) {
          onProgress(
            ProcessingProgress(
              stage = "AI ফেস রিস্টোরেশন চলছে...",
              percent = 0.18f,
              isIndeterminate = false,
              detail = "${detectedFaces.size}টি পোর্ট্রেট এরিয়া রিস্টোর করা হচ্ছে..."
            )
          )

          val restoredBitmap = restoreFacesWithOnnx(
            workingBitmap,
            detectedFaces,
            faceModelFile,
            faceStrength = config.faceStrength
          )
          workingBitmap.recycle()
          workingBitmap = restoredBitmap
        }
      }

      coroutineContext.ensureActive()

      // STAGE 2: Whole-image stage
      if (inputLongSide <= maxInputLongSide) {
        // Run AI upscale on ORIGINAL input at full resolution (no pre-downscaling)
        lastAiUpscaleWasSkipped = false
        onProgress(
          ProcessingProgress(
            stage = "AI সুপার-রেজোলিউশন প্রসেসিং...",
            percent = 0.25f,
            isIndeterminate = false,
            detail = "টাইলভিত্তিক ONNX (${scale}x) ইনফ্যারেন্স শুরু হচ্ছে..."
          )
        )

        val upscaled = runRealEsrganTiled(
          inputBitmap = workingBitmap,
          modelFile = imageModelFile,
          scale = scale,
          onProgress = onProgress
        )
        workingBitmap.recycle()
        workingBitmap = null
        intermediateBitmap = upscaled
      } else {
        // Large photo already near/above Full HD: SKIP whole-image Real-ESRGAN stage.
        // Keep face restoration stage (already completed), apply light denoise + sharpen
        lastAiUpscaleWasSkipped = true
        onProgress(
          ProcessingProgress(
            stage = "ছবি শার্পেন ও অপ্টিমাইজ করা হচ্ছে...",
            percent = 0.55f,
            isIndeterminate = false,
            detail = "উচ্চ রেজোলিউশন ছবি: লাইট ডিনয়েজ ও শার্পেনিং..."
          )
        )

        val denoised = applyLightDenoise(workingBitmap)
        workingBitmap.recycle()
        val sharpened = applyLightSharpen(denoised, strength = 0.35f)
        denoised.recycle()
        workingBitmap = null
        intermediateBitmap = sharpened
      }

      coroutineContext.ensureActive()

      // STAGE 3: Output Full HD
      // Resizes result down directly to exact Full HD size (1920 long side), keeping aspect ratio
      onProgress(
        ProcessingProgress(
          stage = "Full HD রেজোলিউশনে কনভার্ট করা হচ্ছে...",
          percent = 0.95f,
          isIndeterminate = false,
          detail = "লং সাইড 1920 px এ ফাইনাল অপ্টিমাইজেশন..."
        )
      )

      val finalFullHd = formatToFullHd(intermediateBitmap)
      if (finalFullHd != intermediateBitmap) {
        intermediateBitmap.recycle()
      }

      Result.success(finalFullHd)
    } catch (e: Exception) {
      workingBitmap?.recycle()
      intermediateBitmap?.recycle()
      Result.failure(e)
    }
  }

  private fun applyLightDenoise(input: Bitmap): Bitmap {
    val width = input.width
    val height = input.height
    val output = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    val pixels = IntArray(width * height)
    input.getPixels(pixels, 0, width, 0, 0, width, height)
    val outPixels = pixels.clone()

    val threshold = 25
    for (y in 1 until height - 1) {
      val row = y * width
      for (x in 1 until width - 1) {
        val center = pixels[row + x]
        val cR = (center shr 16) and 0xFF
        val cG = (center shr 8) and 0xFF
        val cB = center and 0xFF

        var sumR = cR * 4
        var sumG = cG * 4
        var sumB = cB * 4
        var count = 4

        for (dy in -1..1) {
          val nRow = (y + dy) * width
          for (dx in -1..1) {
            if (dx == 0 && dy == 0) continue
            val neighbor = pixels[nRow + (x + dx)]
            val nR = (neighbor shr 16) and 0xFF
            val nG = (neighbor shr 8) and 0xFF
            val nB = neighbor and 0xFF

            if (abs(nR - cR) < threshold &&
              abs(nG - cG) < threshold &&
              abs(nB - cB) < threshold
            ) {
              sumR += nR
              sumG += nG
              sumB += nB
              count++
            }
          }
        }

        val fR = (sumR / count).coerceIn(0, 255)
        val fG = (sumG / count).coerceIn(0, 255)
        val fB = (sumB / count).coerceIn(0, 255)
        outPixels[row + x] = (0xFF shl 24) or (fR shl 16) or (fG shl 8) or fB
      }
    }
    output.setPixels(outPixels, 0, width, 0, 0, width, height)
    return output
  }

  private fun applyLightSharpen(input: Bitmap, strength: Float = 0.35f): Bitmap {
    val width = input.width
    val height = input.height
    val output = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    val pixels = IntArray(width * height)
    input.getPixels(pixels, 0, width, 0, 0, width, height)
    val outPixels = pixels.clone()

    val factor = strength.coerceIn(0.1f, 0.8f)

    for (y in 1 until height - 1) {
      val prevRow = (y - 1) * width
      val currRow = y * width
      val nextRow = (y + 1) * width

      for (x in 1 until width - 1) {
        val c = pixels[currRow + x]
        val cR = (c shr 16) and 0xFF
        val cG = (c shr 8) and 0xFF
        val cB = c and 0xFF

        val top = pixels[prevRow + x]
        val bottom = pixels[nextRow + x]
        val left = pixels[currRow + x - 1]
        val right = pixels[currRow + x + 1]

        val lapR = (4 * cR) - (((top shr 16) and 0xFF) + ((bottom shr 16) and 0xFF) + ((left shr 16) and 0xFF) + ((right shr 16) and 0xFF))
        val lapG = (4 * cG) - (((top shr 8) and 0xFF) + ((bottom shr 8) and 0xFF) + ((left shr 8) and 0xFF) + ((right shr 8) and 0xFF))
        val lapB = (4 * cB) - ((top and 0xFF) + (bottom and 0xFF) + (left and 0xFF) + (right and 0xFF))

        val sR = (cR + factor * lapR).roundToInt().coerceIn(0, 255)
        val sG = (cG + factor * lapG).roundToInt().coerceIn(0, 255)
        val sB = (cB + factor * lapB).roundToInt().coerceIn(0, 255)

        outPixels[currRow + x] = (0xFF shl 24) or (sR shl 16) or (sG shl 8) or sB
      }
    }
    output.setPixels(outPixels, 0, width, 0, 0, width, height)
    return output
  }

  private suspend fun restoreFacesWithOnnx(
    source: Bitmap,
    faces: List<FaceDetectorOfflineHelper.DetectedFaceBox>,
    faceModelFile: File,
    faceStrength: Float
  ): Bitmap = withContext(Dispatchers.Default) {
    val session = getFaceSession(faceModelFile)
    val env = getOrCreateEnv()
    val inputName = session.inputNames.iterator().next()

    val resultBitmap = source.copy(Bitmap.Config.ARGB_8888, true)
    val canvas = Canvas(resultBitmap)

    for (faceBox in faces) {
      coroutineContext.ensureActive()
      val rect = faceBox.rect
      val width = rect.width()
      val height = rect.height()
      if (width <= 10 || height <= 10) continue

      // 30% padding, centered square
      val pad = (max(width, height) * 0.30f).toInt()
      val side = max(width, height) + pad * 2
      val cx = rect.centerX()
      val cy = rect.centerY()

      val cropLeft = (cx - side / 2).coerceIn(0, source.width - 1)
      val cropTop = (cy - side / 2).coerceIn(0, source.height - 1)
      val cropRight = (cropLeft + side).coerceIn(cropLeft + 1, source.width)
      val cropBottom = (cropTop + side).coerceIn(cropTop + 1, source.height)
      val cropW = cropRight - cropLeft
      val cropH = cropBottom - cropTop
      if (cropW <= 0 || cropH <= 0) continue

      val faceCrop = Bitmap.createBitmap(source, cropLeft, cropTop, cropW, cropH)
      val resized512 = Bitmap.createScaledBitmap(faceCrop, 512, 512, true)
      faceCrop.recycle()

      // Convert 512x512 to FloatBuffer NCHW [1, 3, 512, 512] normalized [-1, 1]
      val floatBuffer = FloatBuffer.allocate(1 * 3 * 512 * 512)
      val pixels = IntArray(512 * 512)
      resized512.getPixels(pixels, 0, 512, 0, 0, 512, 512)

      // R channel
      for (i in pixels.indices) {
        val r = (pixels[i] shr 16) and 0xFF
        floatBuffer.put((r / 255.0f - 0.5f) / 0.5f)
      }
      // G channel
      for (i in pixels.indices) {
        val g = (pixels[i] shr 8) and 0xFF
        floatBuffer.put((g / 255.0f - 0.5f) / 0.5f)
      }
      // B channel
      for (i in pixels.indices) {
        val b = pixels[i] and 0xFF
        floatBuffer.put((b / 255.0f - 0.5f) / 0.5f)
      }
      floatBuffer.rewind()
      resized512.recycle()

      val tensor = OnnxTensor.createTensor(env, floatBuffer, longArrayOf(1, 3, 512, 512))
      val sessionResult = session.run(mapOf(inputName to tensor))
      tensor.close()

      val outputTensor = sessionResult.get(0) as OnnxTensor
      val outBuffer = outputTensor.floatBuffer
      val outPixels = IntArray(512 * 512)

      val channelStride = 512 * 512
      for (p in 0 until channelStride) {
        val rVal = outBuffer.get(p)
        val gVal = outBuffer.get(p + channelStride)
        val bVal = outBuffer.get(p + channelStride * 2)

        val r = (((rVal * 0.5f) + 0.5f) * 255f).toInt().coerceIn(0, 255)
        val g = (((gVal * 0.5f) + 0.5f) * 255f).toInt().coerceIn(0, 255)
        val b = (((bVal * 0.5f) + 0.5f) * 255f).toInt().coerceIn(0, 255)
        outPixels[p] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
      }
      sessionResult.close()

      val restored512 = Bitmap.createBitmap(outPixels, 512, 512, Bitmap.Config.ARGB_8888)
      val scaledBack = Bitmap.createScaledBitmap(restored512, cropW, cropH, true)
      restored512.recycle()

      // Feathered blend onto resultBitmap using faceStrength (default 0.7)
      blendFaceOntoCanvas(
        canvas = canvas,
        restoredFace = scaledBack,
        x = cropLeft.toFloat(),
        y = cropTop.toFloat(),
        strength = faceStrength.coerceIn(0.1f, 1.0f)
      )
      scaledBack.recycle()
    }

    resultBitmap
  }

  private fun blendFaceOntoCanvas(
    canvas: Canvas,
    restoredFace: Bitmap,
    x: Float,
    y: Float,
    strength: Float
  ) {
    val w = restoredFace.width
    val h = restoredFace.height
    val maskBitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val maskCanvas = Canvas(maskBitmap)

    // Soft feathered circular/oval mask
    val radius = min(w, h) * 0.48f
    val shader = RadialGradient(
      w / 2f, h / 2f, radius,
      intArrayOf(Color.BLACK, Color.BLACK, Color.TRANSPARENT),
      floatArrayOf(0f, 0.75f, 1.0f),
      Shader.TileMode.CLAMP
    )
    val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
      this.shader = shader
    }
    maskCanvas.drawCircle(w / 2f, h / 2f, radius, paint)

    // Apply strength to mask alpha
    val blendPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
      alpha = (strength * 255).toInt().coerceIn(0, 255)
      xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN)
    }

    val maskedFace = restoredFace.copy(Bitmap.Config.ARGB_8888, true)
    val faceCanvas = Canvas(maskedFace)
    faceCanvas.drawBitmap(maskBitmap, 0f, 0f, blendPaint)
    maskBitmap.recycle()

    canvas.drawBitmap(maskedFace, x, y, null)
    maskedFace.recycle()
  }

  /**
   * Auto-detect the scale factor from the session output tensor shape.
   * Checks static shape first, then runs a probe tile tensor if dynamic.
   * Caches result per loaded model. Supports x2 and x4.
   */
  private fun getOrDetectImageScale(
    session: OrtSession,
    env: OrtEnvironment,
    modelFile: File,
    tileSize: Int = 128
  ): Int {
    modelScaleCache[modelFile.absolutePath]?.let { return it }

    // 1. Try static shape inspection if available
    try {
      val outNode = session.outputInfo.values.firstOrNull()?.info as? TensorInfo
      val inNode = session.inputInfo.values.firstOrNull()?.info as? TensorInfo
      val outShape = outNode?.shape
      val inShape = inNode?.shape
      if (outShape != null && inShape != null && outShape.size >= 4 && inShape.size >= 4) {
        val outH = outShape[2]
        val inH = inShape[2]
        if (outH > 0 && inH > 0) {
          val s = (outH / inH).toInt()
          if (s in listOf(2, 4)) {
            modelScaleCache[modelFile.absolutePath] = s
            return s
          }
        }
      }
    } catch (_: Exception) {}

    // 2. Probe with a dummy tile tensor
    try {
      val inputName = session.inputNames.iterator().next()
      val dummyBuffer = FloatBuffer.allocate(1 * 3 * tileSize * tileSize)
      val tensor = OnnxTensor.createTensor(
        env,
        dummyBuffer,
        longArrayOf(1, 3, tileSize.toLong(), tileSize.toLong())
      )
      val result = session.run(mapOf(inputName to tensor))
      tensor.close()
      val outTensor = result.get(0) as OnnxTensor
      val outShape = outTensor.info.shape
      val realOutH = if (outShape.size >= 4) outShape[2].toInt() else tileSize * 2
      result.close()
      val detectedScale = (realOutH / tileSize).let { if (it >= 3) 4 else 2 }
      modelScaleCache[modelFile.absolutePath] = detectedScale
      return detectedScale
    } catch (_: Exception) {
      val fallback = 2
      modelScaleCache[modelFile.absolutePath] = fallback
      return fallback
    }
  }

  private suspend fun runRealEsrganTiled(
    inputBitmap: Bitmap,
    modelFile: File,
    scale: Int,
    onProgress: (ProcessingProgress) -> Unit
  ): Bitmap = withContext(Dispatchers.Default) {
    val session = getImageSession(modelFile)
    val env = getOrCreateEnv()
    val inputName = session.inputNames.iterator().next()

    val tileSize = 128
    val overlap = 10
    val step = (tileSize - overlap).coerceAtLeast(1)

    // Run AI upscale on the ORIGINAL input at full resolution (no pre-downscaling)
    val inW = inputBitmap.width
    val inH = inputBitmap.height
    val outW = inW * scale
    val outH = inH * scale

    val outputBitmap = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
    val outputCanvas = Canvas(outputBitmap)

    // Coordinate steps covering the full dimensions with native tile size (no stretching)
    val xCoords = mutableListOf<Int>()
    var currX = 0
    if (inW <= tileSize) {
      xCoords.add(0)
    } else {
      while (currX + tileSize < inW) {
        xCoords.add(currX)
        currX += step
      }
      val lastX = inW - tileSize
      if (xCoords.isEmpty() || xCoords.last() != lastX) {
        xCoords.add(lastX)
      }
    }

    val yCoords = mutableListOf<Int>()
    var currY = 0
    if (inH <= tileSize) {
      yCoords.add(0)
    } else {
      while (currY + tileSize < inH) {
        yCoords.add(currY)
        currY += step
      }
      val lastY = inH - tileSize
      if (yCoords.isEmpty() || yCoords.last() != lastY) {
        yCoords.add(lastY)
      }
    }

    val totalTiles = xCoords.size * yCoords.size
    var processedTiles = 0

    val tilePixels = IntArray(tileSize * tileSize)

    for ((yi, y) in yCoords.withIndex()) {
      for ((xi, x) in xCoords.withIndex()) {
        coroutineContext.ensureActive()

        val actualW = min(tileSize, inW - x)
        val actualH = min(tileSize, inH - y)

        val tileBmp = Bitmap.createBitmap(inputBitmap, x, y, actualW, actualH)
        val uniformTile = if (actualW != tileSize || actualH != tileSize) {
          // If image dimension is smaller than tileSize, pad onto tileSize x tileSize
          val padded = Bitmap.createBitmap(tileSize, tileSize, Bitmap.Config.ARGB_8888)
          val pCanvas = Canvas(padded)
          pCanvas.drawBitmap(tileBmp, 0f, 0f, null)
          tileBmp.recycle()
          padded
        } else {
          tileBmp
        }

        uniformTile.getPixels(tilePixels, 0, tileSize, 0, 0, tileSize, tileSize)
        uniformTile.recycle()

        // NCHW float32 RGB in [0.0f, 1.0f]
        val floatBuffer = FloatBuffer.allocate(1 * 3 * tileSize * tileSize)
        val channelSize = tileSize * tileSize

        // R
        for (i in 0 until channelSize) {
          floatBuffer.put(((tilePixels[i] shr 16) and 0xFF) / 255.0f)
        }
        // G
        for (i in 0 until channelSize) {
          floatBuffer.put(((tilePixels[i] shr 8) and 0xFF) / 255.0f)
        }
        // B
        for (i in 0 until channelSize) {
          floatBuffer.put((tilePixels[i] and 0xFF) / 255.0f)
        }
        floatBuffer.rewind()

        val tensor = OnnxTensor.createTensor(
          env,
          floatBuffer,
          longArrayOf(1, 3, tileSize.toLong(), tileSize.toLong())
        )
        val runResult = session.run(mapOf(inputName to tensor))
        tensor.close()

        val outTensor = runResult.get(0) as OnnxTensor
        val outBuf = outTensor.floatBuffer
        val outShape = outTensor.info.shape // [1, 3, realOutH, realOutW]

        // Read output with its real dimensions from output tensor shape
        val realOutH = if (outShape.size >= 4) outShape[2].toInt() else tileSize * scale
        val realOutW = if (outShape.size >= 4) outShape[3].toInt() else tileSize * scale

        // Update cached scale
        val tensorScale = (realOutH / tileSize).let { if (it >= 3) 4 else 2 }
        modelScaleCache[modelFile.absolutePath] = tensorScale

        val outChannelSize = realOutW * realOutH
        val outTilePixels = IntArray(outChannelSize)

        // Linear feathering to avoid seams:
        val hasLeftOverlap = xi > 0
        val overlapW = if (hasLeftOverlap) {
          ((xCoords[xi - 1] + tileSize - x) * scale).coerceIn(1, realOutW)
        } else 0

        val hasTopOverlap = yi > 0
        val overlapH = if (hasTopOverlap) {
          ((yCoords[yi - 1] + tileSize - y) * scale).coerceIn(1, realOutH)
        } else 0

        for (py in 0 until realOutH) {
          val weightY = if (hasTopOverlap && py < overlapH) {
            py.toFloat() / overlapH.toFloat()
          } else {
            1.0f
          }

          val rowOffset = py * realOutW

          for (px in 0 until realOutW) {
            val weightX = if (hasLeftOverlap && px < overlapW) {
              px.toFloat() / overlapW.toFloat()
            } else {
              1.0f
            }

            val p = rowOffset + px
            val r = (outBuf.get(p) * 255.0f).toInt().coerceIn(0, 255)
            val g = (outBuf.get(p + outChannelSize) * 255.0f).toInt().coerceIn(0, 255)
            val b = (outBuf.get(p + outChannelSize * 2) * 255.0f).toInt().coerceIn(0, 255)

            // Linear feather alpha blending
            val alphaF = weightX * weightY
            val alpha = (alphaF * 255.0f).roundToInt().coerceIn(0, 255)

            outTilePixels[p] = (alpha shl 24) or (r shl 16) or (g shl 8) or b
          }
        }
        runResult.close()

        val outTileBmp = Bitmap.createBitmap(outTilePixels, realOutW, realOutH, Bitmap.Config.ARGB_8888)

        // If actual input was smaller than tileSize, draw only the valid region
        val drawW = actualW * scale
        val drawH = actualH * scale
        val finalCropTile = if (drawW != realOutW || drawH != realOutH) {
          Bitmap.createBitmap(outTileBmp, 0, 0, drawW, drawH).also { outTileBmp.recycle() }
        } else {
          outTileBmp
        }

        outputCanvas.drawBitmap(finalCropTile, (x * scale).toFloat(), (y * scale).toFloat(), null)
        finalCropTile.recycle()

        processedTiles++
        val progressPercent = 0.25f + 0.65f * (processedTiles.toFloat() / totalTiles.toFloat())
        onProgress(
          ProcessingProgress(
            stage = "AI সুপার-রেজোলিউশন প্রসেসিং...",
            percent = progressPercent,
            isIndeterminate = false,
            detail = "টাইল $processedTiles / $totalTiles সম্পন্ন (${(progressPercent * 100).roundToInt()}%)"
          )
        )
      }
    }

    outputBitmap
  }

  /**
   * Output Full HD: the long side = 1920 px (1080x1920 portrait or 1920x1080 landscape),
   * keeping the aspect ratio, never stretch or crop.
   */
  private fun formatToFullHd(bitmap: Bitmap): Bitmap {
    val srcW = bitmap.width
    val srcH = bitmap.height

    val targetW: Int
    val targetH: Int

    if (srcW >= srcH) {
      targetW = 1920
      targetH = (1920.0 * srcH / srcW).roundToInt()
    } else {
      targetH = 1920
      targetW = (1920.0 * srcW / srcH).roundToInt()
    }

    if (srcW == targetW && srcH == targetH) {
      return bitmap
    }

    return Bitmap.createScaledBitmap(bitmap, targetW, targetH, true)
  }

  override fun release() {
    try {
      imageSession?.close()
      imageSession = null
      loadedImagePath = null
      modelScaleCache.clear()
    } catch (_: Exception) {}

    try {
      faceSession?.close()
      faceSession = null
      loadedFacePath = null
    } catch (_: Exception) {}

    try {
      ortEnvironment?.close()
      ortEnvironment = null
    } catch (_: Exception) {}
  }
}
