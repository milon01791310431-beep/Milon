package com.example

import com.example.enhancer.config.ModelConfig
import com.example.enhancer.engine.DownloadStatus
import com.example.enhancer.model.ModelSlotType
import com.example.enhancer.utils.MemorySafetyCalculator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ModelEnhancerPipelineTest {

  @Test
  fun testFullHdDimensionsCalculation_Landscape() {
    // 4:3 landscape
    val dims = MemorySafetyCalculator.calculateFullHdDimensions(800, 600)
    assertEquals(1920, dims.width)
    assertEquals(1440, dims.height)

    // 16:9 landscape
    val dims169 = MemorySafetyCalculator.calculateFullHdDimensions(1280, 720)
    assertEquals(1920, dims169.width)
    assertEquals(1080, dims169.height)
  }

  @Test
  fun testFullHdDimensionsCalculation_Portrait() {
    // 3:4 portrait
    val dims = MemorySafetyCalculator.calculateFullHdDimensions(600, 800)
    assertEquals(1440, dims.width)
    assertEquals(1920, dims.height)

    // 9:16 portrait
    val dims916 = MemorySafetyCalculator.calculateFullHdDimensions(720, 1280)
    assertEquals(1080, dims916.width)
    assertEquals(1920, dims916.height)
  }

  @Test
  fun testFullHdDimensionsCalculation_Square() {
    val dims = MemorySafetyCalculator.calculateFullHdDimensions(500, 500)
    assertEquals(1920, dims.width)
    assertEquals(1920, dims.height)
  }

  @Test
  fun testFullHdDimensionsCalculation_LargerImageDownscaling() {
    // 4000x3000 input should downscale so long side is 1920
    val dims = MemorySafetyCalculator.calculateFullHdDimensions(4000, 3000)
    assertEquals(1920, dims.width)
    assertEquals(1440, dims.height)
  }

  @Test
  fun testTilingCoordinates() {
    val dimension = 500
    val tileSize = 128
    val overlap = 10
    val coords = MemorySafetyCalculator.calculateTilingCoordinates(dimension, tileSize, overlap)

    assertTrue("Should have multiple tile coordinates", coords.size > 1)
    assertEquals("First tile must start at 0", 0, coords.first())
    val lastCoord = coords.last()
    assertTrue("Last coordinate + tileSize must cover entire dimension", lastCoord + tileSize >= dimension)
  }

  @Test
  fun testModelConfigUrlValidation() {
    // Default placeholder should be recognized as unconfigured
    assertFalse(ModelConfig.isUrlConfigured("PUT_DIRECT_LINK_HERE"))
    assertFalse(ModelConfig.isUrlConfigured(""))
    assertFalse(ModelConfig.isUrlConfigured("   "))
    assertFalse(ModelConfig.isUrlConfigured("invalid_url_string"))

    // Real http/https URLs should be recognized as configured
    assertTrue(ModelConfig.isUrlConfigured("https://huggingface.co/models/realesrgan.onnx"))
    assertTrue(ModelConfig.isUrlConfigured("http://example.com/model.onnx"))
  }

  @Test
  fun testModelConfigSlots() {
    assertEquals(ModelConfig.IMAGE_MODEL_URL, ModelConfig.getModelUrl(ModelSlotType.IMAGE_MODEL))
    assertEquals(ModelConfig.FACE_MODEL_URL, ModelConfig.getModelUrl(ModelSlotType.FACE_MODEL))
    assertEquals(ModelConfig.IMAGE_MODEL_SIZE_BYTES, ModelConfig.getExpectedSizeBytes(ModelSlotType.IMAGE_MODEL))
    assertEquals(ModelConfig.FACE_MODEL_SIZE_BYTES, ModelConfig.getExpectedSizeBytes(ModelSlotType.FACE_MODEL))
  }

  @Test
  fun testDownloadStatusFormatting() {
    val status = DownloadStatus.Downloading(
      slotType = ModelSlotType.IMAGE_MODEL,
      bytesDownloaded = 2_621_440L, // 2.5 MB
      totalBytes = 5_242_880L, // 5.0 MB
      percent = 50,
      speedText = "1.5 MB/s",
      isResuming = false
    )

    assertEquals("2.5", status.downloadedMb)
    assertEquals("5.0", status.totalMb)
    assertEquals(50, status.percent)
  }

  @Test
  fun testMemoryCapThresholdRules() {
    val maxOutputLongSide = 3840

    // Scale x4: maxInputLongSide = 960
    val scale4 = 4
    val maxInputLongSide4 = maxOutputLongSide / scale4
    assertEquals(960, maxInputLongSide4)

    // Image with long side 800 <= 960 -> Should run AI upscale
    val inputLongSideSmall = 800
    val shouldRunAiSmall4 = inputLongSideSmall <= maxInputLongSide4
    assertTrue("Small image (800) with x4 model should run AI upscale", shouldRunAiSmall4)

    // Image with long side 1200 > 960 -> Should skip whole-image Real-ESRGAN
    val inputLongSideLarge = 1200
    val shouldRunAiLarge4 = inputLongSideLarge <= maxInputLongSide4
    assertFalse("Large image (1200) with x4 model should skip Real-ESRGAN stage", shouldRunAiLarge4)

    // Scale x2: maxInputLongSide = 1920
    val scale2 = 2
    val maxInputLongSide2 = maxOutputLongSide / scale2
    assertEquals(1920, maxInputLongSide2)

    // Image with long side 1200 <= 1920 -> Should run AI upscale with x2 model
    val shouldRunAiMedium2 = inputLongSideLarge <= maxInputLongSide2
    assertTrue("Image (1200) with x2 model should run AI upscale", shouldRunAiMedium2)

    // Image with long side 2400 > 1920 -> Should skip Real-ESRGAN stage with x2 model
    val inputLongSideHuge = 2400
    val shouldRunAiHuge2 = inputLongSideHuge <= maxInputLongSide2
    assertFalse("Huge image (2400) with x2 model should skip Real-ESRGAN stage", shouldRunAiHuge2)
  }
}
