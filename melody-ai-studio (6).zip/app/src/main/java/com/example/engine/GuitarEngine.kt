package com.example.engine

import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

/**
 * ENGINE 5: Local Guitar Engine (Acoustic Steel-String Guitar Synthesis)
 *
 * Implements physical acoustic guitar synthesis:
 * - Crisp pick attack transient on note pluck
 * - Multi-harmonic overtone damping where higher harmonics decay faster
 * - Rhythmic fingerpicking arpeggio patterns following song chord changes
 * - Right-sided spatial stereo imaging for complementary mix placement
 *
 * Note: High-fidelity physical acoustic synthesis, not remote generative AI.
 */
object GuitarEngine {
    private const val SAMPLE_RATE = VocalAnalysisEngine.TARGET_SAMPLE_RATE
    private const val CHANNELS = VocalAnalysisEngine.TARGET_CHANNELS

    fun generateStem(
        analysis: VocalAnalysis,
        totalFrames: Int,
        chords: List<List<Double>>,
        aiStemPcm: ShortArray? = null
    ): StemData {
        if (aiStemPcm != null && aiStemPcm.isNotEmpty()) {
            return StemData.createFromPcm("Guitar", aiStemPcm, totalFrames)
        }

        val pcm = ShortArray(totalFrames * CHANNELS)
        val bpm = analysis.estimatedBpm.toDouble()
        val beatSec = 60.0 / bpm
        val framesPerBeat = (beatSec * SAMPLE_RATE).toInt().coerceAtLeast(1)
        val beatsPerChord = 4
        val framesPerChord = framesPerBeat * beatsPerChord

        for (frame in 0 until totalFrames) {
            val time = frame.toDouble() / SAMPLE_RATE
            val beatIndex = frame / framesPerBeat
            val beatFrac = (frame % framesPerBeat).toDouble() / framesPerBeat
            val chordIdx = ((frame / framesPerChord) % chords.size)
            val currentChord = chords[chordIdx]

            // 16th-note fingerpicking arpeggio pattern: Bass (thumb) on 0, mid notes on 1, 2, 3
            val sixteenthIdx = (beatFrac * 4.0).toInt() % 4
            val subFrac = (beatFrac * 4.0) % 1.0
            val noteTime = subFrac * (beatSec / 4.0)

            val noteFreq = when (sixteenthIdx) {
                0 -> currentChord[0] // Root
                1 -> if (currentChord.size > 2) currentChord[2] else currentChord[0] * 1.5 // 5th
                2 -> currentChord[1] // 3rd
                3 -> currentChord[0] * 2.0 // Octave
                else -> currentChord[0]
            }

            // Pick attack transient during first 6ms
            val pickClick = if (noteTime < 0.006) (sin(2.0 * PI * 4200.0 * noteTime) * exp(-noteTime * 600.0) * 0.18) else 0.0

            // Frequency-dependent damping: higher harmonics decay faster
            val envH1 = exp(-noteTime * 4.2)
            val envH2 = exp(-noteTime * 6.5)
            val envH3 = exp(-noteTime * 9.8)
            val envH4 = exp(-noteTime * 14.0)

            val guitarTone = (
                sin(2.0 * PI * noteFreq * time) * 0.60 * envH1 +
                sin(4.0 * PI * noteFreq * time) * 0.24 * envH2 +
                sin(6.0 * PI * noteFreq * time) * 0.12 * envH3 +
                sin(8.0 * PI * noteFreq * time) * 0.04 * envH4 +
                pickClick
            ) * 0.20

            // Panned right (30% L, 70% R) for natural acoustic width
            val sampleL = (guitarTone * 0.60 * 26000.0).coerceIn(-32767.0, 32767.0).toInt().toShort()
            val sampleR = (guitarTone * 1.40 * 26000.0).coerceIn(-32767.0, 32767.0).toInt().toShort()

            pcm[frame * CHANNELS] = sampleL
            pcm[frame * CHANNELS + 1] = sampleR
        }

        return StemData.createFromPcm("Guitar", pcm, totalFrames)
    }
}
