package com.example.engine

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.RandomAccessFile
import kotlin.math.max

/**
 * ENGINE 10: Audio Export Engine
 *
 * Encodes mastered PCM into valid 16-bit 44.1 kHz Stereo WAV files
 * and provides verified file saving to phone storage (via Android MediaStore)
 * as well as external sharing capabilities.
 */
object AudioExportEngine {
    private const val TAG = "AudioExportEngine"
    private const val BITS_PER_SAMPLE = 16
    private const val SAMPLE_RATE = VocalAnalysisEngine.TARGET_SAMPLE_RATE
    private const val CHANNELS = VocalAnalysisEngine.TARGET_CHANNELS

    fun formatDuration(ms: Long): String {
        val totalSec = max(0L, ms / 1000)
        val minutes = totalSec / 60
        val seconds = totalSec % 60
        return "%02d:%02d".format(minutes, seconds)
    }

    fun formatFileSize(bytes: Long): String {
        return when {
            bytes < 1024 -> "$bytes B"
            bytes < 1024 * 1024 -> "%.1f KB".format(bytes / 1024.0)
            else -> "%.1f MB".format(bytes / (1024.0 * 1024.0))
        }
    }

    suspend fun exportMasterWav(
        outputFile: File,
        masteredPcm: ShortArray
    ): Result<File> = withContext(Dispatchers.IO) {
        try {
            val fos = FileOutputStream(outputFile)
            val header = ByteArray(44)
            fos.write(header)

            val buffer = ByteArray(4096)
            var bufIdx = 0
            for (sample in masteredPcm) {
                buffer[bufIdx++] = (sample.toInt() and 0xFF).toByte()
                buffer[bufIdx++] = ((sample.toInt() shr 8) and 0xFF).toByte()
                if (bufIdx >= buffer.size) {
                    fos.write(buffer, 0, bufIdx)
                    bufIdx = 0
                }
            }
            if (bufIdx > 0) {
                fos.write(buffer, 0, bufIdx)
            }
            fos.flush()
            fos.close()

            val audioLen = (masteredPcm.size * (BITS_PER_SAMPLE / 8)).toLong()
            val dataLen = audioLen + 36
            val byteRate = (SAMPLE_RATE * CHANNELS * BITS_PER_SAMPLE) / 8

            updateWavHeader(outputFile, audioLen, dataLen, SAMPLE_RATE, CHANNELS, byteRate)

            if (outputFile.exists() && outputFile.length() > 44L) {
                Log.d(TAG, "Master WAV successfully written: ${outputFile.name} (${outputFile.length()} bytes)")
                Result.success(outputFile)
            } else {
                Result.failure(IllegalStateException("Export file verification failed (empty or corrupt output)."))
            }
        } catch (e: Exception) {
            Log.e(TAG, "Export failed", e)
            Result.failure(e)
        }
    }

    private fun updateWavHeader(
        file: File,
        totalAudioLen: Long,
        totalDataLen: Long,
        longSampleRate: Int,
        channels: Int,
        byteRate: Int
    ) {
        val raf = RandomAccessFile(file, "rw")
        val header = ByteArray(44)

        header[0] = 'R'.code.toByte()
        header[1] = 'I'.code.toByte()
        header[2] = 'F'.code.toByte()
        header[3] = 'F'.code.toByte()
        header[4] = (totalDataLen and 0xff).toByte()
        header[5] = ((totalDataLen shr 8) and 0xff).toByte()
        header[6] = ((totalDataLen shr 16) and 0xff).toByte()
        header[7] = ((totalDataLen shr 24) and 0xff).toByte()

        header[8] = 'W'.code.toByte()
        header[9] = 'A'.code.toByte()
        header[10] = 'V'.code.toByte()
        header[11] = 'E'.code.toByte()

        header[12] = 'f'.code.toByte()
        header[13] = 'm'.code.toByte()
        header[14] = 't'.code.toByte()
        header[15] = ' '.code.toByte()
        header[16] = 16
        header[17] = 0
        header[18] = 0
        header[19] = 0
        header[20] = 1 // PCM
        header[21] = 0
        header[22] = channels.toByte()
        header[23] = 0
        header[24] = (longSampleRate and 0xff).toByte()
        header[25] = ((longSampleRate shr 8) and 0xff).toByte()
        header[26] = ((longSampleRate shr 16) and 0xff).toByte()
        header[27] = ((longSampleRate shr 24) and 0xff).toByte()
        header[28] = (byteRate and 0xff).toByte()
        header[29] = ((byteRate shr 8) and 0xff).toByte()
        header[30] = ((byteRate shr 16) and 0xff).toByte()
        header[31] = ((byteRate shr 24) and 0xff).toByte()
        header[32] = (channels * BITS_PER_SAMPLE / 8).toByte()
        header[33] = 0
        header[34] = BITS_PER_SAMPLE.toByte()
        header[35] = 0

        header[36] = 'd'.code.toByte()
        header[37] = 'a'.code.toByte()
        header[38] = 't'.code.toByte()
        header[39] = 'a'.code.toByte()
        header[40] = (totalAudioLen and 0xff).toByte()
        header[41] = ((totalAudioLen shr 8) and 0xff).toByte()
        header[42] = ((totalAudioLen shr 16) and 0xff).toByte()
        header[43] = ((totalAudioLen shr 24) and 0xff).toByte()

        raf.seek(0)
        raf.write(header)
        raf.close()
    }

    /**
     * Downloads/saves the final WAV file directly into the device's external storage
     * (Music/MelodyAI directory) via Android MediaStore.
     * Verifies that the file is created with correct byte size.
     */
    suspend fun saveWavToDeviceStorage(
        context: Context,
        sourceFile: File
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            if (!sourceFile.exists() || sourceFile.length() <= 44L) {
                return@withContext Result.failure(IllegalStateException("Master audio file does not exist or is empty."))
            }

            val fileName = "MelodyStudio_${System.currentTimeMillis()}.wav"
            val resolver = context.contentResolver

            val values = ContentValues().apply {
                put(MediaStore.Audio.Media.DISPLAY_NAME, fileName)
                put(MediaStore.Audio.Media.MIME_TYPE, "audio/wav")
                put(MediaStore.Audio.Media.TITLE, "Melody AI Studio Master")
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    put(MediaStore.Audio.Media.RELATIVE_PATH, "${Environment.DIRECTORY_MUSIC}/MelodyAI")
                    put(MediaStore.Audio.Media.IS_PENDING, 1)
                }
            }

            val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            } else {
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
            }

            val itemUri: Uri = resolver.insert(collection, values)
                ?: return@withContext Result.failure(IllegalStateException("Could not create MediaStore entry in Music directory."))

            resolver.openOutputStream(itemUri)?.use { outStream ->
                FileInputStream(sourceFile).use { inStream ->
                    inStream.copyTo(outStream)
                }
                outStream.flush()
            } ?: return@withContext Result.failure(IllegalStateException("Failed to open output stream to storage."))

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                values.clear()
                values.put(MediaStore.Audio.Media.IS_PENDING, 0)
                resolver.update(itemUri, values, null, null)
            }

            // Verify file written
            val pfd = resolver.openFileDescriptor(itemUri, "r")
            val savedBytes = pfd?.statSize ?: 0L
            pfd?.close()

            if (savedBytes <= 44L) {
                return@withContext Result.failure(IllegalStateException("Saved file verification failed (size: $savedBytes bytes)."))
            }

            val relativePathDesc = "Music/MelodyAI/$fileName"
            Log.d(TAG, "Successfully saved master WAV to MediaStore: $relativePathDesc ($savedBytes bytes)")
            Result.success(relativePathDesc)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to save WAV to device storage", e)
            Result.failure(e)
        }
    }

    fun shareMasterAudio(context: Context, file: File) {
        try {
            val contentUri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )

            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "audio/wav"
                putExtra(Intent.EXTRA_STREAM, contentUri)
                putExtra(Intent.EXTRA_SUBJECT, "Melody AI Studio Master Audio")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            val chooser = Intent.createChooser(shareIntent, "Share Master WAV").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(chooser)
        } catch (e: Exception) {
            Log.e(TAG, "Share failed", e)
        }
    }
}
