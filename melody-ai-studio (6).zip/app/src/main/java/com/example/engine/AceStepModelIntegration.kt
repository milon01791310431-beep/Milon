package com.example.engine

import java.io.File

data class ServerHealth(
    val isOnline: Boolean = false,
    val modelName: String = "None (Offline Mode)",
    val gpuAvailable: Boolean = false,
    val message: String = "App runs 100% offline on-device"
)

data class AiGenerationTaskResponse(
    val taskId: String = "",
    val status: String = "offline",
    val progress: Float = 0f,
    val error: String? = null,
    val downloadUrl: String? = null
)

/**
 * Dormant, inactive interface reserved for future server integration.
 *
 * Current Version Requirement:
 * The app functions 100% offline with zero cloud, remote, or network requests.
 * All generation is handled exclusively by the local on-device DSP synthesizer engines.
 */
interface RemoteMusicServerService {
    fun isConfigured(): Boolean
    suspend fun checkHealth(): ServerHealth
    suspend fun submitVocalAndGenerate(
        analysis: VocalAnalysis,
        vocalFile: File,
        outputFile: File,
        onProgress: (String) -> Unit
    ): Result<File>
}

/**
 * Inactive reference implementation ensuring the app has no active network dependencies.
 */
class InactiveAceStepClient(var endpointUrl: String = "") : RemoteMusicServerService {
    override fun isConfigured(): Boolean {
        val trimmed = endpointUrl.trim()
        return trimmed.isNotBlank() && (trimmed.startsWith("http://") || trimmed.startsWith("https://"))
    }

    override suspend fun checkHealth(): ServerHealth {
        return ServerHealth(
            isOnline = false,
            modelName = "Offline DSP Synthesizer",
            gpuAvailable = false,
            message = "Offline Mode active: Generation runs 100% locally on-device without network."
        )
    }

    override suspend fun submitVocalAndGenerate(
        analysis: VocalAnalysis,
        vocalFile: File,
        outputFile: File,
        onProgress: (String) -> Unit
    ): Result<File> {
        return Result.failure(
            UnsupportedOperationException("Remote server generation is disabled in offline mode. Use local DSP pipeline.")
        )
    }
}
