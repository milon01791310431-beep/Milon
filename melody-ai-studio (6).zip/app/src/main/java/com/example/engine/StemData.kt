package com.example.engine

import kotlin.math.abs
import kotlin.math.sqrt

/**
 * Common data structure representing an individual instrumental stem track
 * (Bass, Drums, Piano, Guitar, Strings) with verified metadata, channel layout,
 * peak level, RMS, and integrity validation.
 */
data class StemData(
    val stemName: String,
    val sampleRate: Int = VocalAnalysisEngine.TARGET_SAMPLE_RATE,
    val channelCount: Int = VocalAnalysisEngine.TARGET_CHANNELS,
    val frameCount: Int,
    val peakLevel: Int,
    val averageRms: Float,
    val isSilentOrCorrupt: Boolean,
    val pcmSamples: ShortArray
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is StemData) return false
        return stemName == other.stemName && frameCount == other.frameCount
    }

    override fun hashCode(): Int = stemName.hashCode() * 31 + frameCount

    companion object {
        fun createFromPcm(stemName: String, pcm: ShortArray, totalFrames: Int): StemData {
            if (pcm.isEmpty() || totalFrames <= 0) {
                return StemData(
                    stemName = stemName,
                    frameCount = 0,
                    peakLevel = 0,
                    averageRms = 0f,
                    isSilentOrCorrupt = true,
                    pcmSamples = ShortArray(0)
                )
            }

            var peak = 0
            var sumSquares = 0.0
            val count = minOf(pcm.size, totalFrames * VocalAnalysisEngine.TARGET_CHANNELS)

            for (i in 0 until count) {
                val s = abs(pcm[i].toInt())
                if (s > peak) peak = s
                sumSquares += (s * s)
            }

            val rms = if (count > 0) sqrt(sumSquares / count).toFloat() else 0f
            val isSilent = peak < 50 // effectively silence / corrupt

            return StemData(
                stemName = stemName,
                frameCount = totalFrames,
                peakLevel = peak,
                averageRms = rms,
                isSilentOrCorrupt = isSilent,
                pcmSamples = pcm
            )
        }
    }
}
