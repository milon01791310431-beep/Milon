package com.example.engine

import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * ENGINE 4: Local Piano Engine (Acoustic Grand Piano Synthesis)
 *
 * Implements physical acoustic piano modeling:
 * - Stiff string inharmonicity overtone series: f_k = k * f_0 * sqrt(1 + B * k^2)
 * - Dual-stage soundboard decay (fast hammer strike dissipation + warm sustain resonance)
 * - Natural stereo soundstage (bass strings left, treble strings right)
 * - Left-hand bass octaves and right-hand staggered voicing rolls
 *
 * Note: Physical acoustic synthesis, not remote generative AI.
 */
object PianoEngine {
    private const val SAMPLE_RATE = VocalAnalysisEngine.TARGET_SAMPLE_RATE
    private const val CHANNELS = VocalAnalysisEngine.TARGET_CHANNELS

    fun generateStem(
        analysis: VocalAnalysis,
        totalFrames: Int,
        chords: List<List<Double>>,
        aiStemPcm: ShortArray? = null
    ): StemData {
        if (aiStemPcm != null && aiStemPcm.isNotEmpty()) {
            return StemData.createFromPcm("Piano", aiStemPcm, totalFrames)
        }

        val pcm = ShortArray(totalFrames * CHANNELS)
        val bpm = analysis.estimatedBpm.toDouble()
        val beatSec = 60.0 / bpm
        val framesPerBeat = (beatSec * SAMPLE_RATE).toInt().coerceAtLeast(1)
        val beatsPerChord = 4
        val framesPerChord = framesPerBeat * beatsPerChord

        for (frame in 0 until totalFrames) {
            val time = frame.toDouble() / SAMPLE_RATE
            val beatIndex = frame / framesPerBeat
            val beatFrac = (frame % framesPerBeat).toDouble() / framesPerBeat
            val chordIdx = ((frame / framesPerChord) % chords.size)
            val currentChord = chords[chordIdx]

            var left = 0.0
            var right = 0.0

            // 1. Left Hand: Deep bass octaves on downbeats (beats 0 and 2)
            if (beatIndex % 2 == 0) {
                val lhFreq = normalizePianoBass(currentChord[0])
                val lhTime = beatFrac * beatSec
                val lhEnv = 0.40 * exp(-lhTime * 4.5) + 0.60 * exp(-lhTime * 1.1)

                val lhTone = synthesizePianoNote(lhFreq, time, lhEnv) * 0.22
                // Panned left (70% L, 30% R)
                left += lhTone * 1.30
                right += lhTone * 0.70
            }

            // 2. Right Hand: Natural rolled triad voicings on beats 1, 2, 3
            for ((noteIdx, freq) in currentChord.withIndex()) {
                val staggerOffset = noteIdx * 0.045
                val adjustedFrac = (beatFrac - staggerOffset).coerceAtLeast(0.0)
                val rhTime = adjustedFrac * beatSec
                val rhEnv = 0.45 * exp(-rhTime * 5.2) + 0.55 * exp(-rhTime * 1.4)

                val rhTone = synthesizePianoNote(freq, time, rhEnv) * 0.14

                // Stereo spatial pan across piano keyboard
                val panRight = 0.35 + (noteIdx * 0.20)
                left += rhTone * (1.0 - panRight) * 1.5
                right += rhTone * panRight * 1.5
            }

            val sampleL = (left * 25000.0).coerceIn(-32767.0, 32767.0).toInt().toShort()
            val sampleR = (right * 25000.0).coerceIn(-32767.0, 32767.0).toInt().toShort()

            pcm[frame * CHANNELS] = sampleL
            pcm[frame * CHANNELS + 1] = sampleR
        }

        return StemData.createFromPcm("Piano", pcm, totalFrames)
    }

    /**
     * Synthesizes piano note with string stiffness inharmonicity.
     */
    private fun synthesizePianoNote(f0: Double, time: Double, env: Double): Double {
        val b = 0.00035 // Inharmonicity coefficient
        var note = 0.0
        val weights = doubleArrayOf(1.0, 0.48, 0.22, 0.10, 0.04)

        for (k in 1..5) {
            val f_k = k * f0 * sqrt(1.0 + b * k * k)
            val harmonicWeight = weights[k - 1]
            note += sin(2.0 * PI * f_k * time) * harmonicWeight
        }
        return note * env
    }

    private fun normalizePianoBass(freq: Double): Double {
        var f = freq
        while (f > 140.0) f /= 2.0
        while (f < 65.0) f *= 2.0
        return f
    }
}
