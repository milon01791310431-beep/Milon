package com.example.engine

import android.util.Log
import kotlin.math.abs
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.sqrt

data class MasteringReport(
    val integratedLoudnessDbfs: Float, // RMS dBFS loudness metric
    val peakDbfs: Float,
    val truePeakDbfs: Float,
    val clippingDetected: Boolean,
    val stereoCorrelation: Float, // -1.0 to +1.0
    val isStereoCompatible: Boolean,
    val masteredPcm: ShortArray
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is MasteringReport) return false
        return integratedLoudnessDbfs == other.integratedLoudnessDbfs &&
                masteredPcm.size == other.masteredPcm.size
    }

    override fun hashCode(): Int = integratedLoudnessDbfs.hashCode() * 31 + masteredPcm.size
}

/**
 * ENGINE 9: Mastering Engine
 *
 * Implements professional audio mastering verification:
 * 1. RMS Loudness measurement (dBFS)
 * 2. Peak & 4x Cubic Oversampled Inter-Sample True-Peak detection (dBFS TP)
 * 3. Digital full-scale clipping & distortion verification
 * 4. Stereo phase correlation & mono-compatibility check
 * 5. High-frequency air balance filter (> 10 kHz)
 * 6. Transparent soft-knee mastering limiter (-0.5 dBFS ceiling ~ 30800)
 */
object MasteringEngine {
    private const val TAG = "MasteringEngine"
    private const val SAMPLE_RATE = VocalAnalysisEngine.TARGET_SAMPLE_RATE
    private const val CHANNELS = VocalAnalysisEngine.TARGET_CHANNELS

    fun master(
        mixedPcm: ShortArray,
        fadeInSec: Float = 0.5f,
        fadeOutSec: Float = 1.8f
    ): MasteringReport {
        val totalFrames = mixedPcm.size / CHANNELS
        val masteredPcm = ShortArray(mixedPcm.size)

        val clipSec = totalFrames.toFloat() / SAMPLE_RATE
        val effectiveFadeIn = kotlin.math.min(fadeInSec, clipSec * 0.1f)
        val effectiveFadeOut = kotlin.math.min(fadeOutSec, clipSec * 0.15f)
        val fadeInFrames = (effectiveFadeIn * SAMPLE_RATE).toInt()
        val fadeOutFrames = (effectiveFadeOut * SAMPLE_RATE).toInt()
        val fadeOutStart = max(0, totalFrames - fadeOutFrames)

        // 1. Air balance shelf filter
        var airFilterL = 0.0f
        var airFilterR = 0.0f
        val airAlpha = 0.75f

        // 2. Metrics accumulators
        var sumSquaresTotal = 0.0
        var maxPeakSample = 0
        var maxTruePeakSample = 0.0f
        var sumLR = 0.0
        var sumL2 = 0.0
        var sumR2 = 0.0
        var clippedCount = 0

        for (frame in 0 until totalFrames) {
            val idxL = frame * CHANNELS
            val idxR = idxL + 1

            // Natural fade-in / fade-out envelope to eliminate digital clicks
            var envelope = 1.0f
            if (fadeInFrames > 0 && frame < fadeInFrames) {
                envelope = frame.toFloat() / fadeInFrames.toFloat()
            } else if (fadeOutFrames > 0 && frame >= fadeOutStart) {
                val progress = (frame - fadeOutStart).toFloat() / fadeOutFrames.toFloat()
                envelope = (1.0f - progress).coerceIn(0.0f, 1.0f)
            }

            val rawL = mixedPcm[idxL].toFloat() * envelope
            val rawR = mixedPcm[idxR].toFloat() * envelope

            // Gentle high-frequency air enhancement (> 10 kHz)
            val highPassL = rawL - airFilterL
            val highPassR = rawR - airFilterR
            airFilterL += (rawL - airFilterL) * airAlpha
            airFilterR += (rawR - airFilterR) * airAlpha

            val balancedL = rawL + (highPassL * 0.06f)
            val balancedR = rawR + (highPassR * 0.06f)

            // Transparent Soft Limiting (-0.5 dBFS ceiling ~ 30800)
            val limitedL = applySoftLimiter(balancedL)
            val limitedR = applySoftLimiter(balancedR)

            val sL = limitedL.toInt().coerceIn(-32768, 32767).toShort()
            val sR = limitedR.toInt().coerceIn(-32768, 32767).toShort()

            masteredPcm[idxL] = sL
            masteredPcm[idxR] = sR

            // Absolute sample peak
            val absL = abs(sL.toInt())
            val absR = abs(sR.toInt())
            val framePeak = max(absL, absR)
            if (framePeak > maxPeakSample) maxPeakSample = framePeak
            if (framePeak >= 32760) clippedCount++

            sumSquaresTotal += (sL * sL) + (sR * sR)
            sumLR += (sL.toDouble() * sR.toDouble())
            sumL2 += (sL.toDouble() * sL.toDouble())
            sumR2 += (sR.toDouble() * sR.toDouble())
        }

        // 3. 4x Oversampled Inter-Sample True-Peak estimation using Cubic Hermite Spline
        val step = max(1, totalFrames / 10000) // Sample up to 10,000 frames for fast analysis
        for (f in 1 until (totalFrames - 2) step step) {
            val i0 = (f - 1) * CHANNELS
            val i1 = f * CHANNELS
            val i2 = (f + 1) * CHANNELS
            val i3 = (f + 2) * CHANNELS

            for (ch in 0..1) {
                val y0 = masteredPcm[i0 + ch].toFloat()
                val y1 = masteredPcm[i1 + ch].toFloat()
                val y2 = masteredPcm[i2 + ch].toFloat()
                val y3 = masteredPcm[i3 + ch].toFloat()

                // Inter-sample fractions 0.25, 0.50, 0.75
                for (t in listOf(0.25f, 0.50f, 0.75f)) {
                    val interp = cubicHermite(y0, y1, y2, y3, t)
                    val absInterp = abs(interp)
                    if (absInterp > maxTruePeakSample) {
                        maxTruePeakSample = absInterp
                    }
                }
            }
        }
        if (maxTruePeakSample < maxPeakSample) {
            maxTruePeakSample = maxPeakSample.toFloat()
        }

        // Integrated RMS Loudness (dBFS)
        val meanSquare = if (totalFrames > 0) sumSquaresTotal / (totalFrames * CHANNELS) else 1.0
        val rms = sqrt(meanSquare)
        val integratedLoudnessDbfs = (20.0 * log10(max(1.0, rms) / 32768.0)).toFloat()

        // Peak dBFS & True-Peak dBFS
        val peakDbfs = (20.0 * log10(max(1, maxPeakSample).toDouble() / 32768.0)).toFloat()
        val truePeakDbfs = (20.0 * log10(max(1.0, maxTruePeakSample.toDouble()) / 32768.0)).toFloat()

        // Stereo Correlation: r = sum(L*R) / sqrt(sum(L^2) * sum(R^2))
        val denom = sqrt(sumL2 * sumR2)
        val stereoCorrelation = if (denom > 0.0) (sumLR / denom).toFloat().coerceIn(-1.0f, 1.0f) else 1.0f
        val isStereoCompatible = stereoCorrelation >= 0.20f

        val clippingDetected = clippedCount > 0

        Log.d(
            TAG,
            "Mastering Report: RMS Loudness=${"%.1f".format(integratedLoudnessDbfs)} dBFS, " +
                    "Peak=${"%.2f".format(peakDbfs)} dBFS, TruePeak=${"%.2f".format(truePeakDbfs)} dBFS TP, " +
                    "StereoCorr=${"%.2f".format(stereoCorrelation)}, Clipped=$clippingDetected"
        )

        return MasteringReport(
            integratedLoudnessDbfs = integratedLoudnessDbfs,
            peakDbfs = peakDbfs,
            truePeakDbfs = truePeakDbfs,
            clippingDetected = clippingDetected,
            stereoCorrelation = stereoCorrelation,
            isStereoCompatible = isStereoCompatible,
            masteredPcm = masteredPcm
        )
    }

    /**
     * Cubic Hermite spline for 4x inter-sample true-peak reconstruction.
     */
    private fun cubicHermite(y0: Float, y1: Float, y2: Float, y3: Float, t: Float): Float {
        val a = -0.5f * y0 + 1.5f * y1 - 1.5f * y2 + 0.5f * y3
        val b = y0 - 2.5f * y1 + 2.0f * y2 - 0.5f * y3
        val c = -0.5f * y0 + 0.5f * y2
        val d = y1
        return a * t * t * t + b * t * t + c * t + d
    }

    /**
     * Soft-knee mastering limiter with -0.5 dBFS safety ceiling (~30800).
     */
    private fun applySoftLimiter(sample: Float): Float {
        val absVal = abs(sample)
        val threshold = 27000.0f
        val ceiling = 30800.0f // -0.5 dBFS

        return if (absVal <= threshold) {
            sample
        } else {
            val excess = absVal - threshold
            val sign = if (sample > 0) 1.0f else -1.0f
            val compressed = threshold + (excess * 0.35f)
            sign * compressed.coerceAtMost(ceiling)
        }
    }
}
