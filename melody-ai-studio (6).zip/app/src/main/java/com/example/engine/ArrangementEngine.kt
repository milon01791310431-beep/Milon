package com.example.engine

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.max
import kotlin.math.min

data class ArrangedInstrumental(
    val bassStem: StemData,
    val drumStem: StemData,
    val pianoStem: StemData,
    val guitarStem: StemData,
    val stringsStem: StemData,
    val combinedAccompanimentPcm: ShortArray,
    val totalFrames: Int,
    val sectionCount: Int
)

/**
 * ENGINE 7: Music Arrangement Engine
 *
 * Coordinates the 5 instrumental parts according to the vocal's timing,
 * tempo, detected musical key, and professional dynamic song structure
 * (Intro, Verse, Chorus, Bridge, Outro).
 */
object ArrangementEngine {
    private const val TAG = "ArrangementEngine"
    private const val SAMPLE_RATE = VocalAnalysisEngine.TARGET_SAMPLE_RATE
    private const val CHANNELS = VocalAnalysisEngine.TARGET_CHANNELS

    /**
     * Builds authentic diatonic chord progressions based on the detected key.
     * Major Key: I - V - vi - IV
     * Minor Key: i - VI - III - VII
     */
    fun buildDiatonicChords(keyName: String, rootFreqHz: Double): List<List<Double>> {
        val isMinor = keyName.contains("minor", ignoreCase = true)
        val f0 = rootFreqHz.coerceIn(55.0, 440.0)

        fun noteFreq(semitones: Int): Double {
            val freq = f0 * Math.pow(2.0, semitones / 12.0)
            var f = freq
            while (f > 420.0) f /= 2.0
            while (f < 130.0) f *= 2.0
            return f
        }

        return if (!isMinor) {
            // Major Key: I - V - vi - IV (e.g. C - G - Am - F)
            val c1 = listOf(noteFreq(0), noteFreq(4), noteFreq(7))
            val c2 = listOf(noteFreq(7), noteFreq(11), noteFreq(14))
            val c3 = listOf(noteFreq(9), noteFreq(12), noteFreq(16))
            val c4 = listOf(noteFreq(5), noteFreq(9), noteFreq(12))
            listOf(c1, c2, c3, c4)
        } else {
            // Minor Key: i - VI - III - VII (e.g. Am - F - C - G)
            val c1 = listOf(noteFreq(0), noteFreq(3), noteFreq(7))
            val c2 = listOf(noteFreq(8), noteFreq(12), noteFreq(15))
            val c3 = listOf(noteFreq(3), noteFreq(7), noteFreq(10))
            val c4 = listOf(noteFreq(10), noteFreq(14), noteFreq(17))
            listOf(c1, c2, c3, c4)
        }
    }

    suspend fun arrange(
        analysis: VocalAnalysis,
        aiStems: Map<String, ShortArray>? = null,
        onProgress: (String) -> Unit
    ): ArrangedInstrumental = withContext(Dispatchers.Default) {
        val vocalFrames = analysis.pcmStereoSamples.size / CHANNELS
        // Headroom for natural reverb decay after vocal ends
        val totalFrames = max(vocalFrames, (analysis.durationMs * SAMPLE_RATE / 1000L).toInt() + (SAMPLE_RATE * 2))

        val chords = buildDiatonicChords(analysis.keyName, analysis.rootFrequencyHz)
        Log.d(TAG, "Generated diatonic chord progression for key '${analysis.keyName}': $chords")

        onProgress("Arrangement: Generating Bass stem...")
        val bassStem = BassEngine.generateStem(analysis, totalFrames, chords, aiStems?.get("bass"))

        onProgress("Arrangement: Generating Drum & Percussion stem...")
        val drumStem = DrumEngine.generateStem(analysis, totalFrames, aiStems?.get("drums"))

        onProgress("Arrangement: Generating Piano stem...")
        val pianoStem = PianoEngine.generateStem(analysis, totalFrames, chords, aiStems?.get("piano"))

        onProgress("Arrangement: Generating Guitar stem...")
        val guitarStem = GuitarEngine.generateStem(analysis, totalFrames, chords, aiStems?.get("guitar"))

        onProgress("Arrangement: Generating Strings & Texture stem...")
        val stringsStem = StringsTextureEngine.generateStem(analysis, totalFrames, chords, aiStems?.get("strings"))

        onProgress("Arrangement: Dynamic section orchestration (Intro, Verse, Chorus, Bridge, Outro)...")
        coordinateStems(
            analysis = analysis,
            bassStem = bassStem,
            drumStem = drumStem,
            pianoStem = pianoStem,
            guitarStem = guitarStem,
            stringsStem = stringsStem,
            totalFrames = totalFrames
        )
    }

    fun coordinateStems(
        analysis: VocalAnalysis,
        bassStem: StemData,
        drumStem: StemData,
        pianoStem: StemData,
        guitarStem: StemData,
        stringsStem: StemData,
        totalFrames: Int
    ): ArrangedInstrumental {
        val combined = ShortArray(totalFrames * CHANNELS)

        val beatSec = 60.0 / analysis.estimatedBpm.toDouble()
        val framesPerMeasure = (beatSec * 4.0 * SAMPLE_RATE).toInt().coerceAtLeast(1)
        val onsetFrame = (analysis.vocalOnsetMs * SAMPLE_RATE / 1000L).toInt().coerceIn(0, totalFrames)
        val totalMeasures = (totalFrames / framesPerMeasure).coerceAtLeast(1)

        for (frame in 0 until totalFrames) {
            val idxL = frame * CHANNELS
            val idxR = idxL + 1

            val measureIdx = frame / framesPerMeasure
            val isIntro = frame < onsetFrame || measureIdx < 2
            val isOutro = measureIdx >= (totalMeasures - 2)
            val isBridge = !isIntro && !isOutro && (measureIdx in 16..19)
            val isChorus = !isIntro && !isOutro && !isBridge && ((measureIdx % 8) in 4..7)

            // Dynamic gain automation across musical sections:
            // Intro: Drums and Bass completely muted; warm acoustic piano, guitar & strings lead in
            // Verse: Tight rhythmic groove with balanced accompaniment
            // Chorus: Full energy swell with driving drums, bass punch, and lush strings
            // Bridge: Breakdown with tom fills, ambient strings swell, stripped guitar
            // Outro: Natural fade out to silence
            val (bGain, dGain, pGain, gGain, sGain) = when {
                isIntro -> listOf(0.00f, 0.00f, 0.55f, 0.50f, 0.35f)
                isOutro -> listOf(0.20f, 0.20f, 0.50f, 0.40f, 0.45f)
                isBridge -> listOf(0.70f, 0.75f, 0.70f, 0.25f, 0.75f)
                isChorus -> listOf(0.90f, 0.85f, 0.75f, 0.75f, 0.65f)
                else -> listOf(0.75f, 0.65f, 0.60f, 0.60f, 0.40f) // Verse
            }

            val bL = if (!bassStem.isSilentOrCorrupt && idxL < bassStem.pcmSamples.size) bassStem.pcmSamples[idxL] * bGain else 0f
            val bR = if (!bassStem.isSilentOrCorrupt && idxR < bassStem.pcmSamples.size) bassStem.pcmSamples[idxR] * bGain else 0f

            val dL = if (!drumStem.isSilentOrCorrupt && idxL < drumStem.pcmSamples.size) drumStem.pcmSamples[idxL] * dGain else 0f
            val dR = if (!drumStem.isSilentOrCorrupt && idxR < drumStem.pcmSamples.size) drumStem.pcmSamples[idxR] * dGain else 0f

            val pL = if (!pianoStem.isSilentOrCorrupt && idxL < pianoStem.pcmSamples.size) pianoStem.pcmSamples[idxL] * pGain else 0f
            val pR = if (!pianoStem.isSilentOrCorrupt && idxR < pianoStem.pcmSamples.size) pianoStem.pcmSamples[idxR] * pGain else 0f

            val gL = if (!guitarStem.isSilentOrCorrupt && idxL < guitarStem.pcmSamples.size) guitarStem.pcmSamples[idxL] * gGain else 0f
            val gR = if (!guitarStem.isSilentOrCorrupt && idxR < guitarStem.pcmSamples.size) guitarStem.pcmSamples[idxR] * gGain else 0f

            val sL = if (!stringsStem.isSilentOrCorrupt && idxL < stringsStem.pcmSamples.size) stringsStem.pcmSamples[idxL] * sGain else 0f
            val sR = if (!stringsStem.isSilentOrCorrupt && idxR < stringsStem.pcmSamples.size) stringsStem.pcmSamples[idxR] * sGain else 0f

            val sumL = (bL + dL + pL + gL + sL).coerceIn(-32767.0f, 32767.0f)
            val sumR = (bR + dR + pR + gR + sR).coerceIn(-32767.0f, 32767.0f)

            combined[idxL] = sumL.toInt().toShort()
            combined[idxR] = sumR.toInt().toShort()
        }

        Log.d(TAG, "Arrangement coordinated across $totalMeasures musical measures.")

        return ArrangedInstrumental(
            bassStem = bassStem,
            drumStem = drumStem,
            pianoStem = pianoStem,
            guitarStem = guitarStem,
            stringsStem = stringsStem,
            combinedAccompanimentPcm = combined,
            totalFrames = totalFrames,
            sectionCount = totalMeasures
        )
    }
}
