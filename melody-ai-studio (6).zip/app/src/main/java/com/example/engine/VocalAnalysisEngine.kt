package com.example.engine

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * ENGINE 1: Vocal Analysis Engine
 *
 * Performs high-quality audio decoding, linear-interpolated resampling,
 * autocorrelation-based BPM detection with confidence scoring,
 * chromagram-based Krumhansl-Schmuckler musical key detection with confidence scoring,
 * vocal onset detection, and phrase boundary segmentation.
 */
data class VocalAnalysis(
    val fileName: String,
    val durationMs: Long,
    val fileSizeBytes: Long,
    val sampleRate: Int = VocalAnalysisEngine.TARGET_SAMPLE_RATE,
    val channelCount: Int = VocalAnalysisEngine.TARGET_CHANNELS,
    val estimatedBpm: Int,
    val bpmConfidence: Float, // 0.0 to 1.0
    val rootFrequencyHz: Double,
    val keyName: String,
    val keyConfidence: Float, // 0.0 to 1.0
    val isConfident: Boolean,
    val vocalOnsetMs: Long,
    val phraseBoundariesMs: List<Long>,
    val averageVocalRms: Float,
    val peakSample: Int,
    val pcmStereoSamples: ShortArray
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is VocalAnalysis) return false
        return fileName == other.fileName && durationMs == other.durationMs
    }

    override fun hashCode(): Int = fileName.hashCode() * 31 + durationMs.hashCode()
}

object VocalAnalysisEngine {
    private const val TAG = "VocalAnalysisEngine"
    const val TARGET_SAMPLE_RATE = 44100
    const val TARGET_CHANNELS = 2
    private const val MAX_SUPPORTED_SIZE = 35 * 1024 * 1024L // 35 MB

    // Krumhansl-Schmuckler Key Profiles (12 pitch classes: C, C#, D, D#, E, F, F#, G, G#, A, A#, B)
    private val MAJOR_PROFILE = doubleArrayOf(6.35, 2.23, 3.48, 2.33, 4.38, 4.09, 2.52, 5.19, 2.39, 3.66, 2.29, 2.88)
    private val MINOR_PROFILE = doubleArrayOf(6.33, 2.68, 3.52, 5.38, 2.60, 3.53, 2.54, 4.75, 3.98, 2.69, 3.34, 3.17)
    private val NOTE_NAMES = listOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")
    private val NOTE_FREQUENCIES = doubleArrayOf(
        130.81, 138.59, 146.83, 155.56, 164.81, 174.61, 185.00, 196.00, 207.65, 220.00, 233.08, 246.94
    )

    fun validateAudioFile(file: File): String? {
        if (!file.exists() || file.length() == 0L) {
            return "Audio file is empty or missing."
        }
        val ext = file.extension.lowercase()
        if (ext !in listOf("mp3", "wav", "m4a", "aac", "ogg")) {
            return "Unsupported format '.$ext'. Please upload an MP3, WAV, or M4A file."
        }
        if (file.length() > MAX_SUPPORTED_SIZE) {
            return "File size (${file.length() / (1024 * 1024)} MB) exceeds 35 MB safety threshold for 4 GB RAM mobile devices."
        }
        try {
            val mmr = MediaMetadataRetriever()
            mmr.setDataSource(file.absolutePath)
            val durStr = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
            mmr.release()
            val durMs = durStr?.toLongOrNull() ?: 0L
            if (durMs > 180_000L) {
                return "Audio file duration (${durMs / 1000}s) exceeds the 3-minute limit. Melody AI Studio offline engine supports audio up to 180 seconds for stable memory on 4 GB RAM mobile devices. Please trim to under 3 minutes."
            }
        } catch (_: Exception) {}
        return null
    }

    suspend fun analyze(
        context: Context,
        audioFile: File,
        onProgress: (String) -> Unit
    ): Result<VocalAnalysis> = withContext(Dispatchers.IO) {
        val validationErr = validateAudioFile(audioFile)
        if (validationErr != null) {
            return@withContext Result.failure(IllegalArgumentException(validationErr))
        }

        onProgress("Decoding audio stream into 44.1 kHz PCM...")
        var pcm: ShortArray? = null
        if (audioFile.extension.equals("wav", ignoreCase = true)) {
            pcm = decodeWavDirect(audioFile)
        }
        if (pcm == null) {
            pcm = decodeAudioToStereoPcm(context, Uri.fromFile(audioFile))
        }
        if (pcm == null && !audioFile.extension.equals("wav", ignoreCase = true)) {
            pcm = decodeWavDirect(audioFile)
        }

        if (pcm == null || pcm.isEmpty()) {
            return@withContext Result.failure(IllegalStateException("Could not decode audio into PCM format. Please upload a valid MP3, WAV, or M4A audio file."))
        }

        onProgress("Extracting vocal timing and audio duration...")
        var durationMs = 0L
        try {
            val mmr = MediaMetadataRetriever()
            mmr.setDataSource(audioFile.absolutePath)
            durationMs = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            mmr.release()
        } catch (_: Exception) {}

        if (durationMs <= 0L) {
            durationMs = (pcm.size.toLong() * 1000L) / (TARGET_SAMPLE_RATE * TARGET_CHANNELS)
        }

        onProgress("Computing energy profile and onset detection...")
        val windowSize = TARGET_SAMPLE_RATE / 20 // 50ms windows
        val totalFrames = pcm.size / TARGET_CHANNELS
        var peak = 0
        var totalEnergy = 0.0

        val energyProfile = mutableListOf<Float>()
        for (i in 0 until totalFrames step windowSize) {
            var sum = 0.0
            val count = min(windowSize, totalFrames - i)
            for (j in 0 until count) {
                val s = abs(pcm[(i + j) * TARGET_CHANNELS].toInt())
                if (s > peak) peak = s
                sum += (s * s)
            }
            val rms = sqrt(sum / count).toFloat()
            energyProfile.add(rms)
            totalEnergy += rms
        }

        val avgRms = if (energyProfile.isNotEmpty()) (totalEnergy / energyProfile.size).toFloat() else 1000f

        // Detect Vocal Onset (first sustained energy window above 28% avg RMS)
        var onsetWindow = 0
        val onsetThreshold = avgRms * 0.28f
        for (idx in energyProfile.indices) {
            if (energyProfile[idx] > onsetThreshold) {
                onsetWindow = idx
                break
            }
        }
        val vocalOnsetMs = (onsetWindow * 50L).coerceAtLeast(0L)

        // Phrase Boundaries: detect significant pauses/breathing intervals (silence >= 350ms)
        val phraseBoundaries = mutableListOf<Long>()
        var silenceWindows = 0
        var inSilence = false
        val silenceThreshold = avgRms * 0.18f

        for (idx in energyProfile.indices) {
            if (energyProfile[idx] < silenceThreshold) {
                silenceWindows++
                if (silenceWindows >= 7 && !inSilence) {
                    inSilence = true
                    phraseBoundaries.add(idx * 50L)
                }
            } else {
                silenceWindows = 0
                inSilence = false
            }
        }

        onProgress("Computing autocorrelation tempo (BPM) analysis...")
        val (detectedBpm, bpmConf) = detectBpmWithConfidence(energyProfile)

        onProgress("Computing chromagram and musical key correlation...")
        val keyResult = detectKeyWithConfidence(pcm)

        val isConfident = bpmConf >= 0.40f && keyResult.confidence >= 0.40f

        Log.d(
            TAG,
            "Analysis Result: BPM=$detectedBpm (conf: ${(bpmConf * 100).toInt()}%), " +
                    "Key=${keyResult.keyName} (conf: ${(keyResult.confidence * 100).toInt()}%), " +
                    "Onset=${vocalOnsetMs}ms, Dur=${durationMs}ms"
        )

        Result.success(
            VocalAnalysis(
                fileName = audioFile.name,
                durationMs = durationMs,
                fileSizeBytes = audioFile.length(),
                sampleRate = TARGET_SAMPLE_RATE,
                channelCount = TARGET_CHANNELS,
                estimatedBpm = detectedBpm,
                bpmConfidence = bpmConf,
                rootFrequencyHz = keyResult.rootFrequencyHz,
                keyName = keyResult.keyName,
                keyConfidence = keyResult.confidence,
                isConfident = isConfident,
                vocalOnsetMs = vocalOnsetMs,
                phraseBoundariesMs = phraseBoundaries,
                averageVocalRms = avgRms,
                peakSample = peak,
                pcmStereoSamples = pcm
            )
        )
    }

    /**
     * Autocorrelation-based tempo estimation with onset strength envelope and Gaussian tempo prior.
     * Prevents half-tempo and double-tempo octave errors.
     */
    private fun detectBpmWithConfidence(energy: List<Float>): Pair<Int, Float> {
        if (energy.size < 20) return Pair(96, 0.25f)

        // 1. First-difference rectified onset strength envelope:
        // Highlights syllabic onsets, plosives, and note attacks while removing steady-state vocal bias
        val onsetEnvelope = FloatArray(energy.size)
        for (i in 1 until energy.size) {
            val diff = energy[i] - energy[i - 1]
            onsetEnvelope[i] = if (diff > 0f) diff else 0f
        }

        val minLag = 7 // ~171 BPM at 50ms intervals
        val maxLag = min(25, onsetEnvelope.size / 2) // ~48 BPM
        if (maxLag <= minLag) return Pair(96, 0.25f)

        var maxWeightedScore = -1.0
        var bestLag = 10
        var sumCorr = 0.0
        var countLags = 0
        val scores = DoubleArray(maxLag + 1)

        for (lag in minLag..maxLag) {
            var sum = 0.0
            var count = 0
            for (i in 0 until (onsetEnvelope.size - lag)) {
                sum += (onsetEnvelope[i] * onsetEnvelope[i + lag]).toDouble()
                count++
            }
            if (count > 0) {
                val rawCorr = sum / count
                sumCorr += rawCorr
                countLags++

                val intervalSec = lag * 0.05
                val candidateBpm = 60.0 / intervalSec

                // Gaussian tempo prior centered at 115 BPM (standard musical sweet spot)
                // Prevents octave error jumping to half-time (<65 BPM) or double-time (>180 BPM)
                val diffBpm = candidateBpm - 115.0
                val prior = exp(-(diffBpm * diffBpm) / (2.0 * 38.0 * 38.0))
                val weightedScore = rawCorr * (0.60 + 0.40 * prior)
                scores[lag] = weightedScore

                if (weightedScore > maxWeightedScore) {
                    maxWeightedScore = weightedScore
                    bestLag = lag
                }
            }
        }

        // Sub-harmonic / Octave verification:
        // Check if double-tempo (lag / 2) or half-tempo (lag * 2) has strong onset reinforcement
        val doubleLag = bestLag * 2
        val halfLag = bestLag / 2
        var finalLag = bestLag

        if (doubleLag in minLag..maxLag && scores[doubleLag] > maxWeightedScore * 0.82) {
            val candBpm = 60.0 / (doubleLag * 0.05)
            if (candBpm in 75.0..140.0) {
                finalLag = doubleLag
            }
        } else if (halfLag in minLag..maxLag && scores[halfLag] > maxWeightedScore * 0.85) {
            val candBpm = 60.0 / (halfLag * 0.05)
            if (candBpm in 80.0..145.0) {
                finalLag = halfLag
            }
        }

        val avgScore = if (countLags > 0) sumCorr / countLags else 1.0
        val peakRatio = if (avgScore > 0.0) (maxWeightedScore / avgScore).toFloat() else 1.0f
        val confidence = ((peakRatio - 1.0f) / 1.8f).coerceIn(0.20f, 0.95f)

        val finalIntervalSec = finalLag * 0.05
        val rawBpm = (60.0 / finalIntervalSec).toInt()
        val bpm = rawBpm.coerceIn(60, 180)

        return Pair(bpm, confidence)
    }

    data class KeyDetectionResult(
        val keyName: String,
        val rootFrequencyHz: Double,
        val confidence: Float
    )

    /**
     * Discrete Goertzel spectral power filter for a target frequency.
     * Computes the exact Fourier magnitude squared |X(f)|^2 with a Hann window.
     */
    private fun goertzelMagnitudeSq(samples: ShortArray, startOffset: Int, length: Int, targetFreqHz: Double): Double {
        val n = length
        if (n <= 0 || startOffset + n > samples.size) return 0.0
        val omega = 2.0 * PI * targetFreqHz / TARGET_SAMPLE_RATE
        val coeff = 2.0 * cos(omega)
        var s0 = 0.0
        var s1 = 0.0
        var s2 = 0.0

        for (i in 0 until n) {
            val window = 0.5 * (1.0 - cos(2.0 * PI * i / (n - 1)))
            val x = samples[startOffset + i] * window
            s0 = x + coeff * s1 - s2
            s2 = s1
            s1 = s0
        }
        val power = s1 * s1 + s2 * s2 - coeff * s1 * s2
        return if (power > 0.0) power else 0.0
    }

    /**
     * Krumhansl-Schmuckler Chromagram key profile analysis using Goertzel Spectral DFT.
     * Computes chromagram energy across the 12 chromatic pitch classes over multiple octaves
     * (C2 up to B5) and correlates against standard Major and Minor key profiles.
     */
    private fun detectKeyWithConfidence(pcm: ShortArray): KeyDetectionResult {
        val totalFrames = pcm.size / TARGET_CHANNELS
        if (totalFrames < 2048) {
            return KeyDetectionResult("A minor (Estimated)", 220.0, 0.20f)
        }

        // Extract mono samples for spectral analysis
        val monoCount = min(totalFrames, TARGET_SAMPLE_RATE * 30) // First 30s
        val monoSamples = ShortArray(monoCount)
        for (i in 0 until monoCount) {
            monoSamples[i] = pcm[i * TARGET_CHANNELS]
        }

        // Find active vocal windows with high energy (avoiding silence)
        val windowSize = 2048
        val candidateWindows = mutableListOf<Int>()
        val step = windowSize

        for (wStart in 0 until (monoCount - windowSize) step step) {
            var sumSq = 0.0
            for (j in 0 until windowSize) {
                val s = monoSamples[wStart + j].toDouble()
                sumSq += s * s
            }
            val winRms = sqrt(sumSq / windowSize)
            if (winRms > 600.0) {
                candidateWindows.add(wStart)
            }
        }

        val selectedWindows = if (candidateWindows.size >= 8) {
            val stepSize = candidateWindows.size / 12
            (0 until 12).map { candidateWindows[min(it * stepSize, candidateWindows.size - 1)] }
        } else {
            val count = min(8, (monoCount - windowSize) / windowSize)
            (0 until count).map { it * windowSize }
        }

        val chroma = DoubleArray(12)
        // Multi-octave harmonic analysis (C2=65.4Hz up to B5=987.8Hz)
        val octaves = listOf(0.5, 1.0, 2.0, 4.0)

        for (wStart in selectedWindows) {
            for (semitone in 0 until 12) {
                val baseFreq = NOTE_FREQUENCIES[semitone]
                var pitchClassEnergy = 0.0
                for (oct in octaves) {
                    val f = baseFreq * oct
                    if (f in 60.0..1200.0) {
                        val magSq = goertzelMagnitudeSq(monoSamples, wStart, windowSize, f)
                        pitchClassEnergy += sqrt(magSq)
                    }
                }
                chroma[semitone] += pitchClassEnergy
            }
        }

        // Normalize chroma vector
        val chromaSum = chroma.sum().coerceAtLeast(1.0)
        for (i in chroma.indices) {
            chroma[i] = (chroma[i] / chromaSum) * 100.0
        }

        var bestKeyName = "A minor"
        var bestRootFreq = 220.0
        var bestCorrelation = -2.0
        var secondBestCorrelation = -2.0

        for (rootIdx in 0 until 12) {
            // Test Major profile
            val majCorr = correlateProfiles(chroma, MAJOR_PROFILE, rootIdx)
            if (majCorr > bestCorrelation) {
                secondBestCorrelation = bestCorrelation
                bestCorrelation = majCorr
                bestKeyName = "${NOTE_NAMES[rootIdx]} Major"
                bestRootFreq = NOTE_FREQUENCIES[rootIdx]
            } else if (majCorr > secondBestCorrelation) {
                secondBestCorrelation = majCorr
            }

            // Test Minor profile
            val minCorr = correlateProfiles(chroma, MINOR_PROFILE, rootIdx)
            if (minCorr > bestCorrelation) {
                secondBestCorrelation = bestCorrelation
                bestCorrelation = minCorr
                bestKeyName = "${NOTE_NAMES[rootIdx]} minor"
                bestRootFreq = NOTE_FREQUENCIES[rootIdx]
            } else if (minCorr > secondBestCorrelation) {
                secondBestCorrelation = minCorr
            }
        }

        val margin = (bestCorrelation - secondBestCorrelation).toFloat().coerceAtLeast(0.0f)
        val correlationFloat = bestCorrelation.toFloat().coerceIn(-1.0f, 1.0f)
        val confidence = if (correlationFloat > 0.35f) {
            ((correlationFloat * 0.7f) + (margin * 1.5f)).coerceIn(0.20f, 0.95f)
        } else {
            (correlationFloat * 0.5f).coerceIn(0.10f, 0.35f)
        }

        val finalKeyName = if (confidence < 0.40f) {
            "$bestKeyName (Low Confidence)"
        } else {
            bestKeyName
        }

        return KeyDetectionResult(finalKeyName, bestRootFreq, confidence)
    }

    private fun correlateProfiles(chroma: DoubleArray, profile: DoubleArray, shift: Int): Double {
        var sumX = 0.0
        var sumY = 0.0
        var sumXY = 0.0
        var sumX2 = 0.0
        var sumY2 = 0.0
        val n = 12.0

        for (i in 0 until 12) {
            val x = chroma[(i + shift) % 12]
            val y = profile[i]
            sumX += x
            sumY += y
            sumXY += x * y
            sumX2 += x * x
            sumY2 += y * y
        }

        val numerator = n * sumXY - sumX * sumY
        val denominator = sqrt((n * sumX2 - sumX * sumX) * (n * sumY2 - sumY * sumY))
        return if (denominator > 0.0) numerator / denominator else 0.0
    }

    /**
     * Decodes audio to stereo PCM and resamples to 44.1 kHz using linear interpolation.
     */
    private fun decodeAudioToStereoPcm(context: Context, audioUri: Uri): ShortArray? {
        val extractor = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            extractor.setDataSource(context, audioUri, null)
            var audioTrackIdx = -1
            var format: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val f = extractor.getTrackFormat(i)
                val mime = f.getString(MediaFormat.KEY_MIME) ?: ""
                if (mime.startsWith("audio/")) {
                    audioTrackIdx = i
                    format = f
                    break
                }
            }

            if (audioTrackIdx < 0 || format == null) {
                extractor.release()
                return null
            }

            extractor.selectTrack(audioTrackIdx)
            val mime = format.getString(MediaFormat.KEY_MIME) ?: return null
            codec = MediaCodec.createDecoderByType(mime)
            codec.configure(format, null, null, 0)
            codec.start()

            val pcmOut = ByteArrayOutputStream()
            val bufferInfo = MediaCodec.BufferInfo()
            var isEos = false
            val timeoutUs = 5000L

            val nativeRate = if (format.containsKey(MediaFormat.KEY_SAMPLE_RATE)) {
                format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            } else TARGET_SAMPLE_RATE

            val nativeChannels = if (format.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) {
                format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            } else TARGET_CHANNELS

            var actualRate = nativeRate
            var actualChannels = nativeChannels

            val maxAllowedBytes = (TARGET_SAMPLE_RATE * TARGET_CHANNELS * 2 * 180).toLong() // 3 mins max

            while (!isEos && pcmOut.size() < maxAllowedBytes) {
                val inIdx = codec.dequeueInputBuffer(timeoutUs)
                if (inIdx >= 0) {
                    val inBuffer = codec.getInputBuffer(inIdx)
                    if (inBuffer != null) {
                        val sampleSize = extractor.readSampleData(inBuffer, 0)
                        if (sampleSize < 0) {
                            codec.queueInputBuffer(inIdx, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            isEos = true
                        } else {
                            codec.queueInputBuffer(inIdx, 0, sampleSize, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }

                var outIdx = codec.dequeueOutputBuffer(bufferInfo, timeoutUs)
                while (outIdx >= 0 || outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    if (outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        val newFormat = codec.outputFormat
                        if (newFormat.containsKey(MediaFormat.KEY_SAMPLE_RATE)) {
                            actualRate = newFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        }
                        if (newFormat.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) {
                            actualChannels = newFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                        }
                    } else if (outIdx >= 0) {
                        val outBuffer = codec.getOutputBuffer(outIdx)
                        if (outBuffer != null && bufferInfo.size > 0) {
                            val chunk = ByteArray(bufferInfo.size)
                            outBuffer.position(bufferInfo.offset)
                            outBuffer.get(chunk)
                            pcmOut.write(chunk)
                        }
                        codec.releaseOutputBuffer(outIdx, false)
                    }
                    outIdx = codec.dequeueOutputBuffer(bufferInfo, timeoutUs)
                }
            }

            codec.stop()
            codec.release()
            extractor.release()

            val raw = pcmOut.toByteArray()
            if (raw.isEmpty()) return null

            val byteBuf = ByteBuffer.wrap(raw).order(ByteOrder.LITTLE_ENDIAN)
            val shortsCount = raw.size / 2
            val decoded = ShortArray(shortsCount)
            for (i in 0 until shortsCount) {
                decoded[i] = byteBuf.short
            }

            return resampleLinearInterpolated(decoded, actualRate, actualChannels)
        } catch (e: Exception) {
            Log.e(TAG, "PCM Decoding error", e)
            try { codec?.release() } catch (_: Exception) {}
            try { extractor.release() } catch (_: Exception) {}
            return null
        }
    }

    /**
     * High-quality linear interpolated resampling from sourceRate to 44.1 kHz Stereo.
     * Prevents nearest-neighbour aliasing and clicks.
     */
    fun resampleLinearInterpolated(input: ShortArray, sourceRate: Int, sourceChannels: Int): ShortArray {
        // Step 1: Normalize channels to stereo
        val stereo = when (sourceChannels) {
            1 -> {
                val st = ShortArray(input.size * 2)
                for (i in input.indices) {
                    st[i * 2] = input[i]
                    st[i * 2 + 1] = input[i]
                }
                st
            }
            2 -> input
            else -> {
                val frames = input.size / sourceChannels
                val st = ShortArray(frames * 2)
                for (f in 0 until frames) {
                    st[f * 2] = input[f * sourceChannels]
                    st[f * 2 + 1] = input[f * sourceChannels + 1]
                }
                st
            }
        }

        if (sourceRate == TARGET_SAMPLE_RATE) return stereo

        val inFrames = stereo.size / 2
        val ratio = TARGET_SAMPLE_RATE.toDouble() / sourceRate.toDouble()
        val outFrames = (inFrames * ratio).toInt()
        val result = ShortArray(outFrames * 2)

        for (i in 0 until outFrames) {
            val srcPos = i / ratio
            val srcIdx = srcPos.toInt()
            val frac = (srcPos - srcIdx).toFloat()

            val idx0 = srcIdx.coerceIn(0, inFrames - 1)
            val idx1 = (srcIdx + 1).coerceIn(0, inFrames - 1)

            // Left Channel
            val l0 = stereo[idx0 * 2].toFloat()
            val l1 = stereo[idx1 * 2].toFloat()
            val interpL = l0 + frac * (l1 - l0)
            result[i * 2] = interpL.toInt().coerceIn(-32768, 32767).toShort()

            // Right Channel
            val r0 = stereo[idx0 * 2 + 1].toFloat()
            val r1 = stereo[idx1 * 2 + 1].toFloat()
            val interpR = r0 + frac * (r1 - r0)
            result[i * 2 + 1] = interpR.toInt().coerceIn(-32768, 32767).toShort()
        }

        return result
    }

    /**
     * Direct RIFF/WAVE header and PCM parser.
     * Guaranteed offline decoding for WAV audio in all environments.
     */
    fun decodeWavDirect(file: File): ShortArray? {
        if (!file.exists() || file.length() < 44L) return null
        try {
            val bytes = file.readBytes()
            if (bytes.size < 44) return null
            if (bytes[0] != 'R'.code.toByte() || bytes[1] != 'I'.code.toByte() ||
                bytes[2] != 'F'.code.toByte() || bytes[3] != 'F'.code.toByte() ||
                bytes[8] != 'W'.code.toByte() || bytes[9] != 'A'.code.toByte() ||
                bytes[10] != 'V'.code.toByte() || bytes[11] != 'E'.code.toByte()
            ) {
                return null
            }

            val buffer = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
            var offset = 12
            var channels = TARGET_CHANNELS
            var sampleRate = TARGET_SAMPLE_RATE
            var bitsPerSample = 16
            var dataOffset = -1
            var dataSize = 0

            while (offset + 8 <= bytes.size) {
                val chunkId = String(bytes, offset, 4)
                val chunkSize = buffer.getInt(offset + 4)
                if (chunkId == "fmt ") {
                    channels = buffer.getShort(offset + 10).toInt()
                    sampleRate = buffer.getInt(offset + 12)
                    bitsPerSample = buffer.getShort(offset + 22).toInt()
                } else if (chunkId == "data") {
                    dataOffset = offset + 8
                    dataSize = chunkSize.coerceAtMost(bytes.size - dataOffset)
                    break
                }
                offset += 8 + chunkSize
            }

            if (dataOffset < 0 || dataSize <= 0) {
                if (bytes.size > 44) {
                    dataOffset = 44
                    dataSize = bytes.size - 44
                } else {
                    return null
                }
            }

            if (bitsPerSample != 16) {
                return null
            }

            val numSamples = dataSize / 2
            val samples = ShortArray(numSamples)
            buffer.position(dataOffset)
            for (i in 0 until numSamples) {
                samples[i] = buffer.short
            }

            return resampleLinearInterpolated(samples, sampleRate, channels)
        } catch (e: Exception) {
            Log.e(TAG, "decodeWavDirect error", e)
            return null
        }
    }
}

