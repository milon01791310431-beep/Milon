package com.example.engine

import android.content.Context
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

enum class GenerationStep {
    IDLE,
    VALIDATING,
    DECODING,
    ANALYZING,
    GENERATING_BASS,
    GENERATING_DRUMS,
    GENERATING_PIANO,
    GENERATING_GUITAR,
    GENERATING_STRINGS,
    ARRANGING,
    AUTO_MIXING,
    MASTERING,
    EXPORTING,
    SUCCESS,
    FAILED
}

data class GenerationProgress(
    val step: GenerationStep,
    val progressPercent: Int, // 0 to 100
    val statusMessage: String,
    val isRealAi: Boolean = false
)

data class OrchestrationResult(
    val masterWavFile: File,
    val durationMs: Long,
    val bpm: Int,
    val keyName: String,
    val isRealAiGenerated: Boolean = false,
    val generationSource: String = "Melody Studio Local Offline Audio Engine",
    val masteringReport: MasteringReport
)

/**
 * 100% Local Offline Studio Orchestrator for Melody AI Studio.
 *
 * Runs entirely on-device without remote servers, endpoints, or API keys.
 * Lightweight and optimized for 4 GB RAM Android mobile devices.
 *
 * Full 13-stage pipeline:
 * 1. Validate Vocal Audio (format, duration, size)
 * 2. Decode Vocal Audio (into 44.1 kHz PCM stereo)
 * 3. Analyze Vocal Audio (BPM, key/chords, vocal onset, phrase boundaries)
 * 4. Generate Bass Audio (via BassEngine)
 * 5. Generate Drum Audio (via DrumEngine)
 * 6. Generate Piano Audio (via PianoEngine)
 * 7. Generate Guitar Audio (via GuitarEngine)
 * 8. Generate Strings Audio (via StringsTextureEngine)
 * 9. Music Arrangement & Alignment (dynamic section coordination)
 * 10. Auto Mixing (vocal high-pass, room reverb, ducking, bass/kick separation, soft limiter)
 * 11. Mastering (loudness normalization, true-peak check, stereo correlation, air filter)
 * 12. Audio Export (16-bit 44.1 kHz Stereo lossless WAV)
 * 13. Enable playback and download controls in UI.
 */
object StudioOrchestrator {
    private const val TAG = "StudioOrchestrator"

    // Optional dormant reference for future server expansion, never invoked in offline mode
    val aceStepClient = InactiveAceStepClient()

    suspend fun executePipeline(
        context: Context,
        vocalFile: File,
        outputDir: File,
        onProgress: (GenerationProgress) -> Unit
    ): Result<OrchestrationResult> = withContext(Dispatchers.Default) {
        try {
            // Step 1: Validate Vocal Audio
            onProgress(
                GenerationProgress(
                    step = GenerationStep.VALIDATING,
                    progressPercent = 5,
                    statusMessage = "Validating vocal audio format, size, and integrity..."
                )
            )

            val validationErr = VocalAnalysisEngine.validateAudioFile(vocalFile)
            if (validationErr != null) {
                onProgress(
                    GenerationProgress(
                        step = GenerationStep.FAILED,
                        progressPercent = 0,
                        statusMessage = validationErr
                    )
                )
                return@withContext Result.failure(IllegalArgumentException(validationErr))
            }

            // Step 2: Decode Vocal Audio
            onProgress(
                GenerationProgress(
                    step = GenerationStep.DECODING,
                    progressPercent = 15,
                    statusMessage = "Decoding audio stream into 44.1 kHz stereo PCM..."
                )
            )

            // Step 3: Analyze Vocal Audio
            onProgress(
                GenerationProgress(
                    step = GenerationStep.ANALYZING,
                    progressPercent = 25,
                    statusMessage = "Analyzing vocal tempo (BPM), key, onset, and phrase boundaries..."
                )
            )

            val analysisResult = VocalAnalysisEngine.analyze(context, vocalFile) { msg ->
                onProgress(
                    GenerationProgress(
                        step = GenerationStep.ANALYZING,
                        progressPercent = 28,
                        statusMessage = msg
                    )
                )
            }

            val analysis = analysisResult.getOrElse {
                onProgress(
                    GenerationProgress(
                        step = GenerationStep.FAILED,
                        progressPercent = 0,
                        statusMessage = "Audio analysis failed: ${it.localizedMessage}"
                    )
                )
                return@withContext Result.failure(it)
            }

            // Compute total frames needed (with 1.5s natural decay tail for musicality)
            val vocalFrames = analysis.pcmStereoSamples.size / VocalAnalysisEngine.TARGET_CHANNELS
            val durationFrames = (analysis.durationMs * VocalAnalysisEngine.TARGET_SAMPLE_RATE / 1000L).toInt()
            val decayTailFrames = (VocalAnalysisEngine.TARGET_SAMPLE_RATE * 1.5).toInt()
            val totalFrames = maxOf(vocalFrames, durationFrames) + decayTailFrames

            // Harmonic diatonic chord progression based on detected musical key and root frequency
            val chords = ArrangementEngine.buildDiatonicChords(analysis.keyName, analysis.rootFrequencyHz)

            // Step 4: Generate Bass Audio
            onProgress(
                GenerationProgress(
                    step = GenerationStep.GENERATING_BASS,
                    progressPercent = 35,
                    statusMessage = "Generating harmonic bassline stem in ${analysis.keyName} (${analysis.estimatedBpm} BPM)..."
                )
            )
            val bassStem = BassEngine.generateStem(analysis, totalFrames, chords)

            // Step 5: Generate Drum Audio
            onProgress(
                GenerationProgress(
                    step = GenerationStep.GENERATING_DRUMS,
                    progressPercent = 45,
                    statusMessage = "Generating rhythmic drums (kick, snare, hi-hats, and measure fills)..."
                )
            )
            val drumStem = DrumEngine.generateStem(analysis, totalFrames)

            // Step 6: Generate Piano Audio
            onProgress(
                GenerationProgress(
                    step = GenerationStep.GENERATING_PIANO,
                    progressPercent = 55,
                    statusMessage = "Generating piano accompaniment and chord voicings..."
                )
            )
            val pianoStem = PianoEngine.generateStem(analysis, totalFrames, chords)

            // Step 7: Generate Guitar Audio
            onProgress(
                GenerationProgress(
                    step = GenerationStep.GENERATING_GUITAR,
                    progressPercent = 65,
                    statusMessage = "Generating acoustic guitar fingerpicking and rhythm tracks..."
                )
            )
            val guitarStem = GuitarEngine.generateStem(analysis, totalFrames, chords)

            // Step 8: Generate Strings Audio
            onProgress(
                GenerationProgress(
                    step = GenerationStep.GENERATING_STRINGS,
                    progressPercent = 75,
                    statusMessage = "Generating string section harmonies and ambient textures..."
                )
            )
            val stringsStem = StringsTextureEngine.generateStem(analysis, totalFrames, chords)

            // Step 9: Music Arrangement & Alignment
            onProgress(
                GenerationProgress(
                    step = GenerationStep.ARRANGING,
                    progressPercent = 82,
                    statusMessage = "Arranging and aligning all 5 instrumental stems with vocal timeline..."
                )
            )
            val arrangedInstrumental = ArrangementEngine.coordinateStems(
                analysis = analysis,
                bassStem = bassStem,
                drumStem = drumStem,
                pianoStem = pianoStem,
                guitarStem = guitarStem,
                stringsStem = stringsStem,
                totalFrames = totalFrames
            )

            // Step 10: Auto Mixing
            onProgress(
                GenerationProgress(
                    step = GenerationStep.AUTO_MIXING,
                    progressPercent = 88,
                    statusMessage = "Auto-Mixing: Vocal high-pass filter, room reverb, ducking & stem balancing..."
                )
            )
            val mixedPcm = AutoMixingEngine.mix(
                vocalPcm = analysis.pcmStereoSamples,
                instrumental = arrangedInstrumental,
                averageVocalRms = analysis.averageVocalRms
            )

            // Step 11: Mastering
            onProgress(
                GenerationProgress(
                    step = GenerationStep.MASTERING,
                    progressPercent = 94,
                    statusMessage = "Mastering: Integrated loudness normalization, true-peak check & transparent soft limiting..."
                )
            )
            val masteringReport = MasteringEngine.master(mixedPcm)

            // Step 12: Audio Export
            onProgress(
                GenerationProgress(
                    step = GenerationStep.EXPORTING,
                    progressPercent = 98,
                    statusMessage = "Encoding verified 16-bit 44.1 kHz Stereo lossless WAV file..."
                )
            )
            val finalOutputFile = File(outputDir, "MelodyStudio_Master_${System.currentTimeMillis()}.wav")
            val exportResult = AudioExportEngine.exportMasterWav(finalOutputFile, masteringReport.masteredPcm)

            val finalFile = exportResult.getOrElse {
                onProgress(
                    GenerationProgress(
                        step = GenerationStep.FAILED,
                        progressPercent = 0,
                        statusMessage = "WAV export failed: ${it.localizedMessage}"
                    )
                )
                return@withContext Result.failure(it)
            }

            val finalDurationMs = (masteringReport.masteredPcm.size.toLong() * 1000L) /
                    (VocalAnalysisEngine.TARGET_SAMPLE_RATE * VocalAnalysisEngine.TARGET_CHANNELS)

            // Step 13: Success
            onProgress(
                GenerationProgress(
                    step = GenerationStep.SUCCESS,
                    progressPercent = 100,
                    statusMessage = "Song successfully generated and mastered to lossless WAV (${analysis.estimatedBpm} BPM, ${analysis.keyName})."
                )
            )

            Result.success(
                OrchestrationResult(
                    masterWavFile = finalFile,
                    durationMs = finalDurationMs,
                    bpm = analysis.estimatedBpm,
                    keyName = analysis.keyName,
                    isRealAiGenerated = false,
                    generationSource = "Melody Studio Local Offline Audio Engine",
                    masteringReport = masteringReport
                )
            )

        } catch (e: Exception) {
            Log.e(TAG, "Pipeline failed", e)
            onProgress(
                GenerationProgress(
                    step = GenerationStep.FAILED,
                    progressPercent = 0,
                    statusMessage = "Pipeline failed: ${e.localizedMessage}"
                )
            )
            Result.failure(e)
        }
    }
}
