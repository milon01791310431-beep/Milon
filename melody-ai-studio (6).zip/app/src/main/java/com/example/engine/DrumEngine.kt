package com.example.engine

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.sin
import kotlin.random.Random

/**
 * ENGINE 3: Local Drum Engine (Acoustic Drum & Percussion Synthesis)
 *
 * Implements physical acoustic percussion synthesis:
 * - Kick: 135 Hz -> 46 Hz exponential pitch sweep with punchy beater transient
 * - Snare: Tuned 185 Hz / 280 Hz head resonance combined with snappy wire noise
 * - Hi-Hat: Inharmonic metallic cluster frequencies with crisp stereo shimmer
 * - Fills & Crash: Dynamic tom rolls and crash cymbals at phrase transitions
 *
 * Note: High-fidelity physical modeling, not remote generative AI.
 */
object DrumEngine {
    private const val SAMPLE_RATE = VocalAnalysisEngine.TARGET_SAMPLE_RATE
    private const val CHANNELS = VocalAnalysisEngine.TARGET_CHANNELS

    fun generateStem(
        analysis: VocalAnalysis,
        totalFrames: Int,
        aiStemPcm: ShortArray? = null
    ): StemData {
        if (aiStemPcm != null && aiStemPcm.isNotEmpty()) {
            return StemData.createFromPcm("Drums", aiStemPcm, totalFrames)
        }

        val pcm = ShortArray(totalFrames * CHANNELS)
        val bpm = analysis.estimatedBpm.toDouble()
        val beatSec = 60.0 / bpm
        val framesPerBeat = (beatSec * SAMPLE_RATE).toInt().coerceAtLeast(1)
        val random = Random(1337)

        for (frame in 0 until totalFrames) {
            val beatIndex = frame / framesPerBeat
            val beatFrac = (frame % framesPerBeat).toDouble() / framesPerBeat
            val measureIndex = beatIndex / 4
            val beatInMeasure = beatIndex % 4
            val timeInBeat = beatFrac * beatSec

            // Tom fill on measure 7 (last measure of 8-bar block) on beats 2 & 3
            val isFillBar = (measureIndex % 8 == 7) && (beatInMeasure >= 2)
            // Crash cymbal on downbeat of every 8-bar chorus
            val isCrashDownbeat = (measureIndex % 8 == 0) && (beatInMeasure == 0)

            var left = 0.0
            var right = 0.0

            if (isFillBar) {
                val sixteenthFrac = (beatFrac * 4.0) % 1.0
                val fillEnv = exp(-sixteenthFrac * 10.0)
                val tomPitch = 130.0 - (beatInMeasure * 20.0)
                val tomSound = (
                    sin(2.0 * PI * tomPitch * sixteenthFrac * (beatSec / 4.0)) * 0.45 +
                    (random.nextDouble() - 0.5) * 0.15
                ) * fillEnv
                val pan = 0.25 + (beatInMeasure * 0.20)
                left += tomSound * (1.0 - pan)
                right += tomSound * pan
            } else {
                // 1. Kick Drum (Beats 0 & 2)
                if (beatInMeasure == 0 || beatInMeasure == 2) {
                    val kickEnv = exp(-timeInBeat * 14.0)
                    val kickPitch = 46.0 + 89.0 * exp(-timeInBeat * 38.0)
                    val beaterClick = (random.nextDouble() - 0.5) * exp(-timeInBeat * 180.0) * 0.20
                    val kickBody = sin(2.0 * PI * kickPitch * timeInBeat) * kickEnv * 0.58
                    val kick = kickBody + beaterClick
                    left += kick
                    right += kick
                }

                // 2. Snare Drum (Backbeats 1 & 3)
                if (beatInMeasure == 1 || beatInMeasure == 3) {
                    val snareEnv = exp(-timeInBeat * 9.5)
                    val toneA = sin(2.0 * PI * 185.0 * timeInBeat) * 0.22
                    val toneB = sin(2.0 * PI * 280.0 * timeInBeat) * 0.14
                    val wireNoise = (random.nextDouble() - 0.5) * 0.38
                    val snare = (toneA + toneB + wireNoise) * snareEnv
                    left += snare * 0.95
                    right += snare * 1.05
                }

                // 3. Hi-Hat (8th notes with natural velocity swing)
                val eighthFrac = (beatFrac * 2.0) % 1.0
                val isOffbeat = beatFrac >= 0.5
                val hatTime = eighthFrac * (beatSec / 2.0)
                val hatEnv = exp(-hatTime * if (isOffbeat) 26.0 else 36.0)

                // Inharmonic metallic square/cluster frequencies
                val metalA = sin(2.0 * PI * 3240.0 * hatTime) * 0.12
                val metalB = sin(2.0 * PI * 5420.0 * hatTime) * 0.10
                val metalC = sin(2.0 * PI * 7850.0 * hatTime) * 0.08
                val noise = (random.nextDouble() - 0.5) * 0.16
                val hatLevel = if (isOffbeat) 0.85 else 0.65
                val hatSound = (metalA + metalB + metalC + noise) * hatEnv * hatLevel

                left += hatSound * 0.75
                right += hatSound * 1.25

                // 4. Crash Cymbal on section transitions
                if (isCrashDownbeat && timeInBeat < 1.8) {
                    val crashEnv = exp(-timeInBeat * 2.2)
                    val crashNoise = (random.nextDouble() - 0.5) * 0.25 * crashEnv
                    left += crashNoise * 1.1
                    right += crashNoise * 0.9
                }
            }

            // Analog mix saturation
            val satL = (left / (1.0 + abs(left) * 0.25)) * 26000.0
            val satR = (right / (1.0 + abs(right) * 0.25)) * 26000.0

            pcm[frame * CHANNELS] = satL.coerceIn(-32767.0, 32767.0).toInt().toShort()
            pcm[frame * CHANNELS + 1] = satR.coerceIn(-32767.0, 32767.0).toInt().toShort()
        }

        return StemData.createFromPcm("Drums", pcm, totalFrames)
    }
}
