package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Studio Dark Theme Colors - Premium Purple and Blue Accents
val StudioBackground = Color(0xFF0C0814)
val StudioSurface = Color(0xFF160F24)
val StudioSurfaceVariant = Color(0xFF221638)
val StudioCardBorder = Color(0xFF3B2A5E)

val StudioPurple = Color(0xFFA855F7)
val StudioPurpleDark = Color(0xFF7E22CE)
val StudioPurpleLight = Color(0xFFC084FC)

val StudioCyan = Color(0xFF06B6D4)
val StudioCyanLight = Color(0xFF67E8F9)
val StudioCyanDark = Color(0xFF0891B2)

val StudioBlue = Color(0xFF3B82F6)
val StudioBlueLight = Color(0xFF60A5FA)

val StudioPink = Color(0xFFEC4899)
val StudioGreen = Color(0xFF10B981)
val StudioAmber = Color(0xFFF59E0B)
val StudioRed = Color(0xFFEF4444)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

val MixerTrackTrackBg = Color(0xFF120B1F)
val MixerFaderThumb = Color(0xFF06B6D4)
