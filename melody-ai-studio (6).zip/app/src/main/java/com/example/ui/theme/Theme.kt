package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val StudioColorScheme = darkColorScheme(
    primary = StudioPurple,
    onPrimary = TextPrimary,
    primaryContainer = StudioPurpleDark,
    onPrimaryContainer = StudioPurpleLight,

    secondary = StudioCyan,
    onSecondary = StudioBackground,
    secondaryContainer = StudioCyanDark,
    onSecondaryContainer = StudioCyanLight,

    tertiary = StudioBlue,
    onTertiary = TextPrimary,
    tertiaryContainer = StudioPurpleDark,
    onTertiaryContainer = StudioBlueLight,

    background = StudioBackground,
    onBackground = TextPrimary,

    surface = StudioSurface,
    onSurface = TextPrimary,
    surfaceVariant = StudioSurfaceVariant,
    onSurfaceVariant = TextSecondary,

    outline = StudioCardBorder,
    error = StudioRed,
    onError = TextPrimary
)

@Composable
fun MelodyAiStudioTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = StudioColorScheme,
        typography = Typography,
        content = content
    )
}
