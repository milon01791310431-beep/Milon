package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import android.media.MediaPlayer
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.engine.AudioExportEngine
import com.example.engine.GenerationProgress
import com.example.engine.GenerationStep
import com.example.engine.StudioOrchestrator
import com.example.engine.VocalAnalysisEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

data class PlayerState(
    val isPlaying: Boolean = false,
    val currentPositionMs: Long = 0L,
    val durationMs: Long = 0L
)

data class UploadedAudioInfo(
    val file: File,
    val fileName: String,
    val fileSizeBytes: Long,
    val durationMs: Long
)

data class ExportedAudioInfo(
    val file: File,
    val fileName: String,
    val fileSizeBytes: Long,
    val durationMs: Long,
    val bpm: Int,
    val keyName: String
)

class StudioViewModel(application: Application) : AndroidViewModel(application) {
    private val TAG = "StudioViewModel"
    private val context = application.applicationContext

    // 1. Uploaded Audio State
    private val _uploadedAudio = MutableStateFlow<UploadedAudioInfo?>(null)
    val uploadedAudio: StateFlow<UploadedAudioInfo?> = _uploadedAudio.asStateFlow()

    // Uploaded audio preview player
    private val _uploadPlayerState = MutableStateFlow(PlayerState())
    val uploadPlayerState: StateFlow<PlayerState> = _uploadPlayerState.asStateFlow()
    private var uploadMediaPlayer: MediaPlayer? = null
    private var uploadTickerJob: Job? = null

    // 2. Processing State (Offline Accompaniment Pipeline)
    private val _isProcessing = MutableStateFlow(false)
    val isProcessing: StateFlow<Boolean> = _isProcessing.asStateFlow()

    private val _generationProgress = MutableStateFlow<GenerationProgress?>(null)
    val generationProgress: StateFlow<GenerationProgress?> = _generationProgress.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    private val _saveNotification = MutableStateFlow<String?>(null)
    val saveNotification: StateFlow<String?> = _saveNotification.asStateFlow()

    // 3. Final Exported Audio (Shown strictly after successful export)
    private val _exportedAudio = MutableStateFlow<ExportedAudioInfo?>(null)
    val exportedAudio: StateFlow<ExportedAudioInfo?> = _exportedAudio.asStateFlow()

    // 4. Final Audio Player State
    private val _finalPlayerState = MutableStateFlow(PlayerState())
    val finalPlayerState: StateFlow<PlayerState> = _finalPlayerState.asStateFlow()

    private var finalMediaPlayer: MediaPlayer? = null
    private var finalTickerJob: Job? = null

    fun clearError() {
        _errorMessage.value = null
    }

    fun clearSaveNotification() {
        _saveNotification.value = null
    }

    /**
     * Upload Audio Action: Validates and saves audio file locally.
     */
    fun onAudioSelected(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                _errorMessage.value = null
                stopAllPlayback()

                var fileName = "vocal_${System.currentTimeMillis()}.mp3"
                context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                    val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (cursor.moveToFirst() && nameIdx >= 0) {
                        fileName = cursor.getString(nameIdx) ?: fileName
                    }
                }

                val audioDir = File(context.cacheDir, "studio_uploads").apply { mkdirs() }
                val targetFile = File(audioDir, "vocal_${System.currentTimeMillis()}_$fileName")

                context.contentResolver.openInputStream(uri)?.use { input ->
                    FileOutputStream(targetFile).use { output ->
                        input.copyTo(output)
                    }
                }

                val validationError = VocalAnalysisEngine.validateAudioFile(targetFile)
                if (validationError != null) {
                    targetFile.delete()
                    withContext(Dispatchers.Main) {
                        _errorMessage.value = validationError
                    }
                    return@launch
                }

                var durationMs = 0L
                try {
                    val mp = MediaPlayer().apply {
                        setDataSource(targetFile.absolutePath)
                        prepare()
                    }
                    durationMs = mp.duration.toLong()
                    mp.release()
                } catch (_: Exception) {}

                if (durationMs > 180_000L) {
                    targetFile.delete()
                    withContext(Dispatchers.Main) {
                        _errorMessage.value = "Audio file duration (${durationMs / 1000}s) exceeds the 3-minute limit. Melody AI Studio supports audio up to 180 seconds for stable memory on 4 GB RAM devices. Please trim to under 3 minutes."
                    }
                    return@launch
                }

                val info = UploadedAudioInfo(
                    file = targetFile,
                    fileName = fileName,
                    fileSizeBytes = targetFile.length(),
                    durationMs = durationMs
                )

                withContext(Dispatchers.Main) {
                    _uploadedAudio.value = info
                    _uploadPlayerState.value = PlayerState(durationMs = durationMs)
                    // Reset previous exports when fresh audio is uploaded
                    _exportedAudio.value = null
                    _finalPlayerState.value = PlayerState()
                }
            } catch (e: Exception) {
                Log.e(TAG, "Audio upload error", e)
                withContext(Dispatchers.Main) {
                    _errorMessage.value = "Failed to upload audio: ${e.localizedMessage}"
                }
            }
        }
    }

    /**
     * Generate Music Action: Executes the full 100% offline accompaniment pipeline.
     */
    fun generateMusic() {
        val upload = _uploadedAudio.value ?: run {
            _errorMessage.value = "Please upload an audio file first."
            return
        }

        viewModelScope.launch {
            _isProcessing.value = true
            _errorMessage.value = null
            _generationProgress.value = GenerationProgress(
                step = GenerationStep.VALIDATING,
                progressPercent = 5,
                statusMessage = "Starting offline generation pipeline...",
                isRealAi = false
            )
            stopAllPlayback()

            val outputDir = File(context.cacheDir, "engine_masters").apply { mkdirs() }

            val result = StudioOrchestrator.executePipeline(
                context = context,
                vocalFile = upload.file,
                outputDir = outputDir
            ) { progress ->
                _generationProgress.value = progress
            }

            _isProcessing.value = false

            result.onSuccess { orchestration ->
                val exportedInfo = ExportedAudioInfo(
                    file = orchestration.masterWavFile,
                    fileName = orchestration.masterWavFile.name,
                    fileSizeBytes = orchestration.masterWavFile.length(),
                    durationMs = orchestration.durationMs,
                    bpm = orchestration.bpm,
                    keyName = orchestration.keyName
                )
                _exportedAudio.value = exportedInfo
                _finalPlayerState.value = PlayerState(durationMs = orchestration.durationMs)
            }.onFailure { error ->
                _errorMessage.value = error.localizedMessage ?: "Generation failed."
            }
        }
    }

    // --- Upload Audio Preview Controls ---
    fun togglePlayUploadAudio() {
        val info = _uploadedAudio.value ?: return
        if (_uploadPlayerState.value.isPlaying) {
            pauseUploadAudio()
        } else {
            playUploadAudio(info.file)
        }
    }

    private fun playUploadAudio(file: File) {
        try {
            stopFinalAudio()
            if (uploadMediaPlayer == null) {
                uploadMediaPlayer = MediaPlayer().apply {
                    setDataSource(file.absolutePath)
                    prepare()
                    setOnCompletionListener {
                        _uploadPlayerState.value = _uploadPlayerState.value.copy(isPlaying = false, currentPositionMs = 0L)
                        stopUploadTicker()
                    }
                }
            }
            uploadMediaPlayer?.start()
            val dur = uploadMediaPlayer?.duration?.toLong() ?: 0L
            _uploadPlayerState.value = _uploadPlayerState.value.copy(isPlaying = true, durationMs = dur)
            startUploadTicker()
        } catch (e: Exception) {
            Log.e(TAG, "Error playing vocal preview", e)
        }
    }

    fun pauseUploadAudio() {
        try {
            uploadMediaPlayer?.pause()
            _uploadPlayerState.value = _uploadPlayerState.value.copy(isPlaying = false)
            stopUploadTicker()
        } catch (e: Exception) {
            Log.e(TAG, "Error pausing upload audio", e)
        }
    }

    private fun startUploadTicker() {
        uploadTickerJob?.cancel()
        uploadTickerJob = viewModelScope.launch {
            while (isActive) {
                val pos = uploadMediaPlayer?.currentPosition?.toLong() ?: 0L
                _uploadPlayerState.value = _uploadPlayerState.value.copy(currentPositionMs = pos)
                delay(100)
            }
        }
    }

    private fun stopUploadTicker() {
        uploadTickerJob?.cancel()
        uploadTickerJob = null
    }

    // --- Final Audio Player Controls ---
    fun togglePlayFinalAudio() {
        val info = _exportedAudio.value ?: return
        if (_finalPlayerState.value.isPlaying) {
            pauseFinalAudio()
        } else {
            playFinalAudio(info.file)
        }
    }

    private fun playFinalAudio(file: File) {
        try {
            stopUploadAudio()
            if (finalMediaPlayer == null) {
                finalMediaPlayer = MediaPlayer().apply {
                    setDataSource(file.absolutePath)
                    prepare()
                    setOnCompletionListener {
                        _finalPlayerState.value = _finalPlayerState.value.copy(isPlaying = false, currentPositionMs = 0L)
                        stopFinalTicker()
                    }
                }
            }
            finalMediaPlayer?.start()
            val dur = finalMediaPlayer?.duration?.toLong() ?: 0L
            _finalPlayerState.value = _finalPlayerState.value.copy(
                isPlaying = true,
                durationMs = dur
            )
            startFinalTicker()
        } catch (e: Exception) {
            Log.e(TAG, "Error playing final master audio", e)
        }
    }

    fun pauseFinalAudio() {
        try {
            finalMediaPlayer?.pause()
            _finalPlayerState.value = _finalPlayerState.value.copy(isPlaying = false)
            stopFinalTicker()
        } catch (e: Exception) {
            Log.e(TAG, "Error pausing audio", e)
        }
    }

    fun seekFinalAudio(posMs: Long) {
        try {
            finalMediaPlayer?.seekTo(posMs.toInt())
            _finalPlayerState.value = _finalPlayerState.value.copy(currentPositionMs = posMs)
        } catch (e: Exception) {
            Log.e(TAG, "Error seeking final audio", e)
        }
    }

    // --- Download Audio Action ---
    fun downloadFinalAudio() {
        val info = _exportedAudio.value ?: return
        viewModelScope.launch {
            val result = AudioExportEngine.saveWavToDeviceStorage(context, info.file)
            result.onSuccess { relativePath ->
                _saveNotification.value = "Saved successfully to device ($relativePath)"
            }.onFailure { error ->
                Log.e(TAG, "MediaStore save failed, opening share chooser", error)
                _saveNotification.value = "Saved to storage failed (${error.localizedMessage}). Sharing file..."
                AudioExportEngine.shareMasterAudio(context, info.file)
            }
        }
    }

    fun shareFinalAudio() {
        val info = _exportedAudio.value ?: return
        AudioExportEngine.shareMasterAudio(context, info.file)
    }

    private fun startFinalTicker() {
        finalTickerJob?.cancel()
        finalTickerJob = viewModelScope.launch {
            while (isActive) {
                val pos = finalMediaPlayer?.currentPosition?.toLong() ?: 0L
                _finalPlayerState.value = _finalPlayerState.value.copy(currentPositionMs = pos)
                delay(100)
            }
        }
    }

    private fun stopFinalTicker() {
        finalTickerJob?.cancel()
        finalTickerJob = null
    }

    fun stopUploadAudio() {
        stopUploadTicker()
        try {
            uploadMediaPlayer?.stop()
            uploadMediaPlayer?.release()
        } catch (_: Exception) {}
        uploadMediaPlayer = null
        _uploadPlayerState.value = _uploadPlayerState.value.copy(isPlaying = false)
    }

    fun stopFinalAudio() {
        stopFinalTicker()
        try {
            finalMediaPlayer?.stop()
            finalMediaPlayer?.release()
        } catch (_: Exception) {}
        finalMediaPlayer = null
        _finalPlayerState.value = _finalPlayerState.value.copy(isPlaying = false)
    }

    fun stopAllPlayback() {
        stopUploadAudio()
        stopFinalAudio()
    }

    override fun onCleared() {
        super.onCleared()
        stopAllPlayback()
    }
}
