package com.example.ui.localization

enum class AppLanguage(val code: String, val displayName: String, val nativeName: String) {
    ENGLISH("en", "English", "English"),
    BENGALI("bn", "Bengali", "বাংলা")
}

object StudioStrings {
    fun appTitle(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Melody AI Studio"
        AppLanguage.BENGALI -> "মেলোডি এআই স্টুডিও"
    }

    fun appSubtitle(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Mobile AI Vocal & Instrumental Studio"
        AppLanguage.BENGALI -> "মোবাইল এআই ভোকাল ও মিউজিক স্টুডিও"
    }

    fun tabVocal(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "1. Vocal"
        AppLanguage.BENGALI -> "১. ভোকাল"
    }

    fun tabSettings(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "2. Settings"
        AppLanguage.BENGALI -> "২. সেটিংস"
    }

    fun tabGenerate(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "3. Generate"
        AppLanguage.BENGALI -> "৩. মিউজিক"
    }

    fun tabMixer(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "4. Mixer"
        AppLanguage.BENGALI -> "৪. মিক্সার"
    }

    fun tabExport(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "5. Export"
        AppLanguage.BENGALI -> "৫. এক্সপোর্ট"
    }

    // Vocal Upload
    fun vocalHeader(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Vocal Track Upload"
        AppLanguage.BENGALI -> "ভোকাল ট্র্যাক আপলোড"
    }

    fun vocalDesc(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Upload an MP3 or WAV vocal recording or record directly from your microphone."
        AppLanguage.BENGALI -> "আপনার ভয়েস রেকর্ডিং (MP3 বা WAV) আপলোড করুন অথবা সরাসরি রেকর্ড করুন।"
    }

    fun uploadButton(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Choose Audio File (MP3 / WAV)"
        AppLanguage.BENGALI -> "অডিও ফাইল বাছাই করুন (MP3 / WAV)"
    }

    fun recordButton(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Record Live Vocal"
        AppLanguage.BENGALI -> "ভোকাল রেকর্ড করুন"
    }

    fun stopRecordButton(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Stop Recording"
        AppLanguage.BENGALI -> "রেকর্ডিং থামান"
    }

    fun noVocalSelected(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "No vocal audio selected yet"
        AppLanguage.BENGALI -> "এখনও কোনো ভোকাল অডিও নির্বাচন করা হয়নি"
    }

    fun previewVocal(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Vocal Preview"
        AppLanguage.BENGALI -> "ভোকাল প্রিভিউ"
    }

    fun duration(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Duration"
        AppLanguage.BENGALI -> "সময়কাল"
    }

    fun fileSize(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Size"
        AppLanguage.BENGALI -> "ফাইলের সাইজ"
    }

    // Music Settings
    fun settingsHeader(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Music Composition Settings"
        AppLanguage.BENGALI -> "মিউজিক কম্পোজিশন সেটিংস"
    }

    fun styleLabel(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Music Style / Genre"
        AppLanguage.BENGALI -> "মিউজিক স্টাইল বা ঘরানা"
    }

    fun moodLabel(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Mood"
        AppLanguage.BENGALI -> "মুড বা অনুভূতি"
    }

    fun instrumentsLabel(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Instruments (Select Multiple)"
        AppLanguage.BENGALI -> "বাদ্যযন্ত্র (একাধিক নির্বাচন করুন)"
    }

    fun tempoLabel(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Tempo / BPM"
        AppLanguage.BENGALI -> "টেম্পো / লয় (BPM)"
    }

    fun promptLabel(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Music Description / Prompt"
        AppLanguage.BENGALI -> "মিউজিকের বিবরণ / প্রম্পট"
    }

    fun promptPlaceholder(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "e.g., A rainy evening Bengali acoustic song with soft acoustic guitar and soothing piano..."
        AppLanguage.BENGALI -> "যেমন: বৃষ্টির সন্ধ্যার একটি আবেগঘন বাংলা অ্যাকোস্টিক গান, নরম গিটার ও পিয়ানোর সুর..."
    }

    // AI Generation
    fun generateHeader(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "AI Music Generation"
        AppLanguage.BENGALI -> "এআই মিউজিক জেনারেশন"
    }

    fun providerSelectLabel(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Generation Engine"
        AppLanguage.BENGALI -> "জেনারেশন ইঞ্জিন"
    }

    fun generateAction(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Generate Instrumental Track"
        AppLanguage.BENGALI -> "ইন্সট্রুমেন্টাল মিউজিক তৈরি করুন"
    }

    fun generatingStatus(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Composing instrumental arrangement..."
        AppLanguage.BENGALI -> "ইন্সট্রুমেন্টাল মিউজিক তৈরি হচ্ছে..."
    }

    fun providerOfflineNote(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Built-in Studio Engine: Generates authentic 16-bit acoustic PCM audio on-device. No server or API key required."
        AppLanguage.BENGALI -> "বিল্ট-ইন স্টুডিও ইঞ্জিন: ডিভাইসেই আসল ১৬-বিট অডিও তৈরি করে। কোনো সার্ভার বা এপিআই কি প্রয়োজন নেই।"
    }

    fun cloudProviderNotConfigured(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Real AI Cloud Music provider is not yet connected. Click 'Configure Cloud API' to set up Suno/MusicGen credentials, or use the Built-in Studio Engine."
        AppLanguage.BENGALI -> "রিয়েল এআই ক্লাউড মিউজিক প্রোভাইডার এখনও সংযুক্ত নেই। Suno/MusicGen কনফিগার করতে 'এপিআই সেটআপ' চাপুন অথবা বিল্ট-ইন স্টুডিও ব্যবহার করুন।"
    }

    // Mixer
    fun mixerHeader(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Vocal & Instrumental Mixer"
        AppLanguage.BENGALI -> "ভোকাল ও মিউজিক মিক্সার"
    }

    fun vocalVolume(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Vocal Level"
        AppLanguage.BENGALI -> "ভোকাল ভলিউম"
    }

    fun instrumentalVolume(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Instrumental Level"
        AppLanguage.BENGALI -> "মিউজিক ভলিউম"
    }

    fun masterVolume(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Master Output"
        AppLanguage.BENGALI -> "মাস্টার ভলিউম"
    }

    fun fadeIn(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Fade In (seconds)"
        AppLanguage.BENGALI -> "ফেড ইন (সেকেন্ড)"
    }

    fun fadeOut(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Fade Out (seconds)"
        AppLanguage.BENGALI -> "ফেড আউট (সেকেন্ড)"
    }

    fun playAll(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Play Mix"
        AppLanguage.BENGALI -> "মিক্স চালান"
    }

    fun pauseAll(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Pause Mix"
        AppLanguage.BENGALI -> "থামান"
    }

    // Export
    fun exportHeader(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Export Studio Master (WAV)"
        AppLanguage.BENGALI -> "স্টুডিও মাস্টার এক্সপোর্ট (WAV)"
    }

    fun exportAction(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Render & Save Master WAV"
        AppLanguage.BENGALI -> "রেন্ডার ও সেভ করুন (WAV)"
    }

    fun shareAction(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Share Mixed Song"
        AppLanguage.BENGALI -> "মিক্স করা গান শেয়ার করুন"
    }

    fun exportFormatNote(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Export format: Uncompressed 16-bit 44.1 kHz Stereo WAV. Provides true lossless studio dynamic range without lossy MP3 compression artifacts."
        AppLanguage.BENGALI -> "এক্সপোর্ট ফরম্যাট: আনকম্প্রেসড ১৬-বিট ৪৪.১ কিলোহার্টজ স্টিরিও WAV। কোনো লসি MP3 কম্প্রেশন ছাড়াই সম্পূর্ণ স্টুডিও কোয়ালিটি দেয়।"
    }

    fun saveProject(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Save Project"
        AppLanguage.BENGALI -> "প্রজেক্ট সেভ করুন"
    }

    fun projectsHistory(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Saved Projects"
        AppLanguage.BENGALI -> "সংরক্ষিত প্রজেক্টসমূহ"
    }

    fun loadProject(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Load Mix"
        AppLanguage.BENGALI -> "লোড করুন"
    }

    fun deleteProject(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Delete"
        AppLanguage.BENGALI -> "মুছে ফেলুন"
    }

    fun configApiTitle(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "AI Music Provider Setup"
        AppLanguage.BENGALI -> "এআই মিউজিক এপিআই সেটআপ"
    }
}
