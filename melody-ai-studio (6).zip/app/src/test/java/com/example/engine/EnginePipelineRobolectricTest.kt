package com.example.engine

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File
import java.io.RandomAccessFile

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class EnginePipelineRobolectricTest {

    private fun getContext(): Context = ApplicationProvider.getApplicationContext()

    private fun createSampleAnalysis(durationSec: Int = 2): VocalAnalysis {
        val sampleFrames = VocalAnalysisEngine.TARGET_SAMPLE_RATE * durationSec
        val pcm = ShortArray(sampleFrames * VocalAnalysisEngine.TARGET_CHANNELS) { (it % 1000).toShort() }
        return VocalAnalysis(
            fileName = "vocal_test.wav",
            durationMs = (durationSec * 1000).toLong(),
            fileSizeBytes = (pcm.size * 2).toLong(),
            estimatedBpm = 100,
            bpmConfidence = 0.88f,
            rootFrequencyHz = 220.0,
            keyName = "A minor",
            keyConfidence = 0.92f,
            isConfident = true,
            vocalOnsetMs = 200L,
            phraseBoundariesMs = listOf(1000L),
            averageVocalRms = 2500f,
            peakSample = 8000,
            pcmStereoSamples = pcm
        )
    }

    private fun createValidTestWavFile(file: File, durationSec: Int = 1) {
        val sampleRate = 44100
        val channels = 2
        val totalSamples = sampleRate * durationSec * channels
        val pcm = ShortArray(totalSamples) { (it % 2000).toShort() }
        runBlocking {
            AudioExportEngine.exportMasterWav(file, pcm)
        }
    }

    @Test
    fun testVocalFileValidation() {
        val context = getContext()

        // 1. Missing file
        val missingFile = File(context.cacheDir, "non_existent.mp3")
        assertNotNull(VocalAnalysisEngine.validateAudioFile(missingFile))

        // 2. Empty file
        val emptyFile = File(context.cacheDir, "empty.wav").apply {
            createNewFile()
            deleteOnExit()
        }
        assertNotNull(VocalAnalysisEngine.validateAudioFile(emptyFile))

        // 3. Invalid extension
        val invalidExtFile = File(context.cacheDir, "test.txt").apply {
            writeText("hello world")
            deleteOnExit()
        }
        assertNotNull(VocalAnalysisEngine.validateAudioFile(invalidExtFile))

        // 4. Valid audio file
        val validWavFile = File(context.cacheDir, "sample.wav").apply {
            writeBytes(ByteArray(1024) { 1 })
            deleteOnExit()
        }
        assertNull(VocalAnalysisEngine.validateAudioFile(validWavFile))
    }

    @Test
    fun testWavExportHeaderFormatAndVerification() = runBlocking {
        val context = getContext()
        val outputFile = File(context.cacheDir, "test_exported_master.wav").apply {
            deleteOnExit()
        }

        val samples = ShortArray(VocalAnalysisEngine.TARGET_SAMPLE_RATE * VocalAnalysisEngine.TARGET_CHANNELS) {
            (it % 5000).toShort()
        }

        val result = AudioExportEngine.exportMasterWav(outputFile, samples)
        assertTrue(result.isSuccess)
        val file = result.getOrThrow()
        assertTrue(file.exists())

        // Read and verify 44-byte WAV header
        val raf = RandomAccessFile(file, "r")
        val header = ByteArray(44)
        raf.readFully(header)
        raf.close()

        val riff = String(header, 0, 4)
        val wave = String(header, 8, 4)
        val fmt = String(header, 12, 4)
        val data = String(header, 36, 4)

        assertEquals("RIFF", riff)
        assertEquals("WAVE", wave)
        assertEquals("fmt ", fmt)
        assertEquals("data", data)

        // Audio format should be 1 (PCM)
        val audioFormat = (header[20].toInt() and 0xFF) or ((header[21].toInt() and 0xFF) shl 8)
        assertEquals(1, audioFormat)

        // Channels should be 2 (Stereo)
        val channels = (header[22].toInt() and 0xFF) or ((header[23].toInt() and 0xFF) shl 8)
        assertEquals(2, channels)

        // Sample rate should be 44100
        val sampleRate = (header[24].toInt() and 0xFF) or
                ((header[25].toInt() and 0xFF) shl 8) or
                ((header[26].toInt() and 0xFF) shl 16) or
                ((header[27].toInt() and 0xFF) shl 24)
        assertEquals(44100, sampleRate)
    }

    @Test
    fun testDirectWavDecodingAndResampling() {
        val context = getContext()
        val testFile = File(context.cacheDir, "test_direct_decode.wav").apply { deleteOnExit() }
        createValidTestWavFile(testFile, durationSec = 1)

        val decoded = VocalAnalysisEngine.decodeWavDirect(testFile)
        assertNotNull(decoded)
        assertTrue(decoded!!.isNotEmpty())
        assertEquals(44100 * 2, decoded.size)
    }

    @Test
    fun testMasteringEngineLimitingAndSafety() {
        val loudSamples = ShortArray(2000) { 32500.toShort() }
        val report = MasteringEngine.master(loudSamples)

        assertNotNull(report)
        assertEquals(loudSamples.size, report.masteredPcm.size)
        assertTrue(report.integratedLoudnessDbfs <= 0.0f)

        for (s in report.masteredPcm) {
            assertTrue("Sample $s should be <= 32767", s <= 32767)
            assertTrue("Sample $s should be >= -32768", s >= -32768)
        }
    }

    @Test
    fun testAutoMixingEnginePreservesAudioDimensions() {
        val analysis = createSampleAnalysis(2)
        val totalFrames = VocalAnalysisEngine.TARGET_SAMPLE_RATE * 2
        val accompanimentPcm = ShortArray(totalFrames * VocalAnalysisEngine.TARGET_CHANNELS) { 500 }

        val arranged = ArrangedInstrumental(
            bassStem = StemData.createFromPcm("Bass", ShortArray(0), 0),
            drumStem = StemData.createFromPcm("Drums", ShortArray(0), 0),
            pianoStem = StemData.createFromPcm("Piano", ShortArray(0), 0),
            guitarStem = StemData.createFromPcm("Guitar", ShortArray(0), 0),
            stringsStem = StemData.createFromPcm("Strings", ShortArray(0), 0),
            combinedAccompanimentPcm = accompanimentPcm,
            totalFrames = totalFrames,
            sectionCount = 1
        )

        val mixed = AutoMixingEngine.mix(
            vocalPcm = analysis.pcmStereoSamples,
            instrumental = arranged,
            averageVocalRms = analysis.averageVocalRms
        )

        assertEquals(totalFrames * VocalAnalysisEngine.TARGET_CHANNELS, mixed.size)
    }

    @Test
    fun testAllStemsGenerateValidAudio() {
        val analysis = createSampleAnalysis(1)
        val totalFrames = 44100
        val chords = listOf(listOf(220.0, 261.63, 329.63))

        val bass = BassEngine.generateStem(analysis, totalFrames, chords)
        assertFalse(bass.isSilentOrCorrupt)
        assertEquals(totalFrames * 2, bass.pcmSamples.size)

        val drums = DrumEngine.generateStem(analysis, totalFrames)
        assertFalse(drums.isSilentOrCorrupt)
        assertEquals(totalFrames * 2, drums.pcmSamples.size)

        val piano = PianoEngine.generateStem(analysis, totalFrames, chords)
        assertFalse(piano.isSilentOrCorrupt)
        assertEquals(totalFrames * 2, piano.pcmSamples.size)

        val guitar = GuitarEngine.generateStem(analysis, totalFrames, chords)
        assertFalse(guitar.isSilentOrCorrupt)
        assertEquals(totalFrames * 2, guitar.pcmSamples.size)

        val strings = StringsTextureEngine.generateStem(analysis, totalFrames, chords)
        assertFalse(strings.isSilentOrCorrupt)
        assertEquals(totalFrames * 2, strings.pcmSamples.size)
    }

    @Test
    fun testFullOfflinePipelineExecution() = runBlocking {
        val context = getContext()
        val vocalWav = File(context.cacheDir, "sample_vocal_pipeline.wav").apply {
            deleteOnExit()
        }
        createValidTestWavFile(vocalWav, durationSec = 1)

        val outDir = File(context.cacheDir, "offline_test_out").apply { mkdirs() }

        val observedSteps = mutableListOf<GenerationStep>()
        val result = StudioOrchestrator.executePipeline(context, vocalWav, outDir) { progress ->
            observedSteps.add(progress.step)
        }

        assertTrue("Pipeline should succeed offline", result.isSuccess)
        val orchestration = result.getOrThrow()

        assertTrue(orchestration.masterWavFile.exists())
        assertTrue(orchestration.masterWavFile.length() > 44L)
        assertTrue("BPM should be positive and realistic", orchestration.bpm in 60..180)
        assertFalse(orchestration.isRealAiGenerated)
        assertEquals("Melody Studio Local Offline Audio Engine", orchestration.generationSource)

        assertTrue("Should include VALIDATING step", observedSteps.contains(GenerationStep.VALIDATING))
        assertTrue("Should include DECODING step", observedSteps.contains(GenerationStep.DECODING))
        assertTrue("Should include ANALYZING step", observedSteps.contains(GenerationStep.ANALYZING))
        assertTrue("Should include GENERATING_BASS step", observedSteps.contains(GenerationStep.GENERATING_BASS))
        assertTrue("Should include GENERATING_DRUMS step", observedSteps.contains(GenerationStep.GENERATING_DRUMS))
        assertTrue("Should include GENERATING_PIANO step", observedSteps.contains(GenerationStep.GENERATING_PIANO))
        assertTrue("Should include GENERATING_GUITAR step", observedSteps.contains(GenerationStep.GENERATING_GUITAR))
        assertTrue("Should include GENERATING_STRINGS step", observedSteps.contains(GenerationStep.GENERATING_STRINGS))
        assertTrue("Should include ARRANGING step", observedSteps.contains(GenerationStep.ARRANGING))
        assertTrue("Should include AUTO_MIXING step", observedSteps.contains(GenerationStep.AUTO_MIXING))
        assertTrue("Should include MASTERING step", observedSteps.contains(GenerationStep.MASTERING))
        assertTrue("Should include EXPORTING step", observedSteps.contains(GenerationStep.EXPORTING))
        assertTrue("Should include SUCCESS step", observedSteps.contains(GenerationStep.SUCCESS))
    }

    @Test
    fun testDiatonicChordProgression() {
        val majorChords = ArrangementEngine.buildDiatonicChords("C Major", 261.63)
        assertEquals(4, majorChords.size)
        // Each chord should have root, third, fifth
        for (chord in majorChords) {
            assertEquals(3, chord.size)
            assertTrue("Frequencies should be positive", chord.all { it > 100.0 && it < 450.0 })
        }

        val minorChords = ArrangementEngine.buildDiatonicChords("A minor", 220.0)
        assertEquals(4, minorChords.size)
        for (chord in minorChords) {
            assertEquals(3, chord.size)
            assertTrue("Frequencies should be positive", chord.all { it > 100.0 && it < 450.0 })
        }
    }

    @Test
    fun testDeviceStorageDownloadVerification() = runBlocking {
        val context = getContext()
        val masterWav = File(context.cacheDir, "test_download_master.wav").apply { deleteOnExit() }
        createValidTestWavFile(masterWav, durationSec = 1)

        val saveResult = AudioExportEngine.saveWavToDeviceStorage(context, masterWav)
        assertTrue("MediaStore download should succeed", saveResult.isSuccess)
        val path = saveResult.getOrThrow()
        assertTrue("Path should reference Music/MelodyAI", path.contains("Music/MelodyAI"))
    }
}
