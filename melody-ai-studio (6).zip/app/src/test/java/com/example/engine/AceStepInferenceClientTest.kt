package com.example.engine

import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class AceStepInferenceClientTest {

    @Test
    fun testIsConfigured() {
        val configuredClient = InactiveAceStepClient("http://10.0.2.2:8000")
        assertTrue(configuredClient.isConfigured())

        val unconfiguredClient = InactiveAceStepClient("")
        assertFalse(unconfiguredClient.isConfigured())

        val invalidClient = InactiveAceStepClient("ftp://invalid")
        assertFalse(invalidClient.isConfigured())
    }

    @Test
    fun testCheckHealthOffline() = runBlocking {
        val client = InactiveAceStepClient("http://10.0.2.2:8000")
        val health = client.checkHealth()
        assertFalse(health.isOnline)
        assertTrue(health.message.contains("Offline Mode", ignoreCase = true))
    }

    @Test
    fun testSubmitRejectedInOfflineMode() = runBlocking {
        val client = InactiveAceStepClient("http://10.0.2.2:8000")
        val dummyAnalysis = VocalAnalysis(
            fileName = "dummy.wav",
            durationMs = 5000L,
            fileSizeBytes = 1000L,
            sampleRate = 44100,
            channelCount = 2,
            estimatedBpm = 120,
            bpmConfidence = 0.8f,
            rootFrequencyHz = 220.0,
            keyName = "A minor",
            keyConfidence = 0.8f,
            isConfident = true,
            vocalOnsetMs = 0L,
            phraseBoundariesMs = emptyList(),
            averageVocalRms = 1000f,
            peakSample = 5000,
            pcmStereoSamples = ShortArray(44100 * 2)
        )
        val dummyFile = File("dummy.wav")
        val result = client.submitVocalAndGenerate(dummyAnalysis, dummyFile, dummyFile) {}
        assertTrue(result.isFailure)
        assertTrue(result.exceptionOrNull() is UnsupportedOperationException)
    }
}
