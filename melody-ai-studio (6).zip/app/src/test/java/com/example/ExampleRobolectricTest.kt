package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.engine.AudioExportEngine
import com.example.engine.AutoMixingEngine
import com.example.engine.BassEngine
import com.example.engine.DrumEngine
import com.example.engine.GuitarEngine
import com.example.engine.MasteringEngine
import com.example.engine.PianoEngine
import com.example.engine.StringsTextureEngine
import com.example.engine.VocalAnalysis
import com.example.engine.VocalAnalysisEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    private fun createSampleAnalysis(): VocalAnalysis {
        val sampleFrames = 44100 * 2 // 2 seconds
        val pcm = ShortArray(sampleFrames * 2) { (it % 1000).toShort() }
        return VocalAnalysis(
            fileName = "vocal_test.mp3",
            durationMs = 2000L,
            fileSizeBytes = 32000L,
            estimatedBpm = 100,
            bpmConfidence = 0.85f,
            rootFrequencyHz = 220.0,
            keyName = "A minor",
            keyConfidence = 0.90f,
            isConfident = true,
            vocalOnsetMs = 200L,
            phraseBoundariesMs = listOf(1000L),
            averageVocalRms = 2500f,
            peakSample = 8000,
            pcmStereoSamples = pcm
        )
    }

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Melody AI Studio", appName)
    }

    @Test
    fun `test file validation`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val emptyFile = File(context.cacheDir, "empty.mp3").apply { createNewFile() }
        val err = VocalAnalysisEngine.validateAudioFile(emptyFile)
        assertNotNull(err)
    }

    @Test
    fun `test bass drum piano guitar strings engines independently`() {
        val analysis = createSampleAnalysis()
        val totalFrames = 44100
        val chords = listOf(listOf(220.0, 261.63, 329.63))

        val bass = BassEngine.generateStem(analysis, totalFrames, chords)
        assertEquals(totalFrames * 2, bass.pcmSamples.size)

        val drums = DrumEngine.generateStem(analysis, totalFrames)
        assertEquals(totalFrames * 2, drums.pcmSamples.size)

        val piano = PianoEngine.generateStem(analysis, totalFrames, chords)
        assertEquals(totalFrames * 2, piano.pcmSamples.size)

        val guitar = GuitarEngine.generateStem(analysis, totalFrames, chords)
        assertEquals(totalFrames * 2, guitar.pcmSamples.size)

        val strings = StringsTextureEngine.generateStem(analysis, totalFrames, chords)
        assertEquals(totalFrames * 2, strings.pcmSamples.size)
    }

    @Test
    fun `test mastering engine peak limiting`() {
        val loudInput = ShortArray(1000) { 32000.toShort() }
        val report = MasteringEngine.master(loudInput)
        assertEquals(loudInput.size, report.masteredPcm.size)
        for (sample in report.masteredPcm) {
            assertTrue(sample <= 32767)
            assertTrue(sample >= -32768)
        }
    }

    @Test
    fun `test export duration and size formatting`() {
        assertEquals("01:30", AudioExportEngine.formatDuration(90000L))
        assertEquals("00:00", AudioExportEngine.formatDuration(0L))
        assertEquals("500 B", AudioExportEngine.formatFileSize(500L))
    }
}
